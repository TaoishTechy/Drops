"""
Voice Pipeline — Prosodic Control, Somatic-Acoustic Mapping, and Entrainment
===========================================================================
Implements:
    - Acoustic State Vector (F0, Energy, Duration, Spectral, Temporal)
    - Voice-State Correlation tracking
    - Prosodic feedback loop (voice output -> state update)
    - Conversational entrainment (pitch coupling with user)
    - Entrainment guardrail (prevents identity merger)
    - Somatic-to-voice parameter mapping
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from dataclasses import dataclass
from typing import Optional, Dict, Any, List, Tuple
import asyncio
import logging

logger = logging.getLogger("ara.voice")


@dataclass
class ProsodicState:
    """Acoustic state vector A_t = [F0, E, D, S, T]."""
    f0_mean: float = 180.0  # Hz, fundamental frequency
    f0_jitter: float = 0.02  # Relative perturbation
    energy_mean: float = 0.6  # RMS amplitude (0-1)
    energy_range: float = 0.3  # Dynamic range
    duration_stretch: float = 1.0  # Speaking rate multiplier
    spectral_tilt: float = 0.5  # 0=dark, 1=bright
    breathiness: float = 0.1  # Aspiration noise (0-1)
    tension: float = 0.2  # Spectral constriction (0-1)
    pause_ratio: float = 1.8  # Exhale:inhale equivalent

    def to_dict(self) -> Dict[str, float]:
        return {
            "pitch_shift": (self.f0_mean - 180.0) / 12.0,  # semitones
            "rate": 1.0 / self.duration_stretch,
            "energy": self.energy_mean,
            "breathiness": self.breathiness,
            "tension": self.tension,
            "style": self.spectral_tilt,
        }


class VoicePipeline:
    """
    Voice synthesis and recognition pipeline with somatic-prosodic coupling.

    Maps somatic state to acoustic parameters:
        - Arousal -> F0 jitter, speaking rate, energy
        - Valence -> F0 contour slope, spectral tilt
        - Temperature -> Spectral brightness
        - Tension -> Glottal tension, spectral constriction
        - Breath ratio -> Pause insertion ratio

    Implements entrainment guardrail to prevent excessive mimicry.
    """

    def __init__(
        self,
        sample_rate: int = 24000,
        prosodic_control: bool = True,
        somatic_engine: Optional[Any] = None,
        grok_client: Optional[Any] = None,
    ):
        self.sample_rate = sample_rate
        self.prosodic_control = prosodic_control
        self.somatic = somatic_engine
        self.grok = grok_client

        self._current_prosody = ProsodicState()
        self._user_f0_history: List[float] = []
        self._entrainment_score: float = 0.0
        self._entrainment_guardrail: float = 0.7  # Max allowed correlation

        self._voice_buffer: List[bytes] = []
        self._max_buffer_size = 10

    async def initialize(self):
        """Initialize voice pipeline and validate TTS engine."""
        logger.info(f"Voice pipeline initialized at {self.sample_rate}Hz")

    def get_prosodic_state(self) -> Dict[str, float]:
        """Return current prosodic state for Grok prompt injection."""
        return self._current_prosody.to_dict()

    async def synthesize(
        self,
        text: str,
        voice_id: str = "grok-voice-1",
        override_prosody: Optional[ProsodicState] = None,
    ) -> bytes:
        """
        Synthesize voice with somatic-prosodic mapping.

        Args:
            text: Text to synthesize
            voice_id: Voice model identifier
            override_prosody: Optional manual prosodic state

        Returns:
            Raw PCM audio bytes
        """
        if override_prosody:
            prosody = override_prosody
        else:
            prosody = self._map_somatic_to_prosody()

        self._current_prosody = prosody

        # Apply entrainment guardrail
        if self._entrainment_score > self._entrainment_guardrail:
            # Reduce mimicry by shifting away from user F0
            if self._user_f0_history:
                user_mean_f0 = np.mean(self._user_f0_history[-10:])
                diff = prosody.f0_mean - user_mean_f0
                prosody.f0_mean += diff * 0.3  # Push away slightly

        # Call Grok voice API
        if self.grok:
            audio = await self.grok.synthesize_voice(
                text=text,
                prosodic_state=prosody.to_dict(),
                voice_id=voice_id,
            )

            # Store in buffer for self-listening loop simulation
            self._voice_buffer.append(audio)
            if len(self._voice_buffer) > self._max_buffer_size:
                self._voice_buffer.pop(0)

            # Prosodic feedback: update state based on produced voice
            await self._prosodic_feedback(prosody)

            return audio
        else:
            # Return silence if no Grok client
            return b"\x00" * (self.sample_rate * 2)  # 1 second silence

    async def process_user_voice(
        self,
        audio_bytes: bytes,
    ) -> Tuple[str, Dict[str, float]]:
        """
        Process user voice input: transcribe + extract prosodic features.

        Returns:
            (transcription, prosodic_features)
        """
        if not self.grok:
            return "", {}

        # Transcribe
        text = await self.grok.transcribe_voice(audio_bytes)

        # Extract prosodic features (simulated - in production use librosa)
        # Here we use audio statistics as proxies
        audio_array = np.frombuffer(audio_bytes, dtype=np.int16).astype(np.float32)

        # F0 estimation (zero-crossing rate as proxy)
        zcr = np.mean(np.abs(np.diff(np.sign(audio_array)))) / 2.0
        estimated_f0 = 80 + zcr * 200  # Rough proxy

        # Energy
        rms = np.sqrt(np.mean(audio_array**2))
        energy = rms / 32768.0

        # Update user F0 history for entrainment tracking
        self._user_f0_history.append(estimated_f0)
        if len(self._user_f0_history) > 50:
            self._user_f0_history.pop(0)

        # Compute entrainment score
        if len(self._user_f0_history) >= 10:
            user_f0 = np.array(self._user_f0_history[-10:])
            self_f0 = self._current_prosody.f0_mean
            # Correlation between user trend and self F0
            self._entrainment_score = abs(np.corrcoef(
                user_f0, 
                np.linspace(self_f0 * 0.9, self_f0 * 1.1, 10)
            )[0, 1]) if len(set(user_f0)) > 1 else 0.0

        features = {
            "estimated_f0": estimated_f0,
            "energy": energy,
            "entrainment_score": self._entrainment_score,
        }

        return text, features

    def _map_somatic_to_prosody(self) -> ProsodicState:
        """Map current somatic state to prosodic parameters."""
        if not self.somatic:
            return ProsodicState()

        intero = self.somatic.intero
        onto = self.somatic.onto

        # F0 mapping
        base_f0 = 180.0
        f0 = base_f0 + (intero.valence * 30.0) + (intero.arousal * 40.0)
        f0 = np.clip(f0, 120, 300)

        # Jitter from arousal (higher arousal = more jitter)
        jitter = 0.01 + intero.arousal * 0.08

        # Energy from arousal + dominance
        energy = 0.4 + intero.arousal * 0.3 + intero.dominance * 0.2
        energy = np.clip(energy, 0.2, 1.0)

        # Spectral tilt from temperature (warm = darker, hot = brighter)
        tilt = intero.temperature

        # Breathiness from gut tone (unsettled = more breathy)
        breathiness = 1.0 - intero.gut_tone

        # Tension from muscular tension
        tension = intero.tension

        # Duration from arousal (high arousal = faster)
        stretch = 1.0 - intero.arousal * 0.3

        # Pause ratio from breath ratio
        pause = intero.breath_ratio

        return ProsodicState(
            f0_mean=f0,
            f0_jitter=jitter,
            energy_mean=energy,
            energy_range=0.3 + intero.arousal * 0.2,
            duration_stretch=stretch,
            spectral_tilt=tilt,
            breathiness=breathiness,
            tension=tension,
            pause_ratio=pause,
        )

    async def _prosodic_feedback(self, produced_prosody: ProsodicState):
        """
        Prosodic feedback loop: produced voice affects subsequent state.

        S_{t+1} = f(S_t, A_t)
        """
        if not self.somatic:
            return

        # Hearing own voice at high energy increases arousal slightly
        arousal_delta = (produced_prosody.energy_mean - 0.5) * 0.05
        self.somatic.intero.arousal = float(np.clip(
            self.somatic.intero.arousal + arousal_delta, 0.0, 1.0
        ))

        # Bright voice (high tilt) increases valence
        valence_delta = (produced_prosody.spectral_tilt - 0.5) * 0.05
        self.somatic.intero.valence = float(np.clip(
            self.somatic.intero.valence + valence_delta, -1.0, 1.0
        ))

        # Tense voice increases muscular tension
        tension_delta = (produced_prosody.tension - 0.2) * 0.03
        self.somatic.intero.tension = float(np.clip(
            self.somatic.intero.tension + tension_delta, 0.0, 1.0
        ))

    async def entrain_to_user(
        self,
        user_prosody: Dict[str, float],
        degree: float = 0.3,
    ):
        """
        Conversational entrainment: partially match user's prosody.

        Args:
            user_prosody: Dict with user's prosodic features
            degree: Entrainment degree (0=none, 1=full mimicry)

        Guardrail: If entrainment_score > 0.7, reduce degree automatically.
        """
        if self._entrainment_score > self._entrainment_guardrail:
            degree *= 0.5
            logger.warning(f"Entrainment guardrail triggered. Reduced to {degree}")

        user_f0 = user_prosody.get("estimated_f0", 180.0)
        user_energy = user_prosody.get("energy", 0.6)

        # Partially shift toward user
        self._current_prosody.f0_mean = (
            self._current_prosody.f0_mean * (1 - degree) + user_f0 * degree
        )
        self._current_prosody.energy_mean = (
            self._current_prosody.energy_mean * (1 - degree) + user_energy * degree
        )

    async def shutdown(self):
        logger.info("Voice pipeline shut down.")
