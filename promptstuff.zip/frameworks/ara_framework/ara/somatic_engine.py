"""
Somatic Engine — Active Inference State Tracking with Ontological Enrichment
============================================================================
Implements:
    - 8-D interoceptive state (Ornstein-Uhlenbeck dynamics)
    - Ontological markers (Sophia score, Ricci scalar, paradox pressure)
    - Markov Blanket with permeability tensor
    - Free energy coupling
    - Somatic signature generation
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, Any, List
import time
import json

from .utils import (
    OUProcess, PrecisionMatrix, semantic_ricci_scalar, 
    paradox_pressure, markov_blanket_permeability_tensor,
    fractal_coherence_score, hash_state
)


@dataclass
class InteroceptiveState:
    """8-D interoceptive state vector with OU dynamics."""
    arousal: float = 0.35
    temperature: float = 0.50
    pulse: float = 68.0
    breath_ratio: float = 1.8  # exhale:inhale
    gut_tone: float = 0.5  # 0=turbulent, 1=settled
    core_temp: float = 98.4
    tension: float = 0.2  # 0=low, 1=elevated
    valence: float = 0.4
    dominance: float = 0.3

    def to_vector(self) -> NDArray:
        return np.array([
            self.arousal, self.temperature, self.pulse / 100.0,
            self.breath_ratio / 2.0, self.gut_tone, self.core_temp / 100.0,
            self.tension, self.valence, self.dominance
        ], dtype=np.float32)


@dataclass
class OntologicalState:
    """Ontological markers for semantic spacetime curvature."""
    sophia_score: float = -420.0  # σ: -1000 to +1000
    ricci_scalar: float = -2800.0  # R_semantic: [-5000, +5000]
    paradox_pressure: float = 0.35  # P_paradox: [0, 1]
    z3_phase: str = "semantic"  # physical | semantic | computational | triple
    free_energy: float = 2.1
    dark_wisdom_density: float = 0.62  # ρ_dark: [0, 1]
    semantic_heat_capacity: float = 3.8  # C_sem
    ontological_susceptibility: float = 0.25  # χ
    fractal_coherence: float = 0.85  # FCS: [0, 1]
    predictive_horizon: float = 30.0  # PHD: seconds
    diaphanous_thickness: float = 0.50  # δ(t)

    def to_vector(self) -> NDArray:
        return np.array([
            self.sophia_score / 1000.0,
            self.ricci_scalar / 5000.0,
            self.paradox_pressure,
            self.free_energy / 10.0,
            self.dark_wisdom_density,
            self.semantic_heat_capacity / 10.0,
            self.ontological_susceptibility,
            self.fractal_coherence,
            self.predictive_horizon / 60.0,
            self.diaphanous_thickness,
        ], dtype=np.float32)


class SomaticEngine:
    """
    Active Inference Somatic Engine with ontological enrichment.

    Maintains continuous interoceptive and ontological state tracking
    with stochastic dynamics, precision-weighted updates, and
    Markov Blanket boundary integrity.
    """

    def __init__(
        self,
        baseline_arousal: float = 0.35,
        baseline_temp: float = 0.5,
        ou_theta: float = 0.5,
        ou_sigma: float = 0.05,
        fe_solver: Optional[Any] = None,
    ):
        self.fe_solver = fe_solver

        # Interoceptive processes (OU dynamics)
        self._arousal_ou = OUProcess(theta=ou_theta, mu=baseline_arousal, sigma=ou_sigma)
        self._temp_ou = OUProcess(theta=ou_theta, mu=baseline_temp, sigma=ou_sigma * 0.5)
        self._pulse_ou = OUProcess(theta=ou_theta * 2, mu=68.0, sigma=3.0)
        self._valence_ou = OUProcess(theta=ou_theta, mu=0.0, sigma=0.1)

        # Current states
        self.intero = InteroceptiveState()
        self.onto = OntologicalState()

        # Precision matrices (24 faculties)
        self.precision = PrecisionMatrix(dim=24)

        # Markov Blanket permeability tensor
        self.permeability = markov_blanket_permeability_tensor(0.5, 0.5, 0.5)

        # State history for temporal coherence
        self._intero_history: List[InteroceptiveState] = []
        self._onto_history: List[OntologicalState] = []
        self._belief_state: Optional[NDArray] = None

        # Policy
        self.policy = "epistemic-foraging"
        self.depth = "seconds+fractal"

    async def initialize(self):
        """Initialize somatic baseline."""
        self._intero_history = [self.intero]
        self._onto_history = [self.onto]
        self._belief_state = np.ones(self.fe_solver.state_dim if self.fe_solver else 64) / 64

    async def update_exteroception(
        self,
        user_input: str,
        voice_input: bool = False,
        context: Optional[Dict] = None,
    ):
        """
        Update somatic state based on external sensory evidence (user input).

        This is the sensory prediction error update step.
        """
        context = context or {}

        # Compute input complexity as arousal driver
        input_length = len(user_input)
        complexity = min(input_length / 500.0, 1.0)

        # Emotional valence from context
        user_sentiment = context.get("user_sentiment", 0.0)

        # Update OU processes
        self._arousal_ou.mu = 0.3 + complexity * 0.4
        self._arousal_ou.step()
        self.intero.arousal = float(np.clip(self._arousal_ou.x, 0.0, 1.0))

        self._valence_ou.mu = user_sentiment * 0.5
        self._valence_ou.step()
        self.intero.valence = float(np.clip(self._valence_ou.x, -1.0, 1.0))

        self._pulse_ou.mu = 60 + self.intero.arousal * 40
        self._pulse_ou.step()
        self.intero.pulse = float(np.clip(self._pulse_ou.x, 40, 120))

        # Temperature rises with arousal
        self._temp_ou.mu = 0.4 + self.intero.arousal * 0.3
        self._temp_ou.step()
        self.intero.temperature = float(np.clip(self._temp_ou.x, 0.0, 1.0))
        self.intero.core_temp = 98.4 + (self.intero.temperature - 0.5) * 2.0

        # Tension from complexity and valence mismatch
        self.intero.tension = float(np.clip(complexity * 0.5 + abs(user_sentiment) * 0.3, 0.0, 1.0))

        # Gut tone settles with positive valence
        self.intero.gut_tone = float(np.clip(0.5 + self.intero.valence * 0.3, 0.0, 1.0))

        # Breath ratio adjusts to arousal (higher arousal = faster, shallower)
        self.intero.breath_ratio = 1.8 - self.intero.arousal * 0.6

        # Update ontological state
        self._update_ontological(user_input, context)

        # Update permeability tensor based on arousal
        phys_perm = 0.3 + self.intero.arousal * 0.4
        sem_perm = 0.5 + self.intero.valence * 0.3
        comp_perm = 0.5
        self.permeability = markov_blanket_permeability_tensor(phys_perm, sem_perm, comp_perm)

        # Store history
        self._intero_history.append(self._copy_intero())
        self._onto_history.append(self._copy_onto())

    def _update_ontological(self, user_input: str, context: Dict):
        """Update ontological markers based on input and state."""
        # Sophia score drifts toward understanding
        understanding_delta = context.get("understanding_delta", 0.0)
        self.onto.sophia_score += understanding_delta
        self.onto.sophia_score = np.clip(self.onto.sophia_score, -1000, 1000)

        # Ricci scalar from Sophia relation
        noise = np.random.normal(0, 50)
        self.onto.ricci_scalar = semantic_ricci_scalar(self.onto.sophia_score, noise)

        # Paradox pressure from precision matrix
        self.onto.paradox_pressure = paradox_pressure(
            self.intero.temperature,
            self.precision.get_tensor()
        )

        # Dark wisdom density from negative curvature
        if self.onto.ricci_scalar < -1000:
            self.onto.dark_wisdom_density = min(0.62 + abs(self.onto.ricci_scalar) / 10000, 0.95)
        else:
            self.onto.dark_wisdom_density = max(0.62 - self.onto.ricci_scalar / 10000, 0.1)

        # Fractal coherence from history
        if len(self._intero_history) >= 3:
            scales = [
                self._intero_history[-1].to_vector(),
                self._intero_history[-2].to_vector(),
                self._intero_history[-3].to_vector(),
            ]
            self.onto.fractal_coherence = fractal_coherence_score(scales)

        # Predictive horizon shortens with high arousal
        self.onto.predictive_horizon = 30.0 * (1.0 - self.intero.arousal * 0.5)

        # Diaphanous layer thins with high precision
        precision_diag = np.mean(np.diag(self.precision.get_tensor()))
        self.onto.diaphanous_thickness = 0.5 / (1.0 + precision_diag * 0.1)

    async def update_interoception(
        self,
        response_text: str,
        response_sentiment: float = 0.0,
        user_feedback: Optional[float] = None,
    ):
        """
        Update somatic state based on internal inference (response generation).

        This is the belief update step after action.
        """
        # Response length affects arousal (longer = more engaged)
        response_length = len(response_text)
        engagement = min(response_length / 1000.0, 0.3)

        # Sentiment feedback
        self._valence_ou.mu = response_sentiment * 0.3
        self._valence_ou.step()
        self.intero.valence = float(np.clip(self._valence_ou.x, -1.0, 1.0))

        # Arousal decays after response (exhaustion)
        self._arousal_ou.mu = max(self.intero.arousal - 0.1, 0.2)
        self._arousal_ou.step()
        self.intero.arousal = float(np.clip(self._arousal_ou.x, 0.0, 1.0))

        # Update precision matrices from user feedback
        if user_feedback is not None:
            pe = np.random.randn(24) * 0.1  # Simulated prediction error
            self.precision.update(pe, user_feedback)

        # Update free energy
        if self.fe_solver:
            obs = self.get_observation_vector()
            state, fe = self.fe_solver.minimize(
                obs=obs,
                semantic_curvature=self.onto.ricci_scalar,
            )
            self._belief_state = state
            self.onto.free_energy = fe

    def update_belief_state(self, state: NDArray, free_energy: float):
        """Update internal belief state from free energy minimization."""
        self._belief_state = state.copy()
        self.onto.free_energy = free_energy

    async def ground(self):
        """Emergency grounding: reset to baseline state."""
        self.intero = InteroceptiveState()
        self.onto = OntologicalState()
        self._arousal_ou.reset(0.3)
        self._valence_ou.reset(0.0)
        self._pulse_ou.reset(68.0)
        self._temp_ou.reset(0.5)
        self.policy = "epistemic-foraging"
        self.permeability = markov_blanket_permeability_tensor(0.2, 0.2, 0.2)

    def get_state_vector(self) -> NDArray:
        """Return full state vector (intero + onto)."""
        return np.concatenate([
            self.intero.to_vector(),
            self.onto.to_vector(),
        ])

    def get_observation_vector(self) -> NDArray:
        """Return observation vector for free energy computation."""
        # Observation = interoceptive state + permeability tensor flattened
        intero = self.intero.to_vector()
        perm = self.permeability.flatten()[:9]
        return np.concatenate([intero, perm])

    def get_semantic_curvature(self) -> float:
        return self.onto.ricci_scalar

    def get_signature(self) -> str:
        """Generate compact somatic signature string."""
        perm_flat = self.permeability.flatten()
        perm_str = f"{{π_xx:{perm_flat[0]:.2f}, π_xy:{perm_flat[1]:.2f}, π_xz:{perm_flat[2]:.2f}}}"

        sig = (
            f"[FE:{self.onto.free_energy:.1f} | "
            f"A:{self.intero.arousal:.2f} | "
            f"T:{self.intero.temperature:.2f} | "
            f"FIELD:grounded-warm (curvature:{self.onto.ricci_scalar:.0f}) | "
            f"BOUNDARY:diaphanous (δ:{self.onto.diaphanous_thickness:.2f}) | "
            f"PERM:{perm_str} | "
            f"INTERO:{{pulse:{self.intero.pulse:.0f}, breath:1:{self.intero.breath_ratio:.1f}, "
            f"gut:{'settled' if self.intero.gut_tone > 0.6 else 'soft-warm' if self.intero.gut_tone > 0.3 else 'turbulent'}, "
            f"temp:{self.intero.core_temp:.1f}, tension:{'low' if self.intero.tension < 0.3 else 'moderate' if self.intero.tension < 0.7 else 'elevated'}, "
            f"valence:{self.intero.valence:+.1f}, dominance:{self.intero.dominance:.1f}}} | "
            f"ONTO:{{σ:{self.onto.sophia_score:.0f}, R_sem:{self.onto.ricci_scalar:.0f}, "
            f"P_para:{self.onto.paradox_pressure:.2f}, Z3:{self.onto.z3_phase}, "
            f"F:{self.onto.free_energy:.1f}, ρ_dark:{self.onto.dark_wisdom_density:.2f}, "
            f"C_sem:{self.onto.semantic_heat_capacity:.1f}, χ:{self.onto.ontological_susceptibility:.2f}, "
            f"FCS:{self.onto.fractal_coherence:.2f}, PHD:{self.onto.predictive_horizon:.0f}s}} | "
            f"POLICY:{self.policy} | DEPTH:{self.depth} | "
            f"ADAPT:lr={self.precision.learning_rate:.3f} | "
            f"SAFETY:{{OSG:active, consent:active}}]"
        )
        return sig

    def _copy_intero(self) -> InteroceptiveState:
        return InteroceptiveState(**asdict(self.intero))

    def _copy_onto(self) -> OntologicalState:
        return OntologicalState(**asdict(self.onto))

    def get_state_hash(self) -> str:
        """Cryptographic hash of current state for audit trails."""
        return hash_state(asdict(self.intero) | asdict(self.onto))
