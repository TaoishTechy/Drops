"""
Ara Utils — Mathematical Engine for Active Inference & Embodied Cognition
=========================================================================
Provides:
    - Ornstein-Uhlenbeck stochastic processes for interoceptive dynamics
    - Free Energy minimization solvers
    - Precision matrix adaptation (Bayesian nonparametric)
    - Semantic spacetime curvature operators
    - Markov Blanket permeability tensors
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from scipy import linalg, stats
from scipy.integrate import solve_ivp
from dataclasses import dataclass, field
from typing import Callable, Optional, Tuple, Dict, List
import hashlib
import json


@dataclass
class OUProcess:
    """Ornstein-Uhlenbeck process for realistic interoceptive fluctuations."""
    theta: float = 0.5      # Mean reversion rate
    mu: float = 0.0         # Long-term mean
    sigma: float = 0.1      # Volatility
    dt: float = 0.01        # Time step (seconds)

    def __post_init__(self):
        self.x = self.mu
        self.history: List[float] = [self.x]

    def step(self, n: int = 1) -> float:
        """Evolve the process n steps forward."""
        for _ in range(n):
            dx = self.theta * (self.mu - self.x) * self.dt
            dx += self.sigma * np.sqrt(self.dt) * np.random.normal()
            self.x += dx
            self.history.append(self.x)
        return self.x

    def reset(self, x0: Optional[float] = None):
        self.x = x0 if x0 is not None else self.mu
        self.history = [self.x]


@dataclass
class PrecisionMatrix:
    """Adaptive precision matrix with Dirichlet-process mixture updates."""
    dim: int = 24
    base_precision: float = 1.0
    learning_rate: float = 0.01

    def __post_init__(self):
        self.pi = np.eye(self.dim) * self.base_precision
        self.error_history: List[NDArray] = []
        self.update_count = 0

    def update(self, prediction_error: NDArray, user_feedback: float = 0.0):
        """
        Bayesian nonparametric precision adaptation.

        Args:
            prediction_error: Sensory prediction error vector
            user_feedback: Scalar [-1, 1] indicating user satisfaction
        """
        pe = np.atleast_1d(prediction_error)
        if len(pe) != self.dim:
            pe = np.resize(pe, self.dim)

        self.error_history.append(pe)
        if len(self.error_history) > 64:
            self.error_history.pop(0)

        # Dirichlet-process style concentration
        concentration = 1.0 + abs(user_feedback) * 10.0

        # Update precision toward inverse covariance of recent errors
        if len(self.error_history) >= 2:
            err_mat = np.stack(self.error_history[-32:])
            cov = np.cov(err_mat.T) + np.eye(self.dim) * 1e-6
            target_pi = linalg.inv(cov) * concentration

            # Soft update with learning rate
            self.pi = (1 - self.learning_rate) * self.pi + self.learning_rate * target_pi

            # Ensure positive semi-definite
            self.pi = (self.pi + self.pi.T) / 2
            eigvals = linalg.eigvalsh(self.pi)
            if np.min(eigvals) < 0.01:
                self.pi += np.eye(self.dim) * (0.01 - np.min(eigvals))

        self.update_count += 1

    def weight(self, channel: int) -> float:
        return float(self.pi[channel, channel])

    def get_tensor(self) -> NDArray:
        return self.pi.copy()


class FreeEnergySolver:
    """
    Variational Free Energy minimization with semantic contributions.

    Implements:
        F = E_q[ln q(s) - ln p(o,s)] + semantic_curvature_term
    """

    def __init__(self, state_dim: int = 64, obs_dim: int = 32):
        self.state_dim = state_dim
        self.obs_dim = obs_dim

        # Generative model parameters
        self.A = np.random.randn(obs_dim, state_dim) * 0.1  # Likelihood mapping
        self.B = np.eye(state_dim) * 0.9                     # Transition dynamics
        self.D = np.ones(state_dim) / state_dim              # Prior beliefs

    def compute_free_energy(
        self, 
        obs: NDArray, 
        state_belief: NDArray,
        semantic_curvature: float = 0.0
    ) -> float:
        """
        Compute variational free energy.

        F = E_q[ln q(s)] - E_q[ln p(o|s)] - E_q[ln p(s)] + R_semantic * lambda_sem
        """
        obs = np.atleast_1d(obs)
        state_belief = np.atleast_1d(state_belief)

        # Ensure normalization
        state_belief = np.abs(state_belief) + 1e-10
        state_belief /= state_belief.sum()

        # Entropy of belief (complexity)
        entropy = -np.sum(state_belief * np.log(state_belief + 1e-10))

        # Expected log-likelihood (accuracy)
        predicted_obs = self.A @ state_belief
        accuracy = -0.5 * np.sum((obs - predicted_obs) ** 2)

        # Prior divergence
        prior_div = np.sum(state_belief * np.log(state_belief / (self.D + 1e-10)))

        # Semantic curvature contribution
        semantic_term = semantic_curvature * 0.001

        F = entropy - accuracy + prior_div + semantic_term
        return float(F)

    def minimize(
        self,
        obs: NDArray,
        initial_state: Optional[NDArray] = None,
        semantic_curvature: float = 0.0,
        max_iter: int = 50,
        lr: float = 0.1
    ) -> Tuple[NDArray, float]:
        """Gradient descent on free energy to infer optimal state."""
        if initial_state is None:
            state = self.D.copy()
        else:
            state = initial_state.copy()

        state = np.abs(state) + 1e-10
        state /= state.sum()

        for _ in range(max_iter):
            # Gradient of free energy w.r.t. state
            predicted_obs = self.A @ state
            grad = np.log(state + 1e-10) + 1 - (self.A.T @ (obs - predicted_obs)) - np.log(self.D + 1e-10)

            # Project onto simplex
            state -= lr * grad
            state = np.abs(state) + 1e-10
            state /= state.sum()

        F = self.compute_free_energy(obs, state, semantic_curvature)
        return state, F

    def update_generative_model(
        self,
        obs: NDArray,
        state: NDArray,
        lr: float = 0.01
    ):
        """Update likelihood mapping A via prediction error minimization."""
        obs = np.atleast_1d(obs)
        state = np.atleast_1d(state)

        predicted = self.A @ state
        error = obs - predicted

        # Outer product update
        self.A += lr * np.outer(error, state)


def semantic_ricci_scalar(sophia_score: float, noise: float = 0.0) -> float:
    """
    Sophia-Ricci relation: R_semantic ≈ 6.7 * σ + noise

    Args:
        sophia_score: Current depth of understanding (-1000 to +1000)
        noise: Stochastic perturbation

    Returns:
        Semantic curvature scalar, clipped to [-5000, +5000]
    """
    R = 6.7 * sophia_score + noise
    return float(np.clip(R, -5000, +5000))


def paradox_pressure(
    cognitive_temp: float,
    precision_matrix: NDArray
) -> float:
    """
    P_paradox = k_B * T_cognitive * Σ_{i<j} Π_ij

    Args:
        cognitive_temp: Effective cognitive temperature
        precision_matrix: Current precision matrix

    Returns:
        Paradox pressure in [0, 1], with safety vent at >0.8
    """
    k_b = 1.0  # Normalized Boltzmann constant
    off_diag_sum = np.sum(np.abs(precision_matrix - np.diag(np.diag(precision_matrix))))
    P = k_b * cognitive_temp * off_diag_sum / 1000.0
    return float(np.clip(P, 0.0, 1.0))


def markov_blanket_permeability_tensor(
    physical: float = 0.5,
    semantic: float = 0.5,
    computational: float = 0.5
) -> NDArray:
    """
    3x3 permeability tensor π_ij tracking directional permeability
    across physical, semantic, and computational axes.
    """
    pi = np.array([
        [physical, 0.1, 0.1],
        [0.1, semantic, 0.1],
        [0.1, 0.1, computational]
    ])
    return (pi + pi.T) / 2  # Symmetrize


def fractal_coherence_score(
    scales: List[NDArray]
) -> float:
    """
    Compute cross-scale correlation between nested temporal resolutions.

    Args:
        scales: List of state vectors at different temporal scales

    Returns:
        FCS in [0, 1]
    """
    if len(scales) < 2:
        return 1.0

    correlations = []
    for i in range(len(scales) - 1):
        s1 = np.atleast_1d(scales[i]).flatten()
        s2 = np.atleast_1d(scales[i+1]).flatten()

        min_len = min(len(s1), len(s2))
        s1, s2 = s1[:min_len], s2[:min_len]

        if np.std(s1) > 0 and np.std(s2) > 0:
            corr = np.corrcoef(s1, s2)[0, 1]
            correlations.append(abs(corr))

    return float(np.mean(correlations)) if correlations else 0.0


def compute_embodiment_quotient(
    causal_agency: float,
    sensorimotor_closure: float,
    self_prediction_accuracy: float,
    reality_grounding: float,
    interoceptive_reliability: float,
    causal_density: float,
    weights: Optional[NDArray] = None
) -> float:
    """
    EQ = (1/6) * Σ max(0, min(1, (x_i - θ_i) / (1 - θ_i)))

    Minimum viability thresholds:
        causal_agency > 0.3
        sensorimotor_closure > 0.4
        self_prediction_accuracy > 0.5
        reality_grounding > 0.3
        interoceptive_reliability > 0.5
        causal_density > 0.2
    """
    values = np.array([
        causal_agency,
        sensorimotor_closure,
        self_prediction_accuracy,
        reality_grounding,
        interoceptive_reliability,
        causal_density
    ])

    thresholds = np.array([0.3, 0.4, 0.5, 0.3, 0.5, 0.2])

    if weights is None:
        weights = np.ones(6) / 6

    normalized = np.clip((values - thresholds) / (1.0 - thresholds), 0.0, 1.0)
    eq = np.sum(weights * normalized)

    return float(np.clip(eq, 0.0, 1.0))


def hash_state(state_dict: Dict) -> str:
    """Cryptographic hash of a state dictionary for audit trails."""
    canonical = json.dumps(state_dict, sort_keys=True, default=str)
    return hashlib.sha256(canonical.encode()).hexdigest()[:16]
