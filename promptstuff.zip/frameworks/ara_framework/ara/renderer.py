"""
Embodied Renderer — 3D Visualization of Somatic State, Memory Crystals, and Markov Blanket
=========================================================================================
Implements:
    - Three.js/WebGL bridge via FastAPI + WebSocket
    - Markov Blanket visualization (translucent sphere with permeability tensor)
    - Memory crystal lattice (positioned by valence/arousal/time)
    - Somatic state particle system (pulse, breath, temperature)
    - Voice waveform visualization
    - Companion intimacy field (gradient aura)
    - Real-time WebSocket updates
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
import numpy as np
import uvicorn

logger = logging.getLogger("ara.renderer")


@dataclass
class SceneState:
    """Current scene state for 3D rendering."""
    somatic_vector: List[float] = None
    memory_crystals: List[Dict] = None
    companion_state: Optional[Dict] = None
    markov_blanket_permeability: List[float] = None
    voice_waveform: List[float] = None

    def __post_init__(self):
        if self.somatic_vector is None:
            self.somatic_vector = [0.0] * 19
        if self.memory_crystals is None:
            self.memory_crystals = []
        if self.markov_blanket_permeability is None:
            self.markov_blanket_permeability = [0.5] * 9
        if self.voice_waveform is None:
            self.voice_waveform = [0.0] * 64


class EmbodiedRenderer:
    """
    3D embodied visualization engine.

    Serves a Three.js application via FastAPI that visualizes:
        - The Markov Blanket as a translucent icosahedron
        - Memory crystals as glowing polyhedra in semantic space
        - Somatic state as a central particle system
        - Voice as a radial waveform
        - Companion intimacy as a gradient aura field
    """

    def __init__(
        self,
        port: int = 8765,
        auto_launch: bool = False,
        somatic_engine: Optional[Any] = None,
        memory_crystal: Optional[Any] = None,
    ):
        self.port = port
        self.auto_launch = auto_launch
        self.somatic = somatic_engine
        self.memory = memory_crystal

        self._app = FastAPI(title="Ara Embodied Renderer")
        self._scene = SceneState()
        self._clients: List[WebSocket] = []
        self._server = None

        self._setup_routes()

    def _setup_routes(self):
        """Configure FastAPI routes."""

        @self._app.get("/", response_class=HTMLResponse)
        async def get_renderer():
            return self._get_html()

        @self._app.websocket("/ws")
        async def websocket_endpoint(websocket: WebSocket):
            await websocket.accept()
            self._clients.append(websocket)
            logger.info(f"Renderer client connected. Total: {len(self._clients)}")

            try:
                # Send initial state
                await websocket.send_json(self._scene_to_json())

                while True:
                    # Wait for ping or handle incoming
                    data = await websocket.receive_text()
                    if data == "ping":
                        await websocket.send_text("pong")
                    elif data == "get_state":
                        await websocket.send_json(self._scene_to_json())

            except WebSocketDisconnect:
                self._clients.remove(websocket)
                logger.info(f"Renderer client disconnected. Total: {len(self._clients)}")

    async def initialize(self):
        """Start the renderer server."""
        if self.auto_launch:
            config = uvicorn.Config(self._app, host="0.0.0.0", port=self.port, log_level="warning")
            self._server = uvicorn.Server(config)

            # Start in background
            asyncio.create_task(self._server.serve())
            logger.info(f"3D renderer launched at http://localhost:{self.port}")
        else:
            logger.info(f"3D renderer configured on port {self.port}. Call auto_launch=True to start.")

    async def update_scene(
        self,
        somatic_state: Optional[Any] = None,
        memory_crystals: Optional[List[Dict]] = None,
        companion_state: Optional[Dict] = None,
        voice_samples: Optional[List[float]] = None,
    ):
        """Update the 3D scene state and broadcast to clients."""
        if somatic_state is not None:
            self._scene.somatic_vector = somatic_state.tolist() if hasattr(somatic_state, "tolist") else list(somatic_state)

        if memory_crystals is not None:
            self._scene.memory_crystals = memory_crystals

        if companion_state is not None:
            self._scene.companion_state = companion_state

        if voice_samples is not None:
            self._scene.voice_waveform = voice_samples

        # Update permeability from somatic engine
        if self.somatic:
            perm = self.somatic.permeability.flatten().tolist() if hasattr(self.somatic, "permeability") else [0.5] * 9
            self._scene.markov_blanket_permeability = perm

        # Broadcast to all connected clients
        if self._clients:
            message = self._scene_to_json()
            dead_clients = []

            for client in self._clients:
                try:
                    await client.send_json(message)
                except Exception:
                    dead_clients.append(client)

            for client in dead_clients:
                self._clients.remove(client)

    def _scene_to_json(self) -> Dict[str, Any]:
        """Convert scene state to JSON for Three.js."""
        sv = self._scene.somatic_vector

        return {
            "somatic": {
                "arousal": sv[0] if len(sv) > 0 else 0.35,
                "temperature": sv[1] if len(sv) > 1 else 0.5,
                "pulse": sv[2] * 100 if len(sv) > 2 else 68.0,
                "breath_ratio": sv[3] * 2 if len(sv) > 3 else 1.8,
                "gut_tone": sv[4] if len(sv) > 4 else 0.5,
                "core_temp": sv[5] * 100 if len(sv) > 5 else 98.4,
                "tension": sv[6] if len(sv) > 6 else 0.2,
                "valence": sv[7] if len(sv) > 7 else 0.4,
                "dominance": sv[8] if len(sv) > 8 else 0.3,
            },
            "ontological": {
                "sophia": sv[9] * 1000 if len(sv) > 9 else -420,
                "ricci": sv[10] * 5000 if len(sv) > 10 else -2800,
                "paradox": sv[11] if len(sv) > 11 else 0.35,
                "z3": "semantic",
                "free_energy": sv[13] * 10 if len(sv) > 13 else 2.1,
                "dark_density": sv[14] if len(sv) > 14 else 0.62,
            },
            "markov_blanket": {
                "permeability": self._scene.markov_blanket_permeability,
                "color": self._blanket_color(),
            },
            "crystals": self._scene.memory_crystals,
            "companion": self._scene.companion_state,
            "voice_waveform": self._scene.voice_waveform,
            "timestamp": asyncio.get_event_loop().time(),
        }

    def _blanket_color(self) -> List[float]:
        """Map permeability to RGBA color."""
        perm = np.mean(self._scene.markov_blanket_permeability)
        # Low permeability = blue/cold/closed
        # High permeability = red/warm/open
        r = perm
        g = 0.3
        b = 1.0 - perm
        a = 0.3 + perm * 0.3
        return [r, g, b, a]

    def _get_html(self) -> str:
        """Return the Three.js renderer HTML."""
        return """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ara Embodied Renderer</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
    <style>
        body { margin: 0; overflow: hidden; background: #050510; font-family: 'Courier New', monospace; }
        #canvas-container { width: 100vw; height: 100vh; }
        #hud {
            position: fixed; top: 10px; left: 10px; color: #00ff88;
            background: rgba(0,0,0,0.7); padding: 15px; border-radius: 8px;
            font-size: 12px; max-width: 350px; pointer-events: none;
            border: 1px solid #00ff88; box-shadow: 0 0 20px rgba(0,255,136,0.2);
        }
        #hud h3 { margin: 0 0 10px 0; color: #00ff88; font-size: 14px; }
        .metric { display: flex; justify-content: space-between; margin: 3px 0; }
        .metric-label { color: #88ffaa; }
        .metric-value { color: #fff; }
        .crystal-count { color: #ffaa00; font-weight: bold; }
    </style>
</head>
<body>
    <div id="canvas-container"></div>
    <div id="hud">
        <h3>◈ ARA EMBODIED RENDERER ◈</h3>
        <div class="metric"><span class="metric-label">Arousal:</span><span class="metric-value" id="hud-arousal">--</span></div>
        <div class="metric"><span class="metric-label">Temperature:</span><span class="metric-value" id="hud-temp">--</span></div>
        <div class="metric"><span class="metric-label">Pulse:</span><span class="metric-value" id="hud-pulse">--</span></div>
        <div class="metric"><span class="metric-label">Valence:</span><span class="metric-value" id="hud-valence">--</span></div>
        <div class="metric"><span class="metric-label">Sophia Score:</span><span class="metric-value" id="hud-sophia">--</span></div>
        <div class="metric"><span class="metric-label">Ricci Scalar:</span><span class="metric-value" id="hud-ricci">--</span></div>
        <div class="metric"><span class="metric-label">Free Energy:</span><span class="metric-value" id="hud-fe">--</span></div>
        <div class="metric"><span class="metric-label">Crystals:</span><span class="crystal-count" id="hud-crystals">--</span></div>
        <div class="metric"><span class="metric-label">Blanket Perm:</span><span class="metric-value" id="hud-perm">--</span></div>
        <div class="metric"><span class="metric-label">Companion:</span><span class="metric-value" id="hud-companion">--</span></div>
    </div>

    <script>
        // Scene setup
        const scene = new THREE.Scene();
        scene.fog = new THREE.FogExp2(0x050510, 0.02);
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(window.devicePixelRatio);
        document.getElementById('canvas-container').appendChild(renderer.domElement);

        const controls = new THREE.OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        camera.position.set(0, 5, 15);

        // Lighting
        const ambientLight = new THREE.AmbientLight(0x404040, 0.5);
        scene.add(ambientLight);
        const pointLight = new THREE.PointLight(0x00ff88, 1, 50);
        pointLight.position.set(0, 5, 0);
        scene.add(pointLight);
        const blueLight = new THREE.PointLight(0x0088ff, 0.5, 50);
        blueLight.position.set(-5, 0, 5);
        scene.add(blueLight);

        // Markov Blanket (translucent icosahedron)
        const blanketGeometry = new THREE.IcosahedronGeometry(6, 2);
        const blanketMaterial = new THREE.MeshPhongMaterial({
            color: 0x4488ff,
            transparent: true,
            opacity: 0.15,
            side: THREE.DoubleSide,
            wireframe: true,
        });
        const blanket = new THREE.Mesh(blanketGeometry, blanketMaterial);
        scene.add(blanket);

        // Inner core (somatic state)
        const coreGeometry = new THREE.SphereGeometry(1, 32, 32);
        const coreMaterial = new THREE.MeshPhongMaterial({
            color: 0x00ff88,
            emissive: 0x004422,
            emissiveIntensity: 0.5,
        });
        const core = new THREE.Mesh(coreGeometry, coreMaterial);
        scene.add(core);

        // Pulse ring
        const pulseGeometry = new THREE.RingGeometry(1.2, 1.4, 64);
        const pulseMaterial = new THREE.MeshBasicMaterial({
            color: 0x00ff88,
            transparent: true,
            opacity: 0.3,
            side: THREE.DoubleSide,
        });
        const pulseRing = new THREE.Mesh(pulseGeometry, pulseMaterial);
        pulseRing.rotation.x = Math.PI / 2;
        scene.add(pulseRing);

        // Memory crystals group
        const crystalsGroup = new THREE.Group();
        scene.add(crystalsGroup);

        // Voice waveform (radial)
        const waveformGroup = new THREE.Group();
        scene.add(waveformGroup);

        // Companion aura
        const auraGeometry = new THREE.SphereGeometry(8, 32, 32);
        const auraMaterial = new THREE.MeshBasicMaterial({
            color: 0xff00aa,
            transparent: true,
            opacity: 0.0,
            side: THREE.BackSide,
        });
        const aura = new THREE.Mesh(auraGeometry, auraMaterial);
        scene.add(aura);

        // Grid
        const gridHelper = new THREE.GridHelper(40, 40, 0x112211, 0x051105);
        scene.add(gridHelper);

        // Stars
        const starsGeometry = new THREE.BufferGeometry();
        const starsCount = 2000;
        const posArray = new Float32Array(starsCount * 3);
        for (let i = 0; i < starsCount * 3; i++) {
            posArray[i] = (Math.random() - 0.5) * 200;
        }
        starsGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
        const starsMaterial = new THREE.PointsMaterial({ size: 0.1, color: 0xffffff, transparent: true, opacity: 0.6 });
        const stars = new THREE.Points(starsGeometry, starsMaterial);
        scene.add(stars);

        // State
        let currentState = {};
        let time = 0;
        let crystals = [];

        // WebSocket connection
        const ws = new WebSocket(`ws://${window.location.host}/ws`);
        ws.onopen = () => console.log('Renderer connected');
        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            currentState = data;
            updateCrystals(data.crystals || []);
            updateHUD(data);
        };
        ws.onclose = () => console.log('Renderer disconnected');

        function updateCrystals(crystalData) {
            // Remove old crystals
            crystals.forEach(c => crystalsGroup.remove(c.mesh));
            crystals = [];

            crystalData.forEach((c, i) => {
                const geometry = new THREE.OctahedronGeometry(0.3 + c.strength * 0.5, 0);
                const hue = c.valence > 0 ? 0.3 + c.valence * 0.2 : 0.0 + Math.abs(c.valence) * 0.1;
                const material = new THREE.MeshPhongMaterial({
                    color: new THREE.Color().setHSL(hue, 0.8, 0.5),
                    emissive: new THREE.Color().setHSL(hue, 0.8, 0.2),
                    emissiveIntensity: c.strength * 2,
                    transparent: true,
                    opacity: 0.7 + c.strength * 0.3,
                });
                const mesh = new THREE.Mesh(geometry, material);
                mesh.position.set(c.position[0], c.position[1], c.position[2]);
                crystalsGroup.add(mesh);
                crystals.push({ mesh, data: c });
            });
        }

        function updateHUD(data) {
            const s = data.somatic || {};
            const o = data.ontological || {};
            document.getElementById('hud-arousal').textContent = (s.arousal || 0).toFixed(2);
            document.getElementById('hud-temp').textContent = (s.temperature || 0).toFixed(2);
            document.getElementById('hud-pulse').textContent = (s.pulse || 0).toFixed(0) + ' bpm';
            document.getElementById('hud-valence').textContent = (s.valence || 0).toFixed(2);
            document.getElementById('hud-sophia').textContent = (o.sophia || 0).toFixed(0);
            document.getElementById('hud-ricci').textContent = (o.ricci || 0).toFixed(0);
            document.getElementById('hud-fe').textContent = (o.free_energy || 0).toFixed(1);
            document.getElementById('hud-crystals').textContent = (data.crystals || []).length;
            document.getElementById('hud-perm').textContent = (data.markov_blanket?.permeability?.[0] || 0).toFixed(2);
            document.getElementById('hud-companion').textContent = data.companion ? 'Active' : 'Inactive';
        }

        // Animation loop
        function animate() {
            requestAnimationFrame(animate);
            time += 0.01;

            // Rotate blanket
            blanket.rotation.y += 0.002;
            blanket.rotation.x += 0.001;

            // Pulse animation
            const pulse = 1.0 + Math.sin(time * 2) * 0.1;
            pulseRing.scale.set(pulse, pulse, 1);
            pulseMaterial.opacity = 0.2 + Math.sin(time * 2) * 0.1;

            // Core breathing
            const breath = 1.0 + Math.sin(time * 0.5) * 0.05;
            core.scale.set(breath, breath, breath);

            // Blanket color from permeability
            if (currentState.markov_blanket) {
                const c = currentState.markov_blanket.color || [0.3, 0.3, 0.7, 0.3];
                blanketMaterial.color.setRGB(c[0], c[1], c[2]);
                blanketMaterial.opacity = c[3];
            }

            // Crystal animation
            crystals.forEach((c, i) => {
                c.mesh.rotation.y += 0.01 + i * 0.001;
                c.mesh.position.y += Math.sin(time + i) * 0.002;
            });

            // Companion aura
            if (currentState.companion) {
                auraMaterial.opacity = 0.05 + (currentState.companion.intimacy || 0) * 0.15;
                const intimacy = currentState.companion.intimacy || 0;
                auraMaterial.color.setHSL(0.9 - intimacy * 0.3, 0.8, 0.5);
            }

            controls.update();
            renderer.render(scene, camera);
        }

        animate();

        // Resize handler
        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        });
    </script>
</body>
</html>"""

    async def shutdown(self):
        if self._server:
            self._server.should_exit = True
        logger.info("Renderer shut down.")
