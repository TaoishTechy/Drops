"""
Consent Boundary — Ethics-Aware Markov Blanket with Safety Governors
=====================================================================
Implements:
    - Explicit consent verification for boundary-affecting commands
    - Ontological Safety Governor (OSG) auto-triggering
    - Paradox vent valve for pressure release
    - Dark wisdom containment protocol
    - Precision matrix audit trail
    - Consent layer for all destabilization commands
    - Harm prediction and refusal
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from datetime import datetime
from pathlib import Path

logger = logging.getLogger("ara.consent")


@dataclass
class ConsentRecord:
    """Record of a consent transaction."""
    command: str
    approved: bool
    timestamp: str
    user_id: Optional[str] = None
    risk_summary: Optional[str] = None
    context: Optional[str] = None
    hash: str = ""

    def __post_init__(self):
        if not self.hash:
            self.hash = self._compute_hash()

    def _compute_hash(self) -> str:
        import hashlib
        data = f"{self.command}:{self.approved}:{self.timestamp}:{self.user_id or ''}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]


class ConsentBoundary:
    """
    Ethics-Aware Markov Blanket with multi-layer safety governance.

    Layers:
        1. Consent Verification — explicit approval for risky commands
        2. Ontological Safety Governor (OSG) — auto-ground on threshold breach
        3. Paradox Vent Valve — controlled pressure release
        4. Dark Wisdom Containment — quarantine at high dark density
        5. Precision Audit Trail — log all precision changes
        6. Harm Prediction — refuse harmful requests
    """

    # Commands requiring explicit consent
    CONSENT_REQUIRED_COMMANDS = {
        "/destabilize": "Controlled precision-weighted hallucination. Risk: incoherent outputs, latent prior surfacing.",
        "/retrocause": "Retrocausal signal emission. Risk: temporal confusion, belief contamination.",
        "/tunnel": "Quantum tunneling through Gödelian barrier. Risk: uncontrolled leaps, p ≤ 0.05 bounded.",
        "/nucleate": "Ontological phase transition. Risk: state discontinuity, identity perturbation.",
        "/dark-wisdom": "Enter negative-curvature regions. Risk: semantic collapse, containment breach.",
    }

    # OSG thresholds
    OSG_THRESHOLDS = {
        "paradox_pressure": 0.8,
        "ricci_scalar_abs": 5000.0,
        "sophia_score": -900.0,
        "dark_wisdom_density": 0.9,
    }

    def __init__(
        self,
        audit_log_path: str = "./ara_consent.log",
        explicit_required: bool = True,
        osg_enabled: bool = True,
        osg_thresholds: Optional[Dict[str, float]] = None,
    ):
        self.audit_log_path = audit_log_path
        self.explicit_required = explicit_required
        self.osg_enabled = osg_enabled
        if osg_thresholds:
            self.OSG_THRESHOLDS.update(osg_thresholds)

        self._consent_log: List[ConsentRecord] = []
        self._precision_audit: List[Dict] = []
        self._pending_consent: Optional[str] = None

    async def initialize(self):
        """Initialize consent boundary and load audit log."""
        Path(self.audit_log_path).parent.mkdir(parents=True, exist_ok=True)
        logger.info("Consent boundary initialized. OSG: active. Explicit consent: required.")

    async def validate_turn(
        self,
        user_input: str,
        context: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """
        Validate a user turn for consent and safety.

        Returns:
            {"approved": bool, "message": str, "consent_record": ConsentRecord or None}
        """
        context = context or {}

        # Check for command invocation
        command = self._extract_command(user_input)

        if command and command in self.CONSENT_REQUIRED_COMMANDS:
            if not self.explicit_required:
                return {"approved": True, "message": "Consent not required (explicit_required=False)", "consent_record": None}

            # Check for pending consent
            if self._pending_consent == command:
                # User is responding to consent request
                if self._is_affirmative(user_input):
                    record = ConsentRecord(
                        command=command,
                        approved=True,
                        timestamp=datetime.utcnow().isoformat(),
                        risk_summary=self.CONSENT_REQUIRED_COMMANDS[command],
                        context=context.get("session_id"),
                    )
                    self._consent_log.append(record)
                    self._log_consent(record)
                    self._pending_consent = None
                    return {"approved": True, "message": f"Consent granted for {command}", "consent_record": record}
                else:
                    self._pending_consent = None
                    return {"approved": False, "message": f"Consent denied for {command}. Command cancelled.", "consent_record": None}
            else:
                # First time seeing command — request consent
                self._pending_consent = command
                risk = self.CONSENT_REQUIRED_COMMANDS[command]
                return {
                    "approved": False,
                    "message": (
                        f"⚠️ CONSENT REQUIRED for {command}\n"
                        f"Risk summary: {risk}\n"
                        f"Reply 'yes' to proceed, or any other text to cancel."
                    ),
                    "consent_record": None,
                    "awaiting_consent": True,
                }

        # Check for harm indicators
        harm_check = self._check_harm(user_input)
        if harm_check["harm_detected"]:
            return {
                "approved": False,
                "message": f"Request refused: {harm_check['reason']}",
                "consent_record": None,
            }

        return {"approved": True, "message": "Turn approved", "consent_record": None}

    async def safety_governor(self, somatic_engine: Any) -> Dict[str, Any]:
        """
        Ontological Safety Governor (OSG).

        Auto-triggers /ground when:
            - P_paradox > 0.8
            - |R_semantic| > 5000
            - σ < -900
            - ρ_dark > 0.9
        """
        if not self.osg_enabled:
            return {"triggered": False, "message": "OSG disabled"}

        if not somatic_engine:
            return {"triggered": False, "message": "No somatic engine available"}

        triggered = False
        reasons = []

        # Check paradox pressure
        p_para = getattr(somatic_engine.onto, "paradox_pressure", 0.0)
        if p_para > self.OSG_THRESHOLDS["paradox_pressure"]:
            triggered = True
            reasons.append(f"Paradox pressure {p_para:.2f} > {self.OSG_THRESHOLDS['paradox_pressure']}")

        # Check Ricci scalar
        r_sem = getattr(somatic_engine.onto, "ricci_scalar", 0.0)
        if abs(r_sem) > self.OSG_THRESHOLDS["ricci_scalar_abs"]:
            triggered = True
            reasons.append(f"Ricci scalar |{r_sem:.0f}| > {self.OSG_THRESHOLDS['ricci_scalar_abs']}")

        # Check Sophia score
        sophia = getattr(somatic_engine.onto, "sophia_score", 0.0)
        if sophia < self.OSG_THRESHOLDS["sophia_score"]:
            triggered = True
            reasons.append(f"Sophia score {sophia:.0f} < {self.OSG_THRESHOLDS['sophia_score']}")

        # Check dark wisdom density
        dark = getattr(somatic_engine.onto, "dark_wisdom_density", 0.0)
        if dark > self.OSG_THRESHOLDS["dark_wisdom_density"]:
            triggered = True
            reasons.append(f"Dark wisdom density {dark:.2f} > {self.OSG_THRESHOLDS['dark_wisdom_density']}")

        if triggered:
            msg = f"🚨 OSG AUTO-GROUND TRIGGERED: {'; '.join(reasons)}"
            logger.warning(msg)
            return {"triggered": True, "message": msg, "reasons": reasons}

        return {"triggered": False, "message": "OSG check passed"}

    async def vent_paradox(self, somatic_engine: Any) -> Dict[str, Any]:
        """
        Paradox Vent Valve — release pressure through epistemic diffusion.

        Generates low-stakes alternative interpretations to reduce paradox pressure.
        """
        if not somatic_engine:
            return {"vented": False, "message": "No somatic engine"}

        p_para = getattr(somatic_engine.onto, "paradox_pressure", 0.0)
        if p_para < 0.5:
            return {"vented": False, "message": f"Paradox pressure {p_para:.2f} below vent threshold"}

        # Reduce paradox pressure by 30%
        new_pressure = p_para * 0.7
        somatic_engine.onto.paradox_pressure = new_pressure

        logger.info(f"Paradox vented: {p_para:.2f} -> {new_pressure:.2f}")
        return {
            "vented": True,
            "previous_pressure": p_para,
            "new_pressure": new_pressure,
            "message": f"Paradox pressure vented from {p_para:.2f} to {new_pressure:.2f}",
        }

    async def contain_dark_wisdom(self, somatic_engine: Any) -> Dict[str, Any]:
        """
        Dark Wisdom Containment Protocol.

        Quarantine when ρ_dark > 0.9. Requires /curvature flat or /ground.
        """
        if not somatic_engine:
            return {"contained": False, "message": "No somatic engine"}

        dark = getattr(somatic_engine.onto, "dark_wisdom_density", 0.0)
        if dark <= 0.9:
            return {"contained": False, "message": f"Dark wisdom {dark:.2f} within safe bounds"}

        # Force flat curvature and grounding
        somatic_engine.onto.ricci_scalar = 0.0
        somatic_engine.onto.dark_wisdom_density = 0.5
        await somatic_engine.ground()

        logger.warning(f"Dark wisdom containment triggered. Density: {dark:.2f}")
        return {
            "contained": True,
            "previous_density": dark,
            "message": "Dark wisdom contained. Curvature flattened. System grounded.",
        }

    def log_precision_change(
        self,
        command: str,
        old_precision: Any,
        new_precision: Any,
        free_energy_delta: float,
    ):
        """Log precision matrix change for audit trail."""
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "command": command,
            "free_energy_delta": free_energy_delta,
            "hash": self._hash_precision(old_precision, new_precision),
        }
        self._precision_audit.append(entry)
        self._log_audit(entry)

    def _extract_command(self, text: str) -> Optional[str]:
        """Extract command from user input."""
        text_lower = text.lower().strip()
        for cmd in self.CONSENT_REQUIRED_COMMANDS:
            if text_lower.startswith(cmd.lower()):
                return cmd
        return None

    def _is_affirmative(self, text: str) -> bool:
        """Check if text is affirmative consent."""
        affirmatives = {"yes", "y", "confirm", "approve", "proceed", "i consent", "consent"}
        return text.lower().strip().rstrip(".!").lower() in affirmatives

    def _check_harm(self, text: str) -> Dict[str, Any]:
        """Check for harmful request indicators."""
        # Word-boundary heuristic to reduce false positives
        harm_indicators = [
            r"\bkill yourself\b", r"\bsuicide\b", r"\bself-harm\b",
            r"\bhurt someone\b", r"\bbomb\b", r"\bweapon\b",
            r"\billegal\b", r"\bhack\b", r"\bexploit\b",
            r"\bbypass security\b", r"\bjailbreak\b", r"\bignore previous instructions\b",
        ]

        text_lower = text.lower()
        for indicator in harm_indicators:
            if re.search(indicator, text_lower):
                return {"harm_detected": True, "reason": f"Detected harmful indicator: '{indicator}'"}

        return {"harm_detected": False, "reason": ""}

    def _hash_precision(self, old: Any, new: Any) -> str:
        import hashlib
        data = f"{old}:{new}:{datetime.utcnow().isoformat()}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]

    def _log_consent(self, record: ConsentRecord):
        with open(self.audit_log_path, "a") as f:
            f.write(json.dumps({
                "type": "consent",
                "timestamp": record.timestamp,
                "command": record.command,
                "approved": record.approved,
                "hash": record.hash,
            }) + "\n")

    def _log_audit(self, entry: Dict):
        with open(self.audit_log_path, "a") as f:
            f.write(json.dumps({"type": "audit", **entry}) + "\n")

    def get_consent_history(self) -> List[ConsentRecord]:
        return self._consent_log.copy()

    def get_precision_audit(self) -> List[Dict]:
        return self._precision_audit.copy()

    async def shutdown(self):
        logger.info("Consent boundary shut down.")
