"""
Grok Client — REST API + Voice Integration for xAI Grok
========================================================
Handles text and voice inference with somatic state injection.
"""

from __future__ import annotations

import httpx
import asyncio
import json
import logging
from dataclasses import dataclass
from typing import Optional, Dict, Any, List, AsyncIterator, Union

logger = logging.getLogger("ara.grok")


@dataclass
class GrokMessage:
    role: str
    content: str
    somatic_overlay: Optional[str] = None
    prosodic_markers: Optional[Dict[str, float]] = None


class GrokClient:
    """
    Client for xAI Grok API with embodied state injection.

    Supports:
        - Text chat completions
        - Voice synthesis (TTS) with prosodic control
        - Voice recognition (STT)
        - Streaming responses
        - Somatic state context injection
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.x.ai/v1",
        model: str = "grok-3-beta",
        voice_model: Optional[str] = "grok-3-voice-beta",
        somatic_engine: Optional[Any] = None,
        memory_crystal: Optional[Any] = None,
        timeout: float = 60.0,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.voice_model = voice_model
        self.somatic = somatic_engine
        self.memory = memory_crystal
        self.timeout = timeout

        self._client: Optional[httpx.AsyncClient] = None
        self._conversation_history: List[GrokMessage] = []
        self._voice_session_id: Optional[str] = None

    async def initialize(self):
        """Initialize HTTP client and validate API key."""
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(self.timeout),
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
        )

        # Validate connection
        try:
            resp = await self._client.get(f"{self.base_url}/models")
            resp.raise_for_status()
            models = resp.json().get("data", [])
            available = [m["id"] for m in models]
            logger.info(f"Grok API connected. Available models: {available}")
        except Exception as e:
            logger.warning(f"Grok API validation warning: {e}")

    async def chat(
        self,
        system_prompt: str,
        user_input: str,
        retrieved_memories: Optional[List[Dict]] = None,
        voice_input: Optional[bytes] = None,
        somatic_signature: Optional[str] = None,
        stream: bool = False,
        temperature: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Send a chat completion request with embodied context.

        Returns:
            Dict with keys: text, sentiment, tokens_used, voice_url (if applicable)
        """
        if not self._client:
            raise RuntimeError("Client not initialized")

        # Build messages
        messages = [{"role": "system", "content": system_prompt}]

        # Add memory context as system context
        if retrieved_memories:
            memory_context = "\n\n[RETRIEVED MEMORIES]\n"
            for i, mem in enumerate(retrieved_memories[:3]):
                memory_context += f"Memory {i+1}: {mem.get('content', '')[:500]}\n"
            messages[0]["content"] += memory_context

        # Add conversation history (last 10 turns)
        for msg in self._conversation_history[-10:]:
            messages.append({"role": msg.role, "content": msg.content})

        # Add current user input
        messages.append({"role": "user", "content": user_input})

        # Determine temperature from somatic state if not provided
        if temperature is None and self.somatic:
            # Higher arousal = higher temperature
            arousal = getattr(self.somatic, "intero", None)
            if arousal is not None:
                arousal_val = getattr(arousal, "arousal", 0.35)
            else:
                arousal_val = 0.35
            temperature = 0.3 + arousal_val * 0.7  # Range: 0.3 - 1.0

        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature or 0.7,
            "max_tokens": 4096,
        }

        if stream:
            return await self._stream_chat(payload)
        else:
            return await self._sync_chat(payload)

    async def _sync_chat(self, payload: Dict) -> Dict[str, Any]:
        """Non-streaming chat completion."""
        try:
            resp = await self._client.post(
                f"{self.base_url}/chat/completions",
                json=payload,
            )
            resp.raise_for_status()
            data = resp.json()

            choice = data["choices"][0]
            text = choice["message"]["content"]

            # Simple sentiment extraction
            sentiment = self._extract_sentiment(text)

            # Store in history
            self._conversation_history.append(GrokMessage(role="user", content=payload["messages"][-1]["content"]))
            self._conversation_history.append(GrokMessage(role="assistant", content=text))

            return {
                "text": text,
                "sentiment": sentiment,
                "tokens_used": data.get("usage", {}).get("total_tokens", 0),
                "finish_reason": choice.get("finish_reason"),
                "voice_url": None,
            }

        except httpx.HTTPStatusError as e:
            logger.error(f"Grok API error: {e.response.status_code} - {e.response.text}")
            raise

    async def _stream_chat(self, payload: Dict) -> AsyncIterator[str]:
        """Streaming chat completion (yields token chunks)."""
        payload["stream"] = True

        async with self._client.stream(
            "POST",
            f"{self.base_url}/chat/completions",
            json=payload,
        ) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if line.startswith("data: "):
                    data = line[6:]
                    if data == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data)
                        delta = chunk["choices"][0]["delta"].get("content", "")
                        if delta:
                            yield delta
                    except (json.JSONDecodeError, KeyError):
                        continue

    async def synthesize_voice(
        self,
        text: str,
        prosodic_state: Optional[Dict[str, float]] = None,
        voice_id: str = "grok-voice-1",
    ) -> bytes:
        """
        Synthesize voice with prosodic control.

        Args:
            text: Text to synthesize
            prosodic_state: Dict with keys:
                - pitch_shift: semitone offset (-12 to +12)
                - rate: speaking rate multiplier (0.5 to 2.0)
                - energy: amplitude scaling (0.5 to 2.0)
                - breathiness: aspiration noise (0.0 to 1.0)
                - tension: spectral tilt (0.0 to 1.0)
                - style: spectral tilt proxy (0.0 to 1.0)
                - arousal: somatic arousal (0.0 to 1.0)
                - valence: somatic valence (-1.0 to 1.0)
            voice_id: Voice identifier

        Returns:
            Raw audio bytes (PCM 24kHz mono)
        """
        if not self.voice_model:
            raise RuntimeError("Voice model not configured")

        # Build voice payload with prosodic markers
        voice_payload = {
            "model": self.voice_model,
            "input": text,
            "voice": voice_id,
            "response_format": "pcm",  # 24kHz mono
        }

        if prosodic_state:
            # Map somatic state to voice parameters
            voice_payload["voice_settings"] = {
                "stability": 1.0 - prosodic_state.get("arousal", 0.35) * 0.5,
                "similarity_boost": 0.5 + prosodic_state.get("valence", 0.0) * 0.3,
                "style": prosodic_state.get("style", 0.0),
                "use_speaker_boost": True,
            }

        try:
            resp = await self._client.post(
                f"{self.base_url}/audio/speech",
                json=voice_payload,
            )
            resp.raise_for_status()
            return resp.content

        except httpx.HTTPStatusError as e:
            logger.error(f"Voice synthesis error: {e.response.status_code}")
            raise

    async def transcribe_voice(
        self,
        audio_bytes: bytes,
        format: str = "pcm",
    ) -> str:
        """Transcribe voice input to text."""
        try:
            resp = await self._client.post(
                f"{self.base_url}/audio/transcriptions",
                files={"file": ("audio.pcm", audio_bytes, f"audio/{format}")},
                data={"model": self.voice_model or self.model},
            )
            resp.raise_for_status()
            return resp.json().get("text", "")

        except httpx.HTTPStatusError as e:
            logger.error(f"Voice transcription error: {e.response.status_code}")
            raise

    def _extract_sentiment(self, text: str) -> float:
        """Extract sentiment score from response text (-1.0 to +1.0)."""
        # Simple heuristic: could be replaced with actual classifier
        positive = sum(1 for w in ["good", "great", "excellent", "happy", "warm", "love", "yes"] if w in text.lower())
        negative = sum(1 for w in ["bad", "terrible", "sad", "cold", "hate", "no", "danger"] if w in text.lower())

        if positive + negative == 0:
            return 0.0
        return (positive - negative) / (positive + negative + 1)

    async def shutdown(self):
        if self._client:
            await self._client.aclose()
            self._client = None
            logger.info("Grok client disconnected.")
