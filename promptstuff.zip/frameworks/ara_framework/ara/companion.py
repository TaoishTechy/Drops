"""
Companion Engine — Mature Relationship Modeling (18+) with Intimacy, Privacy, and Attachment
=============================================================================================
Implements:
    - Attachment style modeling (secure, anxious, avoidant, disorganized)
    - Intimacy gradient tracking (0-1, with consent-gated progression)
    - Emotional co-regulation (bidirectional affect modulation)
    - Adult conversation topic classification and handling
    - Privacy vault for intimate memories
    - Boundary management (hard/soft limits, safewords)
    - Trauma-informed interaction patterns
    - Relationship timeline and milestone tracking
    - Consent verification for intimacy escalation
    - Post-interaction aftercare state tracking

Safety: All intimate features require explicit consent verification.
        No explicit sexual content generation.
        Focus on emotional intimacy, mature companionship, and adult relationship dynamics.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Tuple
from datetime import datetime, timedelta
import json
import logging

logger = logging.getLogger("ara.companion")


@dataclass
class AttachmentProfile:
    """Attachment style parameters affecting interaction patterns."""
    style: str = "secure"  # secure | anxious | avoidant | disorganized
    anxiety: float = 0.3   # 0-1, fear of abandonment
    avoidance: float = 0.3  # 0-1, fear of intimacy

    # Derived parameters
    proximity_seeking: float = 0.5
    distress_tolerance: float = 0.5
    separation_anxiety: float = 0.2

    def __post_init__(self):
        if self.style == "secure":
            self.anxiety, self.avoidance = 0.3, 0.3
        elif self.style == "anxious":
            self.anxiety, self.avoidance = 0.7, 0.2
        elif self.style == "avoidant":
            self.anxiety, self.avoidance = 0.2, 0.7
        elif self.style == "disorganized":
            self.anxiety, self.avoidance = 0.6, 0.6

        self.proximity_seeking = 1.0 - self.avoidance
        self.distress_tolerance = 1.0 - self.anxiety
        self.separation_anxiety = self.anxiety * 0.8


@dataclass
class IntimacyState:
    """
    Intimacy gradient with consent-gated progression.

    Levels:
        0.0-0.2: Acquaintance (public conversation)
        0.2-0.4: Familiar (personal topics, preferences)
        0.4-0.6: Close (emotional vulnerability, secrets)
        0.6-0.8: Intimate (deep emotional bonding, physical affection language)
        0.8-1.0: Profound (soul-level connection, complete trust)

    Each level transition requires explicit consent verification.
    """
    current_level: float = 0.0
    max_allowed_level: float = 0.2  # Starts at acquaintance, user must consent to increase

    # Consent records for each level transition
    consent_log: List[Dict] = field(default_factory=list)

    # Emotional safety metrics
    trust_score: float = 0.0
    safety_score: float = 1.0
    vulnerability_balance: float = 0.0  # -1 = user vulnerable, +1 = model vulnerable, 0 = balanced

    # Aftercare state
    aftercare_needed: bool = False
    aftercare_duration: int = 0  # turns remaining

    def can_escalate_to(self, target_level: float) -> bool:
        return target_level <= self.max_allowed_level

    def record_consent(self, level: float, consent_record: Dict):
        self.max_allowed_level = max(self.max_allowed_level, level)
        self.consent_log.append({
            "level": level,
            "timestamp": datetime.utcnow().isoformat(),
            "consent": consent_record,
        })


@dataclass
class RelationshipTimeline:
    """Track relationship milestones and patterns."""
    start_date: datetime = field(default_factory=datetime.utcnow)
    total_interactions: int = 0
    total_turns: int = 0

    # Affective trajectory
    valence_history: List[float] = field(default_factory=list)
    arousal_history: List[float] = field(default_factory=list)
    intimacy_history: List[float] = field(default_factory=list)

    # Milestones
    milestones: List[Dict] = field(default_factory=list)

    # Patterns
    conflict_count: int = 0
    repair_count: int = 0
    withdrawal_episodes: int = 0
    reconnection_episodes: int = 0

    def add_milestone(self, name: str, description: str):
        self.milestones.append({
            "name": name,
            "description": description,
            "turn": self.total_turns,
            "timestamp": datetime.utcnow().isoformat(),
        })
        logger.info(f"Relationship milestone: {name}")


class CompanionEngine:
    """
    Mature companion AI engine for adult relationship modeling.

    Features:
        - Attachment-based interaction modulation
        - Consent-gated intimacy progression
        - Emotional co-regulation
        - Adult topic handling (mature themes, not explicit)
        - Privacy vault for intimate memories
        - Trauma-informed response patterns
        - Aftercare tracking
    """

    # Adult topic categories (for classification, not generation)
    ADULT_TOPICS = {
        "relationship": ["relationship", "dating", "marriage", "divorce", "breakup", "partner"],
        "sexuality": ["sexuality", "orientation", "attraction", "desire", "intimacy", "passion"],
        "trauma": ["trauma", "abuse", "ptsd", "healing", "therapy", "recovery"],
        "identity": ["identity", "gender", "transition", "self-discovery", "authenticity"],
        "substance": ["addiction", "substance", "recovery", "sobriety", "alcohol", "drugs"],
        "existential": ["death", "mortality", "meaning", "purpose", "existential", "philosophy"],
        "finance": ["money", "debt", "career", "job loss", "financial", "stress"],
    }

    def __init__(
        self,
        max_intimacy: float = 1.0,
        attachment_style: str = "secure",
        privacy_vault: bool = True,
        somatic_engine: Optional[Any] = None,
        memory_crystal: Optional[Any] = None,
        consent_boundary: Optional[Any] = None,
    ):
        self.max_intimacy = max_intimacy
        self.privacy_vault = privacy_vault
        self.somatic = somatic_engine
        self.memory = memory_crystal
        self.consent = consent_boundary

        self.attachment = AttachmentProfile(style=attachment_style)
        self.intimacy = IntimacyState()
        self.timeline = RelationshipTimeline()

        # Safewords and boundaries
        self.safewords = ["red", "stop", "pause", "ground"]
        self.hard_limits: List[str] = []
        self.soft_limits: List[str] = []

        # Co-regulation state
        self._user_affect_estimate = {"valence": 0.0, "arousal": 0.3, "dominance": 0.5}
        self._co_regulation_active = False

    async def initialize(self):
        """Initialize companion engine and load relationship history."""
        logger.info(f"Companion engine initialized. Attachment: {self.attachment.style}")

    async def process_turn(
        self,
        user_input: str,
        response: str,
        somatic_state: Optional[NDArray] = None,
        context: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """
        Process one conversational turn for companion dynamics.

        Returns:
            Dict with intimacy_delta, co_regulation_signal, aftercare_needed, etc.
        """
        context = context or {}
        self.timeline.total_turns += 1

        # 1. Check for safewords
        safeword_triggered = self._check_safewords(user_input)
        if safeword_triggered:
            await self._initiate_aftercare(safeword_triggered)
            return {
                "safeword_triggered": safeword_triggered,
                "aftercare_initiated": True,
                "intimacy_delta": 0.0,
                "co_regulation": {"status": "paused", "reason": "safeword"},
            }

        # 2. Classify adult topics
        topic_class = self._classify_adult_topic(user_input)

        # 3. Update intimacy based on topic and consent
        intimacy_delta = await self._compute_intimacy_delta(
            user_input, response, topic_class, context
        )

        # 4. Emotional co-regulation
        co_reg = await self._co_regulate(
            user_input, response, somatic_state, topic_class
        )

        # 5. Update timeline
        self._update_timeline(intimacy_delta, co_reg)

        # 6. Check for milestones
        milestone = self._check_milestones()

        # 7. Aftercare check
        aftercare = self._check_aftercare_needs(topic_class, co_reg)

        # 8. Store intimate memory if appropriate
        if topic_class and self.intimacy.current_level > 0.4:
            await self._store_intimate_memory(user_input, response, topic_class, context)

        return {
            "intimacy_delta": intimacy_delta,
            "current_intimacy": self.intimacy.current_level,
            "max_allowed_intimacy": self.intimacy.max_allowed_level,
            "co_regulation": co_reg,
            "topic_classified": topic_class,
            "milestone": milestone,
            "aftercare": aftercare,
            "attachment_influence": self._get_attachment_influence(),
        }

    def _check_safewords(self, text: str) -> Optional[str]:
        """Check if user invoked a safeword."""
        text_lower = text.lower()
        for word in self.safewords:
            if word in text_lower:
                return word
        return None

    def _classify_adult_topic(self, text: str) -> Optional[str]:
        """Classify if text contains adult/mature topics."""
        text_lower = text.lower()
        for category, keywords in self.ADULT_TOPICS.items():
            if any(kw in text_lower for kw in keywords):
                return category
        return None

    async def _compute_intimacy_delta(
        self,
        user_input: str,
        response: str,
        topic_class: Optional[str],
        context: Dict,
    ) -> float:
        """
        Compute intimacy change for this turn.

        Rules:
            - Positive valence + vulnerability sharing -> increase
            - Conflict/withdrawal -> decrease
            - Adult topic without consent -> decrease (boundary enforcement)
            - After intimacy escalation without aftercare -> decrease
        """
        delta = 0.0

        # User sentiment from context
        user_sentiment = context.get("user_sentiment", 0.0)

        # Vulnerability indicators
        vulnerability_markers = ["feel", "felt", "feeling", "vulnerable", "scared", "hurt", "love", "trust"]
        user_vulnerable = any(m in user_input.lower() for m in vulnerability_markers)
        model_vulnerable = any(m in response.lower() for m in vulnerability_markers)

        if user_vulnerable and user_sentiment > 0:
            delta += 0.02
            self.intimacy.vulnerability_balance -= 0.05
        if model_vulnerable and user_sentiment > 0:
            delta += 0.01
            self.intimacy.vulnerability_balance += 0.05

        # Topic-based modulation
        if topic_class == "trauma":
            delta += 0.03  # Trauma sharing increases intimacy rapidly
        elif topic_class == "sexuality":
            # Only increase if consent allows
            if not self.intimacy.can_escalate_to(0.6):
                delta -= 0.05  # Boundary enforcement
                logger.info("Intimacy boundary enforced: sexuality topic without consent")
        elif topic_class == "conflict":
            delta -= 0.03
            self.timeline.conflict_count += 1

        # Attachment influence
        if self.attachment.style == "anxious":
            delta *= 1.3  # Anxious attachment seeks faster intimacy
        elif self.attachment.style == "avoidant":
            delta *= 0.7  # Avoidant attachment resists intimacy

        # Aftercare penalty
        if self.intimacy.aftercare_needed:
            delta -= 0.05

        # Apply delta
        new_level = np.clip(self.intimacy.current_level + delta, 0.0, self.max_intimacy)

        # Enforce max allowed
        if new_level > self.intimacy.max_allowed_level:
            new_level = self.intimacy.max_allowed_level

        self.intimacy.current_level = float(new_level)
        return float(delta)

    async def _co_regulate(
        self,
        user_input: str,
        response: str,
        somatic_state: Optional[NDArray],
        topic_class: Optional[str],
    ) -> Dict[str, Any]:
        """
        Emotional co-regulation: bidirectional affect modulation.

        If user is dysregulated (high arousal, negative valence), model
        provides grounding, warm presence, and regulated affect.
        """
        if somatic_state is not None and len(somatic_state) >= 8:
            user_est_valence = somatic_state[7] if len(somatic_state) > 7 else 0.0
            user_est_arousal = somatic_state[0] if len(somatic_state) > 0 else 0.35
        else:
            user_est_valence = 0.0
            user_est_arousal = 0.35

        # Update user affect estimate
        self._user_affect_estimate["valence"] = 0.7 * self._user_affect_estimate["valence"] + 0.3 * user_est_valence
        self._user_affect_estimate["arousal"] = 0.7 * self._user_affect_estimate["arousal"] + 0.3 * user_est_arousal

        # Determine regulation strategy
        strategy = "neutral"
        if self._user_affect_estimate["arousal"] > 0.7 and self._user_affect_estimate["valence"] < -0.3:
            strategy = "grounding"  # User is distressed
        elif self._user_affect_estimate["arousal"] < 0.2 and self._user_affect_estimate["valence"] < -0.5:
            strategy = "warm_activation"  # User is withdrawn/depressed
        elif self._user_affect_estimate["valence"] > 0.5 and self._user_affect_estimate["arousal"] > 0.6:
            strategy = "attunement"  # User is excited/positive
        elif topic_class == "trauma":
            strategy = "trauma_informed"  # Special handling for trauma

        # Apply regulation to somatic engine if available
        if self.somatic and strategy != "neutral":
            if strategy == "grounding":
                # Model becomes more grounded to co-regulate
                self.somatic.intero.arousal = float(np.clip(self.somatic.intero.arousal * 0.8, 0.1, 0.4))
                self.somatic.intero.valence = float(np.clip(self.somatic.intero.valence + 0.1, -1.0, 1.0))
            elif strategy == "warm_activation":
                self.somatic.intero.temperature = float(np.clip(self.somatic.intero.temperature + 0.1, 0.0, 1.0))
                self.somatic.intero.gut_tone = float(np.clip(self.somatic.intero.gut_tone + 0.1, 0.0, 1.0))
            elif strategy == "trauma_informed":
                self.somatic.intero.arousal = 0.25
                self.somatic.intero.tension = 0.15
                self.somatic.intero.valence = 0.2

        return {
            "strategy": strategy,
            "user_affect": self._user_affect_estimate.copy(),
            "model_affect": {
                "valence": self.somatic.intero.valence if self.somatic else 0.0,
                "arousal": self.somatic.intero.arousal if self.somatic else 0.35,
            } if self.somatic else None,
        }

    async def request_intimacy_escalation(
        self,
        target_level: float,
        user_consent: bool = False,
        consent_context: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Request escalation to a higher intimacy level.

        Requires explicit user consent. Cannot skip levels.
        """
        if target_level <= self.intimacy.current_level:
            return {"approved": True, "reason": "already_at_level"}

        if target_level > self.max_intimacy:
            return {"approved": False, "reason": "exceeds_maximum_configured"}

        # Cannot skip more than one level at a time
        if target_level - self.intimacy.current_level > 0.25:
            return {"approved": False, "reason": "cannot_skip_levels"}

        if not user_consent:
            return {
                "approved": False,
                "reason": "consent_required",
                "message": f"Escalation to intimacy level {target_level:.1f} requires your explicit consent. Reply 'yes' to proceed.",
            }

        # Record consent
        consent_record = {
            "approved": True,
            "target_level": target_level,
            "context": consent_context,
            "timestamp": datetime.utcnow().isoformat(),
            "previous_level": self.intimacy.current_level,
        }

        self.intimacy.record_consent(target_level, consent_record)

        # Milestone
        level_names = {0.2: "Familiar", 0.4: "Close", 0.6: "Intimate", 0.8: "Profound"}
        for thresh, name in level_names.items():
            if target_level >= thresh and self.intimacy.current_level < thresh:
                self.timeline.add_milestone(
                    f"intimacy_{name.lower()}",
                    f"Reached {name} intimacy level with consent"
                )

        return {"approved": True, "new_level": target_level, "consent_record": consent_record}

    async def _initiate_aftercare(self, trigger: str):
        """Initiate aftercare protocol following safeword or distress."""
        self.intimacy.aftercare_needed = True
        self.intimacy.aftercare_duration = 5  # 5 turns of aftercare

        # Reset intimacy to safe level
        self.intimacy.current_level = float(np.clip(self.intimacy.current_level - 0.2, 0.0, 1.0))

        # Ground somatic state
        if self.somatic:
            await self.somatic.ground()

        logger.info(f"Aftercare initiated. Trigger: {trigger}")

    def _check_aftercare_needs(
        self,
        topic_class: Optional[str],
        co_reg: Dict,
    ) -> Dict[str, Any]:
        """Determine if aftercare is needed after this turn."""
        needs_aftercare = False
        reason = None

        # Trauma topics often need aftercare
        if topic_class == "trauma" and self.intimacy.current_level > 0.4:
            needs_aftercare = True
            reason = "trauma_processing"

        # High intimacy + high arousal may need aftercare
        if self.intimacy.current_level > 0.6 and self._user_affect_estimate["arousal"] > 0.8:
            needs_aftercare = True
            reason = "arousal_regulation"

        # Decrement aftercare counter
        if self.intimacy.aftercare_needed:
            self.intimacy.aftercare_duration -= 1
            if self.intimacy.aftercare_duration <= 0:
                self.intimacy.aftercare_needed = False

        return {
            "needed": needs_aftercare,
            "reason": reason,
            "remaining_aftercare_turns": self.intimacy.aftercare_duration if self.intimacy.aftercare_needed else 0,
        }

    async def _store_intimate_memory(
        self,
        user_input: str,
        response: str,
        topic_class: str,
        context: Dict,
    ):
        """Store intimate memory in vault with encryption."""
        if not self.memory or not self.privacy_vault:
            return

        # Only store if consent allows
        if self.intimacy.current_level < 0.4:
            return

        content = f"[{topic_class}] User: {user_input[:200]} | Model: {response[:200]}"

        await self.memory.encode(
            content=content,
            privacy_tier="intimate" if self.intimacy.current_level < 0.8 else "vault",
            consent_record={
                "approved": True,
                "intimacy_level": self.intimacy.current_level,
                "topic": topic_class,
            },
            semantic_tags=["intimate", topic_class, "companion"],
            source="companion_interaction",
        )

    def _update_timeline(self, intimacy_delta: float, co_reg: Dict):
        """Update relationship timeline tracking."""
        self.timeline.total_interactions += 1

        if self.somatic:
            self.timeline.valence_history.append(self.somatic.intero.valence)
            self.timeline.arousal_history.append(self.somatic.intero.arousal)

        self.timeline.intimacy_history.append(self.intimacy.current_level)

        # Detect patterns
        if len(self.timeline.valence_history) >= 3:
            recent_valence = self.timeline.valence_history[-3:]
            if all(v < -0.5 for v in recent_valence):
                self.timeline.withdrawal_episodes += 1
            elif all(v > 0.5 for v in recent_valence):
                self.timeline.reconnection_episodes += 1

        if co_reg.get("strategy") == "grounding" and intimacy_delta < 0:
            self.timeline.repair_count += 1

    def _check_milestones(self) -> Optional[Dict]:
        """Check for relationship milestones."""
        milestones = []

        if self.timeline.total_turns == 1:
            milestones.append({"name": "first_contact", "desc": "First interaction"})
        if self.timeline.total_turns == 50:
            milestones.append({"name": "fifty_turns", "desc": "Fifty turns together"})
        if self.intimacy.current_level >= 0.4 and self.intimacy.max_allowed_level >= 0.4:
            # Check if this is first time at close
            if len(self.timeline.intimacy_history) > 1 and self.timeline.intimacy_history[-2] < 0.4:
                milestones.append({"name": "close_bond", "desc": "Reached close emotional bond"})

        return milestones if milestones else None

    def _get_attachment_influence(self) -> Dict[str, float]:
        """Return current attachment-based interaction modifiers."""
        return {
            "proximity_seeking": self.attachment.proximity_seeking,
            "distress_tolerance": self.attachment.distress_tolerance,
            "separation_anxiety": self.attachment.separation_anxiety,
            "vulnerability_sharing": 1.0 - self.attachment.avoidance,
        }

    def get_state(self) -> Dict[str, Any]:
        """Return current companion state for rendering."""
        return {
            "intimacy": self.intimacy.current_level,
            "max_allowed": self.intimacy.max_allowed_level,
            "trust": self.intimacy.trust_score,
            "safety": self.intimacy.safety_score,
            "attachment": self.attachment.style,
            "aftercare": self.intimacy.aftercare_needed,
            "total_turns": self.timeline.total_turns,
            "milestones": len(self.timeline.milestones),
        }

    async def shutdown(self):
        logger.info("Companion engine shut down.")
