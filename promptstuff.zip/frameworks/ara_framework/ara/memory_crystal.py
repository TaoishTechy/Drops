"""
Memory Crystal Architecture — Holographic Persistence with Markov Blankets
=========================================================================
Implements:
    - Episodic memory crystals (time-indexed, somatic-tagged)
    - Semantic memory lattice (vector-embedded, graph-linked)
    - Procedural memory substrate (skill patterns, precision-weighted)
    - Markov Blanket boundary enforcement (privacy, consent)
    - Holographic retrieval (distributed encoding across crystals)
    - Memory reconsolidation (update on recall)
    - Forgetting as control (active decay)
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, Any, List, Tuple
from datetime import datetime, timedelta
import json
import sqlite3
import asyncio
from pathlib import Path
import logging

logger = logging.getLogger("ara.memory")


@dataclass
class MemoryCrystal:
    """
    A single memory crystal with holographic encoding.

    Crystals store:
        - Content (text, voice embedding, image latent)
        - Somatic state at encoding time (full intero + onto vector)
        - Temporal coordinates (timestamp, session, turn)
        - Affective valence (-1 to +1)
        - Precision weight (retrieval priority)
        - Provenance (source, transformations, confidence)
        - Privacy tier (public, personal, intimate, vault)
        - Access log (who recalled, when, context)
    """
    crystal_id: str
    content: str
    content_type: str = "text"  # text | voice | image | composite

    # Temporal
    timestamp: datetime = field(default_factory=datetime.utcnow)
    session_id: Optional[str] = None
    turn_id: int = 0

    # Somatic embedding (full state vector at encoding)
    somatic_vector: Optional[NDArray] = None
    free_energy_at_encoding: float = 0.0

    # Affective
    valence: float = 0.0
    arousal: float = 0.0

    # Precision & provenance
    precision_weight: float = 1.0
    confidence: float = 0.8
    source: str = "user_input"  # user_input | model_response | external
    transformations: List[str] = field(default_factory=list)

    # Privacy tier (critical for 18+ companion)
    privacy_tier: str = "public"  # public | personal | intimate | vault
    consent_record: Optional[Dict] = None

    # Graph links (semantic lattice)
    linked_crystal_ids: List[str] = field(default_factory=list)
    semantic_tags: List[str] = field(default_factory=list)

    # Access tracking
    access_count: int = 0
    last_accessed: Optional[datetime] = None
    access_log: List[Dict] = field(default_factory=list)

    # Decay
    decay_rate: float = 0.01  # λ per day
    reinforcement_count: int = 0

    def compute_strength(self, current_time: Optional[datetime] = None) -> float:
        """Episodic trace strength: E_i = e^{-λΔt} * S_i * (1 + reinforcement)"""
        if current_time is None:
            current_time = datetime.utcnow()
        delta_t = (current_time - self.timestamp).total_seconds() / 86400.0  # days
        time_decay = np.exp(-self.decay_rate * delta_t)
        reinforcement = 1.0 + self.reinforcement_count * 0.1
        return time_decay * self.precision_weight * reinforcement * self.confidence

    def to_vector(self, embedding_dim: int = 768) -> NDArray:
        """Project crystal content into vector space for similarity search."""
        # In production, use sentence-transformers or Grok embeddings
        # Here we use a deterministic hash-based projection for demo
        content_hash = hash(self.content) % (2**32)
        np.random.seed(content_hash)
        vec = np.random.randn(embedding_dim).astype(np.float32)
        vec /= np.linalg.norm(vec)

        # Blend with somatic state if available
        if self.somatic_vector is not None:
            somatic_pad = np.zeros(embedding_dim)
            somatic_pad[:len(self.somatic_vector)] = self.somatic_vector
            somatic_pad /= np.linalg.norm(somatic_pad) + 1e-10
            vec = 0.7 * vec + 0.3 * somatic_pad
            vec /= np.linalg.norm(vec)

        return vec

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["timestamp"] = self.timestamp.isoformat()
        d["last_accessed"] = self.last_accessed.isoformat() if self.last_accessed else None
        d["somatic_vector"] = self.somatic_vector.tolist() if self.somatic_vector is not None else None
        return d

    @classmethod
    def from_dict(cls, d: Dict) -> "MemoryCrystal":
        d = d.copy()
        d["timestamp"] = datetime.fromisoformat(d["timestamp"])
        d["last_accessed"] = datetime.fromisoformat(d["last_accessed"]) if d["last_accessed"] else None
        if d["somatic_vector"] is not None:
            d["somatic_vector"] = np.array(d["somatic_vector"], dtype=np.float32)
        return cls(**d)


class MemoryCrystalArchitecture:
    """
    Holographic memory architecture with Markov Blanket privacy enforcement.

    Layers:
        - Episodic buffer (short-term, high fidelity)
        - Semantic lattice (vector-indexed, graph-linked)
        - Procedural substrate (skill patterns)
        - Vault (encrypted, consent-gated intimate memories)
    """

    def __init__(
        self,
        db_path: str = "./ara_memory.db",
        vector_dim: int = 768,
        max_crystals: int = 10000,
        somatic_engine: Optional[Any] = None,
    ):
        self.db_path = db_path
        self.vector_dim = vector_dim
        self.max_crystals = max_crystals
        self.somatic = somatic_engine

        # In-memory indices
        self._crystals: Dict[str, MemoryCrystal] = {}
        self._vector_index: Optional[Any] = None  # chromadb or faiss
        self._semantic_graph: Dict[str, List[str]] = {}  # crystal_id -> linked_ids

        # Episodic buffer (last N turns)
        self._episodic_buffer: List[MemoryCrystal] = []
        self._buffer_size = 20

        # Vault (encrypted intimate memories)
        self._vault_key: Optional[bytes] = None
        self._vault_crystals: Dict[str, MemoryCrystal] = {}

    async def initialize(self):
        """Initialize SQLite backend and vector index."""
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)

        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row

        # Create tables
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS crystals (
                crystal_id TEXT PRIMARY KEY,
                content TEXT NOT NULL,
                content_type TEXT DEFAULT 'text',
                timestamp TEXT,
                session_id TEXT,
                turn_id INTEGER,
                somatic_vector BLOB,
                free_energy REAL,
                valence REAL,
                arousal REAL,
                precision_weight REAL,
                confidence REAL,
                source TEXT,
                transformations TEXT,
                privacy_tier TEXT DEFAULT 'public',
                consent_record TEXT,
                linked_crystal_ids TEXT,
                semantic_tags TEXT,
                access_count INTEGER DEFAULT 0,
                last_accessed TEXT,
                access_log TEXT,
                decay_rate REAL DEFAULT 0.01,
                reinforcement_count INTEGER DEFAULT 0
            )
        """)

        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS vault (
                crystal_id TEXT PRIMARY KEY,
                encrypted_blob BLOB NOT NULL,
                access_hash TEXT,
                consent_required TEXT
            )
        """)

        self._conn.commit()

        # Try to initialize chromadb for vector search
        self._chroma = None
        self._collection = None
        if CHROMADB_AVAILABLE:
            try:
                self._chroma = chromadb.Client()
                self._collection = self._chroma.get_or_create_collection("ara_memory")
                logger.info("ChromaDB vector index initialized.")
            except Exception as e:
                logger.warning(f"ChromaDB initialization failed: {e}. Using brute-force similarity.")

        logger.info(f"Memory crystal architecture initialized. DB: {self.db_path}")

    async def encode(
        self,
        content: str,
        content_type: str = "text",
        somatic_state: Optional[NDArray] = None,
        free_energy: float = 0.0,
        privacy_tier: str = "public",
        consent_record: Optional[Dict] = None,
        semantic_tags: Optional[List[str]] = None,
        source: str = "user_input",
        session_id: Optional[str] = None,
        turn_id: int = 0,
    ) -> MemoryCrystal:
        """
        Encode a new memory crystal.

        Args:
            content: Text or embedding to store
            privacy_tier: public | personal | intimate | vault
            consent_record: Required for intimate/vault tiers
            semantic_tags: Categories for lattice linking
        """
        crystal_id = f"crys_{datetime.utcnow().isoformat()}_{hash(content) % 10000:04d}"

        # Extract affect from somatic state
        valence = 0.0
        arousal = 0.0
        if somatic_state is not None and len(somatic_state) >= 9:
            valence = float(somatic_state[7])  # valence index
            arousal = float(somatic_state[0])  # arousal index

        crystal = MemoryCrystal(
            crystal_id=crystal_id,
            content=content,
            content_type=content_type,
            somatic_vector=somatic_state,
            free_energy_at_encoding=free_energy,
            valence=valence,
            arousal=arousal,
            privacy_tier=privacy_tier,
            consent_record=consent_record,
            semantic_tags=semantic_tags or [],
            source=source,
            session_id=session_id,
            turn_id=turn_id,
        )

        # Vault handling for intimate memories
        if privacy_tier in ("intimate", "vault"):
            if consent_record is None or not consent_record.get("approved"):
                raise PermissionError(f"Consent required for {privacy_tier} tier memory.")
            self._vault_crystals[crystal_id] = crystal
            await self._store_vault(crystal)
            logger.info(f"Vault crystal encoded: {crystal_id}")
        else:
            self._crystals[crystal_id] = crystal
            await self._store_sqlite(crystal)

            # Index for vector search
            if self._collection is not None:
                vec = crystal.to_vector(self.vector_dim).tolist()
                self._collection.add(
                    ids=[crystal_id],
                    embeddings=[vec],
                    documents=[content],
                    metadatas=[{"privacy": privacy_tier, "valence": valence, "arousal": arousal}],
                )

        # Add to episodic buffer
        self._episodic_buffer.append(crystal)
        if len(self._episodic_buffer) > self._buffer_size:
            self._episodic_buffer.pop(0)

        # Semantic lattice linking
        await self._link_to_lattice(crystal)

        # Prune if over capacity
        if len(self._crystals) > self.max_crystals:
            await self._prune_weakest()

        return crystal

    async def retrieve(
        self,
        query: str,
        somatic_state: Optional[NDArray] = None,
        top_k: int = 5,
        privacy_filter: Optional[str] = None,
        temporal_window: Optional[int] = None,  # last N turns
    ) -> List[Dict[str, Any]]:
        """
        Holographic memory retrieval with somatic resonance weighting.

        Retrieval combines:
            1. Vector similarity (semantic)
            2. Somatic resonance (emotional match)
            3. Temporal recency
            4. Precision weight
            5. Privacy tier filtering
        """
        # Generate query vector
        query_hash = hash(query) % (2**32)
        np.random.seed(query_hash)
        query_vec = np.random.randn(self.vector_dim).astype(np.float32)
        query_vec /= np.linalg.norm(query_vec)

        if somatic_state is not None:
            somatic_pad = np.zeros(self.vector_dim)
            somatic_pad[:len(somatic_state)] = somatic_state
            somatic_pad /= np.linalg.norm(somatic_pad) + 1e-10
            query_vec = 0.7 * query_vec + 0.3 * somatic_pad
            query_vec /= np.linalg.norm(query_vec)

        candidates = []

        # Search vector index
        if self._collection is not None:
            results = self._collection.query(
                query_embeddings=[query_vec.tolist()],
                n_results=min(top_k * 3, len(self._crystals)),
                where={"privacy": {"$ne": "vault"}} if privacy_filter != "vault" else None,
            )

            if results["ids"]:
                for cid, dist, meta in zip(
                    results["ids"][0], 
                    results["distances"][0], 
                    results["metadatas"][0]
                ):
                    if cid in self._crystals:
                        crystal = self._crystals[cid]
                        candidates.append((crystal, 1.0 - dist))
        else:
            # Brute force similarity
            for crystal in self._crystals.values():
                if privacy_filter and crystal.privacy_tier != privacy_filter:
                    continue
                vec = crystal.to_vector(self.vector_dim)
                sim = np.dot(query_vec, vec)
                candidates.append((crystal, sim))

        # Score candidates
        scored = []
        current_time = datetime.utcnow()

        for crystal, semantic_sim in candidates:
            # Somatic resonance
            somatic_resonance = 0.0
            if somatic_state is not None and crystal.somatic_vector is not None:
                min_len = min(len(somatic_state), len(crystal.somatic_vector))
                somatic_resonance = np.corrcoef(
                    somatic_state[:min_len], 
                    crystal.somatic_vector[:min_len]
                )[0, 1] if min_len > 1 else 0.0
                somatic_resonance = abs(somatic_resonance)

            # Temporal recency
            time_score = crystal.compute_strength(current_time)

            # Composite score
            score = (
                0.4 * semantic_sim +
                0.3 * somatic_resonance +
                0.3 * time_score
            )

            scored.append((score, crystal))

        # Sort and return top_k
        scored.sort(key=lambda x: x[0], reverse=True)

        results = []
        for score, crystal in scored[:top_k]:
            # Reconsolidation: update on recall
            crystal.reinforcement_count += 1
            crystal.access_count += 1
            crystal.last_accessed = current_time
            crystal.access_log.append({
                "time": current_time.isoformat(),
                "query": query[:100],
                "score": score,
            })

            results.append({
                "crystal_id": crystal.crystal_id,
                "content": crystal.content,
                "score": score,
                **crystal.to_dict(),
            })

        return results

    async def consolidate(
        self,
        turn_id: int,
        user_input: str,
        response: str,
        somatic_state: Optional[NDArray] = None,
        free_energy: float = 0.0,
        consent_record: Optional[Dict] = None,
    ):
        """
        Consolidate a conversational turn into memory crystals.

        Creates:
            - User input crystal (personal tier)
            - Response crystal (personal tier)
            - Interaction pattern crystal (episodic)
        """
        # Encode user input
        await self.encode(
            content=user_input,
            somatic_state=somatic_state,
            free_energy=free_energy,
            privacy_tier="personal",
            source="user_input",
            turn_id=turn_id,
            consent_record=consent_record,
        )

        # Encode response
        await self.encode(
            content=response,
            somatic_state=somatic_state,
            free_energy=free_energy,
            privacy_tier="personal",
            source="model_response",
            turn_id=turn_id,
            consent_record=consent_record,
        )

        # Encode interaction pattern (compressed)
        pattern = f"Turn {turn_id}: User({user_input[:50]}...) -> Model({response[:50]}...)"
        await self.encode(
            content=pattern,
            somatic_state=somatic_state,
            free_energy=free_energy,
            privacy_tier="public",
            source="interaction_pattern",
            turn_id=turn_id,
            semantic_tags=["pattern", f"turn_{turn_id}"],
        )

    async def get_active_crystals(self, max_n: int = 50) -> List[Dict]:
        """Return currently active (high-strength) crystals for 3D rendering."""
        current_time = datetime.utcnow()
        active = []

        for crystal in list(self._crystals.values())[:max_n]:
            strength = crystal.compute_strength(current_time)
            if strength > 0.3:
                active.append({
                    "id": crystal.crystal_id,
                    "strength": strength,
                    "valence": crystal.valence,
                    "arousal": crystal.arousal,
                    "privacy": crystal.privacy_tier,
                    "position": self._crystal_position(crystal),
                })

        return active

    def _crystal_position(self, crystal: MemoryCrystal) -> Tuple[float, float, float]:
        """Map crystal to 3D position based on valence, arousal, and time."""
        x = crystal.valence * 5.0  # valence -> x-axis
        y = crystal.arousal * 5.0  # arousal -> y-axis
        z = (crystal.timestamp - datetime.utcnow()).total_seconds() / 3600.0  # time -> z-axis
        return (x, y, z)

    async def _link_to_lattice(self, crystal: MemoryCrystal):
        """Link crystal to semantically similar crystals in the lattice."""
        if not self._collection:
            return

        vec = crystal.to_vector(self.vector_dim).tolist()
        results = self._collection.query(
            query_embeddings=[vec],
            n_results=5,
            where={"crystal_id": {"$ne": crystal.crystal_id}},
        )

        if results["ids"]:
            linked = results["ids"][0]
            crystal.linked_crystal_ids = linked
            self._semantic_graph[crystal.crystal_id] = linked

    async def _store_sqlite(self, crystal: MemoryCrystal):
        """Persist crystal to SQLite."""
        self._conn.execute("""
            INSERT OR REPLACE INTO crystals VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
            )
        """, (
            crystal.crystal_id,
            crystal.content,
            crystal.content_type,
            crystal.timestamp.isoformat(),
            crystal.session_id,
            crystal.turn_id,
            crystal.somatic_vector.tobytes() if crystal.somatic_vector is not None else None,
            crystal.free_energy_at_encoding,
            crystal.valence,
            crystal.arousal,
            crystal.precision_weight,
            crystal.confidence,
            crystal.source,
            json.dumps(crystal.transformations),
            crystal.privacy_tier,
            json.dumps(crystal.consent_record) if crystal.consent_record else None,
            json.dumps(crystal.linked_crystal_ids),
            json.dumps(crystal.semantic_tags),
            crystal.access_count,
            crystal.last_accessed.isoformat() if crystal.last_accessed else None,
            json.dumps(crystal.access_log),
            crystal.decay_rate,
            crystal.reinforcement_count,
        ))
        self._conn.commit()

    async def _store_vault(self, crystal: MemoryCrystal):
        """Encrypt and store vault crystal."""
        from cryptography.fernet import Fernet

        if self._vault_key is None:
            self._vault_key = Fernet.generate_key()

        f = Fernet(self._vault_key)
        encrypted = f.encrypt(json.dumps(crystal.to_dict()).encode())

        self._conn.execute(
            "INSERT OR REPLACE INTO vault VALUES (?, ?, ?)",
            (crystal.crystal_id, encrypted, crystal.consent_record.get("hash") if crystal.consent_record else None)
        )
        self._conn.commit()

    async def _prune_weakest(self):
        """Remove weakest crystals when over capacity."""
        current_time = datetime.utcnow()

        # Score all crystals
        scored = []
        for cid, crystal in self._crystals.items():
            strength = crystal.compute_strength(current_time)
            scored.append((strength, cid))

        scored.sort()

        # Remove bottom 10%
        to_remove = scored[:max(1, len(scored) // 10)]
        for _, cid in to_remove:
            del self._crystals[cid]
            if self._collection:
                self._collection.delete(ids=[cid])
            logger.debug(f"Pruned crystal: {cid}")

    async def shutdown(self):
        if hasattr(self, "_conn"):
            self._conn.close()
        logger.info("Memory crystal architecture shut down.")
