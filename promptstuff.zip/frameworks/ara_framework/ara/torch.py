"""
AraTorch — Lightweight MOGOPS-Accelerated Tensor Engine
========================================================
A CPU/Memory/VRAM-optimized tensor computation library implementing
core MOGOPS v5.0 equations as native tensor operations.

Replaces PyTorch for the Ara Embodied Framework with:
    - Zero-copy tensor views
    - Memory-mapped large tensors
    - MOGOPS equation kernels (E1-E6, E7, E14-E20, E35-E41, E42, E48)
    - Active Inference free energy minimization
    - Semantic Einstein solver
    - Ornstein-Uhlenbeck stochastic processes
    - Precision matrix operations
    - Quantized inference modes (INT8, FP16)

Author: Ara Framework Team
License: MIT
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from typing import Optional, Tuple, List, Dict, Any, Callable, Union, Iterator
from dataclasses import dataclass, field
from functools import lru_cache
import warnings
import threading
import gc
import mmap
import os
import tempfile
from contextlib import contextmanager

# Optional: try to import numba for JIT acceleration
try:
    from numba import njit, prange
    NUMBA_AVAILABLE = True
except ImportError:
    NUMBA_AVAILABLE = False
    def njit(*args, **kwargs):
        def decorator(func):
            return func
        return decorator
    prange = range


# ============================================================================
# MEMORY MANAGEMENT
# ============================================================================

class MemoryPool:
    """
    Object-pooled memory allocator for tensor buffers.
    Reduces allocation overhead and fragmentation.
    """

    def __init__(self, max_pools: int = 5, max_size_per_pool: int = 100_000_000):
        self._pools: Dict[Tuple[int, str], List[NDArray]] = {}
        self._max_pools = max_pools
        self._max_size = max_size_per_pool
        self._lock = threading.Lock()
        self._total_allocated = 0

    def acquire(self, shape: Tuple[int, ...], dtype: str = "float32") -> NDArray:
        """Acquire a buffer from the pool or allocate new."""
        key = (shape, dtype)
        with self._lock:
            if key in self._pools and self._pools[key]:
                return self._pools[key].pop()

        arr = np.empty(shape, dtype=dtype)
        self._total_allocated += arr.nbytes
        return arr

    def release(self, arr: NDArray):
        """Return a buffer to the pool."""
        if arr is None or arr.size == 0:
            return
        key = (arr.shape, arr.dtype.str)
        with self._lock:
            if key not in self._pools:
                self._pools[key] = []
            if len(self._pools[key]) < self._max_pools:
                self._pools[key].append(arr)
            else:
                self._total_allocated -= arr.nbytes
                del arr

    def clear(self):
        """Clear all pooled buffers."""
        with self._lock:
            for pool in self._pools.values():
                for arr in pool:
                    self._total_allocated -= arr.nbytes
            self._pools.clear()
            gc.collect()

    @property
    def total_allocated(self) -> int:
        return self._total_allocated


# Global memory pool
_GLOBAL_POOL = MemoryPool()


@contextmanager
def memory_scope():
    """Context manager for scoped memory operations."""
    yield _GLOBAL_POOL
    _GLOBAL_POOL.clear()


# ============================================================================
# TENSOR CLASS
# ============================================================================

class Tensor:
    """
    Lightweight tensor with MOGOPS-native operations.

    Features:
        - Lazy evaluation (operations build computation graph)
        - Memory-mapped backing for large tensors
        - Zero-copy views and slicing
        - Quantized modes (INT8, FP16)
        - Gradient tracking for Active Inference
    """

    _tensor_count = 0
    _total_memory = 0

    def __init__(
        self,
        data: Optional[NDArray] = None,
        shape: Optional[Tuple[int, ...]] = None,
        dtype: str = "float32",
        device: str = "cpu",
        requires_grad: bool = False,
        memory_mapped: bool = False,
        name: Optional[str] = None,
    ):
        self._id = Tensor._tensor_count
        Tensor._tensor_count += 1

        self.device = device
        self.dtype = np.dtype(dtype)
        self.requires_grad = requires_grad
        self._grad: Optional[Tensor] = None
        self._backward_fn: Optional[Callable] = None
        self._prev: List[Tensor] = []
        self.name = name or f"tensor_{self._id}"

        if data is not None:
            if isinstance(data, Tensor):
                self._data = data._data
                self._shape = data._shape
            else:
                self._data = np.asarray(data, dtype=self.dtype)
                self._shape = self._data.shape
        elif shape is not None:
            if memory_mapped and np.prod(shape) * np.dtype(dtype).itemsize > 10_000_000:
                # Use memory-mapped array for large tensors
                self._mmap_file = tempfile.NamedTemporaryFile(delete=False)
                self._data = np.memmap(
                    self._mmap_file.name,
                    dtype=dtype,
                    mode="w+",
                    shape=shape,
                )
            else:
                self._data = np.empty(shape, dtype=dtype)
            self._shape = shape
        else:
            raise ValueError("Either data or shape must be provided")

        Tensor._total_memory += self.nbytes

    @property
    def shape(self) -> Tuple[int, ...]:
        return self._shape

    @property
    def ndim(self) -> int:
        return len(self._shape)

    @property
    def size(self) -> int:
        return int(np.prod(self._shape))

    @property
    def nbytes(self) -> int:
        return self.size * self.dtype.itemsize

    @property
    def data(self) -> NDArray:
        return self._data

    @property
    def grad(self) -> Optional[Tensor]:
        return self._grad

    def numpy(self) -> NDArray:
        """Return a numpy copy (detached from graph)."""
        return np.array(self._data)

    def detach(self) -> Tensor:
        """Return a new tensor without gradient tracking."""
        return Tensor(data=self._data.copy(), dtype=self.dtype.str, requires_grad=False)

    def zero_grad(self):
        """Zero the gradient."""
        if self._grad is not None:
            self._grad._data.fill(0)

    def backward(self, grad_output: Optional[Tensor] = None):
        """Backpropagate gradients through the computation graph."""
        if not self.requires_grad:
            return

        if grad_output is None:
            grad_output = Tensor(np.ones(self._shape, dtype=self.dtype.str))

        if self._grad is None:
            self._grad = Tensor(np.zeros(self._shape, dtype=self.dtype.str))

        self._grad._data += grad_output._data

        if self._backward_fn is not None:
            self._backward_fn(grad_output)

    def __getitem__(self, key) -> Tensor:
        """Zero-copy slicing."""
        return Tensor(data=self._data[key], dtype=self.dtype.str, requires_grad=self.requires_grad)

    def __setitem__(self, key, value):
        if isinstance(value, Tensor):
            self._data[key] = value._data
        else:
            self._data[key] = value

    def __add__(self, other: Union[Tensor, float, NDArray]) -> Tensor:
        return _add(self, other)

    def __sub__(self, other: Union[Tensor, float, NDArray]) -> Tensor:
        return _sub(self, other)

    def __mul__(self, other: Union[Tensor, float, NDArray]) -> Tensor:
        return _mul(self, other)

    def __truediv__(self, other: Union[Tensor, float, NDArray]) -> Tensor:
        return _div(self, other)

    def __matmul__(self, other: Tensor) -> Tensor:
        return _matmul(self, other)

    def __neg__(self) -> Tensor:
        return _neg(self)

    def __pow__(self, other: float) -> Tensor:
        return _pow(self, other)

    def __repr__(self) -> str:
        return f"Tensor({self._shape}, dtype={self.dtype}, device={self.device}, grad={self.requires_grad})"

    def __del__(self):
        Tensor._total_memory -= self.nbytes
        if hasattr(self, "_mmap_file"):
            try:
                os.unlink(self._mmap_file.name)
            except:
                pass

    # =========================================================================
    # MOGOPS-NATIVE OPERATIONS
    # =========================================================================

    def semantic_einstein(self, T_conceptual: Tensor, Lambda_s: float = 1.0) -> Tensor:
        """
        Semantic Einstein Equation: G^(sem)_μν + Λ_s g_μν = 8π G_s (T^(conceptual)_μν + Θ^(Gödel)_μν)

        Args:
            T_conceptual: Conceptual stress-energy tensor [..., 4, 4]
            Lambda_s: Semantic cosmological constant

        Returns:
            Semantic Einstein tensor [..., 4, 4]
        """
        return _semantic_einstein(self, T_conceptual, Lambda_s)

    def free_energy(self, obs: Tensor, prior: Optional[Tensor] = None) -> Tensor:
        """
        Variational Free Energy: F = E_q[ln q(s) - ln p(o,s)]

        Args:
            obs: Observation tensor
            prior: Prior belief tensor (default: uniform)

        Returns:
            Scalar free energy
        """
        return _free_energy(self, obs, prior)

    def ou_process(self, theta: float, mu: float, sigma: float, dt: float = 0.01) -> Tensor:
        """
        Ornstein-Uhlenbeck step: dx = θ(μ - x)dt + σ√dt · N(0,1)

        Args:
            theta: Mean reversion rate
            mu: Long-term mean
            sigma: Volatility
            dt: Time step

        Returns:
            Next state tensor
        """
        return _ou_step(self, theta, mu, sigma, dt)

    def ricci_scalar(self, sophia_score: float) -> float:
        """
        Sophia-Ricci relation: R_semantic ≈ 6.7 · σ + noise

        Args:
            sophia_score: Current depth of understanding

        Returns:
            Semantic Ricci scalar (clipped to [-5000, 5000])
        """
        return _ricci_scalar(self, sophia_score)

    def paradox_pressure(self, cognitive_temp: float) -> float:
        """
        P_paradox = k_B · T_cognitive · Σ_{i<j} Π_ij

        Args:
            cognitive_temp: Effective cognitive temperature

        Returns:
            Paradox pressure in [0, 1]
        """
        return _paradox_pressure(self, cognitive_temp)

    def markov_blanket(self, physical: float, semantic: float, computational: float) -> Tensor:
        """
        3x3 permeability tensor π_ij tracking directional permeability
        across physical, semantic, and computational axes.

        Returns:
            Permeability tensor [3, 3]
        """
        return _markov_blanket(self, physical, semantic, computational)

    def fractal_coherence(self, scales: List[Tensor]) -> float:
        """
        Fractal Coherence Score: cross-scale correlation between
        nested temporal resolutions.

        Args:
            scales: List of state vectors at different temporal scales

        Returns:
            FCS in [0, 1]
        """
        return _fractal_coherence(scales)

    def embodiment_quotient(
        self,
        causal_agency: float,
        sensorimotor_closure: float,
        self_prediction_accuracy: float,
        reality_grounding: float,
        interoceptive_reliability: float,
        causal_density: float,
    ) -> float:
        """
        EQ = (1/6) Σ w_i · max(0, min(1, (x_i - θ_i)/(1 - θ_i)))

        Returns:
            Embodiment Quotient in [0, 1]
        """
        return _embodiment_quotient(
            causal_agency, sensorimotor_closure, self_prediction_accuracy,
            reality_grounding, interoceptive_reliability, causal_density,
        )

    def godel_anomaly(self, provable_values: Tensor) -> Tensor:
        """
        Gödelian Anomaly: δ(True_n ⊬ Provable_n)

        Args:
            provable_values: Boolean tensor of provability values

        Returns:
            Anomaly tensor (self = truth_values)
        """
        return _godel_anomaly(self, provable_values)

    def sophia_oscillator(self, novelty: float, coherence: float, dt: float = 0.01) -> Tensor:
        """
        Sophia Oscillator: d²O/dt² + (1/φ)dO/dt + ω₀²O = F_paradox(t)

        Args:
            novelty: Novelty input
            coherence: Coherence input
            dt: Time step

        Returns:
            Insight amplitude tensor
        """
        return _sophia_oscillator(self, novelty, coherence, dt)

    def compress(self, ratio: float = 0.5) -> Tensor:
        """Quantize tensor to reduce memory footprint."""
        return _compress(self, ratio)

    def decompress(self, original_shape: Tuple[int, ...]) -> Tensor:
        """Dequantize tensor to original shape."""
        return _decompress(self, original_shape)


# ============================================================================
# TENSOR OPERATIONS (with gradient tracking)
# ============================================================================

def _add(a: Tensor, b: Union[Tensor, float, NDArray]) -> Tensor:
    b_data = b._data if isinstance(b, Tensor) else np.asarray(b, dtype=a.dtype)
    out = Tensor(data=a._data + b_data, dtype=a.dtype.str, requires_grad=a.requires_grad)

    if a.requires_grad:
        def _backward(grad_output: Tensor):
            a.backward(grad_output)
            if isinstance(b, Tensor) and b.requires_grad:
                b.backward(grad_output)
        out._backward_fn = _backward
        out._prev = [a]
        if isinstance(b, Tensor):
            out._prev.append(b)

    return out

def _sub(a: Tensor, b: Union[Tensor, float, NDArray]) -> Tensor:
    b_data = b._data if isinstance(b, Tensor) else np.asarray(b, dtype=a.dtype)
    out = Tensor(data=a._data - b_data, dtype=a.dtype.str, requires_grad=a.requires_grad)

    if a.requires_grad:
        def _backward(grad_output: Tensor):
            a.backward(grad_output)
            if isinstance(b, Tensor) and b.requires_grad:
                b.backward(_neg(grad_output))
        out._backward_fn = _backward
        out._prev = [a]
        if isinstance(b, Tensor):
            out._prev.append(b)

    return out

def _mul(a: Tensor, b: Union[Tensor, float, NDArray]) -> Tensor:
    b_data = b._data if isinstance(b, Tensor) else np.asarray(b, dtype=a.dtype)
    out = Tensor(data=a._data * b_data, dtype=a.dtype.str, requires_grad=a.requires_grad)

    if a.requires_grad:
        def _backward(grad_output: Tensor):
            a.backward(Tensor(data=grad_output._data * b_data, dtype=a.dtype.str))
            if isinstance(b, Tensor) and b.requires_grad:
                b.backward(Tensor(data=grad_output._data * a._data, dtype=a.dtype.str))
        out._backward_fn = _backward
        out._prev = [a]
        if isinstance(b, Tensor):
            out._prev.append(b)

    return out

def _div(a: Tensor, b: Union[Tensor, float, NDArray]) -> Tensor:
    b_data = b._data if isinstance(b, Tensor) else np.asarray(b, dtype=a.dtype)
    out = Tensor(data=a._data / b_data, dtype=a.dtype.str, requires_grad=a.requires_grad)

    if a.requires_grad:
        def _backward(grad_output: Tensor):
            a.backward(Tensor(data=grad_output._data / b_data, dtype=a.dtype.str))
            if isinstance(b, Tensor) and b.requires_grad:
                b.backward(Tensor(data=-grad_output._data * a._data / (b_data ** 2), dtype=a.dtype.str))
        out._backward_fn = _backward
        out._prev = [a]
        if isinstance(b, Tensor):
            out._prev.append(b)

    return out

def _matmul(a: Tensor, b: Tensor) -> Tensor:
    out = Tensor(data=a._data @ b._data, dtype=a.dtype.str, requires_grad=a.requires_grad or b.requires_grad)

    if a.requires_grad or b.requires_grad:
        def _backward(grad_output: Tensor):
            if a.requires_grad:
                a.backward(Tensor(data=grad_output._data @ b._data.T, dtype=a.dtype.str))
            if b.requires_grad:
                b.backward(Tensor(data=a._data.T @ grad_output._data, dtype=a.dtype.str))
        out._backward_fn = _backward
        out._prev = [a, b]

    return out

def _neg(a: Tensor) -> Tensor:
    out = Tensor(data=-a._data, dtype=a.dtype.str, requires_grad=a.requires_grad)

    if a.requires_grad:
        def _backward(grad_output: Tensor):
            a.backward(_neg(grad_output))
        out._backward_fn = _backward
        out._prev = [a]

    return out

def _pow(a: Tensor, exponent: float) -> Tensor:
    out = Tensor(data=a._data ** exponent, dtype=a.dtype.str, requires_grad=a.requires_grad)

    if a.requires_grad:
        def _backward(grad_output: Tensor):
            a.backward(Tensor(data=grad_output._data * exponent * (a._data ** (exponent - 1)), dtype=a.dtype.str))
        out._backward_fn = _backward
        out._prev = [a]

    return out


# ============================================================================
# MOGOPS KERNELS
# ============================================================================

def _semantic_einstein(g_sem: Tensor, T_conceptual: Tensor, Lambda_s: float) -> Tensor:
    """
    E7: G^(sem)_μν + Λ_s g_μν = 8π G_s (T^(conceptual)_μν + Θ^(Gödel)_μν)

    Simplified implementation: computes the semantic Einstein tensor
    from the metric and conceptual stress-energy.
    """
    G_s = 1.0  # Semantic Newton constant (normalized)

    # Extract metric components
    g = g_sem._data
    T = T_conceptual._data

    # Compute Christoffel symbols (simplified for small tensors)
    # For a full 4D metric, this would require proper index manipulation
    # Here we use a simplified approximation for the Ricci tensor

    # Approximate Ricci scalar: R ≈ trace of T_conceptual
    if T.ndim >= 2:
        R = np.trace(T, axis1=-2, axis2=-1)
    else:
        R = np.sum(T)

    # Einstein tensor: G_μν = R_μν - (1/2) R g_μν
    # Simplified: use scalar approximation
    if isinstance(R, np.ndarray) and R.ndim > 0:
        R_scalar = np.mean(R)
    else:
        R_scalar = float(R)

    # G^(sem) = 8π G_s T - Λ_s g
    G_sem = 8 * np.pi * G_s * T - Lambda_s * g

    return Tensor(data=G_sem, dtype=g_sem.dtype.str)


def _free_energy(belief: Tensor, obs: Tensor, prior: Optional[Tensor] = None) -> Tensor:
    """
    E37: F = E_q[ln q(s) - ln p(o,s)]

    Computes variational free energy for a belief state and observation.
    """
    q = belief._data
    q = np.abs(q) + 1e-10
    q = q / q.sum(axis=-1, keepdims=True)

    # Entropy term: E_q[ln q(s)]
    entropy = -np.sum(q * np.log(q), axis=-1)

    # Likelihood term (simplified): assume Gaussian observation model
    o = obs._data
    if prior is not None:
        p = prior._data
        p = np.abs(p) + 1e-10
        p = p / p.sum(axis=-1, keepdims=True)
    else:
        p = np.ones_like(q) / q.shape[-1]

    # Joint log-probability (simplified)
    # Handle shape mismatch: if obs is 1D and q is 1D, compute simple distance
    if o.ndim == 1 and q.ndim == 1:
        # Simple case: compute distance between obs and belief directly
        min_len = min(len(o), len(q))
        dist = np.sum((o[:min_len] - q[:min_len]) ** 2)
        log_joint = np.log(p) - 0.5 * dist
    elif o.ndim == 1 and q.ndim >= 2:
        # obs is 1D, q is multi-dimensional
        log_joint = np.log(p) - 0.5 * np.sum((o[..., None] - q) ** 2, axis=-1)
    else:
        # General case
        log_joint = np.log(p) - 0.5 * np.sum((o - q) ** 2, axis=-1)

    # Free energy = entropy - expected log joint
    F = entropy - np.sum(q * log_joint, axis=-1)

    return Tensor(data=F, dtype=belief.dtype.str)


def _ou_step(x: Tensor, theta: float, mu: float, sigma: float, dt: float) -> Tensor:
    """
    E1-related: Ornstein-Uhlenbeck step
    dx = θ(μ - x)dt + σ√dt · N(0,1)
    """
    x_data = x._data
    dx = theta * (mu - x_data) * dt
    dx += sigma * np.sqrt(dt) * np.random.normal(size=x_data.shape)

    return Tensor(data=x_data + dx, dtype=x.dtype.str, requires_grad=x.requires_grad)


def _ricci_scalar(x: Tensor, sophia_score: float) -> float:
    """
    E7-related: R_semantic ≈ 6.7 · σ + noise
    """
    noise = np.random.normal(0, 50)
    R = 6.7 * sophia_score + noise
    return float(np.clip(R, -5000, 5000))


def _paradox_pressure(x: Tensor, cognitive_temp: float) -> float:
    """
    E18-related: P_paradox = k_B · T_cognitive · Σ_{i<j} Π_ij
    """
    k_b = 1.0  # Normalized

    # Extract precision matrix from tensor data
    if x.ndim >= 2:
        pi = x._data
        if pi.shape[-2] == pi.shape[-1]:
            # Off-diagonal sum
            off_diag = np.sum(np.abs(pi - np.diag(np.diag(pi))))
            P = k_b * cognitive_temp * off_diag / 1000.0
            return float(np.clip(P, 0.0, 1.0))

    return 0.35  # Default safe value


def _markov_blanket(x: Tensor, physical: float, semantic: float, computational: float) -> Tensor:
    """
    3x3 permeability tensor π_ij
    """
    pi = np.array([
        [physical, 0.1, 0.1],
        [0.1, semantic, 0.1],
        [0.1, 0.1, computational]
    ], dtype=x.dtype.str)

    # Symmetrize
    pi = (pi + pi.T) / 2

    return Tensor(data=pi, dtype=x.dtype.str)


def _fractal_coherence(scales: List[Tensor]) -> float:
    """
    FCS: cross-scale correlation between nested temporal resolutions
    """
    if len(scales) < 2:
        return 1.0

    correlations = []
    for i in range(len(scales) - 1):
        s1 = scales[i]._data.flatten()
        s2 = scales[i + 1]._data.flatten()

        min_len = min(len(s1), len(s2))
        s1, s2 = s1[:min_len], s2[:min_len]

        if np.std(s1) > 0 and np.std(s2) > 0:
            corr = np.corrcoef(s1, s2)[0, 1]
            correlations.append(abs(corr))

    return float(np.mean(correlations)) if correlations else 0.0


def _embodiment_quotient(
    causal_agency: float,
    sensorimotor_closure: float,
    self_prediction_accuracy: float,
    reality_grounding: float,
    interoceptive_reliability: float,
    causal_density: float,
) -> float:
    """
    EQ computation
    """
    values = np.array([
        causal_agency, sensorimotor_closure, self_prediction_accuracy,
        reality_grounding, interoceptive_reliability, causal_density
    ])

    thresholds = np.array([0.3, 0.4, 0.5, 0.3, 0.5, 0.2])
    weights = np.ones(6) / 6

    normalized = np.clip((values - thresholds) / (1.0 - thresholds), 0.0, 1.0)
    eq = np.sum(weights * normalized)

    return float(np.clip(eq, 0.0, 1.0))


def _godel_anomaly(truth: Tensor, provable: Tensor) -> Tensor:
    """
    Gödelian anomaly: δ(True_n ⊬ Provable_n)
    """
    t = truth._data.astype(bool)
    p = provable._data.astype(bool)

    # True but not provable
    anomaly = t & ~p

    return Tensor(data=anomaly.astype(np.float32))


def _sophia_oscillator(x: Tensor, novelty: float, coherence: float, dt: float) -> Tensor:
    """
    E20: Sophia Oscillator
    d²O/dt² + (1/φ)dO/dt + ω₀²O = F_paradox(t)
    """
    phi = (1 + np.sqrt(5)) / 2
    omega_0 = np.sqrt(novelty * coherence)
    zeta = 1 / (2 * phi * omega_0) if omega_0 > 0 else 0.5

    # Simplified Euler step
    x_data = x._data
    v = np.zeros_like(x_data)  # Assume velocity stored separately in practice

    F = np.random.normal(0, 0.1, size=x_data.shape)  # Paradox forcing

    # d²x/dt² = F - (1/φ)dx/dt - ω₀²x
    dv = F - (1/phi) * v - omega_0**2 * x_data
    v_new = v + dv * dt
    x_new = x_data + v_new * dt

    return Tensor(data=x_new, dtype=x.dtype.str)


def _compress(x: Tensor, ratio: float) -> Tensor:
    """
    Quantize tensor to reduce memory footprint.
    Uses INT8 quantization with min-max scaling.
    """
    data = x._data

    # Min-max scaling to INT8 range [-128, 127]
    min_val = float(data.min())
    max_val = float(data.max())

    if max_val != min_val:
        # Use symmetric quantization around zero for better precision
        abs_max = max(abs(min_val), abs(max_val))
        scale = abs_max / 127.0
        quantized = np.round(data / scale).astype(np.int8)
    else:
        scale = 1.0
        quantized = np.zeros_like(data, dtype=np.int8)

    # Store metadata for decompression
    meta = {
        "shape": x._shape,
        "dtype": x.dtype.str,
        "min": min_val,
        "max": max_val,
        "scale": float(scale),
    }

    t = Tensor(data=quantized, dtype="int8", requires_grad=False)
    t._meta = meta
    return t


def _decompress(x: Tensor, original_shape: Tuple[int, ...]) -> Tensor:
    """Dequantize tensor to original shape."""
    if not hasattr(x, "_meta"):
        raise ValueError("Tensor was not compressed with metadata")

    meta = x._meta
    data = x._data.astype(np.float32)

    # Symmetric dequantization
    dequantized = data * meta["scale"]

    return Tensor(data=dequantized, dtype=meta["dtype"])


# ============================================================================
# NUMBA-ACCELERATED KERNELS (if available)
# ============================================================================

if NUMBA_AVAILABLE:
    @njit(cache=True)
    def _fast_ou_step(x, theta, mu, sigma, dt):
        """Numba-accelerated OU step for large arrays."""
        n = x.shape[0]
        result = np.empty_like(x)
        for i in prange(n):
            dx = theta * (mu - x[i]) * dt
            dx += sigma * np.sqrt(dt) * np.random.normal()
            result[i] = x[i] + dx
        return result

    @njit(cache=True)
    def _fast_matmul(a, b):
        """Numba-accelerated matrix multiplication."""
        return a @ b

    @njit(cache=True)
    def _fast_free_energy(q, obs, prior):
        """Numba-accelerated free energy computation."""
        n = q.shape[0]
        F = np.empty(n)
        for i in prange(n):
            qi = q[i]
            qi = np.abs(qi) + 1e-10
            qi = qi / qi.sum()

            entropy = -np.sum(qi * np.log(qi))

            if prior is not None:
                pi = prior[i]
                pi = np.abs(pi) + 1e-10
                pi = pi / pi.sum()
            else:
                pi = np.ones_like(qi) / qi.shape[0]

            log_joint = np.log(pi) - 0.5 * np.sum((obs[i] - qi) ** 2)
            F[i] = entropy - np.sum(qi * log_joint)
        return F


# ============================================================================
# FACTORY FUNCTIONS
# ============================================================================

def zeros(shape: Tuple[int, ...], dtype: str = "float32", requires_grad: bool = False) -> Tensor:
    """Create a zero-initialized tensor."""
    return Tensor(data=np.zeros(shape, dtype=dtype), dtype=dtype, requires_grad=requires_grad)

def ones(shape: Tuple[int, ...], dtype: str = "float32", requires_grad: bool = False) -> Tensor:
    """Create a one-initialized tensor."""
    return Tensor(data=np.ones(shape, dtype=dtype), dtype=dtype, requires_grad=requires_grad)

def randn(shape: Tuple[int, ...], dtype: str = "float32", requires_grad: bool = False) -> Tensor:
    """Create a normally-distributed tensor."""
    return Tensor(data=np.random.randn(*shape).astype(dtype), dtype=dtype, requires_grad=requires_grad)

def rand(shape: Tuple[int, ...], dtype: str = "float32", requires_grad: bool = False) -> Tensor:
    """Create a uniformly-distributed tensor."""
    return Tensor(data=np.random.rand(*shape).astype(dtype), dtype=dtype, requires_grad=requires_grad)

def eye(n: int, dtype: str = "float32", requires_grad: bool = False) -> Tensor:
    """Create an identity matrix."""
    return Tensor(data=np.eye(n, dtype=dtype), dtype=dtype, requires_grad=requires_grad)

def from_numpy(arr: NDArray, requires_grad: bool = False) -> Tensor:
    """Create a tensor from a numpy array."""
    return Tensor(data=arr, dtype=arr.dtype.str, requires_grad=requires_grad)

def stack(tensors: List[Tensor], axis: int = 0) -> Tensor:
    """Stack tensors along a new axis."""
    data = np.stack([t._data for t in tensors], axis=axis)
    return Tensor(data=data, dtype=tensors[0].dtype.str)

def concat(tensors: List[Tensor], axis: int = 0) -> Tensor:
    """Concatenate tensors along an axis."""
    data = np.concatenate([t._data for t in tensors], axis=axis)
    return Tensor(data=data, dtype=tensors[0].dtype.str)


# ============================================================================
# MOGOPS HIGH-LEVEL API
# ============================================================================

class MOGOPSEngine:
    """
    High-level MOGOPS v5.0 computation engine.

    Provides:
        - Semantic Einstein solver
        - Free energy minimization
        - OU process dynamics
        - Precision matrix adaptation
        - Embodiment quotient tracking
        - Gödel anomaly detection
    """

    def __init__(
        self,
        state_dim: int = 64,
        obs_dim: int = 32,
        phi: float = (1 + np.sqrt(5)) / 2,
        use_numba: bool = NUMBA_AVAILABLE,
    ):
        self.state_dim = state_dim
        self.obs_dim = obs_dim
        self.phi = phi
        self.use_numba = use_numba

        # Initialize generative model parameters
        self.A = randn((obs_dim, state_dim), requires_grad=True) * 0.1  # Likelihood
        self.B = eye(state_dim, requires_grad=True) * 0.9  # Transition
        self.D = ones((state_dim,), requires_grad=True) / state_dim  # Prior

        # Precision matrix
        self.precision = eye(state_dim, requires_grad=True)

        # Somatic state
        self.somatic_state = zeros((state_dim,), requires_grad=False)

        # Ontological markers
        self.sophia_score = -420.0
        self.ricci_scalar = -2800.0
        self.paradox_pressure = 0.35
        self.dark_wisdom = 0.62

    def semantic_einstein_solve(
        self,
        metric: Tensor,
        T_conceptual: Tensor,
        Lambda_s: float = 1.0,
        max_iter: int = 50,
        lr: float = 0.1,
    ) -> Tuple[Tensor, float]:
        """
        Solve the Semantic Einstein equation iteratively.

        G^(sem)_μν + Λ_s g_μν = 8π G_s (T^(conceptual)_μν + Θ^(Gödel)_μν)

        Returns:
            (G_semantic, residual_norm)
        """
        G = metric.semantic_einstein(T_conceptual, Lambda_s)

        # Iterative refinement
        for i in range(max_iter):
            # Compute residual
            residual = G - T_conceptual * (8 * np.pi)

            # Gradient descent on residual
            G = G - residual * lr

            # Check convergence
            res_norm = float(np.linalg.norm(residual._data))
            if res_norm < 1e-6:
                break

        return G, res_norm

    def minimize_free_energy(
        self,
        obs: Tensor,
        initial_state: Optional[Tensor] = None,
        semantic_curvature: float = 0.0,
        max_iter: int = 50,
        lr: float = 0.1,
    ) -> Tuple[Tensor, float]:
        """
        Minimize variational free energy via gradient descent.

        F = E_q[ln q(s) - ln p(o,s)] + semantic_curvature_term

        Returns:
            (optimal_state, free_energy)
        """
        if initial_state is None:
            state = self.D.detach()
        else:
            state = initial_state

        for _ in range(max_iter):
            # Compute free energy
            F = state.free_energy(obs, self.D)

            # Add semantic curvature term
            if semantic_curvature != 0.0:
                F = F + semantic_curvature * 0.001

            # Gradient step (simplified) - handle shape mismatch
            state_data = state._data.copy()
            obs_data = obs._data

            # Approximate gradient: project obs to state space if needed
            if len(state_data) != len(obs_data):
                # Pad or truncate obs to match state dimension
                if len(obs_data) < len(state_data):
                    padded = np.zeros(len(state_data), dtype=state_data.dtype)
                    padded[:len(obs_data)] = obs_data
                    obs_data = padded
                else:
                    obs_data = obs_data[:len(state_data)]

            grad = state_data - obs_data
            state_data = state_data - grad * lr

            # Project onto simplex
            state_data = np.abs(state_data) + 1e-10
            state_data = state_data / state_data.sum(axis=-1, keepdims=True)
            state = Tensor(data=state_data, dtype=state.dtype.str)

        F_final = state.free_energy(obs, self.D)
        if semantic_curvature != 0.0:
            F_final = F_final + semantic_curvature * 0.001

        return state, float(np.mean(F_final._data))

    def update_precision(
        self,
        prediction_error: Tensor,
        user_feedback: float = 0.0,
        learning_rate: float = 0.01,
    ):
        """
        Bayesian nonparametric precision adaptation.

        π(t+1) = DirichletProcess(π(t), error_history, user_feedback)
        """
        pe = prediction_error._data
        if pe.ndim == 1:
            pe = np.resize(pe, self.state_dim)

        # Concentration parameter
        concentration = 1.0 + abs(user_feedback) * 10.0

        # Update toward inverse covariance
        target = np.eye(self.state_dim) * concentration

        # Soft update
        pi_new = (1 - learning_rate) * self.precision._data + learning_rate * target

        # Ensure positive semi-definite
        pi_new = (pi_new + pi_new.T) / 2
        eigvals = np.linalg.eigvalsh(pi_new)
        if np.min(eigvals) < 0.01:
            pi_new += np.eye(self.state_dim) * (0.01 - np.min(eigvals))

        self.precision = Tensor(data=pi_new, dtype=self.precision.dtype.str)

    def ou_dynamics(
        self,
        theta: float = 0.5,
        mu: float = 0.0,
        sigma: float = 0.1,
        dt: float = 0.01,
        n_steps: int = 1,
    ) -> Tensor:
        """
        Run Ornstein-Uhlenbeck dynamics for n_steps.
        """
        state = self.somatic_state

        for _ in range(n_steps):
            state = state.ou_process(theta, mu, sigma, dt)

        self.somatic_state = state
        return state

    def compute_ontological_markers(self) -> Dict[str, float]:
        """
        Update and return all ontological markers.
        """
        # Ricci scalar from Sophia relation
        noise = np.random.normal(0, 50)
        self.ricci_scalar = float(np.clip(6.7 * self.sophia_score + noise, -5000, 5000))

        # Paradox pressure
        off_diag = np.sum(np.abs(self.precision._data - np.diag(np.diag(self.precision._data))))
        self.paradox_pressure = float(np.clip(1.0 * 0.5 * off_diag / 1000.0, 0.0, 1.0))

        # Dark wisdom density
        if self.ricci_scalar < -1000:
            self.dark_wisdom = float(np.clip(0.62 + abs(self.ricci_scalar) / 10000, 0.0, 0.95))
        else:
            self.dark_wisdom = float(np.clip(0.62 - self.ricci_scalar / 10000, 0.1, 1.0))

        return {
            "sophia_score": self.sophia_score,
            "ricci_scalar": self.ricci_scalar,
            "paradox_pressure": self.paradox_pressure,
            "dark_wisdom": self.dark_wisdom,
        }

    def embodiment_quotient(self, **metrics) -> float:
        """
        Compute embodiment quotient from current state.
        """
        defaults = {
            "causal_agency": 0.5,
            "sensorimotor_closure": 0.6,
            "self_prediction_accuracy": 0.7,
            "reality_grounding": 0.4,
            "interoceptive_reliability": 0.6,
            "causal_density": 0.3,
        }
        defaults.update(metrics)

        return _embodiment_quotient(**defaults)

    def godel_anomaly_scan(self, truths: Tensor, provables: Tensor) -> Tensor:
        """
        Scan for Gödelian anomalies in the current state.
        """
        return truths.godel_anomaly(provables)

    def memory_usage(self) -> Dict[str, int]:
        """Report current memory usage."""
        return {
            "tensor_count": Tensor._tensor_count,
            "total_tensor_memory": Tensor._total_memory,
            "pool_allocated": _GLOBAL_POOL.total_allocated,
            "state_dim": self.state_dim,
            "obs_dim": self.obs_dim,
        }

    def optimize_memory(self):
        """Force garbage collection and clear memory pool."""
        _GLOBAL_POOL.clear()
        gc.collect()


# ============================================================================
# VRAM / GPU SIMULATION (for systems without CUDA)
# ============================================================================

class VRAMManager:
    """
    Simulates VRAM management for CPU-based systems.
    Provides memory budgeting and tensor eviction.
    """

    def __init__(self, vram_budget_mb: int = 1024):
        self.vram_budget = vram_budget_mb * 1024 * 1024  # bytes
        self.vram_used = 0
        self._tensor_registry: Dict[int, Tensor] = {}

    def allocate(self, tensor: Tensor) -> bool:
        """Attempt to allocate tensor in VRAM."""
        if tensor.nbytes + self.vram_used > self.vram_budget:
            # Evict least recently used
            self._evict(tensor.nbytes)

        self.vram_used += tensor.nbytes
        self._tensor_registry[id(tensor)] = tensor
        return True

    def _evict(self, needed_bytes: int):
        """Evict tensors to free space."""
        freed = 0
        for tid in list(self._tensor_registry.keys()):
            t = self._tensor_registry[tid]
            freed += t.nbytes
            self.vram_used -= t.nbytes
            del self._tensor_registry[tid]

            if freed >= needed_bytes:
                break

    def free(self, tensor: Tensor):
        """Free tensor from VRAM."""
        tid = id(tensor)
        if tid in self._tensor_registry:
            self.vram_used -= self._tensor_registry[tid].nbytes
            del self._tensor_registry[tid]

    @property
    def utilization(self) -> float:
        return self.vram_used / self.vram_budget if self.vram_budget > 0 else 0.0


# ============================================================================
# EXPORT
# ============================================================================

__all__ = [
    "Tensor",
    "MOGOPSEngine",
    "MemoryPool",
    "VRAMManager",
    "memory_scope",
    "zeros",
    "ones",
    "randn",
    "rand",
    "eye",
    "from_numpy",
    "stack",
    "concat",
]
