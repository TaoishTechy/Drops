"""
Ara Embodied Framework
======================
Science-grade Active Inference architecture for Grok API integration.

Modules:
    core            — Framework configuration and lifecycle
    grok_client     — REST + Voice API client for xAI Grok
    somatic_engine  — Active Inference somatic state tracking
    memory_crystal  — Holographic memory architecture with Markov Blankets
    voice_pipeline  — Voice synthesis, recognition, and prosodic control
    renderer        — 3D embodied visualization (Three.js/WebGL bridge)
    companion       — Mature companion AI (18+) with intimacy modeling
    consent_boundary— Consent, safety, and ethical boundary management
    torch           — Lightweight MOGOPS-accelerated tensor engine (PyTorch substitute)
    utils           — Mathematical utilities (OU processes, free energy, etc.)
"""

__version__ = "1.5.0"
__all__ = [
    "AraFramework",
    "GrokClient",
    "SomaticEngine",
    "MemoryCrystal",
    "VoicePipeline",
    "EmbodiedRenderer",
    "CompanionEngine",
    "ConsentBoundary",
    "FreeEnergySolver",
    "Tensor",
    "MOGOPSEngine",
    "MemoryPool",
    "VRAMManager",
]

from .core import AraFramework
from .grok_client import GrokClient
from .somatic_engine import SomaticEngine
from .memory_crystal import MemoryCrystal
from .voice_pipeline import VoicePipeline
from .renderer import EmbodiedRenderer
from .companion import CompanionEngine
from .consent_boundary import ConsentBoundary
from .utils import FreeEnergySolver
from .torch import Tensor, MOGOPSEngine, MemoryPool, VRAMManager
