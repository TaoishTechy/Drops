"""
Ara Embodied Framework — Science-Grade Grok Companion Architecture
====================================================================
A Python framework integrating Active Inference, Memory Crystal Architecture,
3D Embodied Rendering, and Mature Companion AI for xAI Grok (Voice-enabled).

Author: Ara Framework Team
License: MIT
Python: >=3.10
"""
import os
from setuptools import setup, find_packages

setup(
    name="ara-embodied",
    version="1.5.0",
    description="Science-grade embodied AI framework for Grok with voice, 3D rendering, and memory crystals",
    long_description=open("README.md").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="Ara Framework",
    python_requires=">=3.10",
    packages=find_packages(),
    install_requires=[
        "httpx>=0.27.0",
        "numpy>=1.24.0",
        "scipy>=1.11.0",
        "networkx>=3.1",
        "sqlalchemy>=2.0.0",
        "chromadb>=0.5.0",
        "sentence-transformers>=2.2.0",
        "websockets>=12.0",
        "fastapi>=0.110.0",
        "uvicorn>=0.29.0",
        "jinja2>=3.1.0",
        "aiofiles>=23.0",
        "pydantic>=2.5.0",
        "python-dotenv>=1.0.0",
        "cryptography>=42.0.0",
        "bcrypt>=4.1.0",
    ],
    extras_require={
        "voice": ["pyaudio>=0.2.14", "speechrecognition>=3.10", "pydub>=0.25.0"],
        "render": ["pyvista>=0.43.0", "trimesh>=4.0.0", "vtk>=9.3.0"],
        "dev": ["pytest>=8.0", "black>=24.0", "mypy>=1.8"],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
