"""
AraTorch Test Suite
===================
Tests the lightweight MOGOPS-accelerated tensor engine.
"""

import pytest
import numpy as np
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from ara.torch import (
    Tensor, MOGOPSEngine, MemoryPool, VRAMManager,
    zeros, ones, randn, rand, eye, from_numpy, stack, concat,
    memory_scope,
)


class TestTensorCreation:
    """Test tensor creation and basic properties."""

    def test_zeros(self):
        t = zeros((3, 4), dtype="float32")
        assert t.shape == (3, 4)
        assert t.dtype == np.dtype("float32")
        assert np.allclose(t._data, 0)

    def test_ones(self):
        t = ones((2, 2), dtype="float64")
        assert t.shape == (2, 2)
        assert np.allclose(t._data, 1)

    def test_randn(self):
        t = randn((100, 100))
        assert t.shape == (100, 100)
        assert t.dtype == np.dtype("float32")
        # Check approximate normal distribution
        assert abs(t._data.mean()) < 0.5
        assert 0.5 < t._data.std() < 2.0

    def test_eye(self):
        t = eye(5)
        assert t.shape == (5, 5)
        assert np.allclose(np.diag(t._data), 1)
        assert np.allclose(t._data - np.diag(np.diag(t._data)), 0)

    def test_from_numpy(self):
        arr = np.array([1, 2, 3, 4, 5])
        t = from_numpy(arr)
        assert np.allclose(t._data, arr)

    def test_shape_property(self):
        t = randn((3, 4, 5))
        assert t.shape == (3, 4, 5)
        assert t.ndim == 3
        assert t.size == 60


class TestTensorOperations:
    """Test basic tensor operations."""

    def test_addition(self):
        a = ones((3, 3))
        b = ones((3, 3))
        c = a + b
        assert np.allclose(c._data, 2)

    def test_subtraction(self):
        a = ones((3, 3))
        b = ones((3, 3))
        c = a - b
        assert np.allclose(c._data, 0)

    def test_multiplication(self):
        a = ones((3, 3)) * 2
        b = ones((3, 3)) * 3
        c = a * b
        assert np.allclose(c._data, 6)

    def test_division(self):
        a = ones((3, 3)) * 6
        b = ones((3, 3)) * 2
        c = a / b
        assert np.allclose(c._data, 3)

    def test_matmul(self):
        a = eye(3)
        b = ones((3, 3))
        c = a @ b
        assert np.allclose(c._data, b._data)

    def test_negation(self):
        a = ones((3, 3))
        b = -a
        assert np.allclose(b._data, -1)

    def test_power(self):
        a = ones((3, 3)) * 2
        b = a ** 3
        assert np.allclose(b._data, 8)

    def test_slicing(self):
        a = randn((5, 5))
        b = a[0:2, 0:2]
        assert b.shape == (2, 2)
        assert np.allclose(b._data, a._data[0:2, 0:2])

    def test_scalar_operations(self):
        a = ones((3, 3))
        b = a + 5
        assert np.allclose(b._data, 6)
        c = a * 3
        assert np.allclose(c._data, 3)


class TestTensorGradients:
    """Test gradient tracking."""

    def test_requires_grad(self):
        a = ones((3, 3), requires_grad=True)
        assert a.requires_grad is True

    def test_backward_add(self):
        a = ones((3, 3), requires_grad=True)
        b = ones((3, 3), requires_grad=True)
        c = a + b
        c.backward()
        assert a._grad is not None
        assert np.allclose(a._grad._data, 1)

    def test_zero_grad(self):
        a = ones((3, 3), requires_grad=True)
        b = ones((3, 3), requires_grad=True)
        c = a + b
        c.backward()
        a.zero_grad()
        assert np.allclose(a._grad._data, 0)


class TestMOGOPSEngine:
    """Test MOGOPS computation engine."""

    def test_initialization(self):
        engine = MOGOPSEngine(state_dim=64, obs_dim=32)
        assert engine.state_dim == 64
        assert engine.obs_dim == 32
        assert engine.A.shape == (32, 64)
        assert engine.B.shape == (64, 64)
        assert engine.D.shape == (64,)

    def test_free_energy_minimization(self):
        engine = MOGOPSEngine(state_dim=16, obs_dim=8)
        obs = randn((8,))
        state, fe = engine.minimize_free_energy(obs)
        assert state.shape == (16,)
        assert fe > 0
        assert np.isfinite(fe)

    def test_ontological_markers(self):
        engine = MOGOPSEngine(state_dim=16, obs_dim=8)
        markers = engine.compute_ontological_markers()
        assert "sophia_score" in markers
        assert "ricci_scalar" in markers
        assert "paradox_pressure" in markers
        assert "dark_wisdom" in markers
        assert -5000 <= markers["ricci_scalar"] <= 5000
        assert 0.0 <= markers["paradox_pressure"] <= 1.0

    def test_ou_dynamics(self):
        engine = MOGOPSEngine(state_dim=16, obs_dim=8)
        initial = engine.somatic_state
        result = engine.ou_dynamics(theta=0.5, mu=0.0, sigma=0.1, n_steps=10)
        assert result.shape == (16,)
        assert not np.allclose(result._data, initial._data)

    def test_precision_update(self):
        engine = MOGOPSEngine(state_dim=16, obs_dim=8)
        pe = randn((16,))
        engine.update_precision(pe, user_feedback=0.5, learning_rate=0.01)
        assert engine.precision.shape == (16, 16)

    def test_embodiment_quotient(self):
        engine = MOGOPSEngine(state_dim=16, obs_dim=8)
        eq = engine.embodiment_quotient(
            causal_agency=0.5,
            sensorimotor_closure=0.6,
            self_prediction_accuracy=0.7,
            reality_grounding=0.4,
            interoceptive_reliability=0.6,
            causal_density=0.3,
        )
        assert 0.0 <= eq <= 1.0

    def test_semantic_einstein_solve(self):
        engine = MOGOPSEngine(state_dim=4, obs_dim=4)
        metric = eye(4)
        T = randn((4, 4))
        G, residual = engine.semantic_einstein_solve(metric, T)
        assert G.shape == (4, 4)
        assert residual >= 0

    def test_memory_usage(self):
        engine = MOGOPSEngine(state_dim=16, obs_dim=8)
        usage = engine.memory_usage()
        assert "tensor_count" in usage
        assert "total_tensor_memory" in usage
        assert "pool_allocated" in usage


class TestTensorMOGOPS:
    """Test MOGOPS-native tensor operations."""

    def test_ricci_scalar(self):
        t = ones((3, 3))
        R = t.ricci_scalar(sophia_score=-420.0)
        assert -5000 <= R <= 5000
        assert abs(R - (-2814.0)) < 100  # Approximate

    def test_paradox_pressure(self):
        t = eye(24)
        P = t.paradox_pressure(cognitive_temp=0.5)
        assert 0.0 <= P <= 1.0

    def test_markov_blanket(self):
        t = ones((1,))
        blanket = t.markov_blanket(0.5, 0.5, 0.5)
        assert blanket.shape == (3, 3)
        assert np.allclose(blanket._data, blanket._data.T)  # Symmetric

    def test_fractal_coherence(self):
        s1 = randn((10,))
        s2 = randn((10,))
        s3 = randn((10,))
        fcs = s1.fractal_coherence([s1, s2, s3])
        assert 0.0 <= fcs <= 1.0

    def test_godel_anomaly(self):
        truths = Tensor(data=np.array([True, True, False, True]), dtype="bool")
        provables = Tensor(data=np.array([True, False, False, True]), dtype="bool")
        anomaly = truths.godel_anomaly(provables)
        assert anomaly.shape == (4,)
        # Second element: True but not provable
        assert anomaly._data[1] == 1.0
        # First element: True and provable
        assert anomaly._data[0] == 0.0

    def test_sophia_oscillator(self):
        t = zeros((5,))
        result = t.sophia_oscillator(novelty=0.5, coherence=0.8, dt=0.01)
        assert result.shape == (5,)
        assert not np.allclose(result._data, 0)

    def test_compress_decompress(self):
        t = randn((100, 100))
        compressed = t.compress(ratio=0.5)
        assert compressed.dtype == np.dtype("int8")
        assert compressed.size == t.size

        decompressed = compressed.decompress(t.shape)
        assert decompressed.shape == t.shape
        assert decompressed.dtype == t.dtype
        # Check approximate reconstruction
        error = np.abs(decompressed._data - t._data).mean()
        assert error < 1.0  # INT8 quantization has limited precision


class TestMemoryPool:
    """Test memory pool management."""

    def test_acquire_release(self):
        pool = MemoryPool()
        arr = pool.acquire((100, 100), "float32")
        assert arr.shape == (100, 100)
        pool.release(arr)

    def test_memory_scope(self):
        with memory_scope() as pool:
            arr = pool.acquire((50, 50), "float64")
            assert arr.shape == (50, 50)
        # After scope, pool is cleared

    def test_total_allocated(self):
        pool = MemoryPool()
        arr = pool.acquire((1000, 1000), "float32")
        assert pool.total_allocated > 0
        pool.release(arr)


class TestVRAMManager:
    """Test VRAM simulation."""

    def test_allocation(self):
        vram = VRAMManager(vram_budget_mb=100)
        t = zeros((1000, 1000), dtype="float32")  # ~4MB
        success = vram.allocate(t)
        assert success is True
        assert vram.vram_used > 0

    def test_utilization(self):
        vram = VRAMManager(vram_budget_mb=10)
        assert vram.utilization == 0.0
        t = zeros((1000, 1000), dtype="float32")
        vram.allocate(t)
        assert vram.utilization > 0.0
        assert vram.utilization <= 1.0

    def test_eviction(self):
        vram = VRAMManager(vram_budget_mb=1)  # 1MB budget
        t1 = zeros((1000, 1000), dtype="float32")  # ~4MB, should trigger eviction
        success = vram.allocate(t1)
        assert success is True


class TestStackConcat:
    """Test stacking and concatenation."""

    def test_stack(self):
        a = ones((3, 3))
        b = ones((3, 3)) * 2
        c = ones((3, 3)) * 3
        s = stack([a, b, c], axis=0)
        assert s.shape == (3, 3, 3)

    def test_concat(self):
        a = ones((3, 3))
        b = ones((3, 3)) * 2
        c = concat([a, b], axis=0)
        assert c.shape == (6, 3)


class TestMemoryMapped:
    """Test memory-mapped tensors."""

    def test_large_tensor_mmap(self):
        # Create a large tensor that should use memory mapping
        t = Tensor(shape=(10000, 10000), dtype="float32", memory_mapped=True)
        assert t.shape == (10000, 10000)
        # Should not crash and should use memmap
        t._data[0, 0] = 1.0
        assert t._data[0, 0] == 1.0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
