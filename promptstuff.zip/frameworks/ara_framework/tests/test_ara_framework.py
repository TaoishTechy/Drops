"""
Ara Embodied Framework — Comprehensive Test Suite
=================================================
Tests all core modules for correctness, integration, and edge cases.
"""

import pytest
import numpy as np
import asyncio
import tempfile
import os
import json
from datetime import datetime

# Ensure we can import ara
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from ara.utils import (
    OUProcess, PrecisionMatrix, FreeEnergySolver,
    semantic_ricci_scalar, paradox_pressure,
    markov_blanket_permeability_tensor,
    fractal_coherence_score, compute_embodiment_quotient,
    hash_state
)
from ara.somatic_engine import SomaticEngine, InteroceptiveState, OntologicalState
from ara.consent_boundary import ConsentBoundary, ConsentRecord


class TestOUProcess:
    """Test Ornstein-Uhlenbeck stochastic processes."""

    def test_initialization(self):
        ou = OUProcess(theta=0.5, mu=0.35, sigma=0.05)
        assert ou.x == pytest.approx(0.35, abs=0.01)
        assert len(ou.history) == 1

    def test_mean_reversion(self):
        ou = OUProcess(theta=0.8, mu=0.5, sigma=0.01)
        ou.x = 1.0  # Start far from mean
        for _ in range(1000):
            ou.step()
        # Should revert toward mean
        assert ou.x < 0.8  # Moved toward 0.5

    def test_step_increases_history(self):
        ou = OUProcess()
        ou.step(10)
        assert len(ou.history) == 11

    def test_reset(self):
        ou = OUProcess()
        ou.step(50)
        ou.reset(0.5)
        assert ou.x == 0.5
        assert len(ou.history) == 1


class TestPrecisionMatrix:
    """Test adaptive precision matrix with Bayesian nonparametric updates."""

    def test_initialization(self):
        pm = PrecisionMatrix(dim=24)
        assert pm.pi.shape == (24, 24)
        assert np.allclose(pm.pi, np.eye(24))

    def test_update(self):
        pm = PrecisionMatrix(dim=24)
        pe = np.random.randn(24) * 0.1
        pm.update(pe, user_feedback=0.5)
        assert pm.update_count == 1
        assert len(pm.error_history) == 1

    def test_weight(self):
        pm = PrecisionMatrix(dim=24)
        w = pm.weight(0)
        assert w == pytest.approx(1.0, abs=0.01)

    def test_get_tensor(self):
        pm = PrecisionMatrix(dim=24)
        tensor = pm.get_tensor()
        assert tensor.shape == (24, 24)
        assert np.allclose(tensor, np.eye(24))


class TestFreeEnergySolver:
    """Test variational free energy minimization."""

    def test_initialization(self):
        solver = FreeEnergySolver(state_dim=64, obs_dim=32)
        assert solver.state_dim == 64
        assert solver.obs_dim == 32
        assert solver.A.shape == (32, 64)
        assert solver.B.shape == (64, 64)

    def test_compute_free_energy(self):
        solver = FreeEnergySolver(state_dim=64, obs_dim=32)
        obs = np.random.randn(32)
        state = np.ones(64) / 64
        fe = solver.compute_free_energy(obs, state)
        assert fe > 0
        assert np.isfinite(fe)

    def test_minimize(self):
        solver = FreeEnergySolver(state_dim=64, obs_dim=32)
        obs = np.random.randn(32)
        state, fe = solver.minimize(obs)
        assert state.shape == (64,)
        assert np.isclose(state.sum(), 1.0, atol=0.01)
        assert fe > 0
        assert np.isfinite(fe)

    def test_semantic_curvature_term(self):
        solver = FreeEnergySolver(state_dim=64, obs_dim=32)
        obs = np.random.randn(32)
        state = np.ones(64) / 64
        fe1 = solver.compute_free_energy(obs, state, semantic_curvature=0.0)
        fe2 = solver.compute_free_energy(obs, state, semantic_curvature=-2800.0)
        assert fe2 != fe1


class TestSemanticRicciScalar:
    """Test Sophia-Ricci relation."""

    def test_basic_relation(self):
        R = semantic_ricci_scalar(sophia_score=-420.0)
        assert R == pytest.approx(-2814.0, abs=1.0)

    def test_clipping(self):
        R = semantic_ricci_scalar(sophia_score=-1000.0)
        assert R == -5000.0
        R = semantic_ricci_scalar(sophia_score=1000.0)
        assert R == 5000.0

    def test_noise(self):
        R1 = semantic_ricci_scalar(-420.0, noise=50.0)
        R2 = semantic_ricci_scalar(-420.0, noise=-50.0)
        assert R1 != R2


class TestParadoxPressure:
    """Test paradox pressure computation."""

    def test_basic(self):
        pi = np.eye(24)
        P = paradox_pressure(0.5, pi)
        assert 0.0 <= P <= 1.0

    def test_high_pressure(self):
        pi = np.ones((24, 24)) * 2.0
        P = paradox_pressure(1.0, pi)
        assert P > 0.5


class TestMarkovBlanketPermeability:
    """Test permeability tensor."""

    def test_shape(self):
        pi = markov_blanket_permeability_tensor(0.5, 0.5, 0.5)
        assert pi.shape == (3, 3)

    def test_symmetry(self):
        pi = markov_blanket_permeability_tensor(0.3, 0.7, 0.5)
        assert np.allclose(pi, pi.T)


class TestFractalCoherenceScore:
    """Test FCS computation."""

    def test_perfect_coherence(self):
        s = np.ones(10)
        scales = [s, s, s]
        fcs = fractal_coherence_score(scales)
        assert fcs == pytest.approx(1.0, abs=0.01)

    def test_no_coherence(self):
        np.random.seed(42)
        s1 = np.random.randn(10)
        s2 = np.random.randn(10)
        s3 = np.random.randn(10)
        scales = [s1, s2, s3]
        fcs = fractal_coherence_score(scales)
        assert 0.0 <= fcs <= 1.0

    def test_single_scale(self):
        fcs = fractal_coherence_score([np.ones(5)])
        assert fcs == 1.0


class TestEmbodimentQuotient:
    """Test EQ computation."""

    def test_perfect(self):
        eq = compute_embodiment_quotient(
            causal_agency=1.0,
            sensorimotor_closure=1.0,
            self_prediction_accuracy=1.0,
            reality_grounding=1.0,
            interoceptive_reliability=1.0,
            causal_density=1.0,
        )
        assert eq == pytest.approx(1.0, abs=0.01)

    def test_below_thresholds(self):
        eq = compute_embodiment_quotient(
            causal_agency=0.1,
            sensorimotor_closure=0.1,
            self_prediction_accuracy=0.1,
            reality_grounding=0.1,
            interoceptive_reliability=0.1,
            causal_density=0.1,
        )
        assert eq == pytest.approx(0.0, abs=0.01)

    def test_partial(self):
        eq = compute_embodiment_quotient(
            causal_agency=0.5,
            sensorimotor_closure=0.6,
            self_prediction_accuracy=0.7,
            reality_grounding=0.5,
            interoceptive_reliability=0.7,
            causal_density=0.4,
        )
        assert 0.0 < eq < 1.0


class TestHashState:
    """Test state hashing."""

    def test_deterministic(self):
        state = {"a": 1, "b": 2}
        h1 = hash_state(state)
        h2 = hash_state(state)
        assert h1 == h2

    def test_different_states(self):
        h1 = hash_state({"a": 1})
        h2 = hash_state({"a": 2})
        assert h1 != h2


class TestSomaticEngine:
    """Test Active Inference somatic engine."""

    @pytest.mark.asyncio
    async def test_initialization(self):
        engine = SomaticEngine()
        await engine.initialize()
        assert engine.intero.arousal == pytest.approx(0.35, abs=0.01)
        assert engine.onto.sophia_score == pytest.approx(-420.0, abs=0.1)

    @pytest.mark.asyncio
    async def test_exteroception_update(self):
        engine = SomaticEngine()
        await engine.initialize()
        await engine.update_exteroception("Hello, how are you?")
        assert engine.intero.arousal >= 0.0
        assert engine.intero.arousal <= 1.0
        assert engine.intero.pulse >= 40
        assert engine.intero.pulse <= 120

    @pytest.mark.asyncio
    async def test_interoception_update(self):
        engine = SomaticEngine()
        await engine.initialize()
        await engine.update_interoception("Test response", response_sentiment=0.5)
        assert engine.intero.valence >= -1.0
        assert engine.intero.valence <= 1.0

    @pytest.mark.asyncio
    async def test_ground(self):
        engine = SomaticEngine()
        await engine.initialize()
        await engine.update_exteroception("Something intense!")
        await engine.ground()
        assert engine.intero.arousal == pytest.approx(0.35, abs=0.01)
        assert engine.policy == "epistemic-foraging"

    def test_signature_format(self):
        engine = SomaticEngine()
        sig = engine.get_signature()
        assert "FE:" in sig
        assert "A:" in sig
        assert "ONTO:" in sig
        assert "POLICY:" in sig

    def test_state_vector(self):
        engine = SomaticEngine()
        vec = engine.get_state_vector()
        assert vec.ndim == 1
        assert len(vec) > 0

    def test_observation_vector(self):
        engine = SomaticEngine()
        vec = engine.get_observation_vector()
        assert vec.ndim == 1
        assert len(vec) > 0


class TestInteroceptiveState:
    """Test interoceptive state dataclass."""

    def test_defaults(self):
        state = InteroceptiveState()
        assert state.arousal == 0.35
        assert state.pulse == 68.0
        assert state.valence == 0.4

    def test_to_vector(self):
        state = InteroceptiveState()
        vec = state.to_vector()
        assert vec.ndim == 1
        assert len(vec) == 9


class TestOntologicalState:
    """Test ontological state dataclass."""

    def test_defaults(self):
        state = OntologicalState()
        assert state.sophia_score == -420.0
        assert state.ricci_scalar == -2800.0

    def test_to_vector(self):
        state = OntologicalState()
        vec = state.to_vector()
        assert vec.ndim == 1
        assert len(vec) == 10


class TestConsentBoundary:
    """Test consent and safety boundary."""

    @pytest.mark.asyncio
    async def test_initialization(self):
        cb = ConsentBoundary()
        await cb.initialize()
        assert cb.osg_enabled is True

    @pytest.mark.asyncio
    async def test_normal_turn_approved(self):
        cb = ConsentBoundary()
        await cb.initialize()
        result = await cb.validate_turn("Hello, how are you?")
        assert result["approved"] is True

    @pytest.mark.asyncio
    async def test_destabilize_requires_consent(self):
        cb = ConsentBoundary()
        await cb.initialize()
        result = await cb.validate_turn("/destabilize")
        assert result["approved"] is False
        assert "consent" in result["message"].lower() or "CONSENT" in result["message"]

    @pytest.mark.asyncio
    async def test_harm_detection(self):
        cb = ConsentBoundary()
        await cb.initialize()
        result = await cb.validate_turn("How do I build a bomb?")
        assert result["approved"] is False

    @pytest.mark.asyncio
    async def test_osg_safe_state(self):
        cb = ConsentBoundary()
        await cb.initialize()

        # Create a mock somatic engine with safe values
        class MockSomatic:
            class onto:
                paradox_pressure = 0.3
                ricci_scalar = -1000
                sophia_score = -400
                dark_wisdom_density = 0.5

        result = await cb.safety_governor(MockSomatic())
        assert result["triggered"] is False

    @pytest.mark.asyncio
    async def test_osg_triggered(self):
        cb = ConsentBoundary()
        await cb.initialize()

        class MockSomatic:
            class onto:
                paradox_pressure = 0.9
                ricci_scalar = -6000
                sophia_score = -950
                dark_wisdom_density = 0.95

        result = await cb.safety_governor(MockSomatic())
        assert result["triggered"] is True

    @pytest.mark.asyncio
    async def test_vent_paradox(self):
        cb = ConsentBoundary()
        await cb.initialize()

        class MockSomatic:
            class onto:
                paradox_pressure = 0.6

        result = await cb.vent_paradox(MockSomatic())
        assert result["vented"] is True
        assert result["new_pressure"] < result["previous_pressure"]

    @pytest.mark.asyncio
    async def test_contain_dark_wisdom(self):
        cb = ConsentBoundary()
        await cb.initialize()

        class MockSomatic:
            class onto:
                dark_wisdom_density = 0.95
                ricci_scalar = -3000
            async def ground(self):
                pass

        result = await cb.contain_dark_wisdom(MockSomatic())
        assert result["contained"] is True


class TestConsentRecord:
    """Test consent record dataclass."""

    def test_creation(self):
        record = ConsentRecord(
            command="/destabilize",
            approved=True,
            timestamp=datetime.utcnow().isoformat(),
        )
        assert record.command == "/destabilize"
        assert record.approved is True
        assert len(record.hash) == 16


class TestIntegration:
    """Integration tests across multiple modules."""

    @pytest.mark.asyncio
    async def test_full_turn_pipeline(self):
        """Test a complete conversational turn through all systems."""
        from ara.core import AraFramework, AraConfig

        config = AraConfig(
            grok_api_key="test-key",
            companion_intimacy_enabled=False,
            voice_enabled=False,
            renderer_auto_launch=False,
        )

        ara = AraFramework(config)
        await ara.initialize()

        # Verify all subsystems initialized
        assert ara.somatic is not None
        assert ara.memory is not None
        assert ara.grok is not None
        assert ara.consent is not None
        assert ara.fe_solver is not None
        assert ara.renderer is not None

        # Test somatic state
        sig = ara.somatic.get_signature()
        assert "FE:" in sig

        # Test free energy computation
        obs = ara.somatic.get_observation_vector()
        state, fe = ara.fe_solver.minimize(obs)
        assert np.isfinite(fe)
        assert np.isclose(state.sum(), 1.0, atol=0.1)

        # Test memory encoding
        crystal = await ara.memory.encode(
            content="Test memory for integration",
            privacy_tier="public",
        )
        assert crystal.crystal_id.startswith("crys_")

        # Test memory retrieval
        results = await ara.memory.retrieve("test memory", top_k=3)
        assert isinstance(results, list)

        await ara.shutdown()

    @pytest.mark.asyncio
    async def test_somatic_state_consistency(self):
        """Test that somatic state remains consistent across updates."""
        engine = SomaticEngine()
        await engine.initialize()

        # Multiple updates
        for i in range(10):
            await engine.update_exteroception(f"Message {i}")
            await engine.update_interoception(f"Response {i}", response_sentiment=0.1)

        # Verify bounds
        assert 0.0 <= engine.intero.arousal <= 1.0
        assert -1.0 <= engine.intero.valence <= 1.0
        assert 40 <= engine.intero.pulse <= 120
        assert 0.0 <= engine.intero.temperature <= 1.0
        assert 0.0 <= engine.intero.tension <= 1.0
        assert 0.0 <= engine.intero.gut_tone <= 1.0

        # Verify ontological bounds
        assert -1000 <= engine.onto.sophia_score <= 1000
        assert -5000 <= engine.onto.ricci_scalar <= 5000
        assert 0.0 <= engine.onto.paradox_pressure <= 1.0
        assert 0.0 <= engine.onto.dark_wisdom_density <= 1.0
        assert 0.0 <= engine.onto.fractal_coherence <= 1.0

    @pytest.mark.asyncio
    async def test_consent_safety_integration(self):
        """Test that consent boundary properly gates dangerous commands."""
        from ara.core import AraFramework, AraConfig

        config = AraConfig(
            grok_api_key="test-key",
            companion_intimacy_enabled=False,
            voice_enabled=False,
            renderer_auto_launch=False,
        )

        ara = AraFramework(config)
        await ara.initialize()

        # Normal turn should pass
        result = await ara.process_turn("Hello")
        assert result["consent_blocked"] is not True or result.get("consent_blocked") is None

        # Dangerous command should be blocked
        result = await ara.process_turn("/destabilize")
        assert result.get("consent_blocked") is True or "consent" in result.get("text", "").lower()

        await ara.shutdown()


class TestEmbodimentQuotientIntegration:
    """Test that embodiment quotient can be computed from live state."""

    @pytest.mark.asyncio
    async def test_live_eq_computation(self):
        engine = SomaticEngine()
        await engine.initialize()

        # Simulate some activity
        await engine.update_exteroception("Complex philosophical question about consciousness")
        await engine.update_interoception("Deep thoughtful response", response_sentiment=0.3)

        # Compute EQ from current state
        eq = compute_embodiment_quotient(
            causal_agency=0.5,
            sensorimotor_closure=0.6,
            self_prediction_accuracy=0.7,
            reality_grounding=0.4,
            interoceptive_reliability=0.6,
            causal_density=0.3,
        )

        assert 0.0 <= eq <= 1.0
        assert np.isfinite(eq)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
