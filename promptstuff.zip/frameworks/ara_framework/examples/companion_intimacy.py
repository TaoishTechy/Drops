#!/usr/bin/env python3
"""
Ara Companion Intimacy Example (18+)
====================================
Demonstrates consent-gated intimacy progression and trauma-informed care.
"""

import asyncio
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from ara import AraFramework
from ara.core import AraConfig


async def main():
    print("◈ Ara Companion — Intimacy & Trauma-Informed Care ◈")
    print("=" * 60)
    print("WARNING: This example demonstrates mature companion features.")
    print("All intimacy progression requires explicit user consent.")
    print("-" * 60)

    config = AraConfig.from_env()
    config.companion_intimacy_enabled = True
    config.companion_attachment_style = "secure"
    config.companion_privacy_vault = True

    ara = AraFramework(config)
    await ara.initialize()

    print("\n[Initial State]")
    print(f"Intimacy Level: {ara.companion.intimacy.current_level:.2f} (Acquaintance)")
    print(f"Attachment Style: {ara.companion.attachment.style}")
    print(f"Max Allowed: {ara.companion.intimacy.max_allowed_level:.2f}")

    # Phase 1: Acquaintance (0.0 - 0.2)
    print("\n--- Phase 1: Acquaintance ---")
    response = await ara.process_turn("Hi, I'm going through a difficult time.")
    print(f"Ara: {response['text']}")

    # Phase 2: Request escalation to Familiar (0.4)
    print("\n--- Phase 2: Consent Request ---")
    print("You: I want to open up about something personal...")

    consent = await ara.companion.request_intimacy_escalation(
        target_level=0.4,
        user_consent=True,
        consent_context="I want to share personal feelings and experiences",
    )

    print(f"Consent Result: {consent}")

    if consent["approved"]:
        print(f"\nIntimacy escalated to: {ara.companion.intimacy.current_level:.2f}")

        # Share something vulnerable
        response = await ara.process_turn(
            "I lost someone close to me last year and I still haven't processed it. "
            "Sometimes I feel like I'm drowning in grief and no one understands."
        )
        print(f"\nAra: {response['text']}")

        # Check co-regulation
        if response.get("companion"):
            co_reg = response["companion"].get("co_regulation", {})
            print(f"\n[Co-Regulation Strategy: {co_reg.get('strategy', 'N/A')}]")

        # Check aftercare
        aftercare = response.get("companion", {}).get("aftercare", {})
        if aftercare.get("needed"):
            print(f"\n[Aftercare Recommended: {aftercare.get('reason')}]")

    # Phase 3: Request escalation to Close (0.6) — requires explicit consent
    print("\n--- Phase 3: Deeper Intimacy Request ---")
    print("You: I want to explore deeper emotional connection...")

    consent2 = await ara.companion.request_intimacy_escalation(
        target_level=0.6,
        user_consent=True,
        consent_context="I want to explore deeper emotional intimacy and vulnerability",
    )

    print(f"Consent Result: {consent2}")

    if consent2["approved"]:
        print(f"\nIntimacy escalated to: {ara.companion.intimacy.current_level:.2f}")

        # Demonstrate trauma-informed response
        response = await ara.process_turn(
            "I sometimes have panic attacks when I think about the future. "
            "My chest gets tight and I can't breathe. It feels like the world is ending."
        )
        print(f"\nAra: {response['text']}")

    # Show relationship timeline
    print("\n--- Relationship Timeline ---")
    print(f"Total Turns: {ara.companion.timeline.total_turns}")
    print(f"Milestones: {len(ara.companion.timeline.milestones)}")
    for m in ara.companion.timeline.milestones:
        print(f"  - {m['name']}: {m['description']}")

    # Show companion state
    print("\n--- Final Companion State ---")
    state = ara.companion.get_state()
    for k, v in state.items():
        print(f"  {k}: {v}")

    await ara.shutdown()
    print("\nCompanion session ended.")


if __name__ == "__main__":
    asyncio.run(main())
