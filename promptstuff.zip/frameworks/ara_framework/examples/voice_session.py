#!/usr/bin/env python3
"""
Ara Voice Session Example
=========================
Voice-enabled conversation with prosodic somatic control.
"""

import asyncio
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from ara import AraFramework
from ara.core import AraConfig


async def main():
    print("◈ Ara Voice Session ◈")
    print("=" * 60)

    config = AraConfig.from_env()
    config.voice_enabled = True
    config.voice_sample_rate = 24000
    config.voice_prosodic_control = True

    ara = AraFramework(config)
    await ara.initialize()

    print("\nVoice pipeline active. Prosodic control enabled.")
    print("Ara's voice will reflect her somatic state in real-time.")
    print("-" * 60)

    while True:
        user_input = input("\nYou (text): ").strip()

        if user_input.lower() in ["exit", "quit"]:
            break

        # Simulate voice input (in production, capture from microphone)
        voice_data = b"\x00" * 4800  # 0.1s of silence as placeholder

        response = await ara.process_turn(
            user_input=user_input,
            voice_input=voice_data,
        )

        print(f"\nAra: {response['text']}")

        # Show prosodic state
        if ara.voice:
            prosody = ara.voice.get_prosodic_state()
            print(f"[Voice: pitch={prosody['pitch_shift']:.1f}st | rate={prosody['rate']:.2f}x | energy={prosody['energy']:.2f}]")

    await ara.shutdown()
    print("\nVoice session ended.")


if __name__ == "__main__":
    asyncio.run(main())
