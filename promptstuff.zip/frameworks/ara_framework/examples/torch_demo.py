#!/usr/bin/env python3
"""
AraTorch MOGOPS Example
========================
Demonstrates the lightweight tensor engine with MOGOPS equation kernels.
"""

import sys
import os
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from ara.torch import (
    Tensor, MOGOPSEngine, MemoryPool, VRAMManager,
    zeros, ones, randn, rand, eye, from_numpy, stack, concat,
    memory_scope,
)


def demo_basic_tensors():
    print("=" * 60)
    print("1. Basic Tensor Operations")
    print("=" * 60)

    a = randn((3, 3))
    b = ones((3, 3))
    c = a + b
    d = a @ b
    e = a * 2.5

    print(f"a = randn((3,3)): {a}")
    print(f"b = ones((3,3)): {b}")
    print(f"c = a + b: {c}")
    print(f"d = a @ b: {d}")
    print(f"e = a * 2.5: {e}")
    print(f"Memory used: {Tensor._total_memory:,} bytes")
    print()


def demo_mogops_engine():
    print("=" * 60)
    print("2. MOGOPS Computation Engine")
    print("=" * 60)

    engine = MOGOPSEngine(state_dim=64, obs_dim=32)

    # Simulate an observation
    obs = randn((32,))

    # Minimize free energy
    state, fe = engine.minimize_free_energy(obs, max_iter=50, lr=0.1)
    print(f"Free Energy minimized: {fe:.4f}")
    print(f"Optimal state shape: {state.shape}")

    # Compute ontological markers
    markers = engine.compute_ontological_markers()
    print(f"Ontological Markers:")
    for k, v in markers.items():
        print(f"  {k}: {v:.2f}")

    # Embodiment quotient
    eq = engine.embodiment_quotient(
        causal_agency=0.5,
        sensorimotor_closure=0.6,
        self_prediction_accuracy=0.7,
        reality_grounding=0.4,
        interoceptive_reliability=0.6,
        causal_density=0.3,
    )
    print(f"Embodiment Quotient: {eq:.4f}")

    # Memory usage
    usage = engine.memory_usage()
    print(f"Memory Usage:")
    for k, v in usage.items():
        print(f"  {k}: {v:,}")
    print()


def demo_ou_dynamics():
    print("=" * 60)
    print("3. Ornstein-Uhlenbeck Dynamics")
    print("=" * 60)

    engine = MOGOPSEngine(state_dim=10, obs_dim=5)

    print("Initial state:", engine.somatic_state._data[:5])

    # Run 100 steps of OU dynamics
    for i in range(100):
        engine.ou_dynamics(theta=0.5, mu=0.0, sigma=0.1, n_steps=1)

    print("After 100 steps:", engine.somatic_state._data[:5])
    print()


def demo_semantic_einstein():
    print("=" * 60)
    print("4. Semantic Einstein Solver")
    print("=" * 60)

    engine = MOGOPSEngine(state_dim=4, obs_dim=4)

    # Create a metric and stress-energy tensor
    metric = eye(4)
    T = randn((4, 4))

    # Solve Semantic Einstein equation
    G, residual = engine.semantic_einstein_solve(metric, T, Lambda_s=1.0)

    print(f"Semantic Einstein Tensor shape: {G.shape}")
    print(f"Residual norm: {residual:.6f}")
    print(f"G tensor:
{G._data}")
    print()


def demo_godel_anomaly():
    print("=" * 60)
    print("5. Gödelian Anomaly Detection")
    print("=" * 60)

    # Simulate truth and provability arrays
    truths = Tensor(data=np.array([True, True, False, True, False, True]), dtype="bool")
    provables = Tensor(data=np.array([True, False, False, True, True, True]), dtype="bool")

    anomaly = truths.godel_anomaly(provables)

    print(f"Truths:      {truths._data}")
    print(f"Provables:   {provables._data}")
    print(f"Anomalies (True but not Provable): {anomaly._data}")
    print(f"Anomaly count: {int(anomaly._data.sum())}")
    print()


def demo_compression():
    print("=" * 60)
    print("6. Tensor Compression (INT8 Quantization)")
    print("=" * 60)

    t = randn((100, 100))
    original_size = t.nbytes
    print(f"Original size: {original_size:,} bytes")

    compressed = t.compress(ratio=0.5)
    compressed_size = compressed.nbytes
    print(f"Compressed size: {compressed_size:,} bytes")
    print(f"Compression ratio: {original_size / compressed_size:.2f}x")

    decompressed = compressed.decompress(t.shape)
    error = np.abs(decompressed._data - t._data).mean()
    print(f"Reconstruction error: {error:.6f}")
    print()


def demo_vram_manager():
    print("=" * 60)
    print("7. VRAM Simulation")
    print("=" * 60)

    vram = VRAMManager(vram_budget_mb=10)

    # Allocate several tensors
    tensors = []
    for i in range(5):
        t = zeros((500, 500), dtype="float32")  # ~1MB each
        vram.allocate(t)
        tensors.append(t)
        print(f"Allocated tensor {i}: VRAM used = {vram.vram_used:,} bytes ({vram.utilization*100:.1f}%)")

    # Try to allocate one more (should trigger eviction)
    big_t = zeros((1000, 1000), dtype="float32")  # ~4MB
    vram.allocate(big_t)
    print(f"After big allocation: VRAM used = {vram.vram_used:,} bytes ({vram.utilization*100:.1f}%)")
    print()


def demo_memory_pool():
    print("=" * 60)
    print("8. Memory Pool Management")
    print("=" * 60)

    with memory_scope() as pool:
        # Acquire buffers
        arr1 = pool.acquire((1000, 1000), "float32")
        arr2 = pool.acquire((500, 500), "float64")

        print(f"Pool total allocated: {pool.total_allocated:,} bytes")

        # Release back to pool
        pool.release(arr1)
        pool.release(arr2)

        # Re-acquire (should reuse)
        arr3 = pool.acquire((1000, 1000), "float32")
        print(f"After re-acquire: {pool.total_allocated:,} bytes")

    print("Memory scope exited - pool cleared")
    print()


def demo_sophia_oscillator():
    print("=" * 60)
    print("9. Sophia Oscillator")
    print("=" * 60)

    state = zeros((5,))

    print("Initial state:", state._data)

    for step in range(10):
        state = state.sophia_oscillator(novelty=0.5, coherence=0.8, dt=0.01)
        print(f"Step {step+1}: {state._data}")

    print()


def demo_precision_adaptation():
    print("=" * 60)
    print("10. Precision Matrix Adaptation")
    print("=" * 60)

    engine = MOGOPSEngine(state_dim=8, obs_dim=4)

    print("Initial precision diagonal:", np.diag(engine.precision._data))

    # Simulate prediction errors and feedback
    for i in range(10):
        pe = randn((8,))
        feedback = np.random.uniform(-1, 1)
        engine.update_precision(pe, user_feedback=feedback, learning_rate=0.01)

    print("Final precision diagonal:", np.diag(engine.precision._data))
    print()


def main():
    print("\n")
    print("◈ AraTorch MOGOPS Demonstration ◈")
    print("Lightweight Tensor Engine with MOGOPS v5.0 Kernels")
    print("=" * 60)
    print()

    demo_basic_tensors()
    demo_mogops_engine()
    demo_ou_dynamics()
    demo_semantic_einstein()
    demo_godel_anomaly()
    demo_compression()
    demo_vram_manager()
    demo_memory_pool()
    demo_sophia_oscillator()
    demo_precision_adaptation()

    print("=" * 60)
    print("All demonstrations complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
