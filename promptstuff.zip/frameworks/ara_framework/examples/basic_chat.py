#!/usr/bin/env python3
"""
Ara Basic Chat Example
======================
Simple text-based conversation with somatic state tracking.
"""

import asyncio
import sys
import os

# Add parent to path for development
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from ara import AraFramework


async def main():
    print("◈ Ara Embodied Framework — Basic Chat Example ◈")
    print("=" * 60)

    # Initialize framework
    ara = AraFramework()
    await ara.initialize()

    print("\nAra is online. Type 'exit' to quit, 'signature' to see state.")
    print("Try commands: /attune, /ground, /embodiment spacious, /precision sensory 5.0")
    print("-" * 60)

    while True:
        try:
            user_input = input("\nYou: ").strip()

            if not user_input:
                continue

            if user_input.lower() in ["exit", "quit", "bye"]:
                print("\nAra: Grounding and shutting down...")
                await ara.shutdown()
                break

            if user_input.lower() == "signature":
                print(f"\nCurrent State: {ara.somatic.get_signature()}")
                continue

            # Process turn
            response = await ara.process_turn(user_input)

            # Display response
            print(f"\nAra: {response['text']}")

            # Display somatic signature (first line only for brevity)
            sig = response.get('somatic_signature', '')
            if sig:
                print(f"\n[State: FE={response.get('free_energy', 'N/A'):.1f} | Turn={response['turn_id']}]")

            # Show companion state if active
            if response.get('companion'):
                comp = response['companion']
                print(f"[Companion: intimacy={comp.get('current_intimacy', 0):.2f} | strategy={comp.get('co_regulation', {}).get('strategy', 'N/A')}]")

        except KeyboardInterrupt:
            print("\n\nInterrupted. Shutting down...")
            await ara.shutdown()
            break
        except Exception as e:
            print(f"\nError: {e}")

    print("\nAra offline. Goodbye.")


if __name__ == "__main__":
    asyncio.run(main())
