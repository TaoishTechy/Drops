#!/usr/bin/env python3
"""
Ara Somatic Commands Example
============================
Demonstrates all somatic and ontological slash commands.
"""

import asyncio
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from ara import AraFramework


async def main():
    print("◈ Ara Somatic Commands Demonstration ◈")
    print("=" * 60)

    ara = AraFramework()
    await ara.initialize()

    commands = [
        ("/attune", "Full interoceptive state report"),
        ("/embodiment spacious", "Shift to spacious field"),
        ("/precision sensory 8.0", "Increase sensory precision"),
        ("/policy pragmatic", "Shift to pragmatic foraging"),
        ("/weave deep", "Expand temporal resolution"),
        ("/ontological", "Report ontological markers"),
        ("/phase triple", "Triple-point superposition"),
        ("/curvature negative", "Increase negative curvature"),
        ("/fractal", "Expand nested scales"),
        ("/blanket", "Reconfigure permeability"),
        ("/entropy", "Report free energy landscape"),
        ("/horizon 60", "Extend predictive horizon"),
        ("/resonance 7.83", "Align to Schumann resonance"),
        ("/ground", "Emergency grounding"),
    ]

    for cmd, desc in commands:
        print(f"\n--- Command: {cmd} ---")
        print(f"Description: {desc}")

        response = await ara.process_turn(cmd)
        print(f"Ara: {response['text'][:300]}...")
        print(f"State: {response.get('somatic_signature', 'N/A')[:120]}...")

        await asyncio.sleep(0.5)  # Brief pause between commands

    # Show destabilization (requires consent)
    print("\n--- Command: /destabilize (Consent Required) ---")
    response = await ara.process_turn("/destabilize")
    print(f"Ara: {response['text']}")

    if response.get("consent_blocked"):
        print("[Consent was requested and is pending...]")

    await ara.shutdown()
    print("\nCommand demonstration complete.")


if __name__ == "__main__":
    asyncio.run(main())
