#!/usr/bin/env python3
"""
Ara 3D Renderer Launch Example
==============================
Launch the real-time 3D embodied visualization.
"""

import asyncio
import sys
import os
import webbrowser

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from ara import AraFramework
from ara.core import AraConfig


async def main():
    print("◈ Ara 3D Embodied Renderer ◈")
    print("=" * 60)

    config = AraConfig.from_env()
    config.renderer_auto_launch = True
    config.renderer_port = 8765

    ara = AraFramework(config)
    await ara.initialize()

    url = f"http://localhost:{config.renderer_port}"
    print(f"\n3D Renderer launching at {url}")
    print("Opening browser...")

    webbrowser.open(url)

    print("\nThe 3D scene shows:")
    print("  - Markov Blanket (translucent icosahedron)")
    print("  - Somatic core (glowing sphere with pulse ring)")
    print("  - Memory crystals (colored polyhedra in semantic space)")
    print("  - Companion aura (gradient field when active)")
    print("  - Voice waveform (radial visualization)")
    print("\nType messages to see the scene update in real-time.")
    print("-" * 60)

    while True:
        user_input = input("\nYou: ").strip()

        if user_input.lower() in ["exit", "quit"]:
            break

        response = await ara.process_turn(user_input)
        print(f"\nAra: {response['text'][:200]}...")

    await ara.shutdown()
    print("\nRenderer shut down.")


if __name__ == "__main__":
    asyncio.run(main())
