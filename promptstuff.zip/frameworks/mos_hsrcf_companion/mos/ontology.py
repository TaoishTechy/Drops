from __future__ import annotations
import numpy as np

class MOSState:
    """Numerical state container corresponding to the compact MOS state.

    C=(sigma,rho,r,q,NL,beta2,beta3,Psi)
    This class does not assert that these quantities describe physical reality.
    """

    def __init__(self, dimension=8):
        self.C = np.zeros(dimension, dtype=float)

    def hyper_forward(self, W, S, Q, NL):
        self.C = np.tanh(
            W @ self.C + S + Q.T @ Q + NL.T @ NL
        )
        return self.C.copy()

    def beta(self, alpha=1.0, lam=1.0):
        return -alpha * self.C + lam * self.C**3

    def free_energy_proxy(self, epsilon, grad_epsilon, kappa=1.0):
        epsilon = np.clip(np.asarray(epsilon), 1e-12, None)
        return float(np.sum(
            0.5 * np.asarray(grad_epsilon)**2
            - epsilon * np.log(epsilon) * kappa
        ))

    def killing_field_proxy(self, epsilon, gradient):
        return np.asarray(gradient)
