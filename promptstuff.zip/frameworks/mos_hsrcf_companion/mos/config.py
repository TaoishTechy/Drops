from __future__ import annotations
from dataclasses import dataclass
import os
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Settings:
    xai_api_key: str | None = os.getenv("XAI_API_KEY")
    deepseek_api_key: str | None = os.getenv("DEEPSEEK_API_KEY")
    grok_model: str = os.getenv("GROK_MODEL", "grok-4.5")
    deepseek_model: str = os.getenv("DEEPSEEK_MODEL", "deepseek-v4-pro")
    grok_voice_model: str = os.getenv("GROK_VOICE_MODEL", "grok-voice-latest")
    grok_tts_voice: str = os.getenv("GROK_TTS_VOICE", "eve")
    grok_tts_language: str = os.getenv("GROK_TTS_LANGUAGE", "en")
    database: str = os.getenv("MOS_DB", "mos_memory.sqlite3")
    audit_log: str = os.getenv("MOS_LOG", "mos_audit.jsonl")
