from .config import Settings
from .providers import DualProvider
from .memory import MemoryCrystal
from .brain import DualCoreBrain
from .mogops import MOGOPController
from .safety import AdultProfile, CompanionGuard

def main():
    settings = Settings()
    memory = MemoryCrystal(settings.database)
    providers = DualProvider(settings)
    brain = DualCoreBrain(providers, memory)

    print("MOS-HSRCF Dual-Core")
    print("Left :", brain.left.provider)
    print("Right:", brain.right.provider)
    print("Providers available:", {p: providers.available(p) for p in ("grok", "deepseek")})

    guard = CompanionGuard()
    profile = AdultProfile(enabled=False, age_verified=False)
    print("Adult mode:", guard.authorize_adult_mode(profile))

    if providers.available("deepseek") and providers.available("grok"):
        result = brain.debate("Explain which MOS-HSRCF assumptions should be experimentally falsified first.")
        print("\nLEFT:\n", result["left"].text)
        print("\nRIGHT:\n", result["right"].text)
    else:
        memory.add("Framework initialized without both provider keys.", kind="system", importance=0.2)

    mogops = MOGOPController()
    print("Crystal metrics:", memory.metrics())
    print("MOGOP target:", mogops.efficiency_report(0.70, 0.82))
    memory.close()

if __name__ == "__main__":
    main()
