from __future__ import annotations
from dataclasses import dataclass
from .providers import DualProvider, Provider
from .memory import MemoryCrystal

@dataclass
class Hemisphere:
    name: str
    provider: Provider
    role: str

class DualCoreBrain:
    """Switchable left/right hemisphere assignment."""

    def __init__(self, providers: DualProvider, memory: MemoryCrystal):
        self.providers = providers
        self.memory = memory
        self.left = Hemisphere("left", "deepseek", "analysis")
        self.right = Hemisphere("right", "grok", "synthesis")

    def swap(self):
        self.left.provider, self.right.provider = self.right.provider, self.left.provider

    def route(self, hemisphere: str, prompt: str, system: str = ""):
        h = self.left if hemisphere == "left" else self.right
        memories = self.memory.retrieve(prompt)
        context = "\n".join(f"- {m.text}" for m in memories)
        messages = [
            {"role": "system", "content": system or "You are one hemisphere of a measured dual-core research companion."},
            {"role": "system", "content": f"Relevant memory crystal:\n{context}"},
            {"role": "user", "content": prompt},
        ]
        reply = self.providers.chat(h.provider, messages, reasoning=(h.role == "analysis"))
        self.memory.add(
            f"{hemisphere}/{h.provider}: {reply.text}",
            kind="response",
            importance=0.25,
            tags=[hemisphere, h.provider],
        )
        return reply

    def debate(self, prompt: str) -> dict:
        left = self.route("left", prompt, "Analyze rigorously. Identify assumptions, falsifiers, and uncertainty.")
        right = self.route("right", prompt, "Synthesize creatively but distinguish hypothesis from established fact.")
        return {"left": left, "right": right}
