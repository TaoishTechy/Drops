from __future__ import annotations
import json, time
from pathlib import Path

class AuditLog:
    def __init__(self, path):
        self.path = Path(path)

    def event(self, kind: str, **data):
        rec = {"timestamp": time.time(), "kind": kind, **data}
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, sort_keys=True) + "\n")
