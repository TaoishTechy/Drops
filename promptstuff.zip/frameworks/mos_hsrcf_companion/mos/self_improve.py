from __future__ import annotations
import hashlib, json, time
from pathlib import Path

class ImprovementJournal:
    """Proposal-only self-improvement with benchmark/regression gating."""

    def __init__(self, path="improvement_journal.jsonl"):
        self.path = Path(path)

    def propose(self, title: str, hypothesis: str, baseline: float, candidate: float) -> dict:
        delta = candidate - baseline
        record = {
            "timestamp": time.time(),
            "title": title,
            "hypothesis": hypothesis,
            "baseline": baseline,
            "candidate": candidate,
            "delta": delta,
            "accepted": candidate > baseline,
        }
        record["hash"] = hashlib.sha256(json.dumps(record, sort_keys=True).encode()).hexdigest()
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")
        return record
