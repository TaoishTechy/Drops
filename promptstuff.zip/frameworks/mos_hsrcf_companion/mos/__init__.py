"""MOS-HSRCF Dual-Core Companion Framework."""
__version__ = "0.1.0"
