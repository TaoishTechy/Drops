from __future__ import annotations
import hashlib, json, math, sqlite3, time
from dataclasses import dataclass, asdict

@dataclass
class Memory:
    id: str
    text: str
    kind: str
    importance: float
    created_at: float
    tags: list[str]

class MemoryCrystal:
    """Persistent episodic memory with explicit provenance and graph topology."""

    def __init__(self, db_path: str):
        self.db = sqlite3.connect(db_path)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS memories(
          id TEXT PRIMARY KEY, text TEXT NOT NULL, kind TEXT NOT NULL,
          importance REAL NOT NULL, created_at REAL NOT NULL, tags TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS edges(
          source TEXT NOT NULL, target TEXT NOT NULL, weight REAL NOT NULL,
          PRIMARY KEY(source,target)
        );
        """)
        self.db.commit()

    @staticmethod
    def make_id(text: str, created_at: float) -> str:
        return hashlib.sha256(f"{created_at:.6f}|{text}".encode()).hexdigest()[:24]

    def add(self, text: str, *, kind="episodic", importance=0.5, tags=None) -> Memory:
        now = time.time()
        m = Memory(self.make_id(text, now), text, kind, float(importance), now, tags or [])
        self.db.execute(
            "INSERT INTO memories VALUES (?,?,?,?,?,?)",
            (m.id, m.text, m.kind, m.importance, m.created_at, json.dumps(m.tags))
        )
        self.db.commit()
        return m

    def link(self, source: str, target: str, weight: float = 1.0):
        self.db.execute("INSERT OR REPLACE INTO edges VALUES (?,?,?)", (source, target, weight))
        self.db.commit()

    def recent(self, limit=20) -> list[Memory]:
        rows = self.db.execute(
            "SELECT * FROM memories ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [Memory(r[0], r[1], r[2], r[3], r[4], json.loads(r[5])) for r in rows]

    def retrieve(self, query: str, limit=8) -> list[Memory]:
        q = set(query.lower().split())
        scored = []
        now = time.time()
        for m in self.recent(500):
            words = set(m.text.lower().split())
            overlap = len(q & words) / max(1, len(q))
            recency = math.exp(-(now - m.created_at) / (86400 * 30))
            score = 0.55 * overlap + 0.30 * m.importance + 0.15 * recency
            scored.append((score, m))
        return [m for _, m in sorted(scored, reverse=True, key=lambda x: x[0])[:limit]]

    def metrics(self) -> dict:
        n = self.db.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        e = self.db.execute("SELECT COUNT(*) FROM edges").fetchone()[0]
        density = e / max(1, n * max(1, n - 1))
        return {
            "nodes": n,
            "edges": e,
            "density": density,
            "coherence_proxy": min(1.0, 2 * density + (0.1 if n else 0)),
            "entropy_proxy": math.log2(max(1, n)),
        }

    def close(self):
        self.db.close()
