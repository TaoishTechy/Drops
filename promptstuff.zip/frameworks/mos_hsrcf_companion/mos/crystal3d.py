from __future__ import annotations
import numpy as np

def render_crystal(memory, output="memory_crystal.html"):
    """Render memory graph using optional PyVista."""
    try:
        import pyvista as pv
    except ImportError:
        raise SystemExit("Install optional renderer: pip install pyvista")

    nodes = memory.recent(150)
    if not nodes:
        print("Memory crystal is empty.")
        return

    n = len(nodes)
    rng = np.random.default_rng(42)
    points = rng.normal(size=(n, 3))
    points /= np.linalg.norm(points, axis=1, keepdims=True) + 1e-12
    points *= (0.5 + np.linspace(0.2, 1.0, n))[:, None]

    cloud = pv.PolyData(points)
    cloud["importance"] = np.array([m.importance for m in nodes])
    plotter = pv.Plotter()
    plotter.add_points(cloud, render_points_as_spheres=True, point_size=12)
    plotter.add_axes()
    plotter.export_html(output)
    print(output)

if __name__ == "__main__":
    from .config import Settings
    from .memory import MemoryCrystal
    s = Settings()
    m = MemoryCrystal(s.database)
    render_crystal(m)
