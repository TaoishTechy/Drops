from __future__ import annotations
import httpx
from .config import Settings

class GrokVoice:
    """Batch TTS helper. Realtime voice is exposed as configuration metadata.

    Realtime endpoint: wss://api.x.ai/v1/realtime
    Voice model: grok-voice-latest (or another currently supported xAI voice model).
    """

    def __init__(self, settings: Settings):
        self.settings = settings

    def list_voices(self) -> list[dict]:
        if not self.settings.xai_api_key:
            raise RuntimeError("XAI_API_KEY is not configured")
        r = httpx.get(
            "https://api.x.ai/v1/tts/voices",
            headers={"Authorization": f"Bearer {self.settings.xai_api_key}"},
            timeout=30,
        )
        r.raise_for_status()
        return r.json()["voices"]

    def synthesize(self, text: str, voice: str | None = None, language: str | None = None) -> bytes:
        if not self.settings.xai_api_key:
            raise RuntimeError("XAI_API_KEY is not configured")
        payload = {
            "text": text,
            "voice_id": voice or self.settings.grok_tts_voice,
            "language": language or self.settings.grok_tts_language,
        }
        r = httpx.post(
            "https://api.x.ai/v1/tts",
            headers={
                "Authorization": f"Bearer {self.settings.xai_api_key}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=60,
        )
        r.raise_for_status()
        return r.content

    @property
    def realtime_config(self) -> dict:
        return {
            "url": "wss://api.x.ai/v1/realtime",
            "model": self.settings.grok_voice_model,
            "voice": self.settings.grok_tts_voice,
        }
