from __future__ import annotations
from dataclasses import dataclass, field

@dataclass
class AdultProfile:
    enabled: bool = False
    age_verified: bool = False
    consent_scope: str = "general"
    boundaries: list[str] = field(default_factory=list)

class CompanionGuard:
    """18+ feature gate and boundary layer.

    This is a local governance layer, not a replacement for provider policies.
    """

    def authorize_adult_mode(self, profile: AdultProfile) -> bool:
        return bool(profile.enabled and profile.age_verified)

    def system_prompt(self, profile: AdultProfile) -> str:
        mode = "adult companion mode is enabled" if self.authorize_adult_mode(profile) else "standard companion mode"
        return (
            f"You are operating in {mode}. Maintain explicit consent, boundaries, "
            "privacy, and user agency. Never claim to be a human or imply that "
            "the companion has independent real-world needs."
        )
