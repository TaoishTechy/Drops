from __future__ import annotations
from dataclasses import dataclass
from typing import Literal
from openai import OpenAI
from .config import Settings

Provider = Literal["grok", "deepseek"]

@dataclass
class LLMReply:
    provider: str
    model: str
    text: str
    usage: dict

class DualProvider:
    """Provider adapter. API secrets stay server-side and are never persisted."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self.clients = {}
        if settings.xai_api_key:
            self.clients["grok"] = OpenAI(
                api_key=settings.xai_api_key,
                base_url="https://api.x.ai/v1",
            )
        if settings.deepseek_api_key:
            self.clients["deepseek"] = OpenAI(
                api_key=settings.deepseek_api_key,
                base_url="https://api.deepseek.com",
            )

    def available(self, provider: Provider) -> bool:
        return provider in self.clients

    def chat(
        self,
        provider: Provider,
        messages: list[dict],
        *,
        temperature: float = 0.7,
        reasoning: bool = False,
    ) -> LLMReply:
        if provider not in self.clients:
            raise RuntimeError(f"{provider} API key is not configured")
        model = self.settings.grok_model if provider == "grok" else self.settings.deepseek_model
        kwargs = dict(model=model, messages=messages, temperature=temperature)
        if provider == "deepseek" and reasoning:
            kwargs["reasoning_effort"] = "high"
            kwargs["extra_body"] = {"thinking": {"type": "enabled"}}
        response = self.clients[provider].chat.completions.create(**kwargs)
        msg = response.choices[0].message
        usage = response.usage.model_dump() if response.usage else {}
        return LLMReply(provider, model, msg.content or "", usage)
