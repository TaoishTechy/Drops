# MOS-HSRCF Dual-Core Companion Framework v0.1

A research-oriented Python scaffold that turns the MOS-HSRCF v4.0 equations into **computable control/measurement objects**, rather than treating the ontology's mathematical claims as experimentally established facts.

## Features

- **Grok + DeepSeek dual-provider brain**
  - Grok via xAI's OpenAI-compatible REST API.
  - DeepSeek via its OpenAI-compatible API.
  - Independently selectable left/right hemisphere assignment.
  - `GROK_MODEL` defaults to `grok-4.5`.
  - `DEEPSEEK_MODEL` defaults to `deepseek-v4-pro`.
- **Grok voice**
  - Selectable `grok-voice-latest`, `grok-voice-think-fast-2.0`, or `grok-voice-think-fast-1.0` for realtime mode.
  - Selectable built-in TTS voice IDs (`ara`, `eve`, `leo`, `rex`, `sal`) for batch speech.
- **Memory Crystal**
  - SQLite-backed episodic memory.
  - Deterministic content hashing.
  - Importance/recency/relevance scoring.
  - Graph edges between memories.
  - "Crystal" topology metrics: density, coherence, entropy proxy, persistence proxy.
- **3D rendering**
  - Optional PyVista/VTK visualization of the memory crystal.
  - Falls back to a numerical snapshot if PyVista is unavailable.
- **MOGOPs**
  - Multi-Objective Governance/Optimization Operations controller.
  - Optimizes latency, token cost, agreement, memory relevance, and safety margin.
  - Never promises 99.9% efficiency; it measures achieved efficiency and reports confidence.
- **Self-improvement**
  - Proposal → benchmark → regression gate → signed journal entry.
  - No autonomous code mutation by default.
- **18+ companion layer**
  - Explicit opt-in adult mode, age-gate state, consent/boundary profile, and content-policy hook.
  - The scaffold does not bypass provider safety systems and does not generate explicit sexual content by default.

## Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Set:
- `XAI_API_KEY`
- `DEEPSEEK_API_KEY`

Run the demo:

```bash
python -m mos.demo
```

Run tests:

```bash
pytest -q
```

Optional 3D:

```bash
pip install pyvista
python -m mos.crystal3d
```

## Important scientific boundary

MOS-HSRCF v4.0 is represented here as a **computational hypothesis/modeling framework**. Axioms such as the ERD-Killing-Field theorem, Standard Model mapping, neuro predictions, cosmological predictions, and the reported 0.979 reliability score are not assumed to be scientifically validated by this software. The framework logs assumptions, residuals, benchmarks, and falsification hooks so those claims can be tested independently.
