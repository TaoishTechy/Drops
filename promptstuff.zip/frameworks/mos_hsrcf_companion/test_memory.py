from mos.memory import MemoryCrystal

def test_memory_roundtrip(tmp_path):
    db = tmp_path / "m.sqlite"
    m = MemoryCrystal(str(db))
    x = m.add("ERD metric hypothesis", importance=0.9, tags=["erd"])
    m.link(x.id, x.id, 1.0)
    found = m.retrieve("ERD metric")
    assert found
    assert found[0].id == x.id
    assert m.metrics()["nodes"] == 1
    m.close()
