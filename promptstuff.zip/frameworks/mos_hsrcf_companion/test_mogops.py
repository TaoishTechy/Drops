from mos.mogops import MOGOPController, Objective

def test_score_range():
    c = MOGOPController()
    s = c.score(Objective(latency=0, cost=0, agreement=1, relevance=1, safety_margin=1))
    assert 0 <= s <= 1

def test_candidate_selection():
    c = MOGOPController()
    a = {"name": "a", "metrics": {"latency": 1, "cost": 1, "agreement": .5, "relevance": .5, "safety_margin": .5}}
    b = {"name": "b", "metrics": {"latency": 0, "cost": 0, "agreement": 1, "relevance": 1, "safety_margin": 1}}
    assert c.choose([a,b])["name"] == "b"
