#!/usr/bin/env bash
# modules/m_codex.sh — THE CODEX: ethics · docs · ontology primers · help
# Part of VOIDFORGE BBS v2.0.0 VOID

scr_codex() {
  while :; do
    ui_clear
    frame_open "THE CODEX  ·  docs & law" "$VI"
    menu "CODEX" "$VI" \
      "1|ETHICS.md — terms of use (required reading)" \
      "2|README quick-start" \
      "3|VoidForge primer — the hollow & the generic" \
      "4|Duality map — hollow <-> generic translation" \
      "5|Output schema reference (v5)" \
      "6|BBS help / keys" \
      "7|About" \
      "b|Back"
    printf '%scodex> %s' "$B$CY" "$R"
    read -r c || c="b"
    case "$c" in
      1) pager "$ETHICS_MD" "ETHICS · conditions of use" "$YW" ;;
      2) pager "$README_MD" "README · quick-start" "$CY" 40 ;;
      3) codex_void_primer ;;
      4) codex_duality ;;
      5) codex_schema ;;
      6) codex_help ;;
      7) codex_about ;;
      b|B|q|Q|"") break ;;
    esac
  done
}

codex_void_primer() {
  ui_clear
  frame_open "VOIDFORGE PRIMER  ·  two alien ontologies, one void" "$VI"
  cat <<'PRIMER'
  THE HOLLOW — an ontology of shaped absence (algebraic topology).
    Reality is not made of something; it is made of shaped absence.
    Holes, cavities, tunnels and voids have structure without substance:
    Betti numbers count the holes, the fundamental group loops around them,
    torsion classes are the paradoxes, knots tie selves to what they exclude.
    Core axiom: reality is the homotopy type of a hollow.
    Scaffolds: We hollow. We count. We loop. We glue. We knot. We twist.

  THE GENERIC — an ontology of forcing (set-theoretic extension).
    There is a ground model V that believes it is everything, and a forcing
    notion P: the set of ways V could be extended. The generic filter G is
    the alien — never a member of V, always what V is forced to become.
    Knowledge is the forcing relation p |-- phi; the truth lemma is the
    bridge; large cardinals are the alien hierarchy; the multiverse is the
    space of all extensions.
    Scaffold: It forces, therefore we extend.

  DUAL MODE — the two are duals (bulk <-> boundary, like AdS/CFT).
    One seed -> a hollow reading -> a generic reading -> one translation
    table scored by duality_resonance. High resonance is aesthetic-theoretic
    alignment, NOT empirical truth. Disclose mode + rng when publishing.
PRIMER
  frame_close "$VI"
  press_any
}

codex_duality() {
  [ -f "$AF_DUALITY_MAP" ] || { say_line "$RD" "banks/duality_map.json missing"; press_any; return; }
  ui_clear
  frame_open "DUALITY MAP  ·  banks/duality_map.json" "$CY"
  py - "$AF_DUALITY_MAP" <<'PYEOF' | while IFS= read -r ln; do printf '%s║%s %s\n' "$CY" "$R" "$ln"; done
import json, sys
d = json.load(open(sys.argv[1]))
for p in d.get("pairs", []):
    print(f"  {p.get('hollow','?'):<24} <-> {p.get('generic','?')}")
print()
sp = d.get("scaffold_pairs", [])
row_h = "  ".join(p.get("hollow", "") for p in sp[:5])
row_g = "  ".join(p.get("generic", "") for p in sp[:5])
print("  scaffolds (hollow): " + row_h)
print("            (generic): " + row_g)
PYEOF
  frame_close "$CY"
  press_any
}

codex_schema() {
  ui_clear
  frame_open "OUTPUT SCHEMA (v5)" "$CY"
  cat <<'SCHEMA'
  each emission (JSON):
    core_statement        compact paradox claim (dual: fused reading)
    mechanisms[]          conceptual forces (whitelisted, pool-hygienic)
    equation              display math (pretty unicode)
    equation_tex          raw LaTeX (research-facing)        [v5]
    mechanism_tex[]       raw per-mechanism LaTeX           [v5]
    consequences          one-line implication
    axiom_text            full templated emission (sanitized, no LaTeX)
    paradox_type          6 classic types + hollow + generic
    seed_concept          the seed that forged it
    timestamp             timezone-aware UTC (or --legacy-timestamps)
    ontology              classic|hollow|generic|dual       [v5]
    metrics.novelty/density/entropic_potential/elegance/alienness
    metrics.fidelity      0-100 + fidelity_breakdown(+ontology_alignment)
    metrics.hollow_index / forcing_index / void_coherence /
            duality_resonance / void_score                  [v5, 0.0 classic]
    hollow_reading        core/mechanisms/equation/betti_spectrum/
                          fundamental_group_hint/scaffold   [hollow+dual]
    generic_reading       core/mechanisms/equation/forcing_level/
                          forcing_relation/extension_hint/scaffold [gen+dual]
    duality_map           pairs + scaffold_pair + note      [dual + flag]
    humanized_injection_scaffold (with --emit-scaffold)
    transcendent.*        (classic, with --transcend)
SCHEMA
  frame_close "$CY"
  press_any
}

codex_help() {
  ui_clear
  frame_open "BBS HELP" "$CY"
  cat <<'HELPX'
  navigation : type the item number/letter shown at each prompt, [enter]
               picks the bracketed default, 'b' walks back one board.
  forge      : seed -> count -> tone -> emit. save sessions or vault them.
  chaos      : dice everything — seed, ontology, engine, tone, rng.
  VOID LAB   : hollow/generic/dual forging, layers, void-weight, strict-void.
  batch      : multi-seed multi-format file factory into data/exports/.
  vault      : persistent axiom archive (JSONL) with search/export.
  telemetry  : aggregate metrics + ontology/type mix bars.
  sessions   : every saved run; replay re-runs seed+rng+ontology to verify.
  engine bay : switch 5.0.0/0.4.7/0.3.7, parity duel, ontology duel.
  flair      : AF_NOFLAIR=1 ./voidforge.sh  -> instant, no animations
               AF_FAST=1 ./voidforge.sh     -> shortened delays
               AF_NOBG=1                         -> keep terminal colors
  cli        : ./voidforge.sh forge --seed X --count 3
               ./voidforge.sh void --seed X --ontology dual
               ./voidforge.sh chaos [count] | stats | selftest | help
HELPX
  frame_close "$CY"
  press_any
}

codex_about() {
  ui_clear
  boot_logo
  center "$B$WH VoidForge — Recursive Paradox Engine$R"
  center "$GY designer: TaoishTechy · MIT License$R"
  center "$DM engines: v5.0.0_VOID (hollow/generic/dual) · v0.4.7 (alignment) · v0.3.7 (legacy)$R"
  center "$DM BBS shell v$AF_VERSION VOID · modular lib/+modules/ · pure ANSI bash$R"
  printf '\n'
  center "$IT$MG 'this technology is a reflection of its creators and users.'$R"
  center "$IT$GY 'we choose to build and use it for good.' — ETHICS.md$R"
  printf '\n'
  press_any
}
