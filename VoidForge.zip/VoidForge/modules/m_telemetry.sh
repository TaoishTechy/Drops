#!/usr/bin/env bash
# modules/m_telemetry.sh — TELEMETRY: aggregate stats incl. ontology mix
# Part of VOIDFORGE BBS v2.0.0 VOID

scr_telemetry() {
  ui_clear
  frame_open "TELEMETRY  ·  aggregate engine stats" "$CY"
  py - "$AF_SESS" "$AF_VAULTF" "$AF_EXPORT" <<'PYEOF' | while IFS= read -r ln; do printf '%s║%s %s\n' "$CY" "$R" "$ln"; done
import json, os, sys, glob, collections
sess_dir, vaultf, export_dir = sys.argv[1], sys.argv[2], sys.argv[3]
rows = []
for p in sorted(glob.glob(os.path.join(sess_dir, "*.json"))):
    try: rows.extend(json.load(open(p)).get("results", []))
    except Exception: pass
for p in sorted(glob.glob(os.path.join(export_dir, "batch_*.json"))):
    try: rows.extend(json.load(open(p)).get("results", []))
    except Exception: pass
try:
    for ln in open(vaultf):
        try: rows.append(json.loads(ln).get("axiom", {}))
        except Exception: pass
except Exception:
    pass
if not rows:
    print("  no telemetry yet — forge, chaos, void, or batch first"); sys.exit(0)
n = len(rows)
types = collections.Counter(r.get("paradox_type", "?") for r in rows)
ontologies = collections.Counter(r.get("ontology", "classic") for r in rows)
seeds = collections.Counter(r.get("seed_concept", "?") for r in rows)
def avg(key, pred=lambda r: True):
    vals = []
    for r in rows:
        try:
            if pred(r):
                v = r.get("metrics", {}).get(key)
                if v is not None: vals.append(float(v))
        except Exception: pass
    return sum(vals)/len(vals) if vals else 0.0
print(f"  EMISSIONS: {n} axioms archived")
print(f"  AVG fidelity {avg('fidelity'):.1f} · novelty {avg('novelty'):.3f} · density {avg('density'):.2f} · elegance {avg('elegance'):.1f} · alienness {avg('alienness'):.2f}")
fb_align = [float(r.get('metrics',{}).get('fidelity_breakdown',{}).get('concept_alignment',0) or 0) for r in rows]
print(f"  AVG concept_alignment {sum(fb_align)/len(fb_align):.3f}")
void_rows = [r for r in rows if r.get("ontology", "classic") != "classic"]
if void_rows:
    print(f"  VOID avg (over {len(void_rows)} non-classic): hollow_idx {avg('hollow_index', lambda r: r.get('ontology','classic') != 'classic'):.2f} · "
          f"forcing_idx {avg('forcing_index', lambda r: r.get('ontology','classic') != 'classic'):.2f} · "
          f"coherence {avg('void_coherence', lambda r: r.get('ontology','classic') != 'classic'):.3f} · "
          f"resonance {avg('duality_resonance', lambda r: r.get('ontology','classic') != 'classic'):.3f} · "
          f"void_score {avg('void_score', lambda r: r.get('ontology','classic') != 'classic'):.3f}")
print("  -- ontology mix --")
for t, c in ontologies.most_common():
    pct = c / n
    b = "█" * max(1, int(pct * 28))
    print(f"  {t:<14} {b:<28} {c:>4} ({pct*100:.0f}%)")
print("  -- paradox type mix --")
for t, c in types.most_common():
    pct = c / n
    b = "█" * max(1, int(pct * 28))
    print(f"  {t:<14} {b:<28} {c:>4} ({pct*100:.0f}%)")
print("  -- top seeds --")
for s, c in seeds.most_common(6):
    print(f"  {s[:40]:<40} x{c}")
PYEOF
  frame_close "$CY"
  press_any
}
