#!/usr/bin/env bash
# modules/m_enginebay.sh — ENGINE BAY: 5.0.0_VOID / 0.4.7 / 0.3.7 + duels
# Part of VOIDFORGE BBS v2.0.0 VOID

scr_enginebay() {
  while :; do
    ui_clear
    frame_open "ENGINE BAY  ·  active: $(engine_label) · ontology: $CFG_ONTOLOGY" "$MGD"
    printf '%s║%s %s5.0.0 %s%s%s  VOID — hollow/generic/dual router + parity classic%s\n' "$MGD" "$R" "$B$CY" "$R" "$( [ "$AF_ENGINE50" = 1 ] && echo "$GR● installed$R" || echo "$RD○ missing$R" )" "$CYD" "$R"
    printf '%s║%s %s0.4.7 %s%s%s  sanitizer+alignment+whitelists (parity baseline)%s\n' "$MGD" "$R" "$B$CY" "$R" "$( [ "$AF_ENGINE47" = 1 ] && echo "$GR● installed$R" || echo "$RD○ missing$R" )" "$CYD" "$R"
    printf '%s║%s %s0.3.7 %s%s%s  legacy god-tier pass (A/B baselines)%s\n' "$MGD" "$R" "$B$CY" "$R" "$( [ "$AF_ENGINE37" = 1 ] && echo "$GR● installed$R" || echo "$RD○ missing$R" )" "$CYD" "$R"
    printf '%s║%s %sactive selection: %s%s%s · ontology %s%s%s\n' "$MGD" "$R" "$GY" "$R$B$WH" "$(engine_label)" "$R$GY" "$R$B$WH" "$CFG_ONTOLOGY" "$R"
    frame_close "$MGD"
    menu "ENGINE BAY" "$MGD" \
      "1|Select 5.0.0 VOID (hollow/generic/dual engine)" \
      "2|Select 0.4.7 (alignment release)" \
      "3|Select 0.3.7 (legacy pass)" \
      "4|PARITY DUEL — 0.4.7 vs 5.0.0 classic (must match)" \
      "5|ONTOLOGY DUEL — hollow vs generic on one seed" \
      "6|Engine CLI reference" \
      "b|Back"
    printf '%sbay> %s' "$B$CY" "$R"
    read -r c || c="b"
    case "$c" in
      1) if [ "$AF_ENGINE50" = 1 ]; then CFG_ENGINE="5.0.0"; [ "$CFG_ONTOLOGY" = "classic" ] && CFG_ONTOLOGY="dual"; conf_save; say_line "$GR" "engine → 5.0.0_VOID (ontology $CFG_ONTOLOGY)"; else say_line "$RD" "5.0.0_VOID not installed"; fi; press_any ;;
      2) if [ "$AF_ENGINE47" = 1 ]; then CFG_ENGINE="0.4.7"; CFG_ONTOLOGY="classic"; conf_save; say_line "$GR" "engine → 0.4.7"; else say_line "$RD" "0.4.7 not installed"; fi; press_any ;;
      3) if [ "$AF_ENGINE37" = 1 ]; then CFG_ENGINE="0.3.7"; CFG_ONTOLOGY="classic"; conf_save; say_line "$YW" "engine → 0.3.7 (legacy quirks included)"; else say_line "$RD" "0.3.7 not installed"; fi; press_any ;;
      4) ab_parity ;;
      5) ab_ontology ;;
      6) engine_help ;;
      b|B|q|Q|"") break ;;
    esac
  done
}

_ab_capture() {  # _ab_capture <outfile> — run one emission with current settings
  local outfile="$1"
  run_engine "$AB_SEED" 1 poetic "$AB_RNG" 1 || return 1
  cp "$AF_TMP/session.json" "$outfile"
}

ab_parity() {
  [ "$AF_ENGINE47" -eq 1 ] && [ "$AF_ENGINE50" -eq 1 ] || { say_line "$RD" "both 0.4.7 and 5.0.0_VOID required for the parity duel"; press_any; return; }
  AB_SEED="$(ask 'duel seed' 'Dark Forest Theory')"
  AB_RNG="$(ask 'duel rng' '1337')"
  ui_clear
  frame_open "PARITY DUEL · \"$AB_SEED\" · rng=$AB_RNG" "$MG"
  sleepx 0.3
  local out47="$AF_TMP/duel47.json" out50="$AF_TMP/duel50.json"
  local pe="$CFG_ENGINE" po="$CFG_ONTOLOGY"
  printf '%s║%s %srunning 0.4.7 …%s\n' "$MG" "$R" "$CY" "$R"
  CFG_ENGINE="0.4.7"; CFG_ONTOLOGY="classic"; _ab_capture "$out47"
  printf '%s║%s %srunning 5.0.0_VOID --ontology classic …%s\n' "$MG" "$R" "$HC" "$R"
  CFG_ENGINE="5.0.0"; CFG_ONTOLOGY="classic"; _ab_capture "$out50"
  CFG_ENGINE="$pe"; CFG_ONTOLOGY="$po"

  ui_clear
  frame_open "PARITY VERDICT" "$MG"
  local a b
  a="$(jget "$out47" results.0.core_statement '?')"
  b="$(jget "$out50" results.0.core_statement '?')"
  printf '%s║%s %s── 0.4.7 ──%s\n' "$MG" "$R" "$CY" "$R"
  printf '%s║%s %s%s%s\n' "$MG" "$R" "$GY" "${a:0:$((AF_COLS-8))}" "$R"
  printf '%s║%s %s── 5.0.0 classic ──%s\n' "$MG" "$R" "$HC" "$R"
  printf '%s║%s %s%s%s\n' "$MG" "$R" "$GY" "${b:0:$((AF_COLS-8))}" "$R"
  printf '%s║%s\n' "$MG" "$R"
  if [ "$a" = "$b" ] && [ "$a" != "?" ]; then
    printf '%s║%s %sverdict: IDENTICAL cores — VOID classic preserves the alignment release%s\n' "$MG" "$R" "$GR" "$R"
  else
    printf '%s║%s %sverdict: MISMATCH — parity broken (report this)%s\n' "$MG" "$R" "$RD" "$R"
  fi
  frame_close "$MG"
  press_any
}

ab_ontology() {
  [ "$AF_ENGINE50" -eq 1 ] || { say_line "$RD" "5.0.0_VOID engine required"; press_any; return; }
  AB_SEED="$(ask 'duel seed' 'Nested Realities')"
  AB_RNG="$(ask 'duel rng' '20250926')"
  ui_clear
  frame_open "ONTOLOGY DUEL · \"$AB_SEED\" · rng=$AB_RNG" "$VI"
  sleepx 0.3
  local pe="$CFG_ENGINE" po="$CFG_ONTOLOGY" ph="$CFG_HLEVEL" pf="$CFG_FLEVEL"
  CFG_ENGINE="5.0.0"
  printf '%s║%s %srunning hollow --hollow-level %s …%s\n' "$VI" "$R" "$HC" "$ph" "$R"
  CFG_ONTOLOGY="hollow"
  run_ontology "$AB_SEED" 1 poetic "$AB_RNG" 1 && cp "$AF_TMP/session.json" "$AF_TMP/duelh.json"
  printf '%s║%s %srunning generic --forcing-level %s …%s\n' "$VI" "$R" "$GC" "$pf" "$R"
  CFG_ONTOLOGY="generic"
  run_ontology "$AB_SEED" 1 poetic "$AB_RNG" 1 && cp "$AF_TMP/session.json" "$AF_TMP/duelg.json"
  CFG_ENGINE="$pe"; CFG_ONTOLOGY="$po"

  ui_clear
  frame_open "ONTOLOGY DUEL VERDICT" "$VI"
  local ch cg eqg eqh
  ch="$(jget "$AF_TMP/duelh.json" results.0.hollow_reading.core_statement '?')"
  cg="$(jget "$AF_TMP/duelg.json" results.0.generic_reading.core_statement '?')"
  eqh="$(jget "$AF_TMP/duelh.json" results.0.equation '-')"
  eqg="$(jget "$AF_TMP/duelg.json" results.0.equation '-')"
  printf '%s║%s\n' "$VI" "$R"
  printf '%s║%s %s── HOLLOW (shaped absence) ──────────────%s\n' "$VI" "$R" "$HC" "$R"
  printf '%s║%s %s%s%s\n' "$VI" "$R" "$GY" "${ch:0:$((AF_COLS-8))}" "$R"
  printf '%s║%s %smath:%s %s%s%s\n' "$VI" "$R" "$DM" "$R" "$OR" "$eqh" "$R"
  printf '%s║%s\n' "$VI" "$R"
  printf '%s║%s %s── GENERIC (forced extension) ───────────%s\n' "$VI" "$R" "$GC" "$R"
  printf '%s║%s %s%s%s\n' "$VI" "$R" "$GY" "${cg:0:$((AF_COLS-8))}" "$R"
  printf '%s║%s %smath:%s %s%s%s\n' "$VI" "$R" "$DM" "$R" "$OR" "$eqg" "$R"
  printf '%s║%s\n' "$VI" "$R"
  printf '%s║%s %sverdict: divergent by design — one void, two readings%s\n' "$VI" "$R" "$YW" "$R"
  printf '%s║%s %s(run VOIDFORGE LAB dual mode to translate between them)%s\n' "$VI" "$R" "$DM" "$R"
  frame_close "$VI"
  press_any
}

engine_help() {
  ui_clear
  frame_open "ENGINE CLI REFERENCE" "$CY"
  cat <<'HELP'
  v5.0.0_VOID: --seed S --count N --tone T --rng N --emit-scaffold
               --ontology {classic|hollow|generic|dual|legacy}
               --hollow-level {cw|betti|cohomology|homotopy}
               --forcing-level {poset|boolean|cardinal|multiverse}
               --void-weight W --emit-duality --allow-temporal-hollow
               --strict-void --paradox-type T --legacy-timestamps
               --out F --selftest
  v0.4.7:      --seed S --count N --tone T --rng N --emit-scaffold
               --transcend --max-mech N --selfref-mode M --out F
  v0.3.7:      --seed S --seedfile F --count N --tone T --rng N
               --max-mech N --allow-duplicates --selfref-mode M
               --emit-scaffold --save-to-history
  tones: poetic | plain | academic | oracular
  determinism: pin --rng; keep bank files unchanged between runs.
  parity: v5 --ontology classic reproduces 0.4.7 (modulo UTC fix).
HELP
  frame_close "$CY"
  press_any
}
