#!/usr/bin/env bash
# modules/m_session.sh — SESSION LOG: history, replay, determinism checks
# Part of VOIDFORGE BBS v2.0.0 VOID (ontology-aware replay)

scr_sessions() {
  while :; do
    ui_clear
    frame_open "SESSION LOG  ·  data/sessions/" "$CY"
    local i=1 f
    while IFS= read -r f; do
      printf '%s║%s  %s%2d%s %s%-34s%s %s%3d axioms%s %s%s%s\n' "$CY" "$R" "$B$MG" "$i" "$R" \
        "$WH" "$(basename "$f")" "$R" "$DM" "$(py -c "
import json,sys
try: print(len(json.load(open('$f')).get('results',[])))
except Exception: print('?')")" "$R" "$DM" \
        "$(jget "$f" session.params.ontology '')" "$R"
      i=$((i+1))
    done < <(ls -t "$AF_SESS"/*.json 2>/dev/null | head -12)
    [ $i -eq 1 ] && printf '%s║%s  %s(no saved sessions — save one from the FORGE or VOID LAB)%s\n' "$CY" "$R" "$DM" "$R"
    frame_close "$CY"
    menu "SESSIONS" "$CY" \
      "1|Inspect a session" \
      "2|REPLAY a session (re-run saved seed + rng + ontology)" \
      "3|Delete a session" \
      "b|Back"
    printf '%ssessions> %s' "$B$MG" "$R"
    read -r c || c="b"
    case "$c" in
      1) sess_inspect ;;
      2) sess_replay ;;
      3) sess_delete ;;
      b|B|q|Q|"") break ;;
    esac
  done
}
sess_pick() {
  local -a files=()
  local f
  while IFS= read -r f; do files+=("$f"); done < <(ls -t "$AF_SESS"/*.json 2>/dev/null)
  (( ${#files[@]} == 0 )) && { say_line "$DM" "no sessions saved"; press_any; return 1; }
  local n=${#files[@]} sel
  sel="$(ask "session # (1-$n)" 1)"
  if [[ "$sel" =~ ^[0-9]+$ ]] && (( sel>=1 && sel<=n )); then
    printf '%s' "${files[$((sel-1))]}"; return 0
  fi
  return 1
}
sess_inspect() {
  local f; f="$(sess_pick)" || return
  ui_clear
  frame_open "SESSION · $(basename "$f")" "$CY"
  local seed rng tone eng count onto
  seed="$(jget "$f" session.seedPrompt '?')"
  rng="$(jget "$f" session.rng '-')"
  tone="$(jget "$f" session.params.tone '?')"
  eng="$(jget "$f" session.params.engine "$(jget "$f" engine '?')")"
  count="$(jget "$f" session.params.count '?')"
  onto="$(jget "$f" session.params.ontology '-')"
  printf '%s║%s %sseed:%s %s%s%s\n' "$CY" "$R" "$DM" "$R" "$WH" "$seed" "$R"
  printf '%s║%s %srng:%s  %s%s%s   %stone:%s %s%s%s   %sengine:%s %s%s%s   %scount:%s %s%s%s\n' \
    "$CY" "$R" "$DM" "$R" "$WH" "$rng" "$R" "$DM" "$R" "$WH" "$tone" "$R" "$DM" "$R" "$WH" "$eng" "$R" "$DM" "$R" "$WH" "$count" "$R"
  [ "$onto" != "-" ] && printf '%s║%s %sontology:%s %s%s%s\n' "$CY" "$R" "$DM" "$R" "$WH" "$onto" "$R"
  frame_close "$CY"
  printf '\n  %sfirst 3 cores:%s\n' "$DM" "$R"
  py - "$f" <<'PYEOF' | sed 's/^/  /'
import json, sys
try: rs = json.load(open(sys.argv[1])).get("results", [])
except Exception: rs = []
for r in rs[:3]:
    onto = r.get("ontology", "classic")
    tag = "" if onto == "classic" else f" ({onto})"
    print("·", r.get("core_statement", "")[:64] + tag)
PYEOF
  press_any
}
sess_replay() {
  local f; f="$(sess_pick)" || return
  local seed rng tone count onto eng
  seed="$(jget "$f" session.seedPrompt '')"
  rng="$(jget "$f" session.rng '')"
  tone="$(jget "$f" session.params.tone 'poetic')"
  count="$(jget "$f" session.params.count 3)"
  onto="$(jget "$f" session.params.ontology 'classic')"
  eng="$(jget "$f" session.params.engine '')"
  [ -z "$seed" ] && { say_line "$YW" "session has no seed recorded"; press_any; return; }
  [ -z "$rng" ] || [ "$rng" = "-" ] && { say_line "$YW" "session has no rng pinned (organic run)"; press_any; return; }
  ui_clear
  frame_open "REPLAY · $seed · rng=$rng · $onto" "$MG"
  printf '%s║%s %sdeterministic engines should reproduce identical cores.%s\n' "$MG" "$R" "$GY" "$R"
  frame_close "$MG"
  sleepx 0.4
  # route to the engine + ontology the session was forged with
  local pe="$CFG_ENGINE" po="$CFG_ONTOLOGY" rc=1
  if [ "$onto" != "classic" ] || [ "$eng" = "voidforge_5.0.0.py" ]; then
    if [ "$AF_ENGINE50" -eq 1 ]; then
      CFG_ENGINE="5.0.0"
      [ "$onto" = "classic" ] && onto="classic"
      CFG_ONTOLOGY="$onto"
      if [ "$CFG_ONTOLOGY" = "classic" ]; then
        run_engine "$seed" "$count" "$tone" "$rng" 1 && rc=0
      else
        run_ontology "$seed" "$count" "$tone" "$rng" 1 && rc=0
      fi
    else
      say_line "$RD" "5.0.0_VOID engine missing — cannot replay void session"
      press_any; return
    fi
  elif [ "$eng" = "axiomforge_0.3.7.py" ] && [ "$AF_ENGINE37" -eq 1 ]; then
    CFG_ENGINE="0.3.7"
    run_engine "$seed" "$count" "$tone" "$rng" 1 && rc=0
  else
    CFG_ENGINE="0.4.7"
    run_engine "$seed" "$count" "$tone" "$rng" 1 && rc=0
  fi
  CFG_ENGINE="$pe"; CFG_ONTOLOGY="$po"
  [ $rc -ne 0 ] && { say_line "$RD" "replay fault"; press_any; return; }
  chime
  # compare against stored
  local match
  match="$(py - "$f" "$AF_TMP/session.json" <<'PYEOF'
import json, sys
try:
    old = [r.get("core_statement","").strip().lower() for r in json.load(open(sys.argv[1])).get("results", [])]
    new = [r.get("core_statement","").strip().lower() for r in json.load(open(sys.argv[2])).get("results", [])]
except Exception:
    print("error"); raise SystemExit
if not old or not new:
    print("error"); raise SystemExit
same = sum(1 for a, b in zip(old, new) if a == b)
print(f"{same}/{len(old)}")
PYEOF
)"
  case "$match" in
    error) say_line "$YW" "could not compare sessions" ;;
  esac
  if [[ "$match" =~ ^[0-9]+/[0-9]+$ ]]; then
    local a="${match%%/*}" b="${match##*/}"
    if [ "$a" = "$b" ]; then
      say_line "$GR" "REPLAY VERIFIED · $match cores identical"
    else
      say_line "$YW" "drift detected · $match cores match (bank edits or wrong engine route?)"
    fi
  fi
  local i n; n="$(ax_count)"
  ui_clear
  for ((i=0; i<n; i++)); do show_axiom "$i"; printf '\n'; done
  press_any
}
sess_delete() {
  local f; f="$(sess_pick)" || return
  rm -f "$f"; say_line "$YW" "deleted $(basename "$f")"; press_any
}
