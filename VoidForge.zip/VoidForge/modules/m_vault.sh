#!/usr/bin/env bash
# modules/m_vault.sh — THE VAULT: persistent axiom archive (JSONL)
# Part of VOIDFORGE BBS v2.0.0 VOID

scr_vault() {
  while :; do
    local cnt; cnt="$(jsonl_count)"
    ui_clear
    frame_open "THE VAULT  ·  $cnt archived axioms" "$VI"
    menu "VAULT MENU" "$VI" \
      "1|List / browse" \
      "2|Search text" \
      "3|Search by tag/seed/ontology" \
      "4|Export vault (MD + TXT)" \
      "5|Purge vault (danger)" \
      "b|Back"
    printf '%svault> %s' "$B$CY" "$R"
    read -r c || c="b"
    case "$c" in
      1) vault_browse ;;
      2) vault_search text ;;
      3) vault_search seed ;;
      4) vault_export ;;
      5) vault_purge ;;
      b|B|q|Q|"") break ;;
    esac
  done
}

vault_browse() {
  [ "$(jsonl_count)" = "0" ] && { say_line "$DM" "vault is empty — forge something first"; press_any; return; }
  local page=0 per=8 total recs
  recs="$(jsonl_count)"
  total=$(( (recs + per - 1) / per ))
  while :; do
    (( page < 0 )) && page=0; (( page >= total )) && page=$((total-1))
    ui_clear
    frame_open "VAULT BROWSE  ·  page $((page+1))/$total" "$VI"
    py - "$AF_VAULTF" "$page" "$per" <<'PYEOF' | while IFS= read -r ln; do printf '%s║%s %s\n' "$VI" "$R" "$ln"; done
import json, sys
page, per = int(sys.argv[2]), int(sys.argv[3])
try:
    lines = open(sys.argv[1]).read().splitlines()
except Exception:
    lines = []
sel = lines[page*per:(page+1)*per]
for ln in sel:
    try: rec = json.loads(ln)
    except Exception: continue
    ax = rec.get("axiom", {})
    core = ax.get("core_statement", "")[:52]
    pt = ax.get("paradox_type", "?")[:9]
    onto = ax.get("ontology", "classic")
    tag = "" if onto == "classic" else f" {onto[:4]}:"
    print(f"  {rec.get('id','?'):<14} [{pt:<9}]{tag:<6} {core}")
PYEOF
    frame_close "$VI"
    printf '%s[#]view id · [n]ext · [p]rev · [d]elete id · [b]ack %s> %s%s' "$MG" "$R" "$B$WH" "$R"
    read -r c || c="b"
    case "$c" in
      n) page=$((page+1)) ;;
      p) page=$((page-1)) ;;
      b|B|q|Q|"") break ;;
      d) vault_delete "$(ask 'id to delete' '')" ;;
      *)
        if [[ "$c" =~ ^AX?[0-9]+$ ]] || [[ "$c" =~ ^[0-9]+$ ]]; then
          vault_view "$c"
        fi ;;
    esac
  done
}

vault_view() {
  py - "$AF_VAULTF" "$1" <<'PYEOF' > "$AF_TMP/vault_hit.json"
import json, sys
want = sys.argv[2].strip().upper().lstrip("AX")
if not want.isdigit():
    sys.exit(0)
want = want.zfill(3)
for ln in open(sys.argv[1]):
    try: rec = json.loads(ln)
    except Exception: continue
    if rec.get("id", "").endswith(want):
        print(json.dumps(rec, ensure_ascii=False)); break
PYEOF
  if [ -s "$AF_TMP/vault_hit.json" ]; then
    cp "$AF_TMP/vault_hit.json" "$AF_TMP/hit_single.json"
    py - "$AF_TMP/hit_single.json" "$AF_TMP/session.json" <<'PYEOF'
import json, sys
rec = json.load(open(sys.argv[1]))
json.dump({"results": [rec.get("axiom", {})]}, open(sys.argv[2], "w"), ensure_ascii=False, indent=2)
PYEOF
    ui_clear
    show_axiom 0
    printf '  %sid: %s · saved: %s%s\n' "$DM" "$(jget "$AF_TMP/hit_single.json" "id" "?")" "$(jget "$AF_TMP/hit_single.json" "savedAt" "?")" "$R"
    press_any
  else
    say_line "$YW" "no vault entry matched"; press_any
  fi
}

vault_delete() {
  local id="$1"; [ -z "$id" ] && return
  py - "$AF_VAULTF" "$id" <<'PYEOF'
import sys
vid = sys.argv[2].strip().upper().lstrip("AX").zfill(3) if sys.argv[2] else ""
keep = []
try:
    lines = open(sys.argv[1]).read().splitlines()
except Exception:
    lines = []
for ln in lines:
    try: rec = json.loads(ln)
    except Exception: continue
    if vid and rec.get("id", "").endswith(vid):
        continue
    keep.append(ln)
open(sys.argv[1], "w").write("\n".join(keep) + ("\n" if keep else ""))
PYEOF
  say_line "$YW" "deleted (if it existed)"
  press_any
}

vault_search() {  # vault_search text|seed
  local mode="$1" q
  q="$(ask "search $mode for" '')"
  [ -z "$q" ] && return
  ui_clear
  frame_open "VAULT SEARCH · \"$q\"" "$VI"
  py - "$AF_VAULTF" "$q" "$mode" <<'PYEOF' | while IFS= read -r ln; do printf '%s║%s %s\n' "$VI" "$R" "$ln"; done
import json, sys
q = sys.argv[2].lower(); mode = sys.argv[3]
try: lines = open(sys.argv[1]).read().splitlines()
except Exception: lines = []
hits = 0
for ln in lines:
    try: rec = json.loads(ln)
    except Exception: continue
    ax = rec.get("axiom", {})
    hay = (json.dumps(ax, ensure_ascii=False) if mode == "text" else (rec.get("seed","") + " " + ax.get("paradox_type","") + " " + ax.get("ontology","classic"))).lower()
    if q in hay:
        hits += 1
        onto = ax.get("ontology", "classic")
        tag = "" if onto == "classic" else f" {onto[:4]}:"
        print(f"  {rec.get('id','?'):<14} [{ax.get('paradox_type','?')[:9]:<9}]{tag:<6} {ax.get('core_statement','')[:48]}")
print(f"  -- {hits} hit(s)" if hits else "  -- no hits")
PYEOF
  frame_close "$VI"
  press_any
}

vault_export() {
  local ts; ts="$(stamp_id)"
  py - "$AF_VAULTF" "$AF_EXPORT/vault_${ts}.md" "$AF_EXPORT/vault_${ts}.txt" <<'PYEOF'
import json, sys
src, md, txt = sys.argv[1], sys.argv[2], sys.argv[3]
try: lines = open(src).read().splitlines()
except Exception: lines = []
recs = []
for ln in lines:
    try: recs.append(json.loads(ln))
    except Exception: pass
with open(md, "w") as f:
    f.write(f"# VoidForge Vault Export\n\n- entries: {len(recs)}\n\n")
    for r in recs:
        ax = r.get("axiom", {})
        onto = ax.get("ontology", "classic")
        f.write(f"## {r.get('id')} · [{onto}/{ax.get('paradox_type','?')}] seed: {r.get('seed','?')}\n\n")
        f.write(f"> {ax.get('axiom_text','')}\n\n")
        f.write(f"- mechanisms: {', '.join(ax.get('mechanisms', []))}\n")
        f.write(f"- equation: `{ax.get('equation','')}`\n")
        hr = ax.get("hollow_reading")
        if hr: f.write(f"- hollow reading: {hr.get('core_statement','')} ({hr.get('scaffold','')})\n")
        gr = ax.get("generic_reading")
        if gr: f.write(f"- generic reading: {gr.get('core_statement','')} ({gr.get('scaffold','')})\n")
        f.write("\n")
with open(txt, "w") as f:
    for r in recs:
        ax = r.get("axiom", {})
        f.write(f"[{r.get('id')}] {ax.get('axiom_text','')}\n\n")
print(f"{len(recs)} entries exported")
PYEOF
  say_line "$GR" "vault exported → data/exports/vault_${ts}.{md,txt}"
  press_any
}

vault_purge() {
  local a; a="$(ask 'type PURGE to erase the whole vault' '')"
  if [ "$a" = "PURGE" ]; then : > "$AF_VAULTF"; say_line "$RD" "vault purged"; else say_line "$DM" "aborted"; fi
  press_any
}
