#!/usr/bin/env bash
# modules/m_chaos.sh — CHAOS FORGE: the dice decide everything
# Part of VOIDFORGE BBS v2.0.0 VOID

CHAOS_SEEDS_FILE="$AF_TMP/chaos_seeds.txt"

chaos_harvest_words() {
  py - "$AF_HOME" <<'PYEOF' > "$CHAOS_SEEDS_FILE"
import json, os, sys, random
root = sys.argv[1]
words = []
for fn in ("concepts.json", "nouns.json", "adjectives.json", "exotic_paradoxes.json"):
    p = os.path.join(root, fn)
    try:
        d = json.load(open(p))
    except Exception:
        continue
    if isinstance(d, dict):
        for v in d.values():
            if isinstance(v, list):
                words.extend(str(x) for x in v)
    elif isinstance(d, list):
        words.extend(str(x) for x in d)
out, seen = [], set()
for w in words:
    w = w.strip()
    if w and len(w) > 2 and not w.startswith("[") and w.lower() not in seen:
        seen.add(w.lower()); out.append(w)
random.shuffle(out)
for w in out[:400]:
    print(w)
PYEOF
}

chaos_random_seed() {
  local a b c
  a="$(shuf -n 1 "$CHAOS_SEEDS_FILE" 2>/dev/null || echo Entropy)"
  b="$(shuf -n 1 "$CHAOS_SEEDS_FILE" 2>/dev/null || echo Horizon)"
  case $(( RANDOM % 4 )) in
    0) printf '%s' "$a" ;;
    1) printf '%s %s' "$a" "$b" ;;
    2) printf 'The %s %s' "$a" "$b" ;;
    3) printf '%s of %s' "$a" "$b" ;;
  esac
}

scr_chaos() {
  [ -s "$CHAOS_SEEDS_FILE" ] || chaos_harvest_words
  while :; do
    ui_clear
    frame_open "CHAOS FORGE  ·  pure random generation" "$MG"
    printf '%s║%s %sno seeds are sacred. the dice decide: seed, ontology, engine,%s\n' "$MG" "$R" "$GY" "$R"
    printf '%s║%s %stone, rng — everything random every time.%s\n' "$MG" "$R" "$GY" "$R"
    frame_close "$MG"
    menu "CHAOS MENU" "$MG" \
      "1|Roll ONE chaos axiom" \
      "2|Roll a chaos BATCH (count from settings)" \
      "3|Dice display — re-roll seed words only" \
      "b|Back"
    printf '%schaos> %s' "$B$CY" "$R"
    read -r c || c="b"
    case "$c" in
      1) chaos_run 1 ;;
      2) chaos_run "$CFG_COUNT" ;;
      3) local s; s="$(chaos_random_seed)"; say_line "$VI" "dice → \"$s\""; chime; press_any ;;
      b|B|q|Q|"") break ;;
    esac
  done
}

chaos_run() {
  local count="${1:-1}" prev_engine="$CFG_ENGINE" prev_ontology="$CFG_ONTOLOGY"
  # dice everything: ontology, engine, tone
  local ontologies=(classic hollow generic dual)
  if [ "$AF_ENGINE50" -eq 1 ]; then
    CFG_ONTOLOGY="${ontologies[$((RANDOM % 4))]}"
  else
    CFG_ONTOLOGY="classic"
  fi
  if [ "$CFG_ONTOLOGY" = "classic" ]; then
    local engines=()
    [ "$AF_ENGINE50" -eq 1 ] && engines+=(5.0.0)
    [ "$AF_ENGINE47" -eq 1 ] && engines+=(0.4.7)
    [ "$AF_ENGINE37" -eq 1 ] && engines+=(0.3.7)
    CFG_ENGINE="${engines[$((RANDOM % ${#engines[@]}))]}"
  else
    CFG_ENGINE="5.0.0"
  fi
  local tones=(poetic plain academic oracular)
  CFG_TONE="${tones[$((RANDOM % 4))]}"
  local seed; seed="$(chaos_random_seed)"
  local rng=$(( RANDOM * 32768 + RANDOM ))
  ui_clear
  frame_open "CHAOS DICE" "$MG"
  printf '%s║%s\n' "$MG" "$R"
  printf '%s║%s   %sseed    %s %s%s%s\n' "$MG" "$R" "$DM" "$R" "$WH" "$seed" "$R"
  printf '%s║%s   %sonto    %s %s%s%s\n' "$MG" "$R" "$DM" "$R" "$WH" "$CFG_ONTOLOGY" "$R"
  printf '%s║%s   %sengine  %s %s%s%s\n' "$MG" "$R" "$DM" "$R" "$WH" "$(engine_label)" "$R"
  printf '%s║%s   %stone    %s %s%s%s\n' "$MG" "$R" "$DM" "$R" "$WH" "$CFG_TONE" "$R"
  printf '%s║%s   %srng     %s %s%s%s\n' "$MG" "$R" "$DM" "$R" "$WH" "$rng" "$R"
  printf '%s║%s\n' "$MG" "$R"
  frame_close "$MG"
  sleepx 0.5; chime
  if ! run_engine "$seed" "$count" "$CFG_TONE" "$rng" 1; then
    say_line "$RD" "chaos engine fault"; press_any; CFG_ENGINE="$prev_engine"; CFG_ONTOLOGY="$prev_ontology"; return
  fi
  CFG_ENGINE="$prev_engine"
  CFG_ONTOLOGY="$prev_ontology"
  local i n; n="$(ax_count)"
  ui_clear
  for ((i=0; i<n; i++)); do show_axiom "$i"; printf '\n'; done
  local a; a="$(ask '[s]ave session  [v]ault-all  [enter] discard' 'n')"
  case "$a" in
    s|S) AF_SEED="$seed"; save_session "$rng" ;;
    v|V) vault_import_session "$AF_TMP/session.json" "$(echo "$seed")" >/dev/null; say_line "$GR" "archived to vault"; press_any ;;
  esac
}
