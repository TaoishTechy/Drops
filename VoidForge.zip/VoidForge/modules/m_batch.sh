#!/usr/bin/env bash
# modules/m_batch.sh — BATCH FACTORY: multi-seed, multi-format axiom files
# Part of VOIDFORGE BBS v2.0.0 VOID (adds ontology source + void CSV cols)

BATCH_F_J=1; BATCH_F_T=1; BATCH_F_M=1; BATCH_F_C=1
BATCH_SEEDS="single"   # single|bank|file|chaos
BATCH_FILE=""
BATCH_COUNT=3
BATCH_ONTOLOGY="classic"  # classic|hollow|generic|dual

scr_batch() {
  while :; do
    local fmts=""
    [ "$BATCH_F_J" = 1 ] && fmts+="JSON "
    [ "$BATCH_F_T" = 1 ] && fmts+="TXT "
    [ "$BATCH_F_M" = 1 ] && fmts+="MD "
    [ "$BATCH_F_C" = 1 ] && fmts+="CSV"
    ui_clear
    frame_open "BATCH FACTORY  ·  multi-format axiom files" "$OR"
    printf '%s║%s %sseeds: %s%s%s · count/seed: %s%s%s · out: %sdata/exports/%s\n' \
      "$OR" "$R" "$GY" "$R$WH" "$BATCH_SEEDS" "$R$GY" "$R$WH" "$BATCH_COUNT" "$R$GY" "$R$DM" "$R"
    printf '%s║%s %sformats: %s%s%s %s·%s ontology: %s%s%s\n' \
      "$OR" "$R" "$GY" "$R$WH" "$fmts" "$R$GY" "$R$DM" "$R" "$R$WH" "$BATCH_ONTOLOGY" "$R"
    frame_close "$OR"
    menu "BATCH MENU" "$OR" \
      "1|Run the factory" \
      "2|Seed source (single / bank / file / chaos)" \
      "3|Count per seed" \
      "4|Toggle formats (JSON/TXT/MD/CSV)" \
      "5|Ontology mode (classic/hollow/generic/dual)" \
      "6|Open exports folder listing" \
      "b|Back"
    printf '%sbatch> %s' "$B$MG" "$R"
    read -r c || c="b"
    case "$c" in
      1) batch_run ;;
      2) batch_seedsrc ;;
      3) local n; n="$(ask 'count per seed (1-99)' "$BATCH_COUNT")"; [[ "$n" =~ ^[0-9]+$ ]] && (( n>=1 && n<=99 )) && BATCH_COUNT="$n" ;;
      4) batch_fmts ;;
      5) batch_ontology ;;
      6) batch_list ;;
      b|B|q|Q|"") break ;;
    esac
  done
}

batch_ontology() {
  menu "FACTORY ONTOLOGY" "$VI" \
    "1|classic — v0.4.7/0.3.7 engines (parity)" \
    "2|hollow  — shaped absence (5.0.0_VOID)" \
    "3|generic — forced extension (5.0.0_VOID)" \
    "4|dual    — two readings per seed (5.0.0_VOID)"
  local o; o="$(ask 'ontology' "$BATCH_ONTOLOGY")"
  case "$o" in
    1|classic) o=classic;; 2|hollow) o=hollow;; 3|generic) o=generic;; 4|dual) o=dual;;
  esac
  case "$o" in
    classic|hollow|generic|dual)
      BATCH_ONTOLOGY="$o"
      say_line "$GR" "factory ontology → $o" ;;
  esac
}

batch_seedsrc() {
  menu "SEED SOURCE" "$OR" \
    "1|single — one seed, typed now" \
    "2|bank   — every .txt in SEED BANK (one seed per line)" \
    "3|file   — custom seedfile path" \
    "4|chaos  — N pure-random seeds"
  local s; s="$(ask 'source' "$BATCH_SEEDS")"
  case "$s" in
    1|single) BATCH_SEEDS="single"; BATCH_SINGLE="$(ask 'seed concept' "${BATCH_SINGLE:-Dark Forest Theory}")" ;;
    2|bank) BATCH_SEEDS="bank" ;;
    3|file) BATCH_SEEDS="file"; BATCH_FILE="$(ask 'seedfile path' "$BATCH_FILE")" ;;
    4|chaos) BATCH_SEEDS="chaos" ;;
  esac
}
batch_fmts() {
  local a
  a="$(ask 'JSON sessions? y/n' "$( [ $BATCH_F_J = 1 ] && echo y || echo n )")"; case "$a" in y*|Y*) BATCH_F_J=1;; *) BATCH_F_J=0;; esac
  a="$(ask 'TXT codex? y/n' "$( [ $BATCH_F_T = 1 ] && echo y || echo n )")"; case "$a" in y*|Y*) BATCH_F_T=1;; *) BATCH_F_T=0;; esac
  a="$(ask 'MD grimoire? y/n' "$( [ $BATCH_F_M = 1 ] && echo y || echo n )")"; case "$a" in y*|Y*) BATCH_F_M=1;; *) BATCH_F_M=0;; esac
  a="$(ask 'CSV metrics? y/n' "$( [ $BATCH_F_C = 1 ] && echo y || echo n )")"; case "$a" in y*|Y*) BATCH_F_C=1;; *) BATCH_F_C=0;; esac
}
batch_list() {
  ui_clear
  frame_open "EXPORTS" "$OR"
  local f
  while IFS= read -r f; do
    printf '%s║%s  %s%s%s\n' "$OR" "$R" "$GY" "$(basename "$f")" "$R"
  done < <(ls -t "$AF_EXPORT"/* 2>/dev/null | head -15)
  [ -z "$(ls "$AF_EXPORT" 2>/dev/null)" ] && printf '%s║%s  %s(empty)%s\n' "$OR" "$R" "$DM" "$R"
  frame_close "$OR"
  press_any
}

batch_run() {
  [ -s "$CHAOS_SEEDS_FILE" ] || chaos_harvest_words
  local -a seeds=()
  case "$BATCH_SEEDS" in
    single) seeds+=("${BATCH_SINGLE:-Dark Forest Theory}") ;;
    bank)
      local f
      while IFS= read -r f; do
        while IFS= read -r s; do [ -n "$s" ] && seeds+=("$s"); done < "$f"
      done < <(ls "$AF_SEEDS"/*.txt 2>/dev/null)
      ;;
    file)
      [ -f "$BATCH_FILE" ] || { say_line "$RD" "no such seedfile: $BATCH_FILE"; press_any; return; }
      local s
      while IFS= read -r s; do [ -n "$s" ] && seeds+=("$s"); done < "$BATCH_FILE"
      ;;
    chaos)
      local i
      for ((i=0; i<BATCH_COUNT; i++)); do seeds+=("$(chaos_random_seed)"); done
      ;;
  esac
  (( ${#seeds[@]} == 0 )) && { say_line "$RD" "no seeds resolved"; press_any; return; }
  (( BATCH_F_J + BATCH_F_T + BATCH_F_M + BATCH_F_C == 0 )) && { say_line "$YW" "all formats disabled — nothing to write"; press_any; return; }
  [ "$BATCH_ONTOLOGY" != "classic" ] && [ "$AF_ENGINE50" -eq 0 ] && { say_line "$RD" "5.0.0_VOID engine missing — ontology run impossible"; press_any; return; }

  local ts; ts="$(stamp_id)"
  local runid="batch_${ts}"
  local out_json="$AF_EXPORT/${runid}.json"
  local out_txt="$AF_EXPORT/${runid}_codex.txt"
  local out_md="$AF_EXPORT/${runid}_grimoire.md"
  local out_csv="$AF_EXPORT/${runid}_metrics.csv"
  local merged="$AF_TMP/batch_merged.json"

  ui_clear
  frame_open "FACTORY RUNNING" "$OR"
  printf '%s║%s %s%d seeds × %d axioms · ontology %s%s%s · writing to data/exports/%s\n' "$OR" "$R" "$GY" "${#seeds[@]}" "$BATCH_COUNT" "$R$WH" "$BATCH_ONTOLOGY" "$R" "$R"
  frame_close "$OR"

  printf '{"sessions":[' > "$merged"
  local first=1 seed k=0
  local total=${#seeds[@]}
  for seed in "${seeds[@]}"; do
    k=$((k+1))
    local pct=$(( k * 100 / total ))
    printf '\r  %s[%s%s%s]%s %3d%%  %sseed: %s%s' "$CY" "$(bar "$(awk "BEGIN{print $pct/100}")" 30 "$OR")" "$R" "$CY" "$R" "$pct" "$DM" "$seed" "$R"
    local rng=$(( RANDOM * 32768 + RANDOM ))
    local ok=0
    if [ "$BATCH_ONTOLOGY" != "classic" ]; then
      local pe="$CFG_ENGINE" po="$CFG_ONTOLOGY"
      CFG_ENGINE="5.0.0"; CFG_ONTOLOGY="$BATCH_ONTOLOGY"
      run_ontology "$seed" "$BATCH_COUNT" "$CFG_TONE" "$rng" "$CFG_SCAFFOLD" && ok=1
      CFG_ENGINE="$pe"; CFG_ONTOLOGY="$po"
    else
      run_engine "$seed" "$BATCH_COUNT" "$CFG_TONE" "$rng" "$CFG_SCAFFOLD" && ok=1
    fi
    if [ "$ok" != 1 ]; then
      printf '\n%s    factory fault on seed: %s%s\n' "$RD" "$seed" "$R"
      continue
    fi
    [ "$first" = 1 ] && first=0 || printf ',' >> "$merged"
    cat "$AF_TMP/session.json" >> "$merged"
  done
  printf ']}' >> "$merged"
  printf '\n'

  # -------- merge & write formats --------
  py - "$merged" "$out_json" "$out_txt" "$out_md" "$out_csv" \
     "$BATCH_F_J" "$BATCH_F_T" "$BATCH_F_M" "$BATCH_F_C" \
     "$BATCH_ONTOLOGY" <<'PYEOF'
import json, sys, csv
from datetime import datetime, timezone
merged_p, out_json, out_txt, out_md, out_csv = sys.argv[1:6]
fj, ft, fm, fc, onto = sys.argv[6], sys.argv[7], sys.argv[8], sys.argv[9], sys.argv[10]
eng = f"voidforge (ontology: {onto})"
sessions = json.load(open(merged_p))["sessions"]
results, seedlabels = [], []
for s in sessions:
    seed = s.get("session", {}).get("seedPrompt", "?")
    for r in s.get("results", []):
        results.append(r); seedlabels.append(seed)
ts = datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00","Z")
payload = {"exportedAt": ts, "engine": eng, "kind": "batch-factory",
           "session": {"name": "batch-factory", "createdAt": ts,
                       "count": len(results),
                       "params": {"formats": "json,txt,md,csv", "ontology": onto}},
           "results": results}
wrote = []
VOID_KEYS = ["hollow_index", "forcing_index", "void_coherence", "duality_resonance", "void_score"]
if fj == "1":
    json.dump(payload, open(out_json, "w"), ensure_ascii=False, indent=2); wrote.append("json")
if ft == "1":
    with open(out_txt, "w") as f:
        bar70 = "=" * 78
        f.write(f"VOIDFORGE CODEX — batch factory\nengine: {eng}\nexported: {ts}\naxioms: {len(results)}\n\n")
        for i, r in enumerate(results, 1):
            onto_r = r.get("ontology", "classic")
            f.write(f"{bar70}\nAXIOM {i:04d}  [{onto_r}/{r.get('paradox_type','?')}]  seed: {r.get('seed_concept','?')}\n{bar70}\n")
            f.write(r.get("axiom_text", "") + "\n\n")
            f.write(f"  mechanisms : {', '.join(r.get('mechanisms', []))}\n")
            f.write(f"  equation   : {r.get('equation','')}\n")
            f.write(f"  consequence: {r.get('consequences','')}\n")
            m = r.get("metrics", {})
            f.write(f"  metrics    : novelty {m.get('novelty','-')} · density {m.get('density','-')} · "
                    f"elegance {m.get('elegance','-')} · fidelity {m.get('fidelity','-')}\n")
            if onto_r != "classic":
                f.write(f"  void       : hollow_idx {m.get('hollow_index','-')} · forcing_idx {m.get('forcing_index','-')} · "
                        f"coherence {m.get('void_coherence','-')} · resonance {m.get('duality_resonance','-')} · "
                        f"void_score {m.get('void_score','-')}\n")
                hr = r.get("hollow_reading")
                if hr: f.write(f"  hollow     : {hr.get('core_statement','')} [{hr.get('scaffold','')}]\n")
                gr = r.get("generic_reading")
                if gr: f.write(f"  generic    : {gr.get('core_statement','')} [{gr.get('scaffold','')}]\n")
                dmp = r.get("duality_map")
                if dmp and dmp.get("pairs"):
                    f.write("  duality    : " + "; ".join(f"{p.get('hollow')} <-> {p.get('generic')}" for p in dmp["pairs"]) + "\n")
            f.write("\n")
    wrote.append("txt")
if fm == "1":
    with open(out_md, "w") as f:
        f.write(f"# VoidForge Grimoire — Batch Factory\n\n")
        f.write(f"- engine: `{eng}`\n- exported: {ts}\n- axioms: {len(results)}\n\n")
        for i, r in enumerate(results, 1):
            m = r.get("metrics", {})
            onto_r = r.get("ontology", "classic")
            f.write(f"## {i}. [{onto_r}/{r.get('paradox_type','?')}] {r.get('seed_concept','?')}\n\n")
            f.write(f"> {r.get('axiom_text','')}\n\n")
            f.write(f"| field | value |\n|---|---|\n")
            f.write(f"| mechanisms | {', '.join(r.get('mechanisms', []))} |\n")
            f.write(f"| equation | `{r.get('equation','')}` |\n")
            f.write(f"| consequence | {r.get('consequences','')} |\n")
            f.write(f"| novelty | {m.get('novelty','-')} |\n| density | {m.get('density','-')} |\n")
            f.write(f"| elegance | {m.get('elegance','-')} |\n| fidelity | {m.get('fidelity','-')} |\n")
            if onto_r != "classic":
                for k in VOID_KEYS:
                    f.write(f"| {k} | {m.get(k,'-')} |\n")
                hr = r.get("hollow_reading")
                if hr: f.write(f"| hollow reading | {hr.get('core_statement','')} |\n")
                gr = r.get("generic_reading")
                if gr: f.write(f"| generic reading | {gr.get('core_statement','')} |\n")
            f.write("\n")
    wrote.append("md")
if fc == "1":
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        head = ["idx", "seed", "ontology", "paradox_type", "equation", "novelty", "density",
                "entropic_potential", "elegance", "alienness", "fidelity",
                "concept_alignment", "emotional_resonance", "qualia_density"] + VOID_KEYS
        w.writerow(head)
        for i, r in enumerate(results, 1):
            m = r.get("metrics", {})
            fb = m.get("fidelity_breakdown", {})
            w.writerow([i, r.get("seed_concept",""), r.get("ontology","classic"),
                        r.get("paradox_type",""), r.get("equation",""),
                        m.get("novelty",""), m.get("density",""),
                        m.get("entropic_potential",""), m.get("elegance",""),
                        m.get("alienness",""), m.get("fidelity",""),
                        fb.get("concept_alignment",""), fb.get("emotional_resonance",""),
                        m.get("qualia_density","")] + [m.get(k,"") for k in VOID_KEYS])
    wrote.append("csv")
print(" ".join(wrote))
PYEOF
  chime
  say_line "$GR" "factory complete → data/exports/${runid}.*"
  press_any
}
