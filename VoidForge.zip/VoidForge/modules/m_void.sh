#!/usr/bin/env bash
# modules/m_void.sh — VOIDFORGE LAB: hollow · generic · dual ontology modes
# Drives voidforge_5.0.0.py with CFG_ONTOLOGY/CFG_HLEVEL/CFG_FLEVEL/
# CFG_VOIDW/CFG_STRICTVOID/CFG_EMITDUAL. One seed → two readings → one map.
# Part of VOIDFORGE BBS v2.0.0 VOID

void_require() {
  [ "$AF_ENGINE50" -eq 1 ] || { say_line "$RD" "voidforge_5.0.0.py not found next to the BBS"; press_any; return 1; }
  return 0
}

void_status_line() {
  printf '%s║%s %sontology%s %s%-8s%s %shollow-layer%s %s%-10s%s %sforcing-layer%s %s%-10s%s\n' \
    "$VI" "$R" "$DM" "$R" "$WH" "$CFG_ONTOLOGY" "$R" "$DM" "$R" "$WH" "$CFG_HLEVEL" "$R" "$DM" "$R" "$WH" "$CFG_FLEVEL" "$R"
  printf '%s║%s %svoid-weight%s %s%s%s %s·%s strict-void: %s%s%s %s·%s duality-map: %s%s%s %s·%s mech≤%s%s%s\n' \
    "$VI" "$R" "$DM" "$R" "$WH" "$CFG_VOIDW" "$R" "$DM" "$R" \
    "$WH" "$( [ "$CFG_STRICTVOID" = 1 ] && echo on || echo off )" "$R" "$DM" "$R" \
    "$WH" "$( [ "$CFG_EMITDUAL" = 1 ] && echo on || echo off )" "$R" "$DM" "$R" "$WH" "$CFG_MAXMECH" "$R"
}

scr_void() {
  void_require || return
  while :; do
    ui_clear
    frame_open "VOIDFORGE LAB  ·  engine voidforge_5.0.0.py" "$VI"
    printf '%s║%s %sTHE HOLLOW (shaped absence, algebraic topology)%s %s⇄%s %sTHE GENERIC (forcing, ground-model extension)%s\n' \
      "$VI" "$R" "$HC" "$R" "$DM" "$R" "$GC" "$R"
    void_status_line
    frame_close "$VI"
    menu "VOID LAB MENU" "$VI" \
      "1|Forge in VOID mode (current ontology)" \
      "2|Ontology mode (classic/hollow/generic/dual)" \
      "3|Hollow layer (cw/betti/cohomology/homotopy)" \
      "4|Forcing layer (poset/boolean/cardinal/multiverse)" \
      "5|Void weight 0.0-1.0 (dual interpolation)" \
      "6|Toggles: strict-void / duality-map emission" \
      "7|The ontology legality matrix" \
      "b|Back to main board"
    printf '%svoid> %s' "$B$MG" "$R"
    read -r c || c="b"
    case "$c" in
      1) void_run ;;
      2) void_pick_ontology ;;
      3) void_pick_hlevel ;;
      4) void_pick_flevel ;;
      5) void_pick_weight ;;
      6) void_toggles ;;
      7) void_legality ;;
      b|B|q|Q|"") break ;;
    esac
  done
}

void_pick_ontology() {
  menu "ONTOLOGY MODE" "$VI" \
    "1|classic — v0.4.7 byte-parity pipeline" \
    "2|hollow  — shaped absence (betti, knots, torsion)" \
    "3|generic — forced extension (filters, cardinals)" \
    "4|dual    — one seed → two readings → one translation"
  local o; o="$(ask 'ontology' "$CFG_ONTOLOGY")"
  case "$o" in
    1|classic) o="classic" ;;
    2|hollow) o="hollow" ;;
    3|generic) o="generic" ;;
    4|dual) o="dual" ;;
  esac
  case "$o" in
    classic|hollow|generic|dual)
      CFG_ONTOLOGY="$o"
      [ "$CFG_ENGINE" != "5.0.0" ] && CFG_ENGINE="5.0.0"
      conf_save
      say_line "$GR" "ontology → $CFG_ONTOLOGY (engine 5.0.0_VOID)" ;;
  esac
}

void_pick_hlevel() {
  menu "HOLLOW LAYER" "$HC" \
    "1|cw         — cell attachment, CW skeletons" \
    "2|betti      — spectra, Euler drift, barcodes" \
    "3|cohomology — cup products, sheaf obstructions" \
    "4|homotopy   — π1 loops, fixed points, ∞-groupoids"
  local l; l="$(ask 'hollow level' "$CFG_HLEVEL")"
  case "$l" in
    1) l=cw;; 2) l=betti;; 3) l=cohomology;; 4) l=homotopy;;
  esac
  case "$l" in
    cw|betti|cohomology|homotopy) CFG_HLEVEL="$l"; conf_save; say_line "$GR" "hollow layer → $l" ;;
  esac
}

void_pick_flevel() {
  menu "FORCING LAYER" "$GC" \
    "1|poset     — dense sets, generic filters, ⊩" \
    "2|boolean   — Boolean truth values, ultrafilters" \
    "3|cardinal  — elementary embeddings, crit(j)" \
    "4|multiverse— iterated forcing, □/◇ modalities"
  local l; l="$(ask 'forcing level' "$CFG_FLEVEL")"
  case "$l" in
    1) l=poset;; 2) l=boolean;; 3) l=cardinal;; 4) l=multiverse;;
  esac
  case "$l" in
    poset|boolean|cardinal|multiverse) CFG_FLEVEL="$l"; conf_save; say_line "$GR" "forcing layer → $l" ;;
  esac
}

void_pick_weight() {
  local w; w="$(ask 'void weight 0.0 (generic) .. 0.5 (balanced) .. 1.0 (hollow)' "$CFG_VOIDW")"
  if awk "BEGIN{exit !($w >= 0 && $w <= 1)}" 2>/dev/null; then
    CFG_VOIDW="$w"; conf_save
    say_line "$GR" "void weight → $w"
  else
    say_line "$RD" "weight must be within [0,1]"
  fi
  press_any
}

void_toggles() {
  menu "VOID TOGGLES" "$VI" \
    "1|strict-void:  $( [ "$CFG_STRICTVOID" = 1 ] && echo ON || echo OFF )  (resample if coherence < 0.5)" \
    "2|duality-map:  $( [ "$CFG_EMITDUAL" = 1 ] && echo ON || echo OFF )  (emit translation table in dual)"
  local t; t="$(ask 'toggle which (1/2)' '')"
  case "$t" in
    1) CFG_STRICTVOID=$(( 1 - CFG_STRICTVOID )); conf_save ;;
    2) CFG_EMITDUAL=$(( 1 - CFG_EMITDUAL )); conf_save ;;
  esac
}

void_legality() {
  ui_clear
  frame_open "ONTOLOGY LEGALITY MATRIX  ·  paradox types x ontology" "$VI"
  printf '%s║%s\n' "$VI" "$R"
  printf '%s║%s   %s%-14s%s %-10s %-10s\n' "$VI" "$R" "$B$WH" "TYPE" "HOLLOW" "GENERIC" "$R"
  py - "$AF_HOME" <<'PYEOF' | while IFS= read -r ln; do printf '%s║%s %s\n' "$VI" "$R" "$ln"; done
rows = [
    ("entropic",     "yes (Euler drift)",     "yes (Levy collapse)"),
    ("temporal",     "OPT-IN ONLY",           "yes (iteration)"),
    ("cosmic",       "yes (Betti spacetime)", "yes (multiverse)"),
    ("metaphysical", "yes (torsion)",         "yes (Reinhardt)"),
    ("linguistic",   "yes (sheaf)",           "yes (truth lemma)"),
    ("Causal Loop",  "yes (cobordism)",       "yes (iterated)"),
    ("hollow",       "yes",                   "never"),
    ("generic",      "never",                 "yes"),
]
for t, h, g in rows:
    print(f"  {t:<14} {h:<22} {g}")
print()
print("  temporal x hollow: rejected by default; the engine suggests")
print("  --ontology generic, or opt in via --allow-temporal-hollow.")
PYEOF
  printf '%s║%s\n' "$VI" "$R"
  frame_close "$VI"
  press_any
}

void_run() {
  [ -z "$AF_SEED" ] && AF_SEED="The Grandfather-Paradox Containment"
  local s; s="$(ask "seed concept" "$AF_SEED")"
  [ -n "$s" ] && AF_SEED="$s"
  ui_clear
  frame_open "VOID FORGE · $CFG_ONTOLOGY · seed: $AF_SEED" "$VI"
  printf '%s║%s %sengine %svoidforge_5.0.0.py%s · tone %s%s%s · rng %s%s%s\n' \
    "$VI" "$R" "$GY" "$WH" "$R" "$R$WH" "$CFG_TONE" "$R$GY" "$R$WH" "${AF_RNG:-(organic)}" "$R"
  void_status_line
  frame_close "$VI"
  local rng="-"
  if [ "${AF_RNG_SET:-0}" = "1" ]; then rng="$AF_RNG"; else rng="$(( (RANDOM * 32768 + RANDOM) % 2147483647 ))"; fi
  spinner_start "collapsing the void wavefunction"
  local prev_engine="$CFG_ENGINE"
  CFG_ENGINE="5.0.0"
  if ! run_ontology "$AF_SEED" "$CFG_COUNT" "$CFG_TONE" "$rng" "$CFG_SCAFFOLD"; then
    spinner_stop
    say_line "$RD" "void fault:"
    sed 's/^/    /' "$AF_TMP/engine.stderr" | head -6
    CFG_ENGINE="$prev_engine"
    press_any; return
  fi
  CFG_ENGINE="$prev_engine"
  spinner_stop
  AF_RNG="$rng"; AF_RNG_SET=1
  chime
  void_view_results "$rng"
}

void_view_results() {  # void_view_results <rng>
  local rng="${1:-}" i n c
  n="$(ax_count)"
  while :; do
    ui_clear
    frame_open "VOID EMISSIONS · $n axioms · rng=$rng" "$VI"
    printf '%s║%s %s[s]%save  %s[v]%siew all  %s[a]%sxiom detail  %s[r]%se-roll  %s[b]%sack\n' \
      "$VI" "$R" "$B$CY" "$R" "$B$CY" "$R" "$B$CY" "$R" "$B$CY" "$R" "$B$CY" "$R"
    frame_close "$VI"
    for ((i=0; i<n; i++)); do
      local onto ptype core
      onto="$(ax_ontology "$i")"
      ptype="$(ax_field "$i" paradox_type)"
      core="$(ax_field "$i" core_statement)"
      printf '  %s#%02d%s %s%-8s%s %s%s%s\n' "$VI" "$((i+1))" "$R" "$HC" "$onto" "$R" "$DM" "[$ptype] " "$R"
      printf '        %s%s%s\n' "$GY" "${core:0:$((AF_COLS-12))}" "$R"
    done
    printf '%schoice> %s' "$B$MG" "$R"
    read -r c || c="b"
    case "$c" in
      s|S) save_session "$rng" ;;
      v|V) ui_clear; for ((i=0; i<n; i++)); do show_void_axiom "$i"; printf '\n'; done; press_any ;;
      a|A) local k; k="$(ask "axiom # (1-$n)" 1)"; [[ "$k" =~ ^[0-9]+$ ]] && (( k>=1 && k<=n )) && { ui_clear; show_void_axiom $((k-1)); press_any; } ;;
      r|R) AF_RNG_SET=0; void_run; return ;;
      b|B|q|Q|"") break ;;
    esac
  done
}
