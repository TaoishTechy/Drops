#!/usr/bin/env bash
# modules/m_forge.sh — THE FORGE: craft axioms from seeds (classic pipeline)
# Part of VOIDFORGE BBS v2.0.0 VOID

scr_forge() {
  while :; do
    ui_clear
    frame_open "THE FORGE  ·  engine $(engine_label)" "$CY"
    printf '%s║%s %sforge paradox axioms from a seed concept%s\n' "$CY" "$R" "$GY" "$R"
    printf '%s║%s %stone: %s%s%s · count: %s%s%s · scaffold: %s%s%s · mech≤%s%s%s · selfref: %s%s%s\n' \
      "$CY" "$R" "$GY" "$R$WH" "$CFG_TONE" "$R$GY" "$R$WH" "$CFG_COUNT" "$R$GY" \
      "$R$WH" "$( [ "$CFG_SCAFFOLD" = 1 ] && echo on || echo off )" "$R$GY" \
      "$R$WH" "$CFG_MAXMECH" "$R$GY" "$R$WH" "$CFG_SELFREF" "$R"
    printf '%s║%s %sontology: %s%s%s %s(classic pipeline — see VOIDFORGE LAB for hollow/generic/dual)%s\n' \
      "$CY" "$R" "$GY" "$R$WH" "$CFG_ONTOLOGY" "$R" "$DM" "$R"
    frame_close "$CY"
    menu "FORGE MENU" "$CY" \
      "1|Forge a batch (current settings)" \
      "2|Change seed concept" \
      "3|Change tone" \
      "4|Change count" \
      "5|Toggle scaffold / transcendence" \
      "6|Legacy 0.3.7 flag panel" \
      "7|Pick seed from SEED BANK" \
      "8|Switch engine / ontology (ENGINE BAY)" \
      "b|Back to main board"
    printf '%sforge> %s' "$B$MG" "$R"
    read -r c || c="b"
    case "$c" in
      1) forge_run ;;
      2) forge_seed ;;
      3) pick_tone ;;
      4) pick_count ;;
      5) pick_scaffold ;;
      6) legacy_panel ;;
      7) pick_seedbank ;;
      8) scr_enginebay ;;
      b|B|q|Q|"") break ;;
    esac
  done
}

forge_seed() {
  local s
  s="$(ask 'seed concept (e.g. "Dark Forest Theory")' "$AF_SEED")"
  [ -n "$s" ] && AF_SEED="$s"
}
pick_tone() {
  menu "TONE MATRIX" "$VI" \
    "1|poetic    — 'Held like falling, then slowly released.'" \
    "2|plain     — 'Net effect:'" \
    "3|academic  — 'We observe. Therefore.'" \
    "4|oracular  — 'It returns by a different door.'"
  local t; t="$(ask 'tone' "$CFG_TONE")"
  case "$t" in 1) t=poetic;; 2) t=plain;; 3) t=academic;; 4) t=oracular;; esac
  case "$t" in poetic|plain|academic|oracular) CFG_TONE="$t"; conf_save;; esac
}
pick_count() {
  local n; n="$(ask 'axioms per run (1-20)' "$CFG_COUNT")"
  [[ "$n" =~ ^[0-9]+$ ]] && (( n>=1 && n<=20 )) && { CFG_COUNT="$n"; conf_save; }
}
pick_scaffold() {
  menu "SCAFFOLD / TRANSCENDENCE" "$VI" \
    "1|scaffold: $( [ "$CFG_SCAFFOLD" = 1 ] && echo ON || echo OFF )  (emit humanized_injection_scaffold)" \
    "2|transcend: $( [ "$CFG_TRANSCEND" = 1 ] && echo ON || echo OFF )  (origami/echo/qualia hooks, 0.4.7+)"
  local s; s="$(ask 'toggle which (1/2)' '')"
  case "$s" in
    1) CFG_SCAFFOLD=$(( 1 - CFG_SCAFFOLD )); conf_save ;;
    2) CFG_TRANSCEND=$(( 1 - CFG_TRANSCEND )); conf_save ;;
  esac
}
legacy_panel() {
  frame_open "LEGACY 0.3.7 PANEL" "$OR"
  printf '%s║%s %s0.3.7 predates --out; the shell captures its stream instead.%s\n' "$OR" "$R" "$GY" "$R"
  printf '%s║%s %ssupported: --seed --seedfile --count --tone --rng%s\n' "$OR" "$R" "$GY" "$R"
  printf '%s║%s %s           --max-mech --allow-duplicates --selfref-mode%s\n' "$OR" "$R" "$GY" "$R"
  printf '%s║%s %s           --emit-scaffold --save-to-history%s\n' "$OR" "$R" "$GY" "$R"
  frame_close "$OR"
  press_any
}
pick_seedbank() {
  local -a files=()
  local f i=1 sel s
  while IFS= read -r f; do files+=("$f"); i=$((i+1)); done < <(ls "$AF_SEEDS"/*.txt 2>/dev/null | sort)
  ui_clear
  frame_open "SEED BANK PICK" "$CY"
  i=1
  while IFS= read -r f; do
    [ -s "$f" ] || continue
    printf '%s║%s  %s%d%s %s\n' "$CY" "$R" "$B$MG" "$i" "$R" "$(basename "$f")"
    i=$((i+1))
  done < <(ls "$AF_SEEDS"/*.txt 2>/dev/null | sort)
  [ $i -eq 1 ] && printf '%s║%s  %s(seed bank empty — visit SEED BANK to create lists)%s\n' "$CY" "$R" "$DM" "$R"
  frame_close "$CY"
  [ $i -eq 1 ] && { press_any; return; }
  sel="$(ask 'seed file #' '1')"
  [[ "$sel" =~ ^[0-9]+$ ]] && (( sel>=1 && sel<${#files[@]}+1 )) && {
    s="$(shuf -n 1 "${files[$((sel-1))]}" 2>/dev/null || head -n 1 "${files[$((sel-1))]}")"
    [ -n "$s" ] && AF_SEED="$s" && say_line "$GR" "seed → $AF_SEED"
  }
  press_any
}

forge_run() {
  [ -z "$AF_SEED" ] && forge_seed
  [ -z "$AF_SEED" ] && AF_SEED="Dark Forest Theory"
  # THE FORGE is the classic pipeline board: force the parity route for the
  # whole chain (run + results viewer + save_session), whatever the VOID LAB
  # has selected. Void ontologies live on their own board.
  local prev_onto="$CFG_ONTOLOGY"
  CFG_ONTOLOGY="classic"
  ui_clear
  frame_open "FORGING · seed: $AF_SEED" "$CY"
  printf '%s║%s %sengine %s%s%s · tone %s%s%s · rng %s%s%s\n' "$CY" "$R" "$GY" "$R$WH" "$(engine_label)" "$R$GY" "$R$WH" "$CFG_TONE" "$R$GY" "$R$WH" "${AF_RNG:-(organic)}" "$R"
  frame_close "$CY"
  local rng="-"
  if [ "${AF_RNG_SET:-0}" = "1" ]; then rng="$AF_RNG"; else rng="$(( (RANDOM * 32768 + RANDOM) % 2147483647 ))"; fi
  spinner_start "heating the forge"
  if ! run_engine "$AF_SEED" "$CFG_COUNT" "$CFG_TONE" "$rng" "$CFG_SCAFFOLD"; then
    spinner_stop
    CFG_ONTOLOGY="$prev_onto"
    say_line "$RD" "engine fault:"
    sed 's/^/    /' "$AF_TMP/engine.stderr" | head -5
    press_any; return
  fi
  spinner_stop
  AF_RNG="$rng"; AF_RNG_SET=1
  local n; n="$(ax_count)"
  chime
  view_results "$rng"
  CFG_ONTOLOGY="$prev_onto"
}

view_results() {  # view_results <rng>
  local rng="${1:-}" i n c
  n="$(ax_count)"
  while :; do
    ui_clear
    frame_open "EMISSIONS · $n axioms · rng=$rng" "$MG"
    printf '%s║%s %s[s]%save  %s[v]%siew all  %s[a]%sxiom detail  %s[r]%se-roll  %s[b]%sack\n' \
      "$MG" "$R" "$B$CY" "$R" "$B$CY" "$R" "$B$CY" "$R" "$B$CY" "$R" "$B$CY" "$R"
    frame_close "$MG"
    for ((i=0; i<n; i++)); do
      local ptype core onto
      ptype="$(ax_field "$i" paradox_type)"
      core="$(ax_field "$i" core_statement)"
      onto="$(ax_ontology "$i")"
      printf '  %s#%02d%s %s%-9s%s %s%s %s%s %s%s\n' "$MG" "$((i+1))" "$R" "$CY" "$ptype" "$R" \
        "$DM" "$([ "$onto" != classic ] && printf '[%s] ' "$onto")" "$R" "$GY" "${core:0:$((AF_COLS-32))}" "$R"
    done
    printf '%schoice> %s' "$B$MG" "$R"
    read -r c || c="b"
    case "$c" in
      s|S) save_session "$rng" ;;
      v|V) ui_clear; for ((i=0; i<n; i++)); do show_axiom "$i"; printf '\n'; done; press_any ;;
      a|A) local k; k="$(ask "axiom # (1-$n)" 1)"; [[ "$k" =~ ^[0-9]+$ ]] && (( k>=1 && k<=n )) && { ui_clear; show_axiom $((k-1)); press_any; } ;;
      r|R) AF_RNG_SET=0; forge_run; return ;;
      b|B|q|Q|"") break ;;
    esac
  done
}
