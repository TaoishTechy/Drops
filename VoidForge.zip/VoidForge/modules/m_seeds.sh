#!/usr/bin/env bash
# modules/m_seeds.sh — SEED BANK: seed list manager
# Part of VOIDFORGE BBS v2.0.0 VOID

scr_seeds() {
  while :; do
    ui_clear
    frame_open "SEED BANK  ·  data/seeds/*.txt" "$GR"
    local i=1 f
    while IFS= read -r f; do
      printf '%s║%s  %s%2d%s %s%-24s%s %s%3d seeds%s\n' "$GR" "$R" "$B$MG" "$i" "$R" "$WH" "$(basename "$f")" "$R" "$DM" "$(wc -l < "$f" | tr -d ' ')" "$R"
      i=$((i+1))
    done < <(ls "$AF_SEEDS"/*.txt 2>/dev/null | sort)
    [ $i -eq 1 ] && printf '%s║%s  %s(no seed files yet)%s\n' "$GR" "$R" "$DM" "$R"
    frame_close "$GR"
    menu "SEED BANK" "$GR" \
      "1|New seed list" \
      "2|View / append a list" \
      "3|Import a file as a list" \
      "4|Harvest lexicon (auto-build from JSON banks)" \
      "5|Delete a list" \
      "b|Back"
    printf '%sseeds> %s' "$B$CY" "$R"
    read -r c || c="b"
    case "$c" in
      1) seeds_new ;;
      2) seeds_edit ;;
      3) seeds_import ;;
      4) seeds_harvest ;;
      5) seeds_delete ;;
      b|B|q|Q|"") break ;;
    esac
  done
}
seeds_new() {
  local name; name="$(ask 'list name (no ext)' "my_seeds")"
  name="$(printf '%s' "$name" | tr -dc 'A-Za-z0-9_-')"
  [ -z "$name" ] && return
  : > "$AF_SEEDS/${name}.txt"
  seeds_append_loop "$AF_SEEDS/${name}.txt"
}
seeds_edit() {
  local f; f="$(seeds_pick)" || return
  ui_clear
  frame_open "SEEDS · $(basename "$f")" "$GR"
  sed 's/^/  /' "$f" | head -20
  frame_close "$GR"
  seeds_append_loop "$f"
}
seeds_append_loop() {
  local f="$1" s
  say_line "$DM" "type seeds one per line; empty line to finish:"
  while :; do
    printf '%s + %s> %s' "$GR" "$(basename "$f")" "$R"
    read -r s || break
    [ -z "$s" ] && break
    printf '%s\n' "$s" >> "$f"
  done
  say_line "$GR" "$(wc -l < "$f" | tr -d ' ') seeds in $(basename "$f")"
  press_any
}
seeds_import() {
  local p; p="$(ask 'source file path' '')"
  [ -f "$p" ] || { say_line "$RD" "no such file"; press_any; return; }
  local name; name="$(ask 'list name' "$(basename "$p" | sed 's/\.[^.]*$//')")"
  name="$(printf '%s' "$name" | tr -dc 'A-Za-z0-9_-')"
  [ -z "$name" ] && return
  grep -v '^\s*$' "$p" > "$AF_SEEDS/${name}.txt" 2>/dev/null || : > "$AF_SEEDS/${name}.txt"
  say_line "$GR" "imported $(wc -l < "$AF_SEEDS/${name}.txt" | tr -d ' ') seeds"
  press_any
}
seeds_harvest() {
  py - "$AF_HOME" "$AF_SEEDS/lexicon_harvest.txt" <<'PYEOF'
import json, os, sys
root, dst = sys.argv[1], sys.argv[2]
words = set()
for fn in ("concepts.json", "exotic_paradoxes.json", "nouns.json"):
    try: d = json.load(open(os.path.join(root, fn)))
    except Exception: continue
    if isinstance(d, dict):
        vals = [v for vs in d.values() if isinstance(vs, list) for v in vs]
    elif isinstance(d, list):
        vals = d
    else:
        vals = []
    for w in vals:
        w = str(w).strip()
        if w and len(w) > 2 and len(w) < 40 and not w.startswith("["):
            words.add(w.title() if w.islower() else w)
# void lexicon seasoning
for fn in ("banks/hollow_bank.json", "banks/generic_bank.json"):
    try: d = json.load(open(os.path.join(root, fn)))
    except Exception: continue
    mechs = d.get("mechanisms", {})
    for lst in mechs.values() if isinstance(mechs, dict) else []:
        for m in lst:
            if isinstance(m, str) and 2 < len(m) < 40:
                words.add(m)
with open(dst, "w") as f:
    f.write("\n".join(sorted(words)) + "\n")
print(len(words))
PYEOF
  say_line "$GR" "harvested lexicon (incl. void mechanisms) → seeds/lexicon_harvest.txt"
  press_any
}
seeds_delete() {
  local f; f="$(seeds_pick)" || return
  rm -f "$f"; say_line "$YW" "deleted $(basename "$f")"; press_any
}
seeds_pick() {
  local -a files=()
  local f i=1
  while IFS= read -r f; do files+=("$f"); done < <(ls "$AF_SEEDS"/*.txt 2>/dev/null | sort)
  (( ${#files[@]} == 0 )) && { say_line "$DM" "no seed lists exist"; press_any; return 1; }
  local n=$(( ${#files[@]} ))
  local sel; sel="$(ask "list # (1-$n)" 1)"
  if [[ "$sel" =~ ^[0-9]+$ ]] && (( sel>=1 && sel<=n )); then
    printf '%s' "${files[$((sel-1))]}"; return 0
  fi
  return 1
}
