# tests/

Non-interactive verification tooling for VoidForge.

| File | Purpose |
|---|---|
| `run_all.sh` | One-shot suite: `bash -n`, printf scanner, engine selftest (15), BBS selftest (20), PTY boot smoke. |
| `pty_capture.sh` | Runs the BBS under a real pseudo-terminal via `script(1)` and captures the raw ANSI typescript (`bbs_session.raw`, git-ignored). Flows: `menu` (boot → login → ethics → logoff) and `forge` (forge a seed, view emissions). |
| `ansi_render.py` | Simulates a compliant terminal (OSC 10/11, SGR 38;5;N, inverse, EL) and renders captured screens to PNG — also byte-asserts the true-black canvas claim. Requires Pillow + DejaVu Mono fonts. |
| `check_printf.py` | Static scanner for printf format/arg count mismatches across every `.sh` file (joins continuations, masks `$(...)`, handles `%*`). |

## Usage

```bash
tests/run_all.sh                          # everything
tests/pty_capture.sh forge                # capture the forge flow
python3 tests/ansi_render.py menu tests/bbs_session.raw preview
python3 tests/check_printf.py lib/        # scan a subtree
```

The built-in suites can also be run directly:

```bash
./voidforge.sh selftest                   # 20-check shell suite
python3 voidforge_5.0.0.py --selftest     # 15-check engine suite
```
