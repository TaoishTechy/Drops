#!/usr/bin/env bash
# tests/run_all.sh — full non-interactive verification for VoidForge:
#   1. bash -n syntax on every shell file
#   2. printf format/arg scanner across the repo
#   3. v5.0.0 engine selftest (15 checks)
#   4. BBS shell selftest (20 checks)
#   5. PTY boot smoke test (BIOS -> login -> ethics -> logoff) + canvas assertions
set -u
HERE="$(cd -P "$(dirname "$0")" && pwd)"
REPO="$(cd -P "$HERE/.." && pwd)"
cd "$REPO"
fails=0

echo "== 1/5  bash -n =="
shopt -s globstar nullglob
for f in ./**/*.sh; do bash -n "$f" || { echo "SYNTAX FAIL: $f"; fails=$((fails+1)); }; done
echo "   syntax OK"

echo "== 2/5  printf scanner =="
if python3 "$HERE/check_printf.py" "$REPO"; then echo "   printf OK"; else fails=$((fails+1)); fi

echo "== 3/5  v5.0.0 engine selftest =="
if python3 voidforge_5.0.0.py --selftest | tail -1 | grep -q "15/15 passed"; then
  echo "   15/15 passed"; else echo "   v5 selftest FAILED"; fails=$((fails+1)); fi

echo "== 4/5  BBS selftest (20 checks) =="
if ./voidforge.sh selftest 2>&1 | tail -1 | grep -q "20 passed · 0 failed"; then
  echo "   20/20 passed"; else echo "   BBS selftest FAILED"; fails=$((fails+1)); fi

echo "== 5/5  PTY boot smoke =="
SHOTDIR="$(mktemp -d "${TMPDIR:-/tmp}/vfshots.XXXXXX")"
if "$HERE/pty_capture.sh" menu >/dev/null 2>&1; then
  if python3 "$HERE/ansi_render.py" menu "$HERE/bbs_session.raw" "$SHOTDIR" | tail -1 | grep -q "ALL CHECKS PASSED"; then
    echo "   boot + canvas assertions OK"; else echo "   canvas assertions FAILED"; fails=$((fails+1)); fi
else
  echo "   PTY boot FAILED"; fails=$((fails+1))
fi
rm -rf "$SHOTDIR"

echo
if [ "$fails" -eq 0 ]; then echo "ALL STAGES PASSED"; else echo "$fails stage(s) FAILED"; exit 1; fi
