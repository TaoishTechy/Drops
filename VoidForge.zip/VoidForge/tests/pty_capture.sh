#!/usr/bin/env bash
# tests/pty_capture.sh — run the VoidForge BBS under a real pseudo-terminal
# and capture the raw ANSI typescript for later rendering (ansi_render.py).
#
# Usage: tests/pty_capture.sh [flow] [repo_dir]
#   flow = menu (default) | forge
#   repo_dir defaults to the repo root (parent of tests/)
set -u
HERE="$(cd -P "$(dirname "$0")" && pwd)"
REPO="${2:-$(cd -P "$HERE/.." && pwd)}"
OUT="$HERE/bbs_session.raw"
FLOW="${1:-menu}"
: > "$OUT"

if [ "$FLOW" = "forge" ]; then
  # login -> pager quit -> ack -> main:1 -> forge:1 -> seed -> view all -> ack -> back x2 -> logoff
  INPUT=$'\nq\n\n1\n1\nDark Forest Theory\nv\n\nb\nb\n0\n'
else
  # login -> pager quit -> ack -> logoff
  INPUT=$'\nq\n\n0\n'
fi

script -q -c "stty cols 100 rows 30 2>/dev/null; \
  AF_FAST=1 AF_HOME='$REPO' '$REPO/voidforge.sh'" "$OUT" <<< "$INPUT" >/dev/null 2>&1
rc=$?
echo "exit=$rc bytes=$(wc -c < "$OUT") raw=$OUT"
[ "$rc" -eq 0 ] || exit $rc
