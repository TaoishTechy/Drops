#!/usr/bin/env python3
"""tests/ansi_render.py — render ANSI typescript segments (split on ESC[2J)
to PNG screens. Simulates a compliant terminal: honors OSC 10/11 default
fg/bg, SGR 0/1/3/7, SGR 38;5;N / 48;5;N, ESC[K, CR, LF. Verifies byte-level
canvas assertions too.

Usage: ansi_render.py [flow] [raw_file] [outdir]
  flow = menu (default) | forge
"""
import re, sys, os

HERE = os.path.dirname(os.path.abspath(__file__))
flow = sys.argv[1] if len(sys.argv) > 1 else "menu"
RAW = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "bbs_session.raw")
OUTDIR = sys.argv[3] if len(sys.argv) > 3 else os.path.join(HERE, "..", "preview")
COLS, ROWS = 100, 30
FONT_DIR = "/usr/share/fonts/truetype/dejavu"

data = open(RAW, "rb").read().decode("utf-8", errors="replace")

# ---------------- byte-level assertions ----------------
checks = {
    "OSC11 black set":      "\x1b]11;#000000\x07" in data,
    "OSC10 fg set":         "\x1b]10;#e6e6e6\x07" in data,
    "OSC110 restore":       "\x1b]110\x07" in data,
    "OSC111 restore":       "\x1b]111\x07" in data,
    "SGR black canvas R":   "\x1b[0;48;5;16m" in data,
    "no old 238 track":     "\x1b[38;5;238m" not in data,
    "new 44 deep cyan":     "\x1b[38;5;44m" in data,
    "DM 245 metadata gray": "\x1b[38;5;245m" in data,
    "no bare dim attr 2m":  "\x1b[2m" not in data,
}
ok = True
for k, v in checks.items():
    print(("PASS " if v else "FAIL ") + k)
    ok &= v
if not ok:
    sys.exit(1)

# ---------------- 256-color palette ----------------
def xterm256(n):
    if n < 16:
        b = [0, 0, 0, 205, 205, 205, 205, 255, 95, 95, 95, 95, 255, 255, 255, 255]
        r = [0, 0, 205, 205, 0, 0, 205, 205, 95, 95, 135, 135, 95, 95, 135, 135]
        g = [0, 205, 0, 0, 0, 205, 205, 205, 95, 135, 95, 135, 95, 135, 95, 135]
        return (r[n], g[n], b[n])
    if n < 232:
        n -= 16
        base = [0, 95, 135, 175, 215, 255]
        return (base[n // 36], base[(n % 36) // 6], base[n % 6])
    v = 8 + (n - 232) * 10
    return (v, v, v)

DEF_FG, DEF_BG = (255, 255, 255), (0, 0, 0)   # light terminal before OSC claim
osc_fg, osc_bg = None, None                    # set by OSC 10/11

def defaults():
    return (osc_fg or DEF_FG, osc_bg or DEF_BG)

# ---------------- segment screen model ----------------
def render_segment(seg, path):
    global osc_fg, osc_bg
    grid = {}                                   # (row,col) -> (ch, style)
    style = {"fg": None, "bg": None, "bold": False, "inv": False}
    row = col = 0
    i = 0
    while i < len(seg):
        c = seg[i]
        if c == "\x1b":
            m = re.match(r"\x1b\[([0-9;]*)([A-Za-z])", seg[i:])
            if m:
                params, cmd = m.group(1), m.group(2)
                nums = [int(x) if x else 0 for x in params.split(";")] if params else [0]
                if cmd == "m":
                    k = 0
                    while k < len(nums):
                        n = nums[k]
                        if n == 0: style.update(fg=None, bg=None, bold=False, inv=False)
                        elif n == 1: style["bold"] = True
                        elif n == 3: pass
                        elif n == 7: style["inv"] = True
                        elif n == 38 and k + 2 < len(nums) and nums[k+1] == 5:
                            style["fg"] = nums[k+2]; k += 2
                        elif n == 48 and k + 2 < len(nums) and nums[k+1] == 5:
                            style["bg"] = nums[k+2]; k += 2
                        k += 1
                elif cmd == "K":
                    for cc in range(col, COLS):
                        grid[(row, cc)] = (" ", dict(style))
                elif cmd == "H":
                    row, col = 0, 0
                i += m.end()
                continue
            m = re.match(r"\x1b\]([0-9]+);([^\x07]*)\x07", seg[i:])
            if m:
                ps, txt = m.group(1), m.group(2)
                if ps == "10": osc_fg = tuple(int(txt[j:j+2], 16) for j in (1, 3, 5))
                if ps == "11": osc_bg = tuple(int(txt[j:j+2], 16) for j in (1, 3, 5))
                i += m.end()
                continue
            i += 1
            continue
        if c == "\r": col = 0
        elif c == "\n": row += 1; col = 0
        elif c == "\a": pass
        else:
            grid[(row, col)] = (c, dict(style))
            col += 1
        i += 1
    if not grid:
        return 0
    maxr = max(r for r, _ in grid)
    dfg, dbg = defaults()
    CW, CH, FS = 10, 21, 17
    img = Image.new("RGB", (COLS * CW, (maxr + 1) * CH), dbg)
    dr = ImageDraw.Draw(img)
    f = ImageFont.truetype(os.path.join(FONT_DIR, "DejaVuSansMono.ttf"), FS)
    fb = ImageFont.truetype(os.path.join(FONT_DIR, "DejaVuSansMono-Bold.ttf"), FS)
    for (r, cc), (ch, st) in grid.items():
        fgv = xterm256(st["fg"]) if st["fg"] is not None else dfg
        bgv = xterm256(st["bg"]) if st["bg"] is not None else dbg
        if st["inv"]: fgv, bgv = bgv, fgv
        x, y = cc * CW, r * CH
        if (bgv != dbg) or st["inv"]:
            dr.rectangle([x, y, x + CW - 1, y + CH - 1], fill=bgv)
        if ch != " ":
            dr.text((x + 1, y + 1), ch, fill=fgv, font=fb if st["bold"] else f)
    img.save(path)
    return maxr + 1

from PIL import Image, ImageDraw, ImageFont

# split on ESC[2J (ui_clear); every ui_clear also emits ESC[H after
parts = data.split("\x1b[2J\x1b[H")
print(f"segments: {len(parts)}")
if flow == "forge":
    names = {7: "screen7_forgemenu.png", 8: "screen8_emissions_list.png",
             9: "screen9_emissions.png", 10: "screen10_axioms_detail.png"}
else:
    names = {1: "screen1_bios.png", 2: "screen2_logo_login.png",
             4: "screen4_ethics.png", 6: "screen6_mainboard.png"}
for idx, name in sorted(names.items()):
    if idx < len(parts):
        rows = render_segment(parts[idx], os.path.join(OUTDIR, name))
        print(f"rendered {name}: {rows} rows")
print("ALL CHECKS PASSED" if ok else "CHECKS FAILED")
