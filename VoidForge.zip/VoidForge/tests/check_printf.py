#!/usr/bin/env python3
"""tests/check_printf.py — printf format/arg mismatch scanner for bash files.
Joins backslash continuations, masks $(...) groups (nested quotes ignored),
tokenizes top-level args, counts %-specs (%% literal, %* consumes 2 args).

Usage: check_printf.py [file_or_dir]
  default: repo root — scans every *.sh recursively
"""
import re, sys, os

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)
target = sys.argv[1] if len(sys.argv) > 1 else REPO

def collect(p):
    if os.path.isfile(p):
        return [p]
    out = []
    for root, dirs, files in os.walk(p):
        dirs[:] = [d for d in dirs if d not in (".git", "__pycache__", "data", "preview")]
        out += [os.path.join(root, f) for f in files if f.endswith(".sh")]
    return sorted(out)

def join_stmt(lines, idx):
    out, i = "", idx
    while i < len(lines):
        ln = lines[i]
        if ln.rstrip().endswith("\\") and i + 1 < len(lines):
            out += ln.rstrip()[:-1] + " "
            i += 1
        else:
            return out + ln, i
    return out, i

def mask_dollar_parens(s):
    """Mask $(...) groups with sentinel tokens. Returns (masked, unterminated):
    unterminated=True when a $( spans past end-of-statement (multiline $(),
    e.g. embedded python) — spec/arg counting is unreliable there."""
    out, i, n, counter = [], 0, len(s), 0
    while i < n:
        if s[i] == "$" and i + 1 < n and s[i + 1] == "(":
            depth, j = 1, i + 2
            while j < n and depth:
                if s[j] == "(": depth += 1
                elif s[j] == ")": depth -= 1
                j += 1
            if depth:                       # $() not closed within statement
                out.append(f"\x02{counter}\x02")
                return "".join(out), True
            out.append(f"\x02{counter}\x02"); counter += 1
            i = j
        else:
            out.append(s[i]); i += 1
    return "".join(out), False

def top_level_tokens(seg):
    toks, tok, k, n = [], "", 0, len(seg)
    in_dq = in_sq = False
    while k < n:
        c = seg[k]
        if in_sq:
            if c == "'": in_sq = False
            tok += c; k += 1; continue
        if in_dq:
            if c == "\\" and k + 1 < n: tok += seg[k:k+2]; k += 2; continue
            if c == '"': in_dq = False; tok += c
            else: tok += c
            k += 1; continue
        if c == "'":
            in_sq = True; tok += c; k += 1; continue
        if c == '"':
            in_dq = True; tok += c; k += 1; continue
        if c in "|;<>&":
            break
        if c in "()":
            k += 1; continue
        if c.isspace():
            if tok: toks.append(tok); tok = ""
            k += 1; continue
        tok += c; k += 1
    if tok.strip(): toks.append(tok.strip())
    return toks

def spec_count(fmt):
    n = 0
    for m in re.finditer(r"%(?:%|[-+ #0*]*\d*(?:\.\d+)?[sdifxXcsb%])", fmt):
        t = m.group(0)
        if t == "%%": continue
        n += 2 if "*" in t else 1
    return n

total = 0
skipped = 0
for src in collect(target):
    lines = open(src, encoding="utf-8").read().split("\n")
    issues = []
    i = 0
    while i < len(lines):
        line = lines[i]
        m = re.match(r"\s*(\w+\(\)\s*\{\s*)?printf\s", line)
        if not m or re.match(r"\s*#", line):
            i += 1; continue
        stmt, i2 = join_stmt(lines, i)
        masked, unterminated = mask_dollar_parens(stmt)
        if unterminated:
            skipped += 1                     # multiline $(): count by hand
            i = i2 + 1; continue
        pm = re.search(r"printf\s", masked)
        if pm:
            toks = top_level_tokens(masked[pm.end():])
            toks = [t for t in toks if t not in ("{", "}", "||", "&&", "!", "2>", "&>", "\\")]
            if toks:
                fmt = toks[0]
                if (fmt.startswith("'") and fmt.endswith("'")) or (fmt.startswith('"') and fmt.endswith('"')):
                    ns = spec_count(fmt[1:-1])
                    na = len(toks) - 1
                    if ns != na:
                        issues.append((i + 1, ns, na, stmt.strip()))
        i = i2 + 1
    rel = os.path.relpath(src, REPO)
    for ln, ns, na, txt in issues:
        print(f"{rel}:{ln}: specs={ns} args={na}  MISMATCH")
        print(f"    {txt[:170]}\n")
    total += len(issues)

print(f"{total} real mismatch(es), {skipped} statement(s) skipped (multiline $() — verify by hand)")
sys.exit(1 if total else 0)
