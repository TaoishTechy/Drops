#!/usr/bin/env bash
# ============================================================================
#  VOIDFORGE BBS  ·  v2.0.0 VOID  ·  "Recursive Paradox Dial-In"
# ----------------------------------------------------------------------------
#  A retro BBS-style terminal dashboard for the VoidForge paradox engines
#  (AxiomForge lineage). Pure ANSI bash + python3. No ncurses/dialog/fzf.
#  This edition is MODULAR: a thin launcher that loads lib/ + modules/.
#
#  Drive:   · voidforge_5.0.0.py   (VOID: hollow/generic/dual ontologies)
#           · axiomforge_0.4.7.py  (Stability & Alignment release)
#           · axiomforge_0.3.7.py  (legacy "god-tier" pass)
#
#  Boards:  forge · chaos · VOIDFORGE LAB · batch factory · vault · telemetry
#           seed bank · session log · engine bay · codex
#
#  Usage:   ./voidforge.sh              interactive BBS
#           ./voidforge.sh --selftest   non-interactive sanity check
#           ./voidforge.sh help         CLI passthrough help
#  Env:     AF_NOFLAIR=1   disable boot animation & typing effects
#           AF_FAST=1      shrink all delays
#           AF_NOBG=1      leave the terminal's own colors alone
#           AF_HOME=PATH   override data home (default: script dir)
#
#  VoidForge is MIT-licensed by TaoishTechy. BBS shell by the community.
#  Read ETHICS.md before serious use. Do not use output to deceive or harm.
# ============================================================================
set -u

# --------------------------------------------------------- resolve home ----
_SELF="${BASH_SOURCE[0]}"
while [ -L "$_SELF" ]; do
  _DIR="$(cd -P "$(dirname "$_SELF")" && pwd)"
  _SELF="$(readlink "$_SELF")"
  [[ "$_SELF" != /* ]] && _SELF="$_DIR/$_SELF"
done
AF_HOME="${AF_HOME:-$(cd -P "$(dirname "$_SELF")" && pwd)}"

# ------------------------------------------------------------ load libs ----
af_require() {
  local f="$1"
  # shellcheck disable=SC1090
  [ -f "$f" ] && { . "$f"; return 0; }
  echo "FATAL: required module missing: $f" >&2
  exit 1
}

af_require "$AF_HOME/lib/util.sh"
af_require "$AF_HOME/lib/colors.sh"
af_require "$AF_HOME/lib/ui.sh"
af_require "$AF_HOME/lib/flair.sh"
af_require "$AF_HOME/lib/engine.sh"
af_require "$AF_HOME/lib/data.sh"

# --------------------------------------------------------- load modules ----
af_require "$AF_HOME/modules/m_forge.sh"
af_require "$AF_HOME/modules/m_chaos.sh"
af_require "$AF_HOME/modules/m_void.sh"
af_require "$AF_HOME/modules/m_batch.sh"
af_require "$AF_HOME/modules/m_vault.sh"
af_require "$AF_HOME/modules/m_telemetry.sh"
af_require "$AF_HOME/modules/m_seeds.sh"
af_require "$AF_HOME/modules/m_session.sh"
af_require "$AF_HOME/modules/m_enginebay.sh"
af_require "$AF_HOME/modules/m_codex.sh"

af_require "$AF_HOME/lib/cli.sh"

# -------------------------------------------------------------- signals ----
on_int() {
  printf '\n%s(hangup requested)%s\n' "$YW" "$R"
  printf '%slog off? [y/n]%s ' "$B$WH" "$R"
  read -r c || exit 0
  case "$c" in
    y*|Y*) scr_logoff; exit 0 ;;
    *) printf '\n' ;;
  esac
}
trap on_int INT

# ---------------------------------------------------------------- main -----
main() {
  af_bg_on   # claim the true-black canvas (restored on exit)
  if [ $# -gt 0 ]; then
    cli_main "$@"
    return $?
  fi
  conf_load
  [ "$AF_TTY" -eq 1 ] && { scr_boot; scr_login; }
  ethics_gate
  scr_main
  conf_save
}

main "$@"
