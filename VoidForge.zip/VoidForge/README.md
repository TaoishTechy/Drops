# VoidForge — Recursive Paradox BBS · VOID Edition

![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)
![Version](https://img.shields.io/badge/version-v2.0.0--VOID-8B5CF6)
![Shell](https://img.shields.io/badge/shell-pure%20ANSI%20bash-06B6D4)
![Python](https://img.shields.io/badge/python-3.9%2B-blue)
![Determinism](https://img.shields.io/badge/deterministic--runs-seeded-success)
![Ethics](https://img.shields.io/badge/ethics-gate%20on%20first%20boot-orange)

**VoidForge** is a retro **BBS-style terminal dashboard** that drives a triple
lineage of paradox engines. Dial in, pick a board, and forge **axioms** —
compact, paradox-aligned statements with attached mechanisms, math hooks,
consequences, metrics, and (optionally) humanized stealth scaffolds.

It is the **VOID edition** of [TaoishTechy/AxiomForge](https://github.com/TaoishTechy/AxiomForge):
the classic v0.4.7 / v0.3.7 engines are kept intact, and a new **v5.0.0 VOID**
engine routes them through two additional ontologies — **THE HOLLOW** (the
algebraic topology of shaped absence) and **THE GENERIC** (set-theoretic
forcing) — plus a **DUAL** mode that translates between them.

**Designer:** [TaoishTechy](https://github.com/TaoishTechy) · MIT License

---

## Screenshots

| | |
|---|---|
| ![BIOS boot](preview/screen1_bios.png) | ![Logo + login](preview/screen2_logo_login.png) |
| *BIOS + modem handshake* | *ASCII logo + new-user login* |
| ![ETHICS gate](preview/screen4_ethics.png) | ![Main board](preview/screen6_mainboard.png) |
| *First-boot ETHICS gate* | *Main board (10 boards)* |
| ![Emissions](preview/screen9_emissions.png) | ![Axiom detail](preview/screen10_axioms_detail.png) |
| *Dual-ontology emissions* | *Axiom detail with void metrics* |

---

## Quick Start

Requirements: **bash ≥ 4** and **python3 ≥ 3.9** (stdlib only — no pip installs,
no ncurses/dialog/fzf). Runtime state lives in `data/` and is created
automatically on first boot.

```bash
git clone https://github.com/TaoishTechy/VoidForge.git
cd VoidForge
chmod +x voidforge.sh
./voidforge.sh
```

The first session opens the **ETHICS gate** — review it once and the BBS
opens. From then on you land straight on the main board.

### 60-second tour

1. **The Forge** — type a seed concept, pick a tone, forge axioms.
2. **VOIDFORGE LAB** — forge in `hollow`, `generic` or `dual` ontology and
   read the duality map.
3. **Chaos Forge** — dice *everything*: seed, ontology, engine, tone, rng.
4. **Batch Factory** — many seeds → JSON + TXT + MD + CSV files in `data/exports/`.
5. **Engine Bay** — run the PARITY DUEL (v5 classic vs 0.4.7 → IDENTICAL) and
   the ONTOLOGY DUEL (hollow vs generic → divergent by design).

### Engine-only (no BBS)

```bash
# v5.0.0 VOID — dual ontology (flagship)
python3 voidforge_5.0.0.py --seed "Dark Forest Theory" --count 6 \
        --ontology dual --rng 1337 --emit-scaffold

# v0.4.7 — stability & alignment (classic pipeline)
python3 axiomforge_0.4.7.py --seed "Nested Realities" --count 6 --rng 20250926

# v0.3.7 — legacy "god-tier" pass
python3 axiomforge_0.3.7.py --seed "The Silent God" --count 8 --rng 42 --emit-scaffold
```

Use `--rng` for fully deterministic runs; omit it for organic variety.

---

## The Boards

| Board | What it does |
|---|---|
| **THE FORGE** | Classic pipeline: seed → count → tone → emit; save sessions or archive to the Vault. |
| **CHAOS FORGE** | Pure-random generation — dice seed, ontology, engine, tone and rng. |
| **VOIDFORGE LAB** | Ontology/layer pickers, void-weight slider, strict-void toggle, §9.2 legality matrix, dual results with re-roll. |
| **BATCH FACTORY** | Single seed / seed bank / seed file / chaos seeds → **JSON, TXT, MD, CSV** exports with void CSV columns. |
| **THE VAULT** | Persistent JSONL archive: browse, search, export, purge; rows carry ontology tags. |
| **TELEMETRY** | Aggregates sessions + exports + vault; metric averages, paradox-type mix and ontology-mix bars. |
| **SEED BANK** | Named seed lists: create, edit, import, lexicon harvest (incl. void mechanisms). |
| **SESSION LOG** | Every saved run; **REPLAY** re-runs seed+rng+ontology and verifies cores match. |
| **ENGINE BAY** | Switch 5.0.0 / 0.4.7 / 0.3.7; PARITY DUEL and ONTOLOGY DUEL. |
| **CODEX** | ETHICS pager, VoidForge primer, duality map renderer, output schema, help, about. |

---

## The Engines

| Capability | v0.3.7 (legacy) | v0.4.7 (alignment) | v5.0.0 VOID |
|---|---|---|---|
| Seed-based axiom generation | ✅ | ✅ | ✅ |
| Tone control (poetic/plain/academic/oracular) | ✅ | ✅ | ✅ |
| Batch uniqueness (no duplicate cores) | ✅ | ✅ stronger | ✅ + per-reading |
| Post-emit sanitization (placeholders) | ⚠️ partial | ✅ hard pass | ✅ + ontology-aware |
| Equation whitelist + type triage | — | ✅ | ✅ |
| Concept-alignment scoring | — | ✅ | ✅ |
| Hollow / generic / dual ontologies | — | — | ✅ |
| Void metrics (`hollow_index`, `void_coherence`, …) | — | — | ✅ |
| Determinism via `--rng` | ✅ | ✅ | ✅ (crc32-stable) |

### VOID ontologies

- `classic` — byte-parity port of the v0.4.7 loop (UTC timestamp fix only;
  `--legacy-timestamps` restores `utcnow()`).
- `hollow` — shaped-absence readings from `banks/hollow_bank.json`: CW
  attachment, Betti spectra, cohomology, knots, torsion; sublevel bias via
  `--hollow-level {cw|betti|cohomology|homotopy}`.
- `generic` — forced-extension readings from `banks/generic_bank.json`:
  posets, generic filters, large cardinals, multiverse; via
  `--forcing-level {poset|boolean|cardinal|multiverse}`.
- `dual` — one seed → a hollow reading + a generic reading → one translation
  table from `banks/duality_map.json`, filtered to the mechanisms actually
  used and scored by `duality_resonance`. `--void-weight` interpolates
  (1.0 collapses to pure hollow, 0.0 to pure generic); below-threshold
  coherence resamples, `--strict-void` enforces it hard.
- `legacy` — wraps `axiomforge_0.3.7.py` untouched.

### Void metrics (declarative in `banks/void_metrics.json`)

`hollow_index` · `forcing_index` (token-lexicon counts, capped) ·
`void_coherence` (cosine) · `duality_resonance` (0.55 threshold) ·
`void_score` (weighted). Appended to `metrics`; `0.0` in classic mode so the
v0.4.7 JSON schema stays stable.

---

## CLI Reference

### `voidforge.sh` (BBS shell + CLI passthrough)

```
./voidforge.sh                      interactive BBS
./voidforge.sh selftest             20-check non-interactive sanity suite
./voidforge.sh forge  --seed "Dark Forest Theory" --count 3
./voidforge.sh void   --seed "Dark Forest Theory" --ontology dual
./voidforge.sh chaos  [count]       pure-random run
./voidforge.sh batch  --seed "Nested Realities" --count 4
./voidforge.sh stats | help
```

| Env var | Effect |
|---|---|
| `AF_NOFLAIR=1` | Disable boot animation & typing effects |
| `AF_FAST=1` | Shrink all delays |
| `AF_NOBG=1` | Leave the terminal's own colors untouched (skip black-canvas claim) |
| `AF_HOME=PATH` | Override data home (default: script dir) |

### `voidforge_5.0.0.py`

| Flag | Values / Default | Description |
|---|---|---|
| `--ontology` | `classic` \| `hollow` \| `generic` \| `dual` \| `legacy` | Ontology route (default `classic`) |
| `--hollow-level` | `cw` \| `betti` \| `cohomology` \| `homotopy` | Hollow sublevel bias |
| `--forcing-level` | `poset` \| `boolean` \| `cardinal` \| `multiverse` | Generic sublevel bias |
| `--void-weight` | 0.0 – 1.0 (default 0.5) | Dual interpolation hollow ↔ generic |
| `--strict-void` | flag | Resample until resonance ≥ threshold |
| `--allow-temporal-hollow` | flag | Opt in to the §9.2-illegal pairing |
| `--emit-duality` | flag | Include the `duality_map` object |
| `--seed`, `--count`, `--tone`, `--rng`, `--emit-scaffold`, `--out` | as v0.4.7 | Every v0.4.7 flag remains verbatim |

`voidforge_5.0.0.py --selftest` runs 15 internal checks, including golden
parity against v0.4.7. See also `axiomforge_0.4.7.py` / `axiomforge_0.3.7.py`
flag tables in [CHANGELOG.md](CHANGELOG.md) and the in-app CODEX board.

---

## Architecture

The shell is deliberately modular: a thin launcher sources libraries and
one file per board.

```
voidforge.sh                thin launcher (resolve home → source libs → boards → main)
lib/
  util.sh                   paths, deps, settings, config io, json utils
  colors.sh                 true-black canvas claim + neon palette (≥7:1 on black)
  ui.sh                     frames, menus, prompts, gauges, typing, spinner, pager
  flair.sh                  BIOS boot, logo, login, first-boot ETHICS gate, logoff
  engine.sh                 3-engine routing, run_engine/run_ontology, rendering
  data.sh                   session save, vault import, collision-safe paths
  cli.sh                    main board dispatcher, CLI passthrough, 20-check selftest
modules/
  m_forge.sh                THE FORGE (classic pipeline, forced parity route)
  m_chaos.sh                CHAOS FORGE (dice seed + ontology + engine + tone + rng)
  m_void.sh                 VOIDFORGE LAB (ontology pickers, void-weight, legality)
  m_batch.sh                BATCH FACTORY (JSON/TXT/MD/CSV × ontology)
  m_vault.sh                THE VAULT (JSONL browse/search/export/purge)
  m_telemetry.sh            TELEMETRY (averages + type/ontology mix bars)
  m_seeds.sh                SEED BANK (lists, import, lexicon harvest)
  m_session.sh              SESSION LOG (deterministic replay)
  m_enginebay.sh            ENGINE BAY (switch + parity duel + ontology duel)
  m_codex.sh                CODEX (ETHICS, primer, duality map, schema, help, about)
banks/
  hollow_bank.json          THE HOLLOW — mechanisms, equations, consequences
  generic_bank.json         THE GENERIC — forcing mechanisms, extensions
  duality_map.json          concept pairs, mechanism pairings, scaffold pairs
  void_metrics.json         declarative metric formulas + token lexicons
```

Runtime state (git-ignored, auto-created under `data/`):
`config.json` · `vault/vault.jsonl` · `sessions/` · `seeds/` · `exports/` ·
`logs/`.

The `axioms/` and `reports/` directories carry the original AxiomForge
corpus (recorded axioms, EntroVerse Codex collection, Grok/AGI reports) kept
for provenance.

---

## Output Schema

Each emission is a standalone JSON object (v0.4.7 schema, extended by v5):

```jsonc
{
  "core_statement": "Boundary ledger updates on the edge determine curvature in the interior.",
  "mechanisms": ["Holographic Accounting", "Geodesic Focusing Suppression"],
  "equation": "S ≤ A/4",                  // display-pretty
  "equation_tex": "S \\leq A/4",           // raw LaTeX (v5)
  "consequences": "frame-conditional geometry",
  "axiom_text": "Consider: … — via … ; encoded as S ≤ A/4. (…)",
  "paradox_type": "cosmic",
  "seed_concept": "Nested Realities",
  "timestamp": "2026-10-24T22:50:03Z",     // UTC, timezone-aware
  "metrics": {
    "novelty": 0.94, "density": 7.12, "fidelity": 73.4,
    "fidelity_breakdown": { "concept_alignment": 0.72, "…": 0 },
    "qualia_density": 0.004,
    "hollow_index": 0.0, "forcing_index": 0.0,
    "void_coherence": 0.0, "duality_resonance": 0.0, "void_score": 0.0
  },
  "hollow_reading":  { "…": "…" },         // hollow + dual
  "generic_reading": { "…": "…" },         // generic + dual
  "duality_map":     { "…": "…" },         // dual (+ flag)
  "humanized_injection_scaffold": "…",     // with --emit-scaffold
  "pillars": ["Nested Realities"]
}
```

Void metrics are `0.0` in classic mode — the schema is stable across engines.

---

## Determinism & Replay

- Pin `--rng` (crc32-stable) to freeze randomness; also pin bank files.
- Session Log → **REPLAY** re-runs a saved session's `seed + rng + ontology`
  through the correct engine and diffs the core statements — the BBS prints
  `VERIFIED` only when every core matches.
- Timestamps are timezone-aware UTC (`datetime.now(UTC)`); the legacy
  `utcnow()` format is available via `--legacy-timestamps`.

## Testing

```bash
./voidforge.sh selftest            # 20-check shell suite (engines, schema,
                                   # sanitizer, determinism, vault, 4 exports,
                                   # void router, legality, parity, batch dual)
python3 voidforge_5.0.0.py --selftest   # 15-check engine suite (golden parity)
tests/run_all.sh                   # + bash -n, printf scanner, PTY boot smoke
```

`tests/` ships a PTY capture harness (`pty_capture.sh`), an ANSI terminal
simulator that renders captured screens to PNG (`ansi_render.py`) and a
printf format/arg mismatch scanner (`check_printf.py`).

---

## Ethics

VoidForge is a research and creativity instrument. Use is conditioned on the
ethics codex — **no deception, no manipulation, no harm**; don't publish
output as established mathematics, and disclose the ontology mode and seed
when sharing results. The full text (with the v5.0.0 VoidForge Addendum)
loads on first boot and lives in [ETHICS.md](ETHICS.md).

## Contributing

- Fork + PR with focused commits; keep additions **data-driven** (JSON banks)
  where feasible.
- `bash` files must pass `bash -n` and the printf scanner; python must pass
  the engine selftests.
- Match the tone: precise, compact, math-aware.

## License

MIT — see [LICENSE](LICENSE). AxiomForge engines © TaoishTechy.

## Citing

```bibtex
@software{TaoishTechy_VoidForge_2026,
  author  = {TaoishTechy},
  title   = {VoidForge: A Recursive Paradox BBS with Hollow/Generic/Dual Ontologies},
  year    = {2026},
  url     = {https://github.com/TaoishTechy/VoidForge}
}
```
