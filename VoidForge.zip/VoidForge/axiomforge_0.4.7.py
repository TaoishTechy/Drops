#!/usr/bin/env python3
# axiomforge_0.4.7.py
# AxiomForge v0.4.7 — "Stability & Alignment" release (reconstructed build)
#
# This file is a faithful reconstruction of the v0.4.7 engine described in the
# repository README, which documents the release but whose original source was
# not included in the repo snapshot. It implements every documented v0.4.7
# capability while remaining stdlib-only and CLI-compatible with v0.3.7:
#
#   * Template Corruption Kill-Switch  — hard post-emit sanitizer stripping
#     residual placeholders ([CORE_STATEMENT], [MECHANISMS], [MATH],
#     [CONSEQUENCES]) and orphaned template clause labels.
#   * Concept-Alignment Scoring       — seed-aware vector scoring of
#     mechanisms; low-alignment generations are resampled; fidelity reflects
#     alignment.
#   * Equation Whitelists by Type     — paradox-type math pools with
#     triangulation from mechanisms (holography -> S <= A/4, attention /
#     continuity -> nabla_t rho + div J = 0, ...).
#   * Seed-Aware Suffixing            — Dark Forest avoids "broadcast" and
#     uses hiding/masking/jamming/silence; Nested Realities prefers
#     boundary/frame; Silent God prefers silence/final-boundary.
#   * Light Transcendent Hooks        — Consciousness Origami, Temporal Echo,
#     Qualia Density scaffolds (opt-in via --transcend).
#   * Tightened Metrics               — qualia_density and a meaningful
#     fidelity_breakdown (alignment / resonance / novelty x density /
#     archetypal fit).
#   * Mechanism whitelist ingestion   — drops single-letter artifacts and
#     category labels; UTC-aware timestamps; stable deterministic RNG via
#     --rng (crc32-based, stable across processes unlike 0.3.7's hash()).

import argparse
import json
import math
import random
import re
import sys
import zlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

# ------------------------------- Defaults --------------------------------- #

DEF_PARADOX_TYPES = ["entropic", "temporal", "cosmic", "metaphysical",
                     "linguistic", "Causal Loop"]

DEF_MECHANISMS = [
    "Holographic Accounting", "Bulk-Boundary Reciprocity", "Geodesic Shear",
    "Metric Fluctuation", "Entropic Drift", "Control-Loop Resonance",
    "Homeostatic Overshoot", "Modal Collapse", "Presence-Absence Superposition",
    "Ontic Fold", "Recurrence Operator", "Self-Correction",
    "Time-Looped Function", "Causal Friction", "Retrocausal Boundary",
    "Information Cascade Failure", "Coherence-Risk Exchange",
    "Negative Feedback Inversion", "Wavefunction Collapse Debt",
    "Computational Horizon Tension", "Chrono-Entrainment", "Ontological Debt",
    "Temporal Repayment", "Epistemic Phase Symmetry", "Noether Coupling",
    "Continuity of Attention", "Two-Time Renormalization",
    "Final-Boundary Constraint", "Consistency Potential Minimization",
]

DEF_EQUATIONS = {
    "entropic":     ["S = k_B ln W", "\u2202_\u03bc j^\u03bc = 0",
                     "\u0394S_univ \u2265 0", "dS \u2265 \u03b4Q/T"],
    "temporal":     ["[H, Q] = 0", "\u2202_t \u03c1 = \u2212i[H, \u03c1]",
                     "\u222e d\u03c4 = 0", "Z = \u222b D\u03c6 e^{iS[\u03c6]}"],
    "cosmic":       ["S \u2264 A/4", "G_\u03bc\u03bd = 8\u03c0T_\u03bc\u03bd",
                     "T^\u03bc\u03bd_;\u03bc = 0",
                     "R_\u03bc\u03bd \u2212 \u00bdR g_\u03bc\u03bd = \u039b g_\u03bc\u03bd"],
    "metaphysical": ["e^{i\u03c0} + 1 = 0",
                     "\u27e8O\u27e9 = Z\u207b\u00b9\u222b D\u03c6 O e^{iS}",
                     "\u25a1\u03c8 = m\u00b2\u03c8"],
    "linguistic":   ["\u22a4 \u2194 \u00ac\u22a4", "T(\u231cS\u231d) \u2194 S",
                     "\u03bcx. f(x) = fix(f)", "P(x) \u2194 \u00acP(\u231cP\u231d)"],
    "Causal Loop":  ["[H, Q] = 0", "\u222e d\u03c4 = 0", "x = f(x)",
                     "\u03c0\u2218\u03c0 = \u03c0"],
}

DEF_TONES = {
    "poetic":    ["A glance understood.", "We keep respect in the pauses.",
                  "Say less; allow more to be understood.",
                  "Held like falling, then slowly released."],
    "plain":     ["Noted.", "In short.", "Net effect:", "Bottom line:"],
    "academic":  ["We observe.", "Accordingly.", "Hence.", "Therefore."],
    "oracular":  ["Unannounced.", "In the hush between horizons.",
                  "As foretold in the quiet.",
                  "It returns by a different door."],
}

DEF_CORES = {
    "entropic": [
        "A sealed vault of order breeds the crack that frees it.",
        "Perfect stabilization creates the fluctuations it must suppress.",
        "Your clarity, mirrored by the universe, breeds the very chaos that "
        "unravels its own certainty.",
    ],
    "temporal": [
        "Only that which endures the last horizon earns a first dawn.",
        "Only laws that survive the final boundary are permitted to begin.",
        "To glimpse the future is to mortgage the present.",
    ],
    "cosmic": [
        "Edge ledgers whisper curvature into the bulk.",
        "Boundary ledger updates on the edge determine curvature in the interior.",
        "Cosmic expansion is driven by desire for ultimate contraction.",
    ],
    "metaphysical": [
        "Attention is a gauge that writes the world.",
        "Observation carries a conserved charge that sources reality itself.",
        "The final truth is the ultimate lie.",
    ],
    "linguistic": [
        "Resolution breathes only while un-resolving itself.",
        "This paradox is resolved iff it remains unresolved, invalidating any "
        "resolution it outputs.",
        "The sentence describing itself ends by describing nothing at all.",
    ],
    "Causal Loop": [
        "A law that returns by a different door.",
        "Outcomes precede premises in subtle loops.",
        "Prediction becomes selection when the loop closes on itself.",
    ],
}

CONSEQUENCE_MAP = {
    "entropic": "entropy leakage",
    "temporal": "unique fixed points",
    "cosmic": "frame-conditional geometry",
    "metaphysical": "gauge of attention",
    "linguistic": "decision paralysis",
    "Causal Loop": "closed loop of consistency",
}

# mechanism keyword -> preferred equation (triangulation table)
TRIANGULATION = [
    (("holograph", "boundary", "ledger", "bulk", "horizon"), "S \u2264 A/4"),
    (("attention", "observer", "continuity", "conservation", "noether",
      "epistemic"), "\u2202_\u03bc j^\u03bc = 0"),
    (("retrocausal", "two-time", "final-boundary", "chronal", "temporal"),
     "[H, Q] = 0"),
    (("recurrence", "loop", "fixed", "self-correct"), "x = f(x)"),
    (("entrop", "degradation", "collapse debt"), "S = k_B ln W"),
    (("self-ref", "liar", "truth", "semantic", "linguistic"),
     "\u22a4 \u2194 \u00ac\u22a4"),
]

# seed keyword -> mechanism affinity lexicon (concept-alignment expansion)
AFFINITY = {
    "forest": {"hiding", "masking", "jamming", "silence", "dark", "predator",
               "broadcast", "signal", "camouflage", "information", "cascade"},
    "dark": {"hiding", "silence", "shadow", "masking", "horizon"},
    "nest": {"boundary", "frame", "recursion", "contain", "layer", "fold"},
    "god": {"silence", "final", "absolute", "transcend", "presence",
            "constraint"},
    "time": {"temporal", "chronal", "retrocausal", "loop", "echo"},
    "mind": {"cognition", "attention", "observer", "epistemic", "qualia"},
    "cosmos": {"curvature", "geodesic", "horizon", "holograph", "cosmic"},
    "entropy": {"entropic", "degradation", "drift", "collapse"},
    "language": {"semantic", "linguistic", "truth", "self-ref", "recursive"},
    "reality": {"ontic", "existence", "metaphysical", "presence", "frame"},
}

TYPE_ARCHETYPES = {
    "entropic": {"entropy", "degradation", "drift", "collapse", "leak",
                 "fluctuation", "echo"},
    "temporal": {"temporal", "chronal", "loop", "retrocausal", "boundary",
                 "repayment", "entrainment"},
    "cosmic": {"holograph", "boundary", "curvature", "geodesic", "bulk",
               "ledger", "cosmic", "inversion"},
    "metaphysical": {"attention", "observer", "ontic", "noether", "epistemic",
                     "presence", "meaning"},
    "linguistic": {"self-ref", "semantic", "recursive", "linguistic", "truth",
                   "meaning"},
    "Causal Loop": {"recurrence", "loop", "self-correct", "inference",
                    "prediction"},
}

QUALIA_TOKENS = {"attention", "observer", "consciousness", "qualia", "felt",
                 "awareness", "presence", "experience", "witness"}
AFFECT_TOKENS = {"silence", "hush", "horizon", "falling", "door", "glance",
                 "respect", "breathes", "quiet", "foretold"}

PLACEHOLDER_RE = re.compile(
    r"\[(CORE_STATEMENT|MECHANISMS|MATH|CONSEQUENCES|SEED|TYPE)\]", re.I)
ORPHAN_LABELS = ["Fixed point persists:", "Closed Loop:", "Mechanisms:",
                 "Math:", "Consequences:", "Loop constraint:"]
SINGLE_TOKEN_RE = re.compile(r"^[A-Za-z]$")

# ---------------------------- Utility helpers ----------------------------- #


def load_json(path: Path) -> Any:
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def coerce_list(x: Any) -> List[str]:
    out: List[str] = []
    if x is None:
        return out
    if isinstance(x, list):
        for v in x:
            out.extend(coerce_list(v))
        return out
    if isinstance(x, dict):
        out.extend(str(k) for k in x.keys())
        for v in x.values():
            out.extend(coerce_list(v))
        return out
    s = str(x).strip()
    if s:
        out.append(s)
    return out


def norm(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def utc_ts() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds") \
        .replace("+00:00", "Z")


def tokens_of(text: str) -> set:
    toks = set()
    for t in re.split(r"[^a-zA-Z]+", text.lower()):
        if len(t) >= 3:
            toks.add(t)
    return toks


def expand(tokens: set) -> set:
    expanded = set(tokens)
    for key, syn in AFFINITY.items():
        if key in tokens:
            expanded |= syn
    return expanded


def cosine(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    inter = len(a & b)
    return inter / math.sqrt(len(a) * len(b))

# --------------------------- Data-bank loading -----------------------------#


def load_banks(root: Path) -> Dict[str, Any]:
    banks: Dict[str, Any] = {
        "mechanisms": [],
        "cores": {t: [] for t in DEF_PARADOX_TYPES},
        "consequences": {t: [] for t in DEF_PARADOX_TYPES},
        "templates": {},
        "exotic": [],
    }
    mech_whitelist_keys = ("mechanisms",)

    def ingest_entry_list(entries: Any) -> None:
        if not isinstance(entries, list):
            return
        for e in entries:
            if not isinstance(e, dict):
                continue
            core = norm(str(e.get("core_statement", "")))
            mechs = [norm(str(m)) for m in coerce_list(e.get("mechanisms", []))]
            cons = [norm(str(c)) for c in coerce_list(e.get("consequences", []))]
            mechs = [m for m in mechs
                     if m and not SINGLE_TOKEN_RE.match(m)
                     and m.lower() not in ("generated", "paradox", "timestamp",
                                           "danger_rating")]
            if not core or PLACEHOLDER_RE.search(core):
                continue
            ptypes = [t for t in DEF_PARADOX_TYPES
                      if t.lower() == str(e.get("_type", "")).lower()]
            banks["mechanisms"].extend(mechs)
            for t in ptypes:
                banks["cores"][t].append((core, mechs))
                banks["consequences"][t].extend(
                    [c for c in cons if c and not PLACEHOLDER_RE.search(c)])

    # paradox_base.json: canon paradox seeds by type
    pb = load_json(root / "paradox_base.json")
    if isinstance(pb, dict):
        for ptype, entries in pb.items():
            if ptype == "generated" or not isinstance(entries, list):
                continue
            key = next((t for t in DEF_PARADOX_TYPES
                        if t.lower() == ptype.lower()), None)
            if key is None:
                continue
            for e in entries:
                if not isinstance(e, dict):
                    continue
                core = norm(str(e.get("core_statement", "")))
                mechs = [norm(str(m)) for m in coerce_list(e.get("mechanisms", []))]
                cons = [norm(str(c)) for c in coerce_list(e.get("consequences", []))]
                mechs = [m for m in mechs
                         if m and not SINGLE_TOKEN_RE.match(m)]
                if not core or PLACEHOLDER_RE.search(core):
                    continue
                banks["mechanisms"].extend(mechs)
                banks["cores"][key].append((core, mechs))
                banks["consequences"][key].extend(
                    [c for c in cons if c and not PLACEHOLDER_RE.search(c)])

    # new_paradoxes.json: extended per-type entries
    np = load_json(root / "new_paradoxes.json")
    if isinstance(np, dict):
        for ptype, entries in np.items():
            key = next((t for t in DEF_PARADOX_TYPES
                        if t.lower() == ptype.lower()), None)
            if key is None or not isinstance(entries, list):
                continue
            for e in entries:
                if not isinstance(e, dict):
                    continue
                e = dict(e)
                e["_type"] = key
                ingest_entry_list([e])

    # templates.json
    tp = load_json(root / "templates.json")
    if isinstance(tp, dict):
        for ptype, tlist in tp.items():
            key = next((t for t in DEF_PARADOX_TYPES
                        if t.lower() == ptype.lower()), None)
            if key and isinstance(tlist, list):
                banks["templates"][key] = [str(t) for t in tlist]

    # exotic paradox seeds (concept-level seasoning)
    ex = load_json(root / "exotic_paradoxes.json")
    if isinstance(ex, list):
        banks["exotic"] = [norm(str(x)) for x in ex if norm(str(x))]

    # concepts seasoning
    concepts: List[str] = []
    cj = load_json(root / "concepts.json")
    if isinstance(cj, dict):
        for v in cj.values():
            concepts.extend(coerce_list(v))
    nj = load_json(root / "nouns.json")
    if isinstance(nj, dict):
        for v in nj.values():
            concepts.extend(coerce_list(v))
    banks["concepts"] = sorted({norm(c) for c in concepts
                                if norm(c) and len(norm(c).split()) <= 3})

    # v0.4.7 whitelist hygiene on mechanisms
    banks["mechanisms"] = sorted(
        {norm(m) for m in banks["mechanisms"] + DEF_MECHANISMS
         if norm(m) and not SINGLE_TOKEN_RE.match(norm(m))
         and len(norm(m)) > 2})
    for t in DEF_PARADOX_TYPES:
        banks["consequences"][t] = sorted(set(banks["consequences"][t]))
    return banks

# ------------------------------ Engine parts -------------------------------#


def pick_type(seed: str, rng: random.Random) -> str:
    types = list(DEF_PARADOX_TYPES)
    bias: List[str] = []
    s = seed.lower()
    if any(k in s for k in ("\u2202", "j^", "continuity", "entropy", "decay",
                            "collapse")):
        bias.append("entropic")
    if any(k in s for k in ("[h,q]", "commutator", "loop", "recurrence",
                            "prediction")):
        bias.append("Causal Loop")
    if any(k in s for k in ("curvature", "einstein", "cosmic", "horizon",
                            "holograph", "boundary")):
        bias.append("cosmic")
    if any(k in s for k in ("time", "temporal", "future", "past", "echo")):
        bias.append("temporal")
    if any(k in s for k in ("truth", "liar", "language", "sentence",
                            "self-ref")):
        bias.append("linguistic")
    if any(k in s for k in ("god", "observer", "attention", "consciousness",
                            "mind")):
        bias.append("metaphysical")
    return rng.choice(bias or types)


def pick_core(seed: str, ptype: str, banks: Dict[str, Any],
              rng: random.Random) -> Tuple[str, List[str]]:
    pool = banks["cores"].get(ptype) or []
    stok = expand(tokens_of(seed))
    if pool:
        best = sorted(pool,
                      key=lambda cm: -cosine(stok, tokens_of(cm[0])))
        window = best[:max(1, len(best) // 2)]
        core, mechs = rng.choice(window)
        if mechs:
            return core, list(mechs)
    core = rng.choice(DEF_CORES.get(ptype, DEF_CORES["entropic"]))
    return core, []


def pick_mechanisms(seed: str, ptype: str, banks: Dict[str, Any],
                    rng: random.Random, max_mech: int) -> List[str]:
    stok = expand(tokens_of(seed))
    arch = TYPE_ARCHETYPES.get(ptype, set())
    scored: List[Tuple[float, str]] = []
    for m in banks["mechanisms"]:
        mtok = tokens_of(m)
        score = cosine(stok, mtok) + 0.45 * cosine(arch, mtok) \
            + rng.uniform(0.0, 0.12)
        scored.append((score, m))
    scored.sort(key=lambda sm: -sm[0])
    pool = [m for _, m in scored[:max(max_mech * 4, 12)]]
    rng.shuffle(pool)
    chosen = pool[:max(1, max_mech)]
    if len(chosen) < max_mech:
        chosen += rng.sample(banks["mechanisms"],
                             min(max_mech - len(chosen),
                                 len(banks["mechanisms"])))
    return chosen[:max(1, max_mech)]


def alignment_score(seed: str, mechs: List[str]) -> float:
    stok = expand(tokens_of(seed))
    mtok = set()
    for m in mechs:
        mtok |= tokens_of(m)
    return round(min(1.0, cosine(stok, mtok) * 1.6), 3)


# per-type preferred entry in TRIANGULATION (checked first, per README:
# linguistic <-> liar/fixed-point, cosmic <-> holography/GR, ...)
TYPE_TRIAGE = {
    "linguistic": ("self-ref", "liar", "truth", "semantic", "linguistic"),
    "cosmic": ("holograph", "boundary", "ledger", "bulk", "horizon"),
    "temporal": ("retrocausal", "two-time", "final-boundary", "chronal",
                 "temporal"),
    "entropic": ("entrop", "degradation", "collapse debt"),
    "Causal Loop": ("recurrence", "loop", "fixed", "self-correct"),
    "metaphysical": ("attention", "observer", "continuity", "conservation",
                     "noether", "epistemic"),
}


def triangulate_equation(ptype: str, seed: str, mechs: List[str],
                         banks: Dict[str, Any], rng: random.Random) -> str:
    joined = " ".join(mechs).lower() + " " + seed.lower()
    preferred = TYPE_TRIAGE.get(ptype)
    if preferred and any(k in joined for k in preferred):
        for keys, eq in TRIANGULATION:
            if keys == preferred:
                return eq
    for keys, eq in TRIANGULATION:
        if any(k in joined for k in keys):
            return eq
    bank = list(DEF_EQUATIONS.get(ptype, DEF_EQUATIONS["entropic"]))
    if banks.get("equations", {}).get(ptype):
        bank = banks["equations"][ptype] + bank
    return rng.choice(bank)


def seed_suffix(seed: str, rng: random.Random) -> str:
    sl = seed.lower()
    if "dark forest" in sl or "forest" in sl:
        return " \u2014 under " + rng.choice(
            ["hiding", "masking", "jamming", "silence"])
    if "nested" in sl or "reality" in sl:
        return " \u2014 " + rng.choice(
            ["at the boundary of frames", "within the frame of frames",
             "inside the nested frame"])
    if "silent god" in sl or ("silent" in sl and "god" in sl):
        return " \u2014 within " + rng.choice(["silence", "the final boundary"])
    return ""


def sanitize_text(text: str) -> str:
    """v0.4.7 hard post-emit sanitizer (Template Corruption Kill-Switch)."""
    prev = None
    while prev != text:
        prev = text
        text = PLACEHOLDER_RE.sub("", text)
        for label in ORPHAN_LABELS:
            text = text.replace(label, "")
        text = re.sub(r"\s+", " ", text)
        text = re.sub(r"\s+([;,.;])", r"\1", text)
        text = re.sub(r";\s*;", "; ", text)
        text = re.sub(r"\.\s*\.", ".", text)
        text = re.sub(r"\s+\.", ".", text)
        text = re.sub(r"(?<!\w)\u2014\s*\u2014", "\u2014", text)
        text = re.sub(r"\s+$", ".", text.strip())
        if not text.endswith((".", "!", "?", "\u2026")):
            text = text.rstrip(" ;,") + "."
    return text


def pick_template(ptype: str, banks: Dict[str, Any],
                  rng: random.Random) -> str:
    tlist = banks["templates"].get(ptype)
    if tlist:
        return rng.choice(tlist)
    return ("Consider: [CORE_STATEMENT] \u2014 via [MECHANISMS]; "
            "encoded as [MATH]; entails [CONSEQUENCES].")


def selfref_transform(core: str, ptype: str, mode: str) -> Tuple[str, str, str]:
    pattern = re.compile(
        r"^Resolution breathes only while un[- ]resolving itself\.?$", re.I)
    if not pattern.search(core):
        return core, ptype, ""
    if mode == "binary":
        return core, "linguistic", "encoded as \u22a4 \u2194 \u00ac\u22a4."
    if mode == "meta":
        text = ("Base claim: Resolution alternates between resolved and "
                "unresolved states. Reflective rule: "
                "SELF_REF(R) \u2261 (R \u2194 \u00acR).")
        return core, "linguistic", text
    text = ("Resolution field: let R(x) \u2208 [0,1] with fixed-point "
            "R \u2248 \u00bd. Dynamics: \u2202_t R = \u2212\u03ba(R\u2212\u00bd).")
    return ("Resolution is a scalar field that hovers at the fixed-point "
            "\u00bd."), "field-fixed-point", text


def compute_metrics(core: str, mechs: List[str], ptype: str, seed: str,
                    alignment: float) -> Dict[str, Any]:
    words = core.split()
    base_len = max(1, len(words))
    uniq = len(set(core.lower()))
    novelty = 0.9 + 0.2 * (uniq / max(30, base_len + 10)) \
        + random.uniform(-0.02, 0.02)
    density = 8.5 + 0.6 * len(mechs) + 0.08 * base_len
    if ptype.startswith("field"):
        density -= 1.5
    joined = " ".join(mechs).lower()
    entropic = 180 + 9.0 * density + (12 if "loop" in joined else 0)
    if "entropy" in joined:
        entropic += 15
    if ptype.lower() in ("linguistic", "causal loop"):
        entropic += 20
    if ptype.startswith("field"):
        entropic -= 25
    elegance = 93.0 + max(0.0, 6.0 - 0.25 * (density - 10)) \
        + (2.0 if ptype.startswith("field") else 0.0)
    elegance = max(90.0, min(99.9, elegance + random.uniform(-0.3, 0.3)))
    exotic_keys = ("holograph", "retro", "ontic", "noether", "geodesic",
                   "wormhole", "rg", "modal")
    alien = 6.0 + 0.9 * sum(1 for k in mechs
                            if any(x in k.lower() for x in exotic_keys)) \
        + random.uniform(-0.2, 0.2)

    core_tok = tokens_of(core)
    resonance = min(1.0, 0.4 + len(core_tok & AFFECT_TOKENS) * 0.15
                    + random.uniform(0.0, 0.1))
    arch = TYPE_ARCHETYPES.get(ptype, set())
    archetypal = min(1.0, cosine(tokens_of(" ".join(mechs)), arch) * 1.5
                     + random.uniform(0.0, 0.08))
    ndp = min(1.0, max(0.0, novelty) * (density / 12.0))
    fidelity = round(100 * (0.5 * alignment + 0.2 * resonance
                            + 0.2 * ndp + 0.1 * archetypal), 1)
    qtokens = sum(1 for w in words if w.lower().strip(".,;:") in QUALIA_TOKENS)
    qualia_density = round(qtokens / base_len, 4)

    return {
        "novelty": round(novelty, 3),
        "density": round(density, 3),
        "entropic_potential": round(entropic, 3),
        "elegance": round(elegance, 2),
        "alienness": round(alien, 3),
        "fidelity": fidelity,
        "fidelity_breakdown": {
            "concept_alignment": round(alignment, 3),
            "emotional_resonance": round(resonance, 3),
            "novelty_density_product": round(ndp, 3),
            "archetypal_alignment": round(archetypal, 3),
        },
        "qualia_density": qualia_density,
    }


def stylize_scaffold(tone: str, rng: random.Random) -> str:
    return rng.choice(DEF_TONES.get((tone or "poetic").lower(),
                                    DEF_TONES["poetic"]))


def transcendent_hooks(seed: str, core: str, mechs: List[str],
                       rng: random.Random) -> Dict[str, Any]:
    return {
        "consciousness_origami": rng.choice([
            "Fold the observer until attention creases into self-shape.",
            "Each fold of awareness leaves a crease the world reads back.",
        ]),
        "temporal_echo": rng.choice([
            "The statement arrives one heartbeat before it is uttered.",
            "An afterimage of the claim persists in the second it replaces.",
        ]),
        "qualia_density": round(
            len(tokens_of(core) & QUALIA_TOKENS) / max(1, len(core.split()))
            + rng.uniform(0.0, 0.01), 4),
        "seed_tag": seed,
    }

# ------------------------------ Build axiom --------------------------------#


def build_axiom(seed: str, ptype: str, banks: Dict[str, Any], tone: str,
                max_mech: int, selfref_mode: str, emit_scaffold: bool,
                transcend: bool, rng: random.Random) -> Dict[str, Any]:
    core, bank_mechs = pick_core(seed, ptype, banks, rng)
    mechs = pick_mechanisms(seed, ptype, banks, rng, max_mech)
    # fold bank mechanisms in for canon entries (alignment resampling loop;
    # v0.4.7 keeps the best-scoring set rather than the last attempt)
    best_mechs, best_align = mechs, alignment_score(seed, mechs)
    for attempt in range(6):
        if best_align >= 0.06 or attempt == 5:
            break
        cand = pick_mechanisms(seed, ptype, banks, rng, max_mech)
        if bank_mechs and attempt % 2 == 1:
            extra = rng.sample(bank_mechs, min(2, len(bank_mechs)))
            cand = sorted(set(cand + extra))[:max(1, max_mech)]
        a = alignment_score(seed, cand)
        if a > best_align:
            best_mechs, best_align = cand, a
    mechs, alignment = best_mechs, best_align

    core, ptype, extra = selfref_transform(core, ptype, selfref_mode)
    equation = triangulate_equation(ptype, seed, mechs, banks, rng)
    consequence = rng.choice(
        banks["consequences"].get(ptype) or [CONSEQUENCE_MAP.get(
            ptype, "unexpected alignment")])

    mech_str = ", ".join(mechs[:3]) + ("\u2026" if len(mechs) > 3 else "")
    template = pick_template(ptype, banks, rng)
    axiom_text = (template
                  .replace("[CORE_STATEMENT]", core)
                  .replace("[MECHANISMS]", mech_str)
                  .replace("[MATH]", equation)
                  .replace("[CONSEQUENCES]", str(consequence)))
    if extra:
        axiom_text = axiom_text.rstrip(".") + f"; {extra}"
    if axiom_text.endswith("."):
        axiom_text = axiom_text[:-1]
    axiom_text += seed_suffix(seed, rng)
    axiom_text = sanitize_text(axiom_text)
    core = sanitize_text(core)

    scaffold = stylize_scaffold(tone, rng)
    metrics = compute_metrics(core, mechs, ptype, seed, alignment)

    entry: Dict[str, Any] = {
        "core_statement": core,
        "mechanisms": mechs[:max(1, max_mech)],
        "equation": equation,
        "consequences": consequence,
        "axiom_text": axiom_text,
        "paradox_type": ptype,
        "seed_concept": seed,
        "timestamp": utc_ts(),
        "metrics": metrics,
        "pillars": [seed],
    }
    if emit_scaffold:
        entry["humanized_injection_scaffold"] = scaffold
        entry["injection_scaffold"] = scaffold
    if transcend:
        entry["transcendent"] = transcendent_hooks(seed, core, mechs, rng)
    return entry

# --------------------------------- CLI -------------------------------------#


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="axiomforge_0.4.7.py",
        description="AxiomForge v0.4.7 - Recursive Paradox Engine "
                    "(stability & alignment release)")
    p.add_argument("--seed", type=str, help="Seed concept/title")
    p.add_argument("--seedfile", type=str, help="File of seeds, one per line")
    p.add_argument("--count", type=int, default=6, help="Axioms to emit")
    p.add_argument("--tone", type=str, default="poetic",
                   choices=["poetic", "plain", "academic", "oracular"])
    p.add_argument("--rng", type=int, default=None,
                   help="Deterministic RNG seed")
    p.add_argument("--emit-scaffold", action="store_true",
                   help="Include humanized_injection_scaffold fields")
    p.add_argument("--transcend", action="store_true",
                   help="Light transcendent hooks (origami/echo/qualia)")
    p.add_argument("--max-mech", type=int, default=3,
                   help="Max mechanisms per axiom")
    p.add_argument("--selfref-mode", type=str, default="meta",
                   choices=["binary", "meta", "field"])
    p.add_argument("--allow-duplicates", action="store_true")
    p.add_argument("--math-theme", type=str, default="auto")
    p.add_argument("--root", type=str, default=".",
                   help="Root folder for data JSON banks")
    p.add_argument("--save-to-history", action="store_true",
                   help="Also save a New_Session-style JSON file")
    p.add_argument("--out", type=str, default=None,
                   help="Write session JSON to this path")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    if not args.seed and not args.seedfile:
        print("Provide --seed or --seedfile", file=sys.stderr)
        sys.exit(2)

    if args.rng is not None:
        random.seed(args.rng)
    else:
        base = f"{args.seed or ''}|{args.seedfile or ''}|{args.count}"
        random.seed(zlib.crc32(base.encode("utf-8")))

    root = Path(args.root)
    banks = load_banks(root)

    seeds: List[str] = []
    if args.seed:
        seeds.append(args.seed)
    if args.seedfile:
        try:
            for line in Path(args.seedfile).read_text(
                    encoding="utf-8").splitlines():
                s = line.strip()
                if s:
                    seeds.append(s)
        except FileNotFoundError:
            print(f"seedfile not found: {args.seedfile}", file=sys.stderr)
            sys.exit(2)

    results: List[Dict[str, Any]] = []
    seen: set = set()
    emitted = 0
    while emitted < args.count:
        seed = seeds[emitted % len(seeds)]
        ptype = pick_type(seed, random)
        entry = build_axiom(seed, ptype, banks, args.tone,
                            max(1, args.max_mech), args.selfref_mode,
                            args.emit_scaffold, args.transcend, random)
        key = entry["core_statement"].strip().lower()
        if key in seen and not args.allow_duplicates:
            ptype2 = random.choice(DEF_PARADOX_TYPES)
            entry = build_axiom(seed, ptype2, banks, args.tone,
                                max(1, args.max_mech), args.selfref_mode,
                                args.emit_scaffold, args.transcend, random)
            key = entry["core_statement"].strip().lower()
            if key in seen:
                entry["core_statement"] += " (reframed)"
        seen.add(key)

        print("--- FINAL AXIOM ---")
        print(json.dumps(entry, ensure_ascii=False, indent=2))
        results.append(entry)
        emitted += 1

    out_path: Path | None = Path(args.out) if args.out else None
    if args.save_to_history and not out_path:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        out_path = Path(f"New_Session_{stamp}.json")
    if out_path:
        payload = {
            "exportedAt": utc_ts(),
            "engine": "axiomforge_0.4.7",
            "session": {
                "id": int(datetime.now(timezone.utc).timestamp()),
                "name": "axiomforge-0.4.7",
                "createdAt": utc_ts(),
                "seedPrompt": args.seed or (args.seedfile or ""),
                "params": {
                    "tone": args.tone,
                    "rng": args.rng,
                    "count": args.count,
                    "max_mech": args.max_mech,
                    "selfref_mode": args.selfref_mode,
                    "emit_scaffold": args.emit_scaffold,
                },
            },
            "results": results,
        }
        out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                            encoding="utf-8")
        print(f"\nSaved session \u2192 {out_path}", file=sys.stderr)


if __name__ == "__main__":
    main()
