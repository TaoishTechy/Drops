#!/usr/bin/env bash
# lib/cli.sh — main board, CLI passthrough, selftest
# Part of VOIDFORGE BBS v2.0.0 VOID

# ========================================================= MAIN BOARD ======
scr_main() {
  while :; do
    ui_clear
    boot_logo
    frame_open "MAIN BOARD" "$MG"
    menu "BOARDS" "$MG" \
      "1|THE FORGE — craft axioms from seeds" \
      "2|CHAOS FORGE — pure random generations" \
      "3|VOIDFORGE LAB — hollow · generic · dual" \
      "4|BATCH FACTORY — multi-format axiom files" \
      "5|THE VAULT — saved axioms" \
      "6|TELEMETRY — aggregate stats" \
      "7|SEED BANK — seed list manager" \
      "8|SESSION LOG — history & replay" \
      "9|ENGINE BAY — 5.0.0 / 0.4.7 / 0.3.7 / duels" \
      "A|THE CODEX — ethics · primers · help" \
      "0|LOG OFF"
    printf '  %suser:%s %s%-10s%s %sengine:%s %s%s %sonto:%s %s%s %svault:%s %s%s\n' \
      "$DM" "$R" "$WH" "$CFG_HANDLE" "$R" "$DM" "$R" "$(engine_label)" "$R" "$DM" "$R" "$CFG_ONTOLOGY" "$R" "$DM" "$R" "$(jsonl_count)" "$R"
    printf '%sboard> %s' "$B$MG" "$R"
    read -r c || c="0"
    chime
    case "$c" in
      1) scr_forge ;;
      2) scr_chaos ;;
      3) scr_void ;;
      4) scr_batch ;;
      5) scr_vault ;;
      6) scr_telemetry ;;
      7) scr_seeds ;;
      8) scr_sessions ;;
      9) scr_enginebay ;;
      a|A) scr_codex ;;
      0) break ;;
      *) : ;;
    esac
  done
  scr_logoff
}

# ==================================================== CLI passthrough ======
cli_usage() {
  cat <<'USAGE'
voidforge.sh — BBS dashboard + CLI passthrough

  (no args)                interactive BBS
  selftest                 non-interactive sanity check
  forge --seed S [--count N] [--tone T] [--rng N]
                           forge + save session to data/sessions/
  void  --seed S [--ontology classic|hollow|generic|dual]
        [--hollow-level L] [--forcing-level L] [--void-weight W]
        [--count N]        VoidForge run + save
  chaos [count]            pure-random generation + save
  batch --seeds FILE|--seed S [--count N] [--tone T] [--ontology O]
                           batch factory (all 4 formats) into data/exports/
  stats                    print telemetry summary
  help                     this text

env: AF_NOFLAIR=1 AF_FAST=1 AF_NOBG=1 AF_HOME=PATH
USAGE
}

cli_main() {
  local cmd="${1:-}"; shift || true
  case "$cmd" in
    selftest|--selftest) cli_selftest; return $? ;;
    forge)
      local seed="" count="$CFG_COUNT" tone="$CFG_TONE" rng=""
      while [ $# -gt 0 ]; do
        case "$1" in
          --seed) seed="$2"; shift 2 ;;
          --count) count="$2"; shift 2 ;;
          --tone) tone="$2"; shift 2 ;;
          --rng) rng="$2"; shift 2 ;;
          *) shift ;;
        esac
      done
      [ -z "$seed" ] && { echo "forge: --seed required" >&2; return 2; }
      local r="${rng:-$(( (RANDOM * 32768 + RANDOM) % 2147483647 ))}"
      run_engine "$seed" "$count" "$tone" "$r" 1 || return 1
      AF_SEED="$seed"
      local f; f="$(new_session_path)"
      cp "$AF_TMP/session.json" "$f"
      py - "$f" "$r" "$seed" "$tone" "$(engine_label)" "$CFG_ONTOLOGY" <<'PYEOF'
import json, sys
p = sys.argv[1]
d = json.load(open(p))
d.setdefault("session", {})
d["session"].update({"rng": sys.argv[2], "seedPrompt": sys.argv[3],
                     "params": {"tone": sys.argv[4], "engine": sys.argv[5],
                                "count": len(d.get("results", [])),
                                "ontology": sys.argv[6]}})
json.dump(d, open(p, "w"), ensure_ascii=False, indent=2)
PYEOF
      echo "saved: $f"
      ;;
    void)
      local seed="" onto="$CFG_ONTOLOGY" count="$CFG_COUNT" tone="$CFG_TONE" rng=""
      while [ $# -gt 0 ]; do
        case "$1" in
          --seed) seed="$2"; shift 2 ;;
          --ontology) onto="$2"; shift 2 ;;
          --count) count="$2"; shift 2 ;;
          --tone) tone="$2"; shift 2 ;;
          --rng) rng="$2"; shift 2 ;;
          *) shift ;;
        esac
      done
      [ "$AF_ENGINE50" -eq 1 ] || { echo "void: voidforge_5.0.0.py missing" >&2; return 2; }
      [ -z "$seed" ] && { echo "void: --seed required" >&2; return 2; }
      case "$onto" in classic|hollow|generic|dual) ;; *) echo "void: bad ontology '$onto'" >&2; return 2 ;; esac
      local r="${rng:-$(( (RANDOM * 32768 + RANDOM) % 2147483647 ))}"
      local pe="$CFG_ENGINE" po="$CFG_ONTOLOGY"
      CFG_ENGINE="5.0.0"; CFG_ONTOLOGY="$onto"
      local rc=0
      if [ "$onto" = "classic" ]; then
        run_engine "$seed" "$count" "$tone" "$r" 1 || rc=1
      else
        run_ontology "$seed" "$count" "$tone" "$r" 1 || rc=1
      fi
      CFG_ENGINE="$pe"; CFG_ONTOLOGY="$po"
      [ $rc -ne 0 ] && return $rc
      AF_SEED="$seed"
      local f; f="$(new_session_path)"
      cp "$AF_TMP/session.json" "$f"
      echo "saved: $f"
      ;;
    chaos)
      local n="${1:-1}"
      [ -s "$CHAOS_SEEDS_FILE" ] || chaos_harvest_words
      local seed; seed="$(chaos_random_seed)"
      local r=$(( RANDOM * 32768 + RANDOM ))
      echo "chaos seed: $seed"
      run_engine "$seed" "$n" "$CFG_TONE" "$r" 1 || return 1
      local f; f="$(new_session_path)"
      cp "$AF_TMP/session.json" "$f"
      echo "saved: $f"
      ;;
    batch)
      local seedfile="" seed="" count="${BATCH_COUNT:-3}" tone="$CFG_TONE" onto="classic"
      while [ $# -gt 0 ]; do
        case "$1" in
          --seeds) seedfile="$2"; shift 2 ;;
          --seed) seed="$2"; shift 2 ;;
          --count) count="$2"; shift 2 ;;
          --tone) tone="$2"; shift 2 ;;
          --ontology) onto="$2"; shift 2 ;;
          *) shift ;;
        esac
      done
      BATCH_SEEDS="single"; BATCH_SINGLE="$seed"; BATCH_COUNT="$count"; CFG_TONE="$tone"
      BATCH_ONTOLOGY="$onto"
      if [ -n "$seedfile" ]; then BATCH_SEEDS="file"; BATCH_FILE="$seedfile"; fi
      [ "$BATCH_SEEDS" = "single" ] && [ -z "$BATCH_SINGLE" ] && { echo "batch: --seed or --seeds required" >&2; return 2; }
      AF_TTY=0 AF_FLAIR=0 batch_run
      ;;
    stats) scr_telemetry ;;
    help|-h|--help) cli_usage ;;
    "") return 2 ;;
    *) echo "unknown command: $cmd (try: help)" >&2; return 2 ;;
  esac
}

# ======================================================== selftest =========
cli_selftest() {
  local fails=0 pass=0
  say() { printf '  %s%s%s %s\n' "$GR" "PASS" "$R" "$1"; pass=$((pass+1)); }
  fal() { printf '  %s%s%s %s\n' "$RD" "FAIL" "$R" "$1"; fails=$((fails+1)); }

  printf '%sVOIDFORGE BBS SELFTEST (v%s)%s\n' "$B$CY" "$AF_VERSION" "$R"
  # 1. engines runnable
  if run_engine "Dark Forest Theory" 1 poetic 1337 1; then say "engine executes and emits session.json"; else fal "engine execution"; fi
  # 2. schema fields present
  local core eq fid
  core="$(ax_field 0 core_statement)"
  eq="$(ax_field 0 equation)"
  fid="$(ax_field 0 metrics.fidelity -)"
  [ -n "$core" ] && [ "$core" != "None" ] && say "core_statement parsed" || fal "core_statement ($core)"
  [ -n "$eq" ] && [ "$eq" != "None" ] && say "equation parsed: $eq" || fal "equation missing"
  [ "$fid" != "-" ] && say "metrics parsed: fidelity=$fid" || fal "metrics missing"
  # 3. sanitizer: no placeholder residue
  local atext; atext="$(ax_field 0 axiom_text)"
  if printf '%s' "$atext" | grep -qE '\[(CORE_STATEMENT|MECHANISMS|MATH|CONSEQUENCES)\]'; then
    fal "placeholder residue in axiom_text"
  else say "sanitizer clean (no placeholder tokens)"; fi
  # 4. determinism
  run_engine "Nested Realities" 2 poetic 42 0 >/dev/null 2>&1
  cp "$AF_TMP/session.json" "$AF_TMP/d1.json"
  run_engine "Nested Realities" 2 poetic 42 0 >/dev/null 2>&1
  if py - "$AF_TMP/d1.json" "$AF_TMP/session.json" <<'PYEOF'
import json, sys
a = [r["core_statement"] for r in json.load(open(sys.argv[1]))["results"]]
b = [r["core_statement"] for r in json.load(open(sys.argv[2]))["results"]]
sys.exit(0 if a == b else 1)
PYEOF
  then say "determinism (same rng → same cores)"; else fal "determinism"; fi
  # 5. legacy engine
  CFG_ENGINE="0.3.7"
  if [ "$AF_ENGINE37" = 1 ] && run_engine "The Silent God" 1 poetic 42 1; then
    say "legacy 0.3.7 executes"; else fal "legacy 0.3.7"; fi
  CFG_ENGINE="5.0.0"
  # 6. vault round-trip
  vault_import_session "$AF_TMP/session.json" "selftest-seed" >/dev/null
  [ "$(jsonl_count)" -ge 1 ] && say "vault write OK ($(jsonl_count) entries)" || fal "vault write"
  # 7. batch factory export (classic)
  BATCH_SEEDS="single"; BATCH_SINGLE="Entropy eats order"; BATCH_COUNT=2; BATCH_ONTOLOGY="classic"
  AF_FLAIR=0 batch_run >/dev/null 2>&1
  local latest
  latest="$(ls -t "$AF_EXPORT"/batch_*.json 2>/dev/null | head -1)"
  if [ -n "$latest" ] && py -c "import json,sys; d=json.load(open('$latest')); sys.exit(0 if d.get('results') else 1)" 2>/dev/null; then
    say "batch factory JSON export valid"; else fal "batch factory"; fi
  local csvl
  csvl="$(ls -t "$AF_EXPORT"/batch_*_metrics.csv 2>/dev/null | head -1)"
  [ -n "$csvl" ] && [ "$(head -1 "$csvl" | grep -c 'novelty')" = 1 ] && say "CSV export header OK" || fal "CSV export"
  local mdl
  mdl="$(ls -t "$AF_EXPORT"/batch_*_grimoire.md 2>/dev/null | head -1)"
  [ -n "$mdl" ] && grep -q "^# VoidForge Grimoire" "$mdl" && say "MD grimoire export OK" || fal "MD grimoire"
  local txtl
  txtl="$(ls -t "$AF_EXPORT"/batch_*_codex.txt 2>/dev/null | head -1)"
  [ -n "$txtl" ] && grep -q "VOIDFORGE CODEX" "$txtl" && say "TXT codex export OK" || fal "TXT codex"
  # 8. ethics file + voidforge addendum
  if [ -f "$ETHICS_MD" ] && grep -q "VoidForge Addendum" "$ETHICS_MD"; then
    say "ETHICS.md present (with VoidForge Addendum)"; else fal "ETHICS.md / addendum missing"; fi
  # 9. v5 engine selftest (15 checks inside)
  if [ "$AF_ENGINE50" = 1 ]; then
    if py "$E50" --selftest >/dev/null 2>&1; then
      say "v5 engine selftest (15 internal checks) PASS"
    else fal "v5 engine selftest"; fi
    # 10. v5 hollow emission through the shell
    CFG_ONTOLOGY="hollow"
    if run_ontology "Nested Realities" 1 poetic 20250926 1; then
      local betti; betti="$(ax_field 0 hollow_reading.betti_spectrum -)"
      [ "$betti" != "-" ] && [ "$betti" != "None" ] && say "void hollow run (betti_spectrum=$betti)" || fal "hollow reading missing"
    else fal "void hollow run"; fi
    # 11. v5 dual emission + duality map
    CFG_ONTOLOGY="dual"
    if run_ontology "The Grandfather-Paradox Containment" 1 poetic 7 1; then
      local dr dmp
      dr="$(ax_field 0 metrics.duality_resonance -)"
      dmp="$(ax_field 0 duality_map.pairs.0.hollow -)"
      { [ "$dr" != "-" ] && [ "$dr" != "None" ]; } && [ "$dmp" != "-" ] && [ "$dmp" != "None" ] \
        && say "void dual run (resonance=$dr, duality map present)" || fal "dual emission malformed"
    else fal "void dual run"; fi
    # 12. ontology router rejection (temporal x hollow)
    CFG_ONTOLOGY="hollow"
    py "$E50" --ontology hollow --paradox-type temporal --seed X --count 1 \
      --root "$AF_HOME" >/dev/null 2> "$AF_TMP/router.err"
    local rrc=$?
    if [ $rrc -eq 0 ]; then
      fal "temporal x hollow should be rejected"
    else
      grep -q "allow-temporal-hollow" "$AF_TMP/router.err" 2>/dev/null \
        && say "ontology router rejects temporal x hollow (redirect hint present)" \
        || fal "router rejection message missing"
    fi
    py "$E50" --ontology hollow --paradox-type temporal --allow-temporal-hollow \
      --seed X --count 1 --rng 1 --root "$AF_HOME" >/dev/null 2>&1 \
      && say "temporal x hollow allowed on --allow-temporal-hollow opt-in" \
      || fal "opt-in override failed"
    # 13. parity duel: 0.4.7 vs v5 classic
    CFG_ONTOLOGY="classic"
    local c47 c50
    CFG_ENGINE="0.4.7"; run_engine "Dark Forest Theory" 1 poetic 777 0 >/dev/null 2>&1
    c47="$(ax_field 0 core_statement)"
    CFG_ENGINE="5.0.0"; run_engine "Dark Forest Theory" 1 poetic 777 0 >/dev/null 2>&1
    c50="$(ax_field 0 core_statement)"
    [ -n "$c47" ] && [ "$c47" = "$c50" ] && say "v5 classic parity with 0.4.7 (rng 777)" || fal "parity duel ($c47 vs $c50)"
    CFG_ENGINE="5.0.0"
  else
    fal "v5 engine present"
  fi
  # 14. batch with ontology=dual export valid
  if [ "$AF_ENGINE50" = 1 ]; then
    BATCH_ONTOLOGY="dual"; BATCH_SEEDS="single"; BATCH_SINGLE="Entropy eats order"; BATCH_COUNT=1
    AF_FLAIR=0 batch_run >/dev/null 2>&1
    latest="$(ls -t "$AF_EXPORT"/batch_*.json 2>/dev/null | head -1)"
    if [ -n "$latest" ] && py -c "
import json,sys
d=json.load(open('$latest'))
r=d.get('results',[])
sys.exit(0 if r and r[0].get('ontology')=='dual' else 1)" 2>/dev/null; then
      say "batch factory dual-ontology export valid"; else fal "batch dual export"; fi
    BATCH_ONTOLOGY="classic"
  fi
  CFG_ONTOLOGY="classic"

  printf '\n  %s%d passed · %d failed%s\n' "$B" "$pass" "$fails" "$R"
  [ "$fails" -eq 0 ]
}
