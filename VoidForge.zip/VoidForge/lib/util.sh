#!/usr/bin/env bash
# lib/util.sh — paths, environment, settings, config io, json helpers
# Part of VOIDFORGE BBS v2.0.0 VOID (sourced by voidforge.sh)

# ---------------------------------------------------------------- paths ----
AF_DATA="$AF_HOME/data"
AF_VAULT="$AF_DATA/vault"
AF_SESS="$AF_DATA/sessions"
AF_SEEDS="$AF_DATA/seeds"
AF_EXPORT="$AF_DATA/exports"
AF_LOGS="$AF_DATA/logs"
AF_CONF="$AF_DATA/config.json"
AF_VAULTF="$AF_VAULT/vault.jsonl"

E50="$AF_HOME/voidforge_5.0.0.py"
E47="$AF_HOME/axiomforge_0.4.7.py"
E37="$AF_HOME/axiomforge_0.3.7.py"
ETHICS_MD="$AF_HOME/ETHICS.md"
README_MD="$AF_HOME/README.md"
AF_BANKS="$AF_HOME/banks"
AF_HOLLOW_BANK="$AF_BANKS/hollow_bank.json"
AF_GENERIC_BANK="$AF_BANKS/generic_bank.json"
AF_DUALITY_MAP="$AF_BANKS/duality_map.json"

for _d in "$AF_DATA" "$AF_VAULT" "$AF_SESS" "$AF_SEEDS" "$AF_EXPORT" "$AF_LOGS"; do
  [ -d "$_d" ] || mkdir -p "$_d" 2>/dev/null
done

AF_VERSION="2.0.0"
AF_TMP="$(mktemp -d "${TMPDIR:-/tmp}/afbbs.XXXXXX")"
cleanup() { af_bg_off; rm -rf "$AF_TMP" 2>/dev/null; }
trap cleanup EXIT

# ------------------------------------------------------------ deps check ---
AF_BASHMAJOR="${BASH_VERSINFO[0]:-0}"
AF_PY="$(command -v python3 || command -v python || true)"
AF_TTY=0
[ -t 0 ] && [ -t 1 ] && AF_TTY=1
if [ -z "$AF_PY" ]; then
  echo "FATAL: python3 is required (the engines are Python). Install python3." >&2
  exit 1
fi
if [ "$AF_BASHMAJOR" -lt 4 ]; then
  echo "WARN: bash $BASH_VERSION detected; bash >= 4 recommended." >&2
  sleep 1
fi
AF_ENGINE50=0; AF_ENGINE47=0; AF_ENGINE37=0
[ -f "$E50" ] && AF_ENGINE50=1
[ -f "$E47" ] && AF_ENGINE47=1
[ -f "$E37" ] && AF_ENGINE37=1
if [ "$AF_ENGINE47" -eq 0 ] && [ "$AF_ENGINE37" -eq 0 ] && [ "$AF_ENGINE50" -eq 0 ]; then
  echo "FATAL: no engine found. Keep voidforge_5.0.0.py / 0.4.7.py / 0.3.7.py next to this script." >&2
  exit 1
fi

# ----------------------------------------------------- canvas + settings ---
af_osc()   { [ "$AF_TTY" -eq 1 ] && printf '\033]%s\007' "$1" || true; }
af_bg_on() {
  [ "${AF_NOBG:-0}" = "1" ] && return 0
  af_osc "10;#e6e6e6"; af_osc "11;#000000"
}
af_bg_off() {
  [ "${AF_NOBG:-0}" = "1" ] && return 0
  af_osc "110"; af_osc "111"
}

AF_FLAIR=1
[ "$AF_TTY" -eq 0 ] && AF_FLAIR=0
[ "${AF_NOFLAIR:-0}" = "1" ] && AF_FLAIR=0
AF_SPEED=1
[ "${AF_FAST:-0}" = "1" ] && AF_SPEED=0

# defaults (persisted in config.json)
CFG_HANDLE="GUEST"
CFG_ENGINE="5.0.0"      # 5.0.0 | 0.4.7 | 0.3.7
CFG_TONE="poetic"       # poetic|plain|academic|oracular
CFG_COUNT=3
CFG_SCAFFOLD=1
CFG_MAXMECH=3
CFG_SELFREF="meta"      # binary|meta|field
CFG_TRANSCEND=0
CFG_FIRSTBOOT=1
# void settings (used when CFG_ENGINE = 5.0.0)
CFG_ONTOLOGY="dual"     # classic|hollow|generic|dual
CFG_HLEVEL="cohomology" # cw|betti|cohomology|homotopy
CFG_FLEVEL="poset"      # poset|boolean|cardinal|multiverse
CFG_VOIDW="0.5"         # 0..1 dual interpolation
CFG_STRICTVOID=0
CFG_EMITDUAL=1

# ------------------------------------------------------------- config io ---
conf_load() {
  [ -f "$AF_CONF" ] || { conf_save; return; }
  local v
  v="$(py -c "
import json,sys
try:
    c=json.load(open('$AF_CONF'))
except Exception:
    sys.exit(0)
for k in ('handle','engine','tone','count','scaffold','maxmech','selfref','transcend','firstboot','ontology','hlevel','flevel','voidw','strictvoid','emitdual'):
    if k in c: print(k+'='+str(c[k]))
")" || v=""
  local kv k val
  while IFS= read -r kv; do
    [ -z "$kv" ] && continue
    k="${kv%%=*}"; val="${kv#*=}"
    case "$k" in
      handle) CFG_HANDLE="$val" ;;
      engine) CFG_ENGINE="$val" ;;
      tone) CFG_TONE="$val" ;;
      count) CFG_COUNT="$val" ;;
      scaffold) CFG_SCAFFOLD="$val" ;;
      maxmech) CFG_MAXMECH="$val" ;;
      selfref) CFG_SELFREF="$val" ;;
      transcend) CFG_TRANSCEND="$val" ;;
      firstboot) CFG_FIRSTBOOT="$val" ;;
      ontology) CFG_ONTOLOGY="$val" ;;
      hlevel) CFG_HLEVEL="$val" ;;
      flevel) CFG_FLEVEL="$val" ;;
      voidw) CFG_VOIDW="$val" ;;
      strictvoid) CFG_STRICTVOID="$val" ;;
      emitdual) CFG_EMITDUAL="$val" ;;
    esac
  done <<< "$v"
}
conf_save() {
  py - "$AF_CONF" <<PYEOF
import json, os, sys
path = sys.argv[1]
cfg = {
 "handle": "$CFG_HANDLE", "engine": "$CFG_ENGINE", "tone": "$CFG_TONE",
 "count": int("$CFG_COUNT" or 3), "scaffold": int("$CFG_SCAFFOLD" or 0),
 "maxmech": int("$CFG_MAXMECH" or 3), "selfref": "$CFG_SELFREF",
 "transcend": int("$CFG_TRANSCEND" or 0), "firstboot": int("$CFG_FIRSTBOOT" or 0),
 "ontology": "$CFG_ONTOLOGY", "hlevel": "$CFG_HLEVEL", "flevel": "$CFG_FLEVEL",
 "voidw": "$CFG_VOIDW", "strictvoid": int("$CFG_STRICTVOID" or 0),
 "emitdual": int("$CFG_EMITDUAL" or 0),
}
try:
    old = json.load(open(path))
    if old.get("handle") and "$CFG_HANDLE" == "GUEST":
        cfg["handle"] = old["handle"]
except Exception:
    pass
os.makedirs(os.path.dirname(path), exist_ok=True)
json.dump(cfg, open(path, "w"), indent=2)
PYEOF
}

py() { "$AF_PY" "$@"; }   # interpreter alias

# ------------------------------------------------------------ json utils ---
jget() {  # jget <json-file-or-'-'> <dotted.key> [default]
  local src="$1" key="$2" def="${3:-}"
  py - "$src" "$key" "$def" <<'PYEOF'
import json, sys
src, key, dflt = sys.argv[1], sys.argv[2], sys.argv[3]
try:
    data = json.load(sys.stdin) if src == "-" else json.load(open(src))
except Exception:
    print(dflt); sys.exit(0)
cur = data
for part in key.split("."):
    if isinstance(cur, dict) and part in cur:
        cur = cur[part]
    elif isinstance(cur, list) and part.lstrip("-").isdigit():
        i = int(part)
        cur = cur[i] if -len(cur) <= i < len(cur) else None
    else:
        cur = None; break
print("" if cur is None else cur)
PYEOF
}

jsonl_count() {  # lines in vault
  [ -f "$AF_VAULTF" ] && wc -l < "$AF_VAULTF" | tr -d ' ' || echo 0
}

stamp_id() { date -u +"%Y%m%dT%H%M%SZ" 2>/dev/null || date +"%Y%m%dT%H%M%SZ"; }
now_local() { date +"%Y-%m-%d %H:%M:%S %Z" 2>/dev/null || date; }
