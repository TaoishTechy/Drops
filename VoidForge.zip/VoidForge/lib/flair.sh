#!/usr/bin/env bash
# lib/flair.sh — boot sequence, logo, login, ethics gate, logoff
# Part of VOIDFORGE BBS v2.0.0 VOID (sourced by voidforge.sh)

LOGO_LINES=(
"     █   █ ▄▄▄▄▄ ▄▄▄▄▄ ▄▄▄▄  ▄▄▄▄▄ ▄▄▄▄▄ ▄▄▄▄▄ ▄▄▄▄▄ ▄▄▄▄▄"
"     █   █ █   █   █   █   █ █     █   █ █   █ █     █    "
"     █   █ █   █   █   █   █ ███   █   █ ████  █  ▄▄ ███  "
"     █ █  █   █   █   █   █ █     █   █ █  █  █   █ █    "
"       █  ▀▀▀▀▀ ▀▀▀▀▀ ▀▄▄▀  ▀     ▀▀▀▀▀ ▀   ▀ ▀▄▄▀  ▀▀▀▀▀"
)
boot_logo() {
  local i
  printf '\n'
  for ((i=0; i<${#LOGO_LINES[@]}; i++)); do
    case $((i % 3)) in
      0) printf '%s%s\n' "$CY"  "${LOGO_LINES[i]}$R" ;;
      1) printf '%s%s\n' "$VI"  "${LOGO_LINES[i]}$R" ;;
      2) printf '%s%s\n' "$MG"  "${LOGO_LINES[i]}$R" ;;
    esac
    sleepx 0.12
  done
  printf '\n'
  center "$DM$IT  recursion depth: ∞ · placeholder residue: 0.00 · stance: research-safe$R"
  printf '\n'
}

scr_boot() {
  ui_clear
  local lines=(
    "VOIDFORGE BIOS v5.0.0-void ...................... OK"
    "MEM CHECK 640K PARADOX RAM ....................... OK"
    "MOUNT /dev/ontology .............................. OK"
    "LOAD banks: paradox_base new_paradoxes templates .. OK"
  )
  local lines_void=(
    "LOAD void banks: hollow generic duality_map ...... OK"
    "VOID ROUTER (classic|hollow|generic|dual|legacy) .. ONLINE"
  )
  local l
  for l in "${lines[@]}"; do
    printf '  %s%s%s\n' "$CYD" "$l" "$R"
    sleepx 0.18
  done
  if [ "$AF_ENGINE50" -eq 1 ]; then
    for l in "${lines_void[@]}"; do
      printf '  %s%s%s\n' "$HC" "$l" "$R"
      sleepx 0.18
    done
  fi
  printf '  %sSANITIZER kill-switch ............................ ARMED%s\n' "$CYD" "$R"
  sleepx 0.18
  printf '  %sEQUATION whitelist triangulator ................... CALIBRATED%s\n' "$CYD" "$R"
  sleepx 0.18
  printf '  %sCONCEPT alignment scorer ........................... ONLINE%s\n' "$CYD" "$R"
  sleepx 0.3
  printf '\n  %sATDT 1-800-VOIDFORGE%s\n' "$MG" "$R"
  local dots
  for dots in "" "." ".." "..." "...."; do
    printf '\r  %sATDT 1-800-VOIDFORGE%s%s' "$MG" "$R" "$dots"
    sleepx 0.35
  done
  printf '\r  %sCONNECT 14400/ARQ/V34/LAPM/V42/BIS%s   %s carrier detected %s\n' "$GR" "$R" "$DM" "$R"
  chime
  sleepx 0.5
  ui_clear
  boot_logo
  center "$B$MG◆$CY  R E C U R S I V E   P A R A D O X   B B S  $MG◆$R"
  center "$DM── node 1 · synthwave ring · v$AF_VERSION VOID · est. 2025 ──$R"
  printf '\n'
}

scr_login() {
  local h
  center "$CY╭──────────────────────────────────────────────╮$R"
  center "$CY│$R  $B$WH          N E W   U S E R   L O G I N        $R$CY│$R"
  center "$CY╰──────────────────────────────────────────────╯$R"
  if [ "$AF_TTY" -eq 1 ]; then
    printf '%s  handle? %s[%s]%s: ' "$CY" "$DM" "$CFG_HANDLE" "$R"
    read -r h || h="$CFG_HANDLE"
    [ -n "$h" ] && CFG_HANDLE="$(printf '%s' "$h" | tr -dc 'A-Za-z0-9._-' | cut -c1-20)"
    [ -z "$CFG_HANDLE" ] && CFG_HANDLE="GUEST"
  fi
  conf_save
  center "$DM  welcome, $GY$CFG_HANDLE$R$DM · ethics codex loads on first session$R"
  printf '\n'
}

# ====================================================== first-boot ethics ===
ethics_gate() {
  [ "$CFG_FIRSTBOOT" = "1" ] || return 0
  [ -f "$ETHICS_MD" ] || { CFG_FIRSTBOOT=0; conf_save; return 0; }
  ui_clear
  center "$YW$B┌────────────────────────────────────────────────────────────┐$R"
  center "$YW$B│  FIRST SESSION — ETHICS.PRELOAD                            │$R"
  center "$YW$B└────────────────────────────────────────────────────────────┘$R"
  printf '\n'
  type_line "  ${GY}voidforge is a research and creativity instrument.${R}"
  type_line "  ${GY}use is conditioned on the ethics codex — no deception,$R"
  type_line "  ${GY}no manipulation, no harm. reviewing now:$R"
  printf '\n'
  sleepx 0.6
  pager "$ETHICS_MD" "ETHICS · conditions of use" "$YW" 14
  CFG_FIRSTBOOT=0
  conf_save
  ui_clear
  say_line "$GR" "ethics codex acknowledged — carrier open. re-read anytime under CODEX."
  press_any
}

scr_logoff() {
  ui_clear
  printf '\n\n'
  center "$CY╭──────────────────────────────────────────────────╮$R"
  center "$CY│$R  $MG carrier dropped · link terminated · NO CARRIER $R$CY│$R"
  center "$CY╰──────────────────────────────────────────────────╯$R"
  printf '\n'
  center "$DM\"the paradox remains unresolved — as designed.\"$R"
  printf '\n\n'
  sleepx 0.6
}
