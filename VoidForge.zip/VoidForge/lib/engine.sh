#!/usr/bin/env bash
# lib/engine.sh — engine selection, execution, session accessors, rendering
# Part of VOIDFORGE BBS v2.0.0 VOID (sourced by voidforge.sh)

engine_py() {
  case "$CFG_ENGINE" in
    5.0.0) [ "$AF_ENGINE50" -eq 1 ] && { printf '%s' "$E50"; return; } ;&
    0.3.7) [ "$AF_ENGINE37" -eq 1 ] && [ "$CFG_ENGINE" = "0.3.7" ] && { printf '%s' "$E37"; return; } ;&
    *) [ "$AF_ENGINE47" -eq 1 ] && printf '%s' "$E47" || printf '%s' "$E50" ;;
  esac
}

engine_label() {
  case "$CFG_ENGINE" in
    5.0.0) printf 'voidforge_5.0.0.py' ;;
    0.3.7) printf 'axiomforge_0.3.7.py' ;;
    *)     printf 'axiomforge_0.4.7.py' ;;
  esac
}

engine_is_void() { [ "$CFG_ENGINE" = "5.0.0" ] && [ "$AF_ENGINE50" -eq 1 ]; }
engine_supports() {  # --transcend / --selfref-mode known by 0.4.7 + v5
  [ "$CFG_ENGINE" = "0.4.7" ] || engine_is_void
}

# --------------------------------------------------------- void runners ----
# run_ontology <seed> <count> <tone> <rng|-> <scaffold 0/1> [count via CFG]
# uses CFG_ONTOLOGY / CFG_HLEVEL / CFG_FLEVEL / CFG_VOIDW / CFG_EMITDUAL /
#      CFG_STRICTVOID / CFG_MAXMECH
run_ontology() {
  local seed="$1" count="$2" tone="$3" rng="$4" scaffold="$5"
  local -a cmd=("$AF_PY" "$E50" --seed "$seed" --count "$count" --tone "$tone"
                --root "$AF_HOME"
                --ontology "$CFG_ONTOLOGY"
                --hollow-level "$CFG_HLEVEL"
                --forcing-level "$CFG_FLEVEL"
                --void-weight "$CFG_VOIDW"
                --max-mech "$CFG_MAXMECH")
  [ "$rng" != "-" ] && cmd+=(--rng "$rng")
  [ "$scaffold" = "1" ] && cmd+=(--emit-scaffold)
  [ "$CFG_EMITDUAL" = "1" ] && cmd+=(--emit-duality)
  [ "$CFG_STRICTVOID" = "1" ] && cmd+=(--strict-void)
  "${cmd[@]}" > "$AF_TMP/engine.stdout" 2> "$AF_TMP/engine.stderr"
  local rc=$?
  [ $rc -ne 0 ] && return $rc
  [ -f "$AF_TMP/session.json" ] && rm -f "$AF_TMP/session.json"
  # v5 writes --- FINAL AXIOM --- stream; assemble session.json from it
  session_from_stdout "voidforge_5.0.0"
  return 0
}

# run_engine <seed> <count> <tone> <rng|-> <scaffold 0/1> -> $AF_TMP/session.json
run_engine() {
  local seed="$1" count="$2" tone="$3" rng="$4" scaffold="$5"
  if engine_is_void && [ "$CFG_ONTOLOGY" != "classic" ]; then
    run_ontology "$seed" "$count" "$tone" "$rng" "$scaffold"
    return $?
  fi
  local eng; eng="$(engine_py)"
  local -a cmd=("$AF_PY" "$eng" --seed "$seed" --count "$count" --tone "$tone" --root "$AF_HOME")
  [ "$rng" != "-" ] && cmd+=(--rng "$rng")
  [ "$scaffold" = "1" ] && cmd+=(--emit-scaffold)
  if engine_supports; then
    cmd+=(--max-mech "$CFG_MAXMECH" --selfref-mode "$CFG_SELFREF" --out "$AF_TMP/session.json")
    [ "$CFG_TRANSCEND" = "1" ] && [ "$CFG_ENGINE" = "0.4.7" ] && cmd+=(--transcend)
  else
    cmd+=(--max-mech "$CFG_MAXMECH" --selfref-mode "$CFG_SELFREF" --allow-duplicates)
  fi
  "${cmd[@]}" > "$AF_TMP/engine.stdout" 2> "$AF_TMP/engine.stderr"
  local rc=$?
  [ $rc -ne 0 ] && return $rc
  # v5 with --out already wrote session.json; 0.4.7 too. 0.3.7 didn't.
  if [ ! -s "$AF_TMP/session.json" ]; then
    session_from_stdout "$(engine_label)"
  fi
  return 0
}

session_from_stdout() {  # build session.json by splitting marker stream
  py - "$AF_TMP/engine.stdout" "$AF_TMP/session.json" "${1:-$(engine_label)}" <<'PYEOF'
import json, sys, re
from datetime import datetime, timezone
raw = open(sys.argv[1], encoding="utf-8").read()
chunks = [c for c in raw.split("--- FINAL AXIOM ---") if c.strip()]
results = []
for c in chunks:
    c = c.strip()
    try:
        results.append(json.loads(c))
    except Exception:
        m = re.search(r"\{.*\}", c, re.S)
        if m:
            try: results.append(json.loads(m.group(0)))
            except Exception: pass
ts = datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00","Z")
payload = {"exportedAt": ts, "engine": sys.argv[3],
           "session": {"id": int(datetime.now(timezone.utc).timestamp()),
                       "name": "bbs-capture", "createdAt": ts,
                       "seedPrompt": "", "params": {}},
           "results": results}
json.dump(payload, open(sys.argv[2], "w"), ensure_ascii=False, indent=2)
PYEOF
}

ax_count() { py -c "
import json
try: print(len(json.load(open('$AF_TMP/session.json')).get('results', [])))
except Exception: print(0)"; }

ax_field() {  # ax_field <index> <key.path> [default]
  local idx="$1" key="$2" def="${3:-}"
  py - "$AF_TMP/session.json" "$idx" "$key" "$def" <<'PYEOF'
import json, sys
try:
    e = json.load(open(sys.argv[1]))["results"][int(sys.argv[2])]
except Exception:
    print(sys.argv[4]); sys.exit(0)
key = sys.argv[3]
cur = e
for part in key.split("."):
    if isinstance(cur, dict) and part in cur: cur = cur[part]
    else: cur = None; break
if isinstance(cur, list): cur = ", ".join(str(x) for x in cur)
print("" if cur is None else cur)
PYEOF
}

ax_ontology() {  # ontology tag of emission i (default classic)
  local o; o="$(ax_field "$1" ontology "classic")"
  [ "$o" = "None" ] && o="classic"
  printf '%s' "$o"
}

# ==================================================== axiom rendering ======
metric_bar_row() {  # label value(0..1) color — framed inside show_axiom
  local label="$1" val="$2" col="$3"
  printf '%s║%s %s%-12s%s %s %s%5.2f%s\n' "$MG" "$R" "$GY" "$label" "$R" \
    "$(bar "$val" 24 "$col")" "$DM" "$val" "$R"
}

void_bar_row() {  # void metric row (hollow/generic dual-accent)
  local label="$1" val="$2"
  printf '%s║%s %s%-12s%s %s %s%5.2f%s\n' "$VI" "$R" "$GY" "$label" "$R" \
    "$(bar "$val" 24 "$HC")" "$DM" "$val" "$R"
}

show_axiom() {  # show_axiom <index> — classic + void-aware dispatcher
  local i="$1"
  local onto; onto="$(ax_ontology "$i")"
  if [ "$onto" != "classic" ]; then
    show_void_axiom "$i"
    return
  fi
  local idx=$((i+1))
  local core mechs eq cons atext ptype seed fid novel dens eleg alien qual scf
  core="$(ax_field "$i" core_statement)"
  mechs="$(ax_field "$i" mechanisms)"
  eq="$(ax_field "$i" equation)"
  cons="$(ax_field "$i" consequences)"
  atext="$(ax_field "$i" axiom_text)"
  ptype="$(ax_field "$i" paradox_type)"
  seed="$(ax_field "$i" seed_concept)"
  fid="$(ax_field "$i" metrics.fidelity 0)"
  novel="$(ax_field "$i" metrics.novelty 0)"
  dens="$(ax_field "$i" metrics.density 0)"
  eleg="$(ax_field "$i" metrics.elegance 0)"
  alien="$(ax_field "$i" metrics.alienness 0)"
  qual="$(ax_field "$i" metrics.qualia_density 0)"
  scf="$(ax_field "$i" humanized_injection_scaffold)"
  local align reso ndp arch
  align="$(ax_field "$i" metrics.fidelity_breakdown.concept_alignment 0)"
  reso="$(ax_field "$i" metrics.fidelity_breakdown.emotional_resonance 0)"
  ndp="$(ax_field "$i" metrics.fidelity_breakdown.novelty_density_product 0)"
  arch="$(ax_field "$i" metrics.fidelity_breakdown.archetypal_alignment 0)"

  frame_open "AXIOM #$idx · [$ptype]" "$MG"
  printf '%s║%s %sSEED%s %s%s%s\n' "$MG" "$R" "$B$CY" "$R" "$WH" "$seed" "$R"
  hr "$MGD"
  printf '%s║%s\n' "$MG" "$R"
  printf '%s║%s %s\n' "$MG" "$R" "$(printf '%s' "$atext" | wrap $(( AF_COLS - 10 )) | head -8 | sed "1s/^/ /;2,\$s/^/       /")"
  printf '%s║%s\n' "$MG" "$R"
  printf '%s║%s %sMECHANISMS%s  %s%s%s\n' "$MG" "$R" "$B$CY" "$R" "$VI" "$mechs" "$R"
  printf '%s║%s %sMATH%s        %s%s%s\n' "$MG" "$R" "$B$CY" "$R" "$OR" "$eq" "$R"
  printf '%s║%s %sCONSEQ%s      %s%s%s\n' "$MG" "$R" "$B$CY" "$R" "$GY" "$cons" "$R"
  printf '%s║%s\n' "$MG" "$R"
  local nf df ef al
  nf="$(awk "BEGIN{print ($novel+0>1.2)?1.0:($novel+0)/1.2}")"
  df="$(awk "BEGIN{print ($dens+0)/14.0}")"
  ef="$(awk "BEGIN{print ($eleg+0)/100.0}")"
  al="$(awk "BEGIN{print ($alien+0)/12.0}")"
  printf '%s║%s\n' "$MG" "$R"
  printf '%s║%s %sMETRICS%s\n' "$MG" "$R" "$B$CY" "$R"
  metric_bar_row "fidelity" "$(awk "BEGIN{print ($fid+0)/100.0}")" "$MG"
  metric_bar_row "novelty" "$nf" "$CY"
  metric_bar_row "density" "$df" "$VI"
  metric_bar_row "elegance" "$ef" "$OR"
  metric_bar_row "alienness" "$al" "$MGD"
  printf '%s║%s %s%-12s%s align %s%4.2f%s reso %s%4.2f%s nxd %s%4.2f%s arch %s%4.2f%s qualia %s%5.3f%s\n' \
    "$MG" "$R" "$DM" "breakdown" "$R" \
    "$CY" "$align" "$R" "$VI" "$reso" "$R" "$OR" "$ndp" "$R" "$MGD" "$arch" "$R" "$DM" "$qual" "$R"
  [ -n "$scf" ] && [ "$scf" != "None" ] && printf '%s║%s %sscaffold%s %s%s%s\n' "$MG" "$R" "$B$YW" "$R" "$IT$GY" "$scf" "$R"
  frame_close "$MG"
}

show_reading() {  # show_reading <index> <hollow|generic> <accent>
  local i="$1" side="$2" acc="$3"
  local low; low="$(printf '%s' "$side" | tr 'A-Z' 'a-z')"
  local core mechs eq cons lvl scaffold extra
  core="$(ax_field "$i" "${low}_reading.core_statement")"
  mechs="$(ax_field "$i" "${low}_reading.mechanisms")"
  eq="$(ax_field "$i" "${low}_reading.equation")"
  cons="$(ax_field "$i" "${low}_reading.consequences")"
  scaffold="$(ax_field "$i" "${low}_reading.scaffold")"
  if [ "$low" = "hollow" ]; then
    lvl="$(ax_field "$i" hollow_reading.hollow_level '?')"
    extra="$(printf 'betti %s · π1 %s' "$(ax_field "$i" hollow_reading.betti_spectrum '?')" "$(ax_field "$i" hollow_reading.fundamental_group_hint '?')")"
  else
    lvl="$(ax_field "$i" generic_reading.forcing_level '?')"
    extra="$(printf 'extension %s · ⊩ %s' "$(ax_field "$i" generic_reading.extension_hint '?')" "$(ax_field "$i" generic_reading.forcing_relation '?')")"
  fi
  frame_open "$(printf '%sREADING · layer %s' "$(printf '%s' "$side" | tr 'a-z' 'A-Z')" "$lvl")" "$acc"
  printf '%s║%s %s%s%s\n' "$acc" "$R" "$IT$WH" "$core" "$R"
  printf '%s║%s %sMECHANISMS%s  %s%s%s\n' "$acc" "$R" "$B$CY" "$R" "$VI" "$mechs" "$R"
  printf '%s║%s %sMATH%s        %s%s%s\n' "$acc" "$R" "$B$CY" "$R" "$OR" "$eq" "$R"
  printf '%s║%s %sCONSEQ%s      %s%s%s\n' "$acc" "$R" "$B$CY" "$R" "$GY" "$cons" "$R"
  printf '%s║%s %s%s%s %s· %s%s%s\n' "$acc" "$R" "$B$YW" "$scaffold" "$R" "$DM" "$DM" "$extra" "$R"
  frame_close "$acc"
}

show_duality_map() {  # show_duality_map <index>
  local i="$1"
  local note sh sg
  note="$(ax_field "$i" duality_map.note '')"
  sh="$(ax_field "$i" duality_map.scaffold_pair.hollow '')"
  sg="$(ax_field "$i" duality_map.scaffold_pair.generic '')"
  frame_open "DUALITY MAP · hollow ↔ generic" "$CY"
  py - "$AF_TMP/session.json" "$i" <<'PYEOF' | while IFS= read -r ln; do printf '%s║%s %s\n' "$CY" "$R" "$ln"; done
import json, sys
try:
    e = json.load(open(sys.argv[1]))["results"][int(sys.argv[2])]
    pairs = (e.get("duality_map") or {}).get("pairs", [])
except Exception:
    pairs = []
if not pairs:
    print("  (no duality map recorded for this emission)")
for p in pairs:
    print(f"  {p.get('hollow','?'):<28} <-> {p.get('generic','?')}")
PYEOF
  [ -n "$sh$sg" ] && printf '%s║%s %sscaffold%s %s%s%s %s⇄%s %s%s%s\n' "$CY" "$R" "$B$YW" "$R" "$HC" "$sh" "$R" "$DM" "$R" "$GC" "$sg" "$R"
  [ -n "$note" ] && printf '%s║%s %s"%s"%s\n' "$CY" "$R" "$IT$DM" "$note" "$R" "$R"
  frame_close "$CY"
}

show_void_axiom() {  # show_void_axiom <index> — hollow/generic/dual rendering
  local i="$1" idx=$((i+1))
  local onto ptype seed atext core fid
  onto="$(ax_ontology "$i")"
  ptype="$(ax_field "$i" paradox_type)"
  seed="$(ax_field "$i" seed_concept)"
  atext="$(ax_field "$i" axiom_text)"
  core="$(ax_field "$i" core_statement)"
  fid="$(ax_field "$i" metrics.fidelity 0)"
  frame_open "AXIOM #$idx · [$onto/$ptype]" "$VI"
  printf '%s║%s %sSEED%s %s%s%s\n' "$VI" "$R" "$B$CY" "$R" "$WH" "$seed" "$R"
  hr "$MGD"
  printf '%s║%s %s\n' "$VI" "$R" "$(printf '%s' "$atext" | wrap $(( AF_COLS - 10 )) | head -10 | sed "1s/^/ /;2,\$s/^/       /")"
  printf '%s║%s\n' "$VI" "$R"
  if [ "$onto" = "dual" ]; then
    printf '%s║%s %sFUSED CORE%s %s%s%s\n' "$VI" "$R" "$B$CY" "$R" "$B$WH" "$core" "$R"
  fi
  frame_close "$VI"
  if [ "$onto" = "hollow" ] || [ "$onto" = "dual" ]; then
    show_reading "$i" hollow "$HC"; printf '\n'
  fi
  if [ "$onto" = "generic" ] || [ "$onto" = "dual" ]; then
    show_reading "$i" generic "$GC"; printf '\n'
  fi
  if [ "$onto" = "dual" ] && [ "$(ax_field "$i" duality_map.note '')" != "" -o "$(ax_field "$i" duality_map.pairs.0.hollow '')" != "" ]; then
    show_duality_map "$i"; printf '\n'
  fi
  # void metrics
  local hI fI vc dr vs
  hI="$(ax_field "$i" metrics.hollow_index 0)"
  fI="$(ax_field "$i" metrics.forcing_index 0)"
  vc="$(ax_field "$i" metrics.void_coherence 0)"
  dr="$(ax_field "$i" metrics.duality_resonance 0)"
  vs="$(ax_field "$i" metrics.void_score 0)"
  frame_open "VOID METRICS" "$VI"
  void_bar_row "hollow_idx" "$hI"
  void_bar_row "forcing_idx" "$fI"
  void_bar_row "v.coherence" "$vc"
  void_bar_row "d.resonance" "$dr"
  void_bar_row "void_score" "$vs"
  frame_close "$VI"
}
