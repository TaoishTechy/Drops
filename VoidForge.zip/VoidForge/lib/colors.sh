#!/usr/bin/env bash
# lib/colors.sh — the theme: true-black canvas, synthwave neon foregrounds
# Part of VOIDFORGE BBS v2.0.0 VOID (sourced by voidforge.sh)
#
# Palette contract: every hue is tuned for high, even contrast against
# #000000. R re-asserts the black background on every reset so colored text
# always sits on black even if the terminal ignored the OSC canvas claim.

if command -v tput >/dev/null 2>&1; then
  AF_COLS="$(tput cols 2>/dev/null || echo 80)"; AF_ROWS="$(tput lines 2>/dev/null || echo 24)"
else
  AF_COLS=80; AF_ROWS=24
fi
(( AF_COLS < 60 )) && AF_COLS=60
(( AF_COLS > 120 )) && AF_COLS=120

if [ "$AF_TTY" -eq 1 ] && [ "${AF_NOBG:-0}" != "1" ]; then
  R="$(printf '\033[0;48;5;16m')"  # reset attrs + keep the black canvas
else
  R="$(printf '\033[0m')"          # plain reset (piped output stays clean)
fi
B="$(printf '\033[1m')"           # bold
DM="$(printf '\033[38;5;245m')"   # metadata gray (readable; was invisible 2m dim)
IT="$(printf '\033[3m')"          # italic
# palette — all checked for >= 7:1 contrast on black
CY="$(printf '\033[38;5;51m')"    # neon cyan        #00ffff
CYD="$(printf '\033[38;5;44m')"   # deep cyan        #00d7d7
MG="$(printf '\033[38;5;201m')"   # hot magenta      #ff00ff
MGD="$(printf '\033[38;5;164m')"  # rose magenta     #d700d7
VI="$(printf '\033[38;5;141m')"   # violet           #af87ff
OR="$(printf '\033[38;5;209m')"   # sunset orange    #ff875f
WH="$(printf '\033[38;5;255m')"   # headline white   #eeeeee
GY="$(printf '\033[38;5;146m')"   # body lavender    #afafd7
GR="$(printf '\033[38;5;84m')"    # success green    #5fff5f
YW="$(printf '\033[38;5;226m')"   # warning yellow   #ffff00
RD="$(printf '\033[38;5;203m')"   # error coral      #ff5f5f
INV="$(printf '\033[7m')"         # inverse (patch highlight)
# void lab accents (hollow vs generic)
HC="$(printf '\033[38;5;80m')"    # hollow accent    #5fd7d7
GC="$(printf '\033[38;5;213m')"   # generic accent   #ff87ff
