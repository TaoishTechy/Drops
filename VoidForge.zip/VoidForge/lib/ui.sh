#!/usr/bin/env bash
# lib/ui.sh — ANSI ui primitives: frames, menus, prompts, gauges, effects
# Part of VOIDFORGE BBS v2.0.0 VOID (sourced by voidforge.sh)

ui_clear()   { [ "$AF_TTY" -eq 1 ] && printf '\033[0;48;5;16m\033[2J\033[H' || printf '\n'; }
ui_home()    { printf '\033[H'; }
chime()      { [ "$AF_FLAIR" -eq 1 ] && printf '\a' || true; }
sleepx()     { local t="$1"; [ "$AF_SPEED" -eq 0 ] && t=$(awk "BEGIN{print $t*0.15}"); [ "$AF_FLAIR" -eq 1 ] && sleep "$t" || true; }

center() {  # center <text...> — visually centered on AF_COLS (ANSI-safe)
  local plain len pad
  plain="$(printf '%b' "$*" | sed 's/\033\[[0-9;]*m//g')"
  len="${#plain}"
  pad=$(( (AF_COLS - len) / 2 )); (( pad < 0 )) && pad=0
  printf '%*s%s\n' "$pad" "" "$*"
}

type_line() {  # typing effect, one line
  local line="$1" i c delay
  if [ "$AF_FLAIR" -eq 0 ]; then printf '%s\n' "$line"; return; fi
  delay="0.006"
  for ((i=0; i<${#line}; i++)); do
    printf '%s' "${line:i:1}"
    sleep "$delay" 2>/dev/null
  done
  printf '\n'
}

repeat_char() { local c="$1" n="$2" out="" i; for ((i=0;i<n;i++)); do out+="$c"; done; printf '%s' "$out"; }

bar() {  # bar <value 0..1> <width> <fill_color> -> filled gauge
  local v="$1" w="$2" col="${3:-$CY}" filled empty
  filled="$(awk "BEGIN{printf \"%d\", ($v+0)*$w}")" || filled=0
  filled="${filled:-0}"; (( filled < 0 )) && filled=0; (( filled > w )) && filled=$w
  empty=$(( w - filled ))
  printf '%s%s%s%s' "$col" "$(repeat_char '█' "$filled")" "$(printf '\033[38;5;240m')" "$(repeat_char '░' "$empty")"
}

frame_open() {  # frame_open <title> <accent>
  local title="$1" acc="${2:-$CY}" pad w
  w=$(( AF_COLS - 4 ))
  pad=$(( (w - ${#title} - 2) / 2 )); (( pad < 0 )) && pad=0
  printf '%s╔%s╗\n' "$acc" "$(repeat_char '═' "$w")"
  printf '%s║%s%s%s %s%s%s %s║%s\n' "$acc" "$R" "$(repeat_char ' ' "$pad")" "$B$WH" "$title" "$R" "$acc" "$R" "$acc"
}
frame_close() { local acc="${1:-$CY}"; printf '%s╚%s╝%s\n' "$acc" "$(repeat_char '═' $(( AF_COLS - 4 )))" "$R"; }
hr() { local acc="${1:-$MGD}"; printf '%s%s%s\n' "$acc" "$(repeat_char '─' "$AF_COLS")" "$R"; }

wrap() {  # wrap <width> ; reads stdin, emits wrapped
  local w="$1"; fold -s -w "$w" 2>/dev/null || cat
}

menu() {  # menu <title> <accent> then items as "key|label" ... ; prints box
  local title="$1" acc="$2"; shift 2
  local items=("$@") key label
  frame_open "$title" "$acc"
  for it in "${items[@]}"; do
    key="${it%%|*}"; label="${it#*|}"
    printf '%s║%s  %s%s%s %s%s%s %s║%s\n' "$acc" "$R" "$B$MG" "$key" "$R" "$WH" "$label" "$R" "$acc" "$R"
  done
  frame_close "$acc"
}

say_line() { printf '%s%s%s\n' "$1" "$2" "$R"; }

ask() {  # ask <prompt> <default> ; echoes reply (default on EOF/empty)
  local prompt="$1" def="${2:-}" reply
  if [ "$AF_TTY" -eq 0 ]; then
    if read -r reply; then [ -n "$reply" ] && printf '%s' "$reply" || printf '%s' "$def"
    else printf '%s' "$def"; fi
    return
  fi
  # prompt goes to STDERR: callers capture stdout via $(), so printing the
  # prompt there would pollute the captured value (and hide it from the user).
  printf '%s? %s%s%s %s[%s]%s: ' "$CY" "$B$WH" "$prompt" "$R" "$DM" "$def" "$R" >&2
  if read -r reply; then [ -n "$reply" ] && printf '%s' "$reply" || printf '%s' "$def"
  else printf '%s' "$def"; fi
}

press_any() {  # pause; never hangs on EOF
  local msg="${1:-press [enter] to continue}"
  [ "$AF_TTY" -eq 1 ] && { printf '%s· %s%s%s' "$DM" "$GY" "$msg" "$R"; read -r _ || true; printf '\r\033[K'; } || { read -r _ || true; }
}

spinner_start() {
  [ "$AF_FLAIR" -eq 0 ] && { printf '  %s… %s\n' "$CY" "$1"; return; }
  ( local i=0 sp=("⠋" "⠙" "⠹" "⠸" "⠼" "⠴" "⠦" "⠧" "⠇" "⠏")
    while :; do printf '\r  %s%s %s%s' "$CY" "${sp[$((i % 10))]}" "$1" "$R"; i=$((i+1)); sleep 0.07; done ) &
  SPIN_PID=$!
}
spinner_stop() {
  [ -n "${SPIN_PID:-}" ] && kill "$SPIN_PID" 2>/dev/null
  wait "${SPIN_PID:-}" 2>/dev/null
  SPIN_PID=""
  printf '\r\033[K'
}

pager() {  # pager <file> <title> <accent> [lines_per_page]
  local file="$1" title="$2" acc="${3:-$CY}" pl="${4:-$((AF_ROWS - 9))}"
  [ -f "$file" ] || { say_line "$RD" "missing: $file"; press_any; return; }
  local total page=1 buf
  total="$(( ($(wc -l < "$file") + pl - 1) / pl ))"
  while :; do
    ui_clear
    frame_open "$title  ·  page $page/$total" "$acc"
    buf="$(sed -n "$(( (page-1)*pl + 1 )),$(( page*pl ))p" "$file" | wrap $(( AF_COLS - 8 )))"
    printf '%s\n' "$buf" | while IFS= read -r ln; do
      printf '%s║%s %s\n' "$acc" "$R" "$GY$ln$R"
    done
    frame_close "$acc"
    printf '%s[n]ext %s[p]%srev %s[q]%suit %s> %s' "$MG" "$R$MG" "$R" "$MG" "$R" "$B$WH" "$R"
    read -r _key || _key="q"
    case "$_key" in
      n|"") (( page < total )) && page=$((page+1)) || break ;;
      p|b) (( page > 1 )) && page=$((page-1)) ;;
      q|Q|x) break ;;
    esac
  done
}
