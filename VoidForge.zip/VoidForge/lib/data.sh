#!/usr/bin/env bash
# lib/data.sh — shared persistence: session save + vault import
# Part of VOIDFORGE BBS v2.0.0 VOID (sourced by voidforge.sh)

vault_import_session() {  # vault_import_session <session.json> [seedlabel]
  local src="$1" label="${2:-}" n
  py - "$src" "$AF_VAULTF" "$label" <<'PYEOF'
import json, sys, os, time
src, dst, label = sys.argv[1], sys.argv[2], sys.argv[3]
try:
    d = json.load(open(src))
except Exception:
    sys.exit(1)
lines = []
t = int(time.time())
for i, r in enumerate(d.get("results", [])):
    rec = {"id": f"AX{t}{i:03d}", "savedAt": t, "handle": os.environ.get("AF_HANDLE", "GUEST"),
           "seed": label or r.get("seed_concept", ""), "axiom": r}
    lines.append(json.dumps(rec, ensure_ascii=False))
if lines:
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    with open(dst, "a") as f:
        f.write("\n".join(lines) + "\n")
print(len(lines))
PYEOF
}

vault_add_current() {  # archive current session axioms
  vault_import_session "$AF_TMP/session.json" "$AF_SEED" >/dev/null && \
    say_line "$GR" "archived to vault" || say_line "$RD" "vault import failed"
  press_any
}

new_session_path() {  # collision-safe session path (same-second saves)
  local f="$AF_SESS/session_$(stamp_id).json" n=1
  while [ -e "$f" ]; do n=$((n+1)); f="$AF_SESS/session_$(stamp_id)_$n.json"; done
  printf '%s' "$f"
}

save_session() {  # save_session <rng> — persist + optional vault
  local rng="${1:--}" name f
  name="session_$(stamp_id).json"
  f="$(new_session_path)"
  py - "$AF_TMP/session.json" "$f" "$rng" "$AF_SEED" "$CFG_TONE" "$(engine_label)" "$CFG_ONTOLOGY" <<'PYEOF'
import json, sys
src, dst, rng, seed, tone, eng, onto = sys.argv[1:8]
d = json.load(open(src))
d.setdefault("session", {})
d["session"]["rng"] = rng
d["session"]["seedPrompt"] = seed
d["session"]["params"] = {"tone": tone, "engine": eng, "count": len(d.get("results", [])),
                          "ontology": onto}
json.dump(d, open(dst, "w"), ensure_ascii=False, indent=2)
print(dst)
PYEOF
  say_line "$GR" "session → data/sessions/$name"
  local a; a="$(ask 'archive all to VAULT? y/n' 'n')"
  case "$a" in y*|Y*) vault_import_session "$f" ;; esac
  press_any
}

AF_SEED=""
AF_RNG=""
AF_RNG_SET=0
