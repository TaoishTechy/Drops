Recorded Axioms
