#!/usr/bin/env python3
# voidforge_5.0.0.py
# VoidForge v5.0.0 VOID — hollow / generic / dual ontologies over AxiomForge v0.4.7
#
# Upgrades the v0.4.7 pipeline by absorbing THE HOLLOW (algebraic topology of
# shaped absence) and THE GENERIC (set-theoretic forcing) as first-class
# ontological modes, without breaking any v0.4.7 behaviour:
#
#   * --ontology {classic|hollow|generic|dual|legacy}
#       classic — byte-parity port of the v0.4.7 loop (modulo the documented
#                 UTC timestamp fix; --legacy-timestamps restores utcnow()).
#       legacy  — wraps axiomforge_0.3.7.py untouched.
#       hollow  — shaped-absence readings from banks/hollow_bank.json
#                 (CW attachment, Betti spectra, cohomology, knots, torsion).
#       generic — forced-extension readings from banks/generic_bank.json
#                 (posets, generic filters, large cardinals, multiverse).
#       dual    — one seed -> two readings -> one translation table drawn
#                 from banks/duality_map.json, scored by duality_resonance.
#   * Void metrics (declarative in banks/void_metrics.json):
#       hollow_index, forcing_index, void_coherence, duality_resonance,
#       void_score  — appended to metrics; 0.0 in classic mode (schema stays
#       stable per the v0.4.7 "Eval-ready JSON schema stability" rule).
#   * Ontology-aware sanitizers: LaTeX stripped from axiom_text only, raw
#     LaTeX preserved in equation_tex / mechanism_tex; placeholder
#     kill-switch extended with [HOLLOW] / [GENERIC] / [DUAL].
#   * Validators: ontology-type coherence (temporal x hollow rejected unless
#     --allow-temporal-hollow), hollow sanity, generic sanity, per-reading
#     batch uniqueness in dual mode.
#   * Every v0.4.7 CLI flag remains verbatim; legacy 0.3.7 untouched.
#
# Ethics: see ETHICS.md §VoidForge Addendum. The mathematics is metaphor,
# not physics or metaphysics. Disclose ontology mode + RNG seed when publishing.

import argparse
import json
import math
import random
import re
import subprocess
import sys
import zlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

HERE = Path(__file__).resolve().parent

# Import the v0.4.7 engine as a library — classic mode calls its builders
# directly so parity is guaranteed by construction, not by wishful thinking.
import importlib.util


def _load_047():
    p = HERE / "axiomforge_0.4.7.py"
    if not p.exists():
        print("FATAL: voidforge_5.0.0.py requires axiomforge_0.4.7.py "
              "alongside it (classic parity baseline).", file=sys.stderr)
        sys.exit(1)
    spec = importlib.util.spec_from_file_location("_af047", str(p))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


_af047 = _load_047()

VERSION = "5.0.0_VOID"
ENGINE_NAME = "voidforge_5.0.0"

ONTOLOGIES = ("classic", "hollow", "generic", "dual", "legacy")
HOLLOW_LEVELS = ("cw", "betti", "cohomology", "homotopy")
FORCING_LEVELS = ("poset", "boolean", "cardinal", "multiverse")

HOLLOW_FAMILY_ORDER = ("primordial", "betti", "algebraic", "geometric",
                       "reflexive", "surgical")
GENERIC_FAMILY_ORDER = ("poset", "relation", "boolean", "cardinal",
                        "preservation", "iteration", "axiomatic", "geology")

HOLLOW_LEVEL_FAMILY = {"cw": "primordial", "betti": "betti",
                       "cohomology": "algebraic", "homotopy": "reflexive"}
FORCING_LEVEL_FAMILY = {"poset": "poset", "boolean": "boolean",
                        "cardinal": "cardinal", "multiverse": "iteration"}

# §9.2 type x ontology legality matrix (+ dual = v0.4.7 types + both new).
LEGAL_TYPES: Dict[str, set] = {
    "classic": set(_af047.DEF_PARADOX_TYPES),
    "hollow": {"hollow", "entropic", "linguistic", "metaphysical", "cosmic"},
    "generic": {"generic", "temporal", "cosmic", "Causal Loop",
                "metaphysical", "linguistic"},
    "dual": {"hollow", "generic", "entropic", "temporal", "cosmic",
             "metaphysical", "linguistic", "Causal Loop"},
    "legacy": set(_af047.DEF_PARADOX_TYPES) | {"field-fixed-point"},
}


class TypeOntologyError(ValueError):
    """Raised for illegal type x ontology pairs (§4.3 / §9.2)."""


# ------------------------------- Bank loading ------------------------------#

def resolve_bank(root: Path, name: str) -> Optional[Path]:
    """Bank resolver: banks/ first, then repo root (§2)."""
    for cand in (root / "banks" / name, root / name):
        if cand.exists():
            return cand
    return None


def load_json_relaxed(path: Optional[Path]) -> Dict[str, Any]:
    if path is None:
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def load_void_banks(root: Path) -> Dict[str, Any]:
    hb = load_json_relaxed(resolve_bank(root, "hollow_bank.json"))
    gb = load_json_relaxed(resolve_bank(root, "generic_bank.json"))
    dm = load_json_relaxed(resolve_bank(root, "duality_map.json"))
    vm = load_json_relaxed(resolve_bank(root, "void_metrics.json"))
    missing = [n for n, d in (("hollow_bank.json", hb), ("generic_bank.json", gb),
                              ("duality_map.json", dm),
                              ("void_metrics.json", vm)) if not d]
    if missing:
        print("FATAL: void banks missing or invalid: " + ", ".join(missing),
              file=sys.stderr)
        sys.exit(1)
    return {"hollow": hb, "generic": gb, "duality": dm, "metrics": vm}


# ------------------------- LaTeX -> display pretty -------------------------#

_LATEX_MAP: List[Tuple[str, str]] = [
    ("\\left", ""), ("\\right", ""),
    ("\\mathbb{P}", "ℙ"), ("\\mathbb{B}", "B"), ("\\mathbb{Z}", "ℤ"),
    ("\\mathbb{R}", "ℝ"), ("\\mathbb{Q}", "ℚ"), ("\\mathbb{N}", "ℕ"),
    ("\\mathcal{F}", "ℱ"),
    ("\\mathrm{Nat}", "Nat"), ("\\mathrm{Hom}", "Hom"),
    ("\\mathrm{crit}", "crit"), ("\\mathrm{Ho}", "Ho"),
    ("\\mathbf{Top}", "Top"), ("\\mathbf{Grpd}", "Grpd"),
    ("\\text{-}", "-"), ("\\text{", ""),
    ("\\infty", "∞"),
    ("\\Vdash", "⊩"), ("\\models", "⊨"), ("\\simeq", "≃"), ("\\cong", "≅"),
    ("\\subseteq", "⊆"), ("\\sqcup", "⊔"), ("\\emptyset", "∅"),
    ("\\oplus", "⊕"), ("\\times", "×"),
    ("\\varphi", "φ"), ("\\psi", "ψ"),
    ("\\kappa", "κ"), ("\\lambda", "λ"), ("\\chi", "χ"),
    ("\\alpha", "α"), ("\\beta", "β"),
    ("\\partial", "∂"), ("\\Gamma", "Γ"),
    ("\\sum", "∑"), ("\\prod", "∏"),
    ("\\Box", "□"), ("\\Diamond", "◇"),
    ("\\neg", "¬"), ("\\land", "∧"), ("\\lor", "∨"),
    ("\\iff", "⇔"), ("\\Rightarrow", "⇒"), ("\\rightarrow", "→"),
    ("\\forall", "∀"), ("\\exists", "∃"),
    ("\\cup", "∪"), ("\\cap", "∩"),
    ("\\neq", "≠"), ("\\in", "∈"),
    ("\\to", "→"), ("\\mapsto", "↦"),
    ("\\pi", "π"),
    ("\\tilde{X}", "X̃"),
    ("\\{", "{"), ("\\}", "}"),
    ("\\|", "‖"), ("\\,", " "), ("\\ ", " "), ("~", " "),
    ("\\cdots", "⋯"), ("\\dots", "…"), ("\\pm", "±"),
]


def latex_pretty(tex: str) -> str:
    s = tex
    for a, b in _LATEX_MAP:
        if a in s:
            s = s.replace(a, b)
    s = re.sub(r"\^\{([^{}]+)\}", lambda m: "^(" + m.group(1) + ")", s)
    s = re.sub(r"_\{([^{}]+)\}", lambda m: "_" + m.group(1), s)
    s = s.replace("$", "")
    return re.sub(r"\s+", " ", s).strip()


# --------------------------- v5 sanitizers (§12) ---------------------------#

VOID_PLACEHOLDER_RE = re.compile(
    r"\[(CORE_STATEMENT|MECHANISMS|MATH|CONSEQUENCES|SEED|TYPE|HOLLOW|GENERIC|"
    r"DUAL)\]", re.I)


def sanitize_void_text(text: str) -> str:
    """Strip LaTeX fragments + placeholders from axiom_text only (§12.2)."""
    text = text.replace("$", " ")
    text = text.replace("\\left", "").replace("\\right", "")
    text = re.sub(r"\\text\{([^{}]*)\}", r"\1", text)
    text = re.sub(r"\\mathrm\{([^{}]*)\}", r"\1", text)
    text = VOID_PLACEHOLDER_RE.sub("", text)
    return _af047.sanitize_text(text)


# ------------------------------ Time helpers -------------------------------#

def utc_ts() -> str:
    """README §Determinism & Time fix: aware UTC, seconds precision, Z."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds") \
        .replace("+00:00", "Z")


def legacy_ts() -> str:
    return datetime.utcnow().isoformat(timespec="seconds") + "Z"


# ------------------------------ Seed helpers -------------------------------#

def pick_motif(seed: str, banks: Dict[str, Any], rng: random.Random) -> str:
    clean = re.sub(r"^(the|a|an)\s+", "", seed.strip(), flags=re.I)
    words = [w for w in re.findall(r"[A-Za-z][A-Za-z'\-]+", clean)
             if len(w) > 3]
    if 0 < len(clean.split()) <= 3 and clean:
        return clean.lower()
    if words:
        words.sort(key=len, reverse=True)
        return rng.choice(words[:2]).lower()
    concepts = banks.get("concepts", [])
    if concepts:
        stok = _af047.expand(_af047.tokens_of(seed))
        best = sorted(concepts,
                      key=lambda c: -_af047.cosine(stok, _af047.tokens_of(c)))
        return rng.choice(best[:4]).lower()
    return rng.choice(["the absent centre", "the unnamed cavity",
                       "the open boundary"])


def ontology_suffix(seed: str, suffixes: Dict[str, Any],
                    rng: random.Random) -> str:
    sl = seed.lower()
    key = "default"
    if "dark forest" in sl or "forest" in sl:
        key = "Dark Forest"
    elif "nested" in sl or "reality" in sl:
        key = "Nested Realities"
    elif "silent god" in sl or ("silent" in sl and "god" in sl):
        key = "The Silent God"
    opts = suffixes.get(key) or suffixes.get("default") or []
    return rng.choice(opts) if opts else ""


def mech_str_of(mechs: List[str]) -> str:
    return ", ".join(mechs[:3]) + ("…" if len(mechs) > 3 else "")


# ------------------------- Mechanism selection -----------------------------#

def family_map(bank_mechs: Dict[str, List[str]]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for fam, lst in bank_mechs.items():
        for m in lst:
            out[m] = fam
    return out


def pick_family_mechanisms(seed: str, fam_pref: str, fam_order: Tuple[str, ...],
                           bank_mechs: Dict[str, List[str]],
                           fam_of: Dict[str, str], rng: random.Random,
                           max_mech: int) -> List[str]:
    """Ontology-family mechanisms, seed-affinity scored, sublevel-biased."""
    pool: List[str] = []
    for fam in fam_order:
        pool.extend(bank_mechs.get(fam, []))
    if not pool:
        return []
    stok = _af047.expand(_af047.tokens_of(seed))
    scored: List[Tuple[float, str]] = []
    for m in pool:
        fam = fam_of.get(m, "")
        score = _af047.cosine(stok, _af047.tokens_of(m)) \
            + (1.5 if fam == fam_pref else 0.0) \
            + (0.6 if fam in fam_order[:2] else 0.0) \
            + rng.uniform(0.0, 0.12)
        scored.append((score, m))
    scored.sort(key=lambda sm: -sm[0])
    return [m for _, m in scored[:max(1, max_mech)]]


# --------------------------- Hollow triage (§7) ----------------------------#

HOLLOW_TRIAGE: List[Tuple[Tuple[str, ...], str]] = [
    (("torsion",), "m[c] = 0,\\ [c] \\neq 0"),
    (("cup product",), "\\alpha \\cup \\beta \\in H^{p+q}(X)"),
    (("cover",), "p: \\tilde{X} \\to X"),
    (("cobordism",), "\\partial W = X \\sqcup Y"),
    (("barcode", "persistent"), "K_0 \\subseteq K_1 \\subseteq \\cdots"),
    (("fundamental group",), "\\pi_1(X) = [S^1, X]"),
    (("surgery",), "X_{n+1} = X_n \\cup_f D^{n+1}"),
    (("sheaf",), "H^k(X, \\mathcal{F}) = R^k \\Gamma(X, \\mathcal{F})"),
    (("yoneda",), "\\mathrm{Nat}(\\mathrm{Hom}(-, X), F) \\cong F(X)"),
    (("homotopy hypothesis", "groupoid"),
     "\\mathrm{Ho}(\\mathbf{Top}) \\simeq \\mathrm{Ho}(\\infty\\text{-}\\mathbf{Grpd})"),
]

GENERIC_TRIAGE: List[Tuple[Tuple[str, ...], str]] = [
    (("ultrafilter", "boolean"), "\\|\\varphi\\| \\in \\mathbb{B}"),
    (("elementary embedding",), "j: V \\to M"),
    (("critical point",), "\\kappa = \\mathrm{crit}(j)"),
    (("supercompact",), "M^\\lambda \\subseteq M"),
    (("reinhardt",), "j: V \\to V"),
    (("iterated", "multiverse", "iteration"),
     "V \\to V[G_1] \\to V[G_1][G_2] \\to \\cdots"),
    (("forcing axiom", "martin", "pfa"),
     "V \\to V[G_1] \\to V[G_1][G_2] \\to \\cdots"),
    (("dense", "filter", "generic"),
     "G \\cap D \\neq \\emptyset"),
    (("name", "truth lemma", "relation"), "p \\Vdash \\varphi"),
    (("levy", "collapse"), "G \\cap D \\neq \\emptyset"),
]


def triage_equation(mechs: List[str], seed: str, triage, tag_pool: List[str],
                    full_pool: List[str], rng: random.Random) -> str:
    joined = " ".join(mechs).lower() + " " + seed.lower()
    for keys, eq in triage:
        if any(k in joined for k in keys):
            return eq
    if tag_pool:
        return rng.choice(tag_pool)
    return rng.choice(full_pool)


# --------------------------- Reading builders ------------------------------#

def build_hollow_reading(seed: str, hb: Dict[str, Any], dm: Dict[str, Any],
                         banks: Dict[str, Any], rng: random.Random,
                         level: str, max_mech: int,
                         pair_idx: int) -> Dict[str, Any]:
    fam_pref = HOLLOW_LEVEL_FAMILY.get(level, "algebraic")
    fam_of = family_map(hb.get("mechanisms", {}))
    mechs = pick_family_mechanisms(seed, fam_pref, HOLLOW_FAMILY_ORDER,
                                   hb.get("mechanisms", {}), fam_of, rng,
                                   max_mech)
    if not mechs:
        mechs = ["Cell Attachment"]
    motif = pick_motif(seed, banks, rng)
    tmpls = hb.get("core_templates", {}).get("hollow") or \
        ["The hollow remembers only its holes: {motif}."]
    core = rng.choice(tmpls).replace("{motif}", motif)
    eq_pool = hb.get("equations", {}).get("hollow", [])
    eq_tags = hb.get("equation_tags", {}).get(level, [])
    eq_tex = triage_equation(mechs, seed, HOLLOW_TRIAGE, eq_tags, eq_pool, rng)
    cons_pool = hb.get("consequences", {}).get("hollow") or \
        ["absence acquires rim"]
    cons = rng.choice(cons_pool)
    betti = [rng.choice([0, 1, 1, 2]), rng.choice([1, 1, 2, 2, 3]),
             rng.choice([0, 1, 1, 2])]
    pg = rng.choice(hb.get("group_hints") or ["Z"])
    scaffold_pairs = dm.get("scaffold_pairs") or [{"hollow": "We hollow.",
                                                   "generic": "We force."}]
    pair = scaffold_pairs[pair_idx % len(scaffold_pairs)]
    return {
        "core_statement": core,
        "mechanisms": mechs,
        "equation": eq_tex,
        "consequences": cons,
        "hollow_level": level,
        "betti_spectrum": betti,
        "fundamental_group_hint": pg,
        "scaffold": pair.get("hollow", "We hollow."),
        "_equation_ui": latex_pretty(eq_tex),
    }


def build_generic_reading(seed: str, gb: Dict[str, Any], dm: Dict[str, Any],
                          banks: Dict[str, Any], rng: random.Random,
                          level: str, max_mech: int,
                          pair_idx: int) -> Dict[str, Any]:
    fam_pref = FORCING_LEVEL_FAMILY.get(level, "poset")
    fam_of = family_map(gb.get("mechanisms", {}))
    mechs = pick_family_mechanisms(seed, fam_pref, GENERIC_FAMILY_ORDER,
                                   gb.get("mechanisms", {}), fam_of, rng,
                                   max_mech)
    if not mechs:
        mechs = ["Generic Filter Selection"]
    motif = pick_motif(seed, banks, rng)
    tmpls = gb.get("core_templates", {}).get("generic") or \
        ["The ground model believes it is everything; {motif} proves otherwise."]
    core = rng.choice(tmpls).replace("{motif}", motif)
    eq_pool = gb.get("equations", {}).get("generic", [])
    eq_tags = gb.get("equation_tags", {}).get(level, [])
    eq_tex = triage_equation(mechs, seed, GENERIC_TRIAGE, eq_tags, eq_pool, rng)
    cons_pool = gb.get("consequences", {}).get("generic") or \
        ["the ground model is not the universe"]
    cons = rng.choice(cons_pool)
    scaffold_pairs = dm.get("scaffold_pairs") or [{"hollow": "We hollow.",
                                                   "generic": "We force."}]
    pair = scaffold_pairs[pair_idx % len(scaffold_pairs)]
    return {
        "core_statement": core,
        "mechanisms": mechs,
        "equation": eq_tex,
        "consequences": cons,
        "forcing_level": level,
        "forcing_relation": rng.choice(
            gb.get("forcing_relations") or ["p \\Vdash \\varphi"]),
        "extension_hint": rng.choice(
            gb.get("extension_hints") or ["V[G] ⊋ V"]),
        "scaffold": pair.get("generic", "It forces, therefore we extend."),
        "_equation_ui": latex_pretty(eq_tex),
    }


# ------------------------------ Validators (§11) ---------------------------#

def validate_hollow_reading(r: Dict[str, Any],
                            hb: Dict[str, Any] = None) -> None:
    for b in r.get("betti_spectrum", []):
        if not isinstance(b, int) or b < 0:
            raise ValueError("hollow sanity: Betti numbers must be "
                             "non-negative integers")
    if not r.get("fundamental_group_hint"):
        raise ValueError("hollow sanity: pi_1(X) must be accompanied by a "
                         "group hint")
    if "V = V" in r.get("equation", ""):
        raise ValueError("hollow sanity: degenerate identity rejected")
    if hb:
        valid = set()
        for lst in hb.get("mechanisms", {}).values():
            valid.update(lst)
        for m in r.get("mechanisms", []):
            if valid and m not in valid:
                raise ValueError(f"hollow sanity: mechanism '{m}' is outside "
                                 f"the hollow pool (pool hygiene, §6)")


def validate_generic_reading(r: Dict[str, Any],
                             gb: Dict[str, Any] = None) -> None:
    eq = r.get("equation", "")
    if re.search(r"\bV\s*=\s*V\b", eq):
        raise ValueError("generic sanity: 'V = V' rejected — the whole point "
                         "of forcing is that V ≠ V[G]")
    if "crit(j)" in eq:
        joined = " ".join(r.get("mechanisms", [])).lower()
        if "embedding" not in joined:
            raise ValueError("generic sanity: kappa = crit(j) requires an "
                             "elementary embedding mechanism")
    if gb:
        valid = set()
        for lst in gb.get("mechanisms", {}).values():
            valid.update(lst)
        for m in r.get("mechanisms", []):
            if valid and m not in valid:
                raise ValueError(f"generic sanity: mechanism '{m}' is outside "
                                 f"the forcing pool (pool hygiene, §6)")


# ---------------------------- Void metrics (§10) ---------------------------#

def void_metric_set(hollow_reading: Optional[Dict[str, Any]],
                    generic_reading: Optional[Dict[str, Any]],
                    mechs: List[str], equation_tex: str,
                    alienness: float, vm: Dict[str, Any]) -> Dict[str, float]:
    cap = int(vm.get("index_cap", 10) or 10)
    h_lex = set(vm.get("hollow_tokens", []))
    g_lex = set(vm.get("generic_tokens", []))
    blob = (" ".join(mechs) + " " + equation_tex).lower()
    hI = min(1.0, sum(1 for t in h_lex if t in blob) / max(1, cap))
    fI = min(1.0, sum(1 for t in g_lex if t in blob) / max(1, cap))
    vc = _af047.cosine(_af047.tokens_of(" ".join(mechs)),
                       _af047.tokens_of(equation_tex))
    if hollow_reading and generic_reading:
        cos_cores = _af047.cosine(
            _af047.tokens_of(hollow_reading["core_statement"]),
            _af047.tokens_of(generic_reading["core_statement"]))
        dr = 1.0 - abs(hI - fI) * (1.0 - cos_cores)
    else:
        dr = 0.0
    dr = min(1.0, max(0.0, dr))
    anorm = min(1.0, max(0.0, alienness / 12.0))
    w = vm.get("weights", {})
    vs = (w.get("alienness_norm", 0.35) * anorm
          + w.get("void_coherence", 0.25) * vc
          + w.get("duality_resonance", 0.20) * dr
          + w.get("index_balance", 0.20) * (hI + fI) / 2.0)
    return {
        "hollow_index": round(hI, 3),
        "forcing_index": round(fI, 3),
        "void_coherence": round(min(1.0, max(0.0, vc)), 3),
        "duality_resonance": round(dr, 3),
        "void_score": round(min(1.0, max(0.0, vs)), 3),
    }


# ------------------------- Type x ontology routing -------------------------#

def pick_type_v5(seed: str, ontology: str, rng: random.Random) -> str:
    s = seed.lower()
    bias: List[str] = []
    if ontology in ("hollow", "dual") and any(
            k in s for k in ("hole", "hollow", "void", "absen", "cavity",
                             "tunnel", "topolog", "knot", "torus", "betti")):
        bias.append("hollow")
    if ontology in ("generic", "dual") and any(
            k in s for k in ("force", "ground", "filter", "extension",
                             "cardinal", "universe", "multiverse", "model")):
        bias.append("generic")
    if any(k in s for k in ("loop", "recurrence", "prediction", "grandfather")):
        bias.append("Causal Loop")
    if any(k in s for k in ("time", "temporal", "future", "past", "echo")):
        bias.append("temporal")
    if any(k in s for k in ("truth", "liar", "language", "sentence",
                            "self-ref")):
        bias.append("linguistic")
    if any(k in s for k in ("god", "observer", "attention", "consciousness",
                            "mind", "silent")):
        bias.append("metaphysical")
    if any(k in s for k in ("curvature", "cosmic", "horizon", "holograph",
                            "boundary", "forest", "dark", "nested")):
        bias.append("cosmic")
    if any(k in s for k in ("entropy", "decay", "collapse", "order")):
        bias.append("entropic")
    allowed = [b for b in dict.fromkeys(bias) if b in LEGAL_TYPES[ontology]]
    if allowed:
        return rng.choice(allowed)
    pool = sorted(LEGAL_TYPES[ontology])
    return rng.choice(pool)


def check_type_ontology(ontology: str, ptype: str,
                        allow_temporal_hollow: bool) -> None:
    if ontology == "hollow" and ptype == "temporal":
        if allow_temporal_hollow:
            return  # opt-in: simplicial-filtration reading of time
        raise TypeOntologyError(
            "temporal x hollow is rejected by default — forcing is the "
            "natural pairing. Use --ontology generic for temporal content, "
            "or pass --allow-temporal-hollow to opt in (simplicial "
            "filtration reads time as a filtration of complexes).")
    if ptype not in LEGAL_TYPES[ontology]:
        redirect = ""
        if ptype == "hollow" and ontology != "hollow":
            redirect = " Try --ontology hollow."
        elif ptype == "generic" and ontology != "generic":
            redirect = " Try --ontology generic."
        elif ptype == "temporal" and ontology == "hollow":
            redirect = " Try --ontology generic or --allow-temporal-hollow."
        raise TypeOntologyError(
            f"paradox type '{ptype}' is not legal under --ontology "
            f"{ontology} (allowed: {', '.join(sorted(LEGAL_TYPES[ontology]))})."
            + redirect)


# --------------------------- Emission assembly -----------------------------#

def _public_reading(r: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if r is None:
        return None
    return {k: v for k, v in r.items() if not k.startswith("_")}


def assemble_entry(core: str, mechs: List[str], eq_tex: str, cons: str,
                   axiom_text: str, ptype: str, seed: str, ontology: str,
                   vm: Dict[str, Any], h: Optional[Dict[str, Any]],
                   g: Optional[Dict[str, Any]], dmap: Optional[Dict[str, Any]],
                   tone_scaffold: Optional[str]) -> Dict[str, Any]:
    alignment = _af047.alignment_score(seed, mechs)
    base = _af047.compute_metrics(core, mechs, ptype, seed, alignment)
    voidm = void_metric_set(h, g, mechs, eq_tex,
                            float(base.get("alienness", 0.0)), vm)
    base.update(voidm)
    fb = base.setdefault("fidelity_breakdown", {})
    fb["ontology_alignment"] = 1.0
    entry: Dict[str, Any] = {
        "core_statement": core,
        "mechanisms": list(mechs),
        "equation": latex_pretty(eq_tex),
        "consequences": cons,
        "axiom_text": axiom_text,
        "paradox_type": ptype,
        "seed_concept": seed,
        "timestamp": utc_ts(),
        "metrics": base,
        "pillars": [seed],
    }
    if tone_scaffold is not None:
        entry["humanized_injection_scaffold"] = tone_scaffold
        entry["injection_scaffold"] = tone_scaffold
    entry["ontology"] = ontology
    entry["equation_tex"] = eq_tex
    entry["mechanism_tex"] = list(mechs)
    entry["hollow_reading"] = _public_reading(h)
    entry["generic_reading"] = _public_reading(g)
    entry["duality_map"] = dmap
    return entry


def build_void_axiom(seed: str, ptype: str, ontology: str,
                     banks: Dict[str, Any], vb: Dict[str, Any],
                     args: argparse.Namespace,
                     rng: random.Random) -> Dict[str, Any]:
    hb, gb, dm, vm = vb["hollow"], vb["generic"], vb["duality"], vb["metrics"]
    max_mech = max(1, min(4, args.max_mech))
    n_pairs = max(1, len(dm.get("scaffold_pairs") or [1]))
    pair_idx = rng.randrange(n_pairs)
    if ontology == "hollow":
        h = build_hollow_reading(seed, hb, dm, banks, rng, args.hollow_level,
                                 max_mech, pair_idx)
        validate_hollow_reading(h, hb)
        g = None
        mechs = list(h["mechanisms"])
        eq_tex = h["equation"]
        cons = h["consequences"]
        suffix_bank = hb.get("suffixes", {})
    else:  # generic
        g = build_generic_reading(seed, gb, dm, banks, rng, args.forcing_level,
                                  max_mech, pair_idx)
        validate_generic_reading(g, gb)
        h = None
        mechs = list(g["mechanisms"])
        eq_tex = g["equation"]
        cons = g["consequences"]
        suffix_bank = gb.get("suffixes", {})
    core = sanitize_void_text(
        (h or g)["core_statement"])
    suffix = ontology_suffix(seed, suffix_bank, rng)
    text = (f"Consider: {core} — via {mech_str_of(mechs)}; "
            f"encoded as {latex_pretty(eq_tex)}; entails {cons}")
    if text.endswith("."):
        text = text[:-1]
    if suffix:
        text += " " + suffix
    axiom_text = sanitize_void_text(text)
    tone_scaffold = _af047.stylize_scaffold(args.tone, rng) \
        if args.emit_scaffold else None
    return assemble_entry(core, mechs, eq_tex, cons, axiom_text, ptype, seed,
                          ontology, vm, h, g, None, tone_scaffold)


def build_dual_axiom(seed: str, ptype: str, banks: Dict[str, Any],
                     vb: Dict[str, Any], args: argparse.Namespace,
                     rng: random.Random) -> Dict[str, Any]:
    hb, gb, dm, vm = vb["hollow"], vb["generic"], vb["duality"], vb["metrics"]
    max_mech = max(1, min(4, args.max_mech))
    scaffold_pairs = dm.get("scaffold_pairs") or [{}]
    n_pairs = max(1, len(scaffold_pairs))
    thr = float(vm.get("resonance_threshold", 0.55) or 0.55)
    attempts = 4 if args.strict_void else 1
    best: Optional[Tuple[float, float, Dict[str, Any], Dict[str, Any], int]] = None
    for _attempt in range(attempts):
        pair_idx = rng.randrange(n_pairs)
        h = build_hollow_reading(seed, hb, dm, banks, rng, args.hollow_level,
                                 max_mech, pair_idx)
        g = build_generic_reading(seed, gb, dm, banks, rng, args.forcing_level,
                                  max_mech, pair_idx)
        validate_hollow_reading(h, hb)
        validate_generic_reading(g, gb)
        joined = list(h["mechanisms"]) + [m for m in g["mechanisms"]
                                          if m not in h["mechanisms"]]
        pre = void_metric_set(h, g, joined, h["equation"], 6.0, vm)
        cand = (pre["void_coherence"], pre["duality_resonance"], h, g, pair_idx)
        if best is None or (cand[0] + cand[1]) > (best[0] + best[1]):
            best = cand
        if best[0] >= 0.5 and best[1] >= thr:
            break
    vc, _resonance, h, g, pair_idx = best
    mechs = list(h["mechanisms"])
    for m in g["mechanisms"]:
        if m not in mechs and len(mechs) < max_mech * 2:
            mechs.append(m)
    w = min(1.0, max(0.0, args.void_weight))
    if w >= 2.0 / 3.0:
        core = h["core_statement"]
    elif w <= 1.0 / 3.0:
        core = g["core_statement"]
    else:
        core = rng.choice(dm.get("duality_core_templates") or
                          ["Absence forces extension; extension hollows absence."])
    core = sanitize_void_text(core)
    # duality map block filtered to mechanisms actually used (§15.1)
    pairs = []
    for mp in dm.get("mechanism_pairs", []):
        if mp.get("hollow") in h["mechanisms"] \
                or mp.get("generic") in g["mechanisms"]:
            pairs.append({"hollow": mp["hollow"], "generic": mp["generic"]})
    if not pairs:
        pairs = [{"hollow": p.get("hollow", ""), "generic": p.get("generic", "")}
                 for p in (dm.get("pairs") or [])[:3]]
    pair = scaffold_pairs[pair_idx % n_pairs]
    dmap_block = {
        "pairs": pairs,
        "scaffold_pair": {"hollow": pair.get("hollow", ""),
                          "generic": pair.get("generic", "")},
        "note": rng.choice(dm.get("duality_notes") or
                           ["One void, two readings."]),
    }
    suffix = ontology_suffix(seed, hb.get("suffixes", {}), rng)
    text = (f"Consider: {core} — the hollow reads: {h['core_statement']}; "
            f"the forcing reads: {g['core_statement']}; "
            f"encoded as {latex_pretty(h['equation'])}. "
            f"({h['consequences']}; yet {g['consequences']}.)")
    if suffix:
        text += " " + suffix
    axiom_text = sanitize_void_text(text)
    cons = f"{h['consequences']} / {g['consequences']}"
    tone_scaffold = _af047.stylize_scaffold(args.tone, rng) \
        if args.emit_scaffold else None
    entry = assemble_entry(core, mechs, h["equation"], cons, axiom_text,
                           ptype, seed, "dual", vm, h, g,
                           dmap_block if args.emit_duality else None,
                           tone_scaffold)
    entry["metrics"]["void_coherence"] = round(
        min(1.0, max(0.0, vc)), 3)
    return entry


# ------------------------------- Runners -----------------------------------#

def collect_seeds(args: argparse.Namespace) -> List[str]:
    seeds: List[str] = []
    if args.seed:
        seeds.append(args.seed)
    if args.seedfile:
        try:
            for line in Path(args.seedfile).read_text(
                    encoding="utf-8").splitlines():
                s = line.strip()
                if s:
                    seeds.append(s)
        except FileNotFoundError:
            print(f"seedfile not found: {args.seedfile}", file=sys.stderr)
            sys.exit(2)
    return seeds


def add_v5_classic_schema(entry: Dict[str, Any]) -> None:
    m = entry.setdefault("metrics", {})
    for k, v in (("hollow_index", 0.0), ("forcing_index", 0.0),
                 ("void_coherence", 0.0), ("duality_resonance", 0.0),
                 ("void_score", 0.0)):
        m.setdefault(k, v)
    m.setdefault("fidelity_breakdown", {})["ontology_alignment"] = 1.0
    entry["ontology"] = "classic"
    entry["equation_tex"] = entry.get("equation", "")
    entry["mechanism_tex"] = []
    entry["hollow_reading"] = None
    entry["generic_reading"] = None
    entry["duality_map"] = None


def run_classic(args: argparse.Namespace) -> List[Dict[str, Any]]:
    """Port of the v0.4.7 main loop — parity guaranteed by construction."""
    root = Path(args.root)
    banks = _af047.load_banks(root)
    seeds = collect_seeds(args)
    results: List[Dict[str, Any]] = []
    seen: set = set()
    emitted = 0
    while emitted < args.count:
        seed = seeds[emitted % len(seeds)]
        ptype = _af047.pick_type(seed, random)
        entry = _af047.build_axiom(seed, ptype, banks, args.tone,
                                   max(1, args.max_mech), args.selfref_mode,
                                   args.emit_scaffold, args.transcend, random)
        key = entry["core_statement"].strip().lower()
        if key in seen and not args.allow_duplicates:
            ptype2 = random.choice(_af047.DEF_PARADOX_TYPES)
            entry = _af047.build_axiom(seed, ptype2, banks, args.tone,
                                       max(1, args.max_mech),
                                       args.selfref_mode, args.emit_scaffold,
                                       args.transcend, random)
            key = entry["core_statement"].strip().lower()
            if key in seen:
                entry["core_statement"] += " (reframed)"
        seen.add(key)
        entry["timestamp"] = legacy_ts() if args.legacy_timestamps else utc_ts()
        add_v5_classic_schema(entry)
        print("--- FINAL AXIOM ---")
        print(json.dumps(entry, ensure_ascii=False, indent=2))
        results.append(entry)
        emitted += 1
    return results


def run_void(args: argparse.Namespace) -> List[Dict[str, Any]]:
    root = Path(args.root)
    banks = _af047.load_banks(root)
    vb = load_void_banks(root)
    seeds = collect_seeds(args)
    results: List[Dict[str, Any]] = []
    seen_cores: set = set()
    seen_pairs: set = set()
    emitted = 0
    guard = 0
    while emitted < args.count:
        guard += 1
        if guard > args.count * 12 + 24:
            break
        seed = seeds[emitted % len(seeds)]
        ptype = args.paradox_type or pick_type_v5(seed, args.ontology, random)
        try:
            check_type_ontology(args.ontology, ptype,
                                args.allow_temporal_hollow)
        except TypeOntologyError as e:
            print(f"TypeOntologyError: {e}", file=sys.stderr)
            sys.exit(2)
        builder = (lambda s_, p_: build_dual_axiom(s_, p_, banks, vb, args,
                                                   random)) \
            if args.ontology == "dual" \
            else (lambda s_, p_: build_void_axiom(s_, p_, args.ontology,
                                                  banks, vb, args, random))
        entry = builder(seed, ptype)
        key = entry["core_statement"].strip().lower()
        if key in seen_cores and not args.allow_duplicates:
            entry = builder(seed, ptype)
            key = entry["core_statement"].strip().lower()
            if key in seen_cores:
                entry["core_statement"] += " (reframed)"
        seen_cores.add(key)
        if args.ontology == "dual":
            h_core = entry["hollow_reading"]["core_statement"]
            g_core = entry["generic_reading"]["core_statement"]
            hc = h_core.strip().lower()
            gc = g_core.strip().lower()
            pk = (hc, gc)
            if pk in seen_pairs and not args.allow_duplicates:
                continue
            # per-reading uniqueness (§11.7) — exempt the reading that the
            # void-weight collapse lifted into the fused core_statement
            if hc in seen_cores and hc != key:
                entry["hollow_reading"]["core_statement"] = h_core + " (reframed)"
            if gc in seen_cores and gc != key:
                entry["generic_reading"]["core_statement"] = g_core + " (reframed)"
            seen_pairs.add(pk)
            seen_cores.update({hc, gc})
        print("--- FINAL AXIOM ---")
        print(json.dumps(entry, ensure_ascii=False, indent=2))
        results.append(entry)
        emitted += 1
    return results


def run_legacy(args: argparse.Namespace) -> int:
    exe = HERE / "axiomforge_0.3.7.py"
    if not exe.exists():
        print("FATAL: --ontology legacy requires axiomforge_0.3.7.py "
              "alongside this engine.", file=sys.stderr)
        return 1
    cmd = [sys.executable, str(exe)]
    if args.seed:
        cmd += ["--seed", args.seed]
    if args.seedfile:
        cmd += ["--seedfile", args.seedfile]
    cmd += ["--count", str(max(1, args.count)), "--tone", args.tone,
            "--max-mech", str(max(1, args.max_mech)),
            "--selfref-mode", args.selfref_mode, "--allow-duplicates"]
    if args.rng is not None:
        cmd += ["--rng", str(args.rng)]
    if args.emit_scaffold:
        cmd += ["--emit-scaffold"]
    if args.out:
        proc = subprocess.run(cmd, capture_output=True, text=True)
        sys.stdout.write(proc.stdout)
        sys.stderr.write(proc.stderr)
        results = []
        for chunk in proc.stdout.split("--- FINAL AXIOM ---"):
            chunk = chunk.strip()
            if not chunk:
                continue
            try:
                results.append(json.loads(chunk))
            except Exception:
                m = re.search(r"\{.*\}", chunk, re.S)
                if m:
                    try:
                        results.append(json.loads(m.group(0)))
                    except Exception:
                        pass
        ts = utc_ts()
        payload = {"exportedAt": ts, "engine": "axiomforge_0.3.7",
                   "session": {"id": int(datetime.now(timezone.utc).timestamp()),
                               "name": "voidforge-legacy", "createdAt": ts,
                               "seedPrompt": args.seed or "",
                               "params": {"tone": args.tone, "rng": args.rng,
                                          "count": args.count}},
                   "results": results}
        Path(args.out).write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8")
        print(f"\nSaved session → {args.out}", file=sys.stderr)
        return proc.returncode
    return subprocess.run(cmd).returncode


# ------------------------------- Selftest ----------------------------------#

SELFTEST_KEY047 = ("core_statement", "mechanisms", "equation", "consequences",
                   "axiom_text", "paradox_type", "seed_concept", "pillars")
SELFTEST_METRIC_KEYS = ("novelty", "density", "entropic_potential", "elegance",
                        "alienness", "fidelity", "qualia_density")
SELFTEST_FB_KEYS = ("concept_alignment", "emotional_resonance",
                    "novelty_density_product", "archetypal_alignment")


def _sp(argv: List[str]) -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, str(HERE / "voidforge_5.0.0.py")]
                          + argv, capture_output=True, text=True, cwd=str(HERE))


def _sp047(argv: List[str]) -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, str(HERE / "axiomforge_0.4.7.py")]
                          + argv, capture_output=True, text=True, cwd=str(HERE))


def _parse_axioms(stdout: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for chunk in stdout.split("--- FINAL AXIOM ---"):
        chunk = chunk.strip()
        if not chunk:
            continue
        try:
            out.append(json.loads(chunk))
        except Exception:
            pass
    return out


def _parity_ok(a: Dict[str, Any], b: Dict[str, Any]) -> Tuple[bool, str]:
    for k in SELFTEST_KEY047:
        if a.get(k) != b.get(k):
            return False, f"field mismatch: {k}"
    ma, mb = a.get("metrics", {}), b.get("metrics", {})
    for k in SELFTEST_METRIC_KEYS:
        if ma.get(k) != mb.get(k):
            return False, f"metrics.{k} mismatch ({ma.get(k)} vs {mb.get(k)})"
    fa = ma.get("fidelity_breakdown", {})
    fb = mb.get("fidelity_breakdown", {})
    for k in SELFTEST_FB_KEYS:
        if fa.get(k) != fb.get(k):
            return False, f"fidelity_breakdown.{k} mismatch"
    return True, "identical on every v0.4.7 field"


def run_selftest() -> int:
    root = str(HERE)
    results: List[Tuple[bool, str, str]] = []

    def check(name: str, ok: bool, detail: str = "") -> None:
        results.append((ok, name, detail))

    # 1. bank integrity (§17.2)
    try:
        vb = load_void_banks(Path(root))
        hb, gb, dm, vm = vb["hollow"], vb["generic"], vb["duality"], vb["metrics"]
        n_h = sum(len(v) for v in hb.get("mechanisms", {}).values())
        n_g = sum(len(v) for v in gb.get("mechanisms", {}).values())
        ok = n_h >= 30 and n_g >= 40 and len(dm.get("pairs", [])) >= 16 \
            and len(dm.get("scaffold_pairs", [])) >= 9
        check("void banks load (hollow>=30 mechs, generic>=40, 16 pairs, "
              f"9 scaffold pairs) — got {n_h}/{n_g}/"
              f"{len(dm.get('pairs', []))}/{len(dm.get('scaffold_pairs', []))}",
              ok)
    except SystemExit:
        check("void banks load", False, "missing banks")

    # 2. classic parity vs 0.4.7 (§17.1)
    common = ["--seed", "Dark Forest Theory", "--count", "2", "--tone",
              "poetic", "--rng", "1337", "--emit-scaffold", "--root", root]
    r47 = _sp047(common)
    r5 = _sp(["--ontology", "classic"] + common)
    a47, a5 = _parse_axioms(r47.stdout), _parse_axioms(r5.stdout)
    if len(a47) == 2 and len(a5) == 2:
        ok, why = _parity_ok(a47[0], a5[0]) and _parity_ok(a47[1], a5[1]) \
            or (False, "second emission differs")
        if not ok:
            ok2, why2 = _parity_ok(a47[0], a5[0])
            ok = ok2 and _parity_ok(a47[1], a5[1])[0]
            why = why2 if not ok2 else _parity_ok(a47[1], a5[1])[1]
        check("classic parity with v0.4.7 (rng 1337)", ok, why)
    else:
        check("classic parity with v0.4.7 (rng 1337)", False,
              f"parsed {len(a47)}/{len(a5)} emissions")

    # 3. classic schema stability (§14)
    e = a5[0] if a5 else {}
    m = e.get("metrics", {})
    ok = e.get("ontology") == "classic" and e.get("hollow_reading", "x") is None \
        and e.get("generic_reading", "x") is None \
        and e.get("duality_map", "x") is None \
        and m.get("hollow_index") == 0.0 and m.get("void_score") == 0.0 \
        and e.get("equation_tex") == e.get("equation")
    check("classic schema stable (empty void fields + zero metrics)", ok)

    # 4. hollow mode
    r = _sp(["--ontology", "hollow", "--seed", "Nested Realities", "--count",
             "2", "--rng", "20250926", "--root", root])
    hs = _parse_axioms(r.stdout)
    h0 = hs[0] if hs else {}
    hr = h0.get("hollow_reading") or {}
    betti = hr.get("betti_spectrum", [])
    ok = (r.returncode == 0 and h0.get("ontology") == "hollow"
          and isinstance(betti, list) and len(betti) >= 3
          and all(isinstance(b, int) and b >= 0 for b in betti)
          and bool(hr.get("mechanisms"))
          and ("boundary" in h0.get("axiom_text", "")
               or "frame" in h0.get("axiom_text", "")))
    check("hollow mode: betti spectrum + seed-aware suffix "
          "(Nested Realities → boundary/frame)", ok)

    # 5. hollow level bias
    r = _sp(["--ontology", "hollow", "--hollow-level", "homotopy", "--seed",
             "Nested Realities", "--count", "1", "--rng", "3", "--root", root])
    h1 = (_parse_axioms(r.stdout) or [{}])[0]
    check("hollow --hollow-level homotopy routes",
          (h1.get("hollow_reading") or {}).get("hollow_level") == "homotopy")

    # 6. generic mode
    r = _sp(["--ontology", "generic", "--forcing-level", "cardinal", "--seed",
             "The Silent God", "--count", "2", "--rng", "42", "--root", root])
    gs = _parse_axioms(r.stdout)
    g0 = (gs or [{}])[0]
    gr = g0.get("generic_reading") or {}
    ok = (r.returncode == 0 and g0.get("ontology") == "generic"
          and gr.get("forcing_level") == "cardinal"
          and bool(gr.get("extension_hint"))
          and bool(gr.get("forcing_relation")))
    check("generic mode: cardinal level + extension hint + forcing relation", ok)

    # 7. dual mode + duality map (§17.4)
    r = _sp(["--ontology", "dual", "--emit-duality", "--seed",
             "The Grandfather-Paradox Containment", "--count", "2", "--rng",
             "7", "--root", root])
    ds = _parse_axioms(r.stdout)
    d0 = (ds or [{}])[0]
    dmap = d0.get("duality_map") or {}
    met = d0.get("metrics", {})
    ok = (r.returncode == 0 and d0.get("ontology") == "dual"
          and bool(dmap.get("pairs"))
          and bool((dmap.get("scaffold_pair") or {}).get("hollow"))
          and bool((dmap.get("scaffold_pair") or {}).get("generic"))
          and 0.0 <= met.get("duality_resonance", -1) <= 1.0
          and (d0.get("hollow_reading") or {}).get("core_statement")
          and (d0.get("generic_reading") or {}).get("core_statement"))
    check("dual mode: two readings + translation table + resonance in [0,1]",
          ok)

    # 8. void metrics range over 200 deterministic seeds (§17.4)
    bad = 0
    for i in range(200):
        rr = random.Random(i)
        dmm = void_metric_set({"core_statement": "The hollow hollows."},
                              {"core_statement": "It forces, therefore we extend."},
                              ["Torsion Twist", "Generic Filter Selection"],
                              "m[c] = 0,\\ [c] \\neq 0", 6.0, vm)
        if not all(0.0 <= v <= 1.0 for v in dmm.values()):
            bad += 1
    check("void metrics bounded in [0,1] across 200 seeds", bad == 0)

    # 9. type x ontology legality (§17.2)
    r = _sp(["--ontology", "hollow", "--paradox-type", "temporal", "--seed",
             "X", "--count", "1", "--root", root])
    ok = r.returncode == 2 and "allow-temporal-hollow" in (r.stderr or "")
    r2 = _sp(["--ontology", "hollow", "--paradox-type", "temporal",
              "--allow-temporal-hollow", "--seed", "X", "--count", "1",
              "--rng", "1", "--root", root])
    check("temporal x hollow rejected by default, allowed on opt-in", ok
          and r2.returncode == 0)
    r = _sp(["--ontology", "hollow", "--paradox-type", "generic", "--seed",
             "X", "--count", "1", "--root", root])
    check("generic type rejected under hollow ontology", r.returncode == 2)

    # 10. sanitizer: LaTeX out of axiom_text, preserved in equation_tex
    r = _sp(["--ontology", "hollow", "--seed", "Dark Forest Theory", "--count",
             "2", "--rng", "11", "--root", root])
    hs = _parse_axioms(r.stdout)
    bad = 0
    for e in hs:
        at = e.get("axiom_text", "")
        if "$" in at or "\\left" in at or "\\right" in at \
                or VOID_PLACEHOLDER_RE.search(at):
            bad += 1
        if "\\" not in (e.get("equation_tex") or ""):
            bad += 1
    check("sanitizer: axiom_text clean, equation_tex keeps raw LaTeX", bad == 0)

    # 11. dual determinism
    dargs = ["--ontology", "dual", "--seed", "Entropy eats order", "--count",
             "2", "--rng", "99", "--root", root]
    s1 = [e.get("core_statement") for e in _parse_axioms(_sp(dargs).stdout)]
    s2 = [e.get("core_statement") for e in _parse_axioms(_sp(dargs).stdout)]
    check("dual determinism (same rng → same cores)", s1 == s2 and bool(s1))

    # 12. void weight routing (§4.2)
    r_h = _parse_axioms(_sp(dargs[:-2] + ["--rng", "99", "--void-weight",
                                          "1.0", "--root", root]).stdout)
    r_g = _parse_axioms(_sp(dargs[:-2] + ["--rng", "99", "--void-weight",
                                          "0.0", "--root", root]).stdout)
    ok = (r_h and r_g
          and r_h[0].get("core_statement")
          == (r_h[0].get("hollow_reading") or {}).get("core_statement")
          and r_g[0].get("core_statement")
          == (r_g[0].get("generic_reading") or {}).get("core_statement"))
    check("void-weight routing: 1.0 collapses to hollow, 0.0 to generic", ok)

    # 13. legacy passthrough
    r = _sp(["--ontology", "legacy", "--seed", "The Silent God", "--count",
             "1", "--rng", "42", "--root", root])
    check("legacy passthrough (0.3.7 via --ontology legacy)",
          r.returncode == 0 and "FINAL AXIOM" in (r.stdout or ""))

    # 14. dual batch uniqueness per reading (§11.7)
    r = _sp(["--ontology", "dual", "--seed", "Nested Realities", "--count",
             "4", "--rng", "5", "--root", root])
    ds = _parse_axioms(r.stdout)
    seenp = set()
    uniq = True
    for e in ds:
        pk = ((e.get("hollow_reading") or {}).get("core_statement", ""),
              (e.get("generic_reading") or {}).get("core_statement", ""))
        if pk in seenp:
            uniq = False
        seenp.add(pk)
    check("dual batch uniqueness (4 pairs, no repeats)", uniq and len(ds) == 4)

    print("VOIDFORGE 5.0.0 VOID SELFTEST")
    fails = 0
    for ok, name, detail in results:
        mark = "PASS" if ok else "FAIL"
        line = f"  [{mark}] {name}"
        if detail and not ok:
            line += f"  — {detail}"
        print(line)
        if not ok:
            fails += 1
    print(f"  {len(results) - fails}/{len(results)} passed")
    return 0 if fails == 0 else 1


# ---------------------------------- CLI ------------------------------------#

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog=ENGINE_NAME,
        description="VoidForge v5.0.0 VOID — VoidForge (hollow / generic / "
                    "dual ontology modes over the v0.4.7 pipeline)")
    # ---- v0.4.7 flags, verbatim ----
    p.add_argument("--seed", type=str, help="Seed concept/title")
    p.add_argument("--seedfile", type=str, help="File of seeds, one per line")
    p.add_argument("--count", type=int, default=6, help="Axioms to emit")
    p.add_argument("--tone", type=str, default="poetic",
                   choices=["poetic", "plain", "academic", "oracular"])
    p.add_argument("--rng", type=int, default=None,
                   help="Deterministic RNG seed")
    p.add_argument("--emit-scaffold", action="store_true",
                   help="Include humanized_injection_scaffold fields")
    p.add_argument("--transcend", action="store_true",
                   help="Light transcendent hooks (classic mode)")
    p.add_argument("--max-mech", type=int, default=3,
                   help="Max mechanisms per axiom/reading")
    p.add_argument("--selfref-mode", type=str, default="meta",
                   choices=["binary", "meta", "field"])
    p.add_argument("--allow-duplicates", action="store_true")
    p.add_argument("--math-theme", type=str, default="auto")
    p.add_argument("--root", type=str, default=str(HERE),
                   help="Root folder for data JSON banks")
    p.add_argument("--save-to-history", action="store_true",
                   help="Also save a New_Session-style JSON file")
    p.add_argument("--out", type=str, default=None,
                   help="Write session JSON to this path")
    # ---- v5 flags ----
    p.add_argument("--ontology", type=str, default="classic",
                   choices=list(ONTOLOGIES),
                   help="Ontology routing mode (default: classic = v0.4.7)")
    p.add_argument("--hollow-level", type=str, default="cohomology",
                   choices=list(HOLLOW_LEVELS),
                   help="Bias hollow equation selection to a topology layer")
    p.add_argument("--forcing-level", type=str, default="poset",
                   choices=list(FORCING_LEVELS),
                   help="Bias generic equation selection to a forcing layer")
    p.add_argument("--void-weight", type=float, default=0.0,
                   help="[0,1] dual-mode interpolation: 0=generic reading, "
                        "0.5=balanced fusion, 1=pure hollow")
    p.add_argument("--emit-duality", action="store_true",
                   help="Emit duality_map block in each dual emission")
    p.add_argument("--allow-temporal-hollow", action="store_true",
                   help="Override the temporal x hollow rejection")
    p.add_argument("--legacy-timestamps", action="store_true",
                   help="Use datetime.utcnow() (v0.4.7 behaviour)")
    p.add_argument("--strict-void", action="store_true",
                   help="Resample rather than emit if void_coherence < 0.5 "
                        "or duality_resonance below threshold")
    p.add_argument("--paradox-type", type=str, default=None,
                   help="Force a paradox type (validated against the "
                        "ontology legality matrix)")
    p.add_argument("--selftest", action="store_true",
                   help="Run the VoidForge self-test suite and exit")
    return p.parse_args()


def main() -> None:
    if "--selftest" in sys.argv:
        sys.exit(run_selftest())
    args = parse_args()
    if args.selftest:
        sys.exit(run_selftest())
    if args.ontology == "legacy":
        sys.exit(run_legacy(args))
    if not args.seed and not args.seedfile:
        print("Provide --seed or --seedfile", file=sys.stderr)
        sys.exit(2)

    if args.rng is not None:
        random.seed(args.rng)
    else:
        base = f"{args.seed or ''}|{args.seedfile or ''}|{args.count}"
        random.seed(zlib.crc32(base.encode("utf-8")))

    if args.ontology == "classic":
        results = run_classic(args)
    else:
        results = run_void(args)

    out_path: Optional[Path] = Path(args.out) if args.out else None
    if args.save_to_history and not out_path:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        out_path = Path(f"New_Session_{stamp}.json")
    if out_path:
        payload = {
            "exportedAt": utc_ts(),
            "engine": ENGINE_NAME,
            "session": {
                "id": int(datetime.now(timezone.utc).timestamp()),
                "name": f"voidforge-void-{args.ontology}",
                "createdAt": utc_ts(),
                "seedPrompt": args.seed or (args.seedfile or ""),
                "params": {
                    "tone": args.tone,
                    "rng": args.rng,
                    "count": args.count,
                    "max_mech": args.max_mech,
                    "selfref_mode": args.selfref_mode,
                    "emit_scaffold": args.emit_scaffold,
                    "ontology": args.ontology,
                    "hollow_level": args.hollow_level,
                    "forcing_level": args.forcing_level,
                    "void_weight": args.void_weight,
                    "paradox_type": args.paradox_type,
                },
            },
            "results": results,
        }
        out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                            encoding="utf-8")
        print(f"\nSaved session → {out_path}", file=sys.stderr)


if __name__ == "__main__":
    main()



