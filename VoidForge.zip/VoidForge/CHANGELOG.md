# Changelog

All notable changes to VoidForge are documented here.
The project follows the AxiomForge lineage (v0.x engines) and the VoidForge
shell/ontology layer (v2.x BBS, v5.0.0 engine).

---

## v2.0.0 VOID — "Recursive Paradox Dial-In" (2026-10-24)

The VoidForge release: a modular BBS shell over a triple-engine drive, plus the
v5.0.0 VOID ontology layer.

### Added — VOIDFORGE BBS shell (`voidforge.sh`)
- Retro dial-in terminal dashboard in pure ANSI bash (no ncurses/dialog/fzf):
  BIOS boot sequence, ASCII logo, modem CONNECT, login, first-boot ETHICS gate,
  logoff with NO CARRIER.
- Ten boards: The Forge · Chaos Forge · VOIDFORGE LAB · Batch Factory ·
  The Vault · Telemetry · Seed Bank · Session Log · Engine Bay · Codex.
- True-black canvas: OSC 10/11 default fg/bg claim, every SGR reset re-asserts
  black, neon palette with >=7:1 contrast on black (`AF_NOBG=1` to opt out).
- Batch Factory exports JSON / TXT / MD (grimoire) / CSV (metrics) in one pass.
- Vault (JSONL) with search, export, purge; Telemetry aggregates sessions,
  exports and vault with type-mix and ontology-mix bars.
- Seed Bank (create/edit/import/harvest), Session Log with deterministic REPLAY
  verification (re-runs seed+rng+ontology and diffs cores).
- Engine Bay: live engine switch, PARITY DUEL (v5 classic vs 0.4.7) and
  ONTOLOGY DUEL (hollow vs generic).
- CLI passthrough: `forge`, `void`, `chaos`, `batch`, `stats`, `selftest`, `help`.
- 20-check built-in selftest (`voidforge.sh selftest`).

### Added — VoidForge v5.0.0 engine (`voidforge_5.0.0.py`)
- Ontology router `--ontology {classic|hollow|generic|dual|legacy}`:
  `classic` is parity with v0.4.7; `legacy` wraps v0.3.7 untouched.
- **THE HOLLOW** — algebraic topology of shaped absence (CW attachment, Betti
  spectra, cohomology, knots, torsion) from `banks/hollow_bank.json`
  (36 mechanisms, 16 equations, 10 consequences, 7 templates).
- **THE GENERIC** — set-theoretic forcing (posets, generic filters, large
  cardinals, multiverse) from `banks/generic_bank.json`
  (43 mechanisms, 14 equations, 9 consequences).
- **DUAL mode** — one seed → hollow reading + generic reading → shared
  scaffold pair → translation table (`banks/duality_map.json`) filtered to the
  mechanisms actually used; `--void-weight` interpolates hollow/generic, 0.55
  resonance threshold with resampling, `--strict-void` enforcement.
- Void metrics appended to every emission (0.0 in classic — schema stable):
  `hollow_index`, `forcing_index`, `void_coherence`, `duality_resonance`,
  `void_score`; formulas declared in `banks/void_metrics.json`.
- Ontology-aware sanitizer (LaTeX stripped from `axiom_text`, raw preserved in
  `equation_tex`/`mechanism_tex`; extended placeholder kill-switch).
- §9.2 legality matrix — `temporal × hollow` rejected unless
  `--allow-temporal-hollow`.
- 15-check built-in selftest including golden parity vs v0.4.7.

### Changed
- Restructured the monolithic dashboard into a modular build:
  thin launcher + `lib/` (util, colors, ui, flair, engine, data, cli) +
  `modules/` (10 boards). Every file `bash -n` clean; printf format/arg scan
  clean.
- README, ETHICS.md (VoidForge Addendum) and branding refreshed; MIT LICENSE
  text restored.

---

## v0.4.7 — Stability & Alignment (2025-09-27, AxiomForge)

- Final post-emit sanitizer for placeholders and template label remnants.
- Seed-aware suffixing (Dark Forest / Nested Realities / Silent God).
- Concept-alignment scoring; fidelity tied to alignment.
- Equation whitelists by paradox type + mechanism triangulation.
- Light transcendent hooks (Consciousness Origami, Temporal Echo, Qualia
  Density); `fidelity_breakdown` + `qualia_density` metrics.

## v0.4.6 — Feature Bloom (2025-09, AxiomForge)

- Mechanism diversity expansion; emotional scaffolds improved; pillars
  tagging; early fidelity metric.

## v0.3.7 — "God-Tier" Power Pass (2025-08-25, AxiomForge)

- Deterministic RNG (`--rng`), self-reference modes (binary/meta/field).
- Mechanism pooling from local JSON banks, batch uniqueness, tone scaffolds.
- Transparent metric heuristic with low-variance noise.
