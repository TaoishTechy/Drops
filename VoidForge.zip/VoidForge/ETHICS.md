# VoidForge Ethics Guidelines

## Preamble

VoidForge is a powerful engine for generating novel philosophical and scientific axioms. Its potential for positive impact in research and creativity is significant, but so is its potential for misuse. These guidelines are a condition of use for this software.

## Principles of Use

Use of VoidForge is governed by the following principles:

1.  **Beneficence:** Use shall be for purposes that promote understanding, creativity, and the betterment of society.
2.  **Non-Maleficence:** Use shall not cause harm, whether physical, psychological, social, or economic.
3.  **Transparency:** Use should be open and clear about the involvement of AI-generated content where appropriate.
4.  **Accountability:** Users are personally accountable for the consequences of their use of this technology.

## Strictly Prohibited Uses

You are expressly forbidden from using VoidForge for:

*   **Generating content intended to deceive, defraud, or mislead.**
*   **Creating content for psychological manipulation, coercion, or targeted harassment.**
*   **Developing applications that infringe upon individual privacy or human rights.**
*   **Any military, cyber-weaponry, or surveillance applications without explicit, verifiable humanitarian oversight.**
*   **Any activity that is illegal under applicable laws.**

## Recommended Practices

*   **Documentation:** Keep records of seeds and outputs used in research or publications.
*   **Oversight:** For significant projects, seek ethical review from relevant boards or peers.
*   **Transparency:** When sharing outputs, disclose their AI-generated nature.

## Enforcement

While enforcement is challenging, violations of these guidelines are taken seriously:
*   **Community Reporting:** Violations can be reported to the project maintainers.
*   **Reputational Cost:** Publicly naming bad actors is a primary deterrent.
*   **License Revocation:** For egregious, verifiable violations, the MIT License may be revoked for the specific bad actor, making their use of the software illegal under copyright law.

## Conclusion

This technology is a reflection of its creators and users. We choose to build and use it for good. Please use this power wisely.

## VoidForge Addendum (v5.0.0 VOID)

The Hollow and the Generic are *mathematical* ontologies — algebraic topology
and set-theoretic forcing. They are not claims about reality. They are
rhetorical instruments for generating novel philosophical micro-theories.

The dual mode's `duality_resonance` metric measures aesthetic-theoretic
alignment, not empirical truth. A high resonance is not evidence that the
hollow ontology or the forcing ontology is correct. It is evidence that
the generator has produced a rhetorically tight dual reading.

Prohibited uses (carried forward from §Strictly Prohibited Uses):
- Presenting `--ontology dual` output as proof of set-theoretic realism.
- Using forcing vocabulary ("the universe is forced to extend") to
  manipulate readers into accepting real-world claims about agency,
  causality, or control.
- Deploying the void_score as if it were a measure of importance,
  intelligence, or truth.

Recommended practice: when publishing VoidForge output, disclose
(a) the ontology mode used, (b) the RNG seed, and (c) that the
mathematics is used as metaphor, not as physics or metaphysics.
