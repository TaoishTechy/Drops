Here is a comprehensive list of **144 limitations, bottlenecks, and constraints** affecting the most common LLM technologies today, including **Safetensors, PyTorch, NumPy, Transformers, vLLM, DeepSpeed, Quantization (GPTQ/AWQ/GGUF), CUDA, FlashAttention, KV-Caching, MoE, and distributed training frameworks**.

They are organized into 12 categories of 12 points each for clarity.

---

### Category 1: Safetensors – File Format & Serialization (1–12)

1. **No architecture storage** – Stores only raw tensors; model structure must be redefined in code separately.
2. **Cannot serialize custom objects** – Optimizers, schedulers, and custom layers are not supported.
3. **No optimizer state persistence** – Cannot save Adam momentum or variance; requires separate checkpointing for resuming training.
4. **Conversion fidelity concerns** – Developers distrust automatic converters (e.g., from pickle); subtle numeric differences can appear.
5. **Complex load/save pipeline** – Requires manual mapping between tensor names and model parameters; error-prone for large models.
6. **Backward compatibility gap** – Many Hugging Face repos still provide legacy pickle versions, forcing a dual-maintenance burden.
7. **Sub-byte datatypes rejected** – Cannot directly load packed 2-bit/3-bit integer formats without custom deserialization.
8. **Non-deterministic tensor iteration** – The `runai_safetensors_weights_iterator` yields tensors in non-deterministic order, breaking FP8 inference on unified memory platforms.
9. **View vs. copy ambiguity** – Loaded tensors are NumPy buffer views, not independent copies; asynchronous operations risk data races.
10. **Cross-device copy races** – On unified memory architectures (e.g., Grace Hopper), CPU→GPU copies are asynchronous; buffers may mutate before completion.
11. **Specification imprecision** – Security audits have found ambiguities in the official spec regarding padding and alignment.
12. **Lax validation** – `[u8;4]` byte sequences can be forcibly reinterpreted as valid f32 data, even when they violate IEEE floating-point norms.

---

### Category 2: PyTorch – Core Framework Limitations (13–24)

13. **FP32 memory bloat** – High-precision training doubles memory compared to bf16/FP16 without proportional accuracy gains.
14. **Non-fused optimizer slowdown** – Fused AdamW (e.g., via `torch.optim.fused`) is unavailable on all hardware; CPU fallback kills throughput.
15. **Naive attention overhead** – Without FlashAttention, memory grows quadratically (`O(N²)`), limiting long sequences.
16. **Missing `torch.compile` stability** – Compilation failures, long recompilation times, and graph breaks are frequent on dynamic control flow.
17. **GIL contention in DataLoader** – The Global Interpreter Lock still limits multi-threaded data preprocessing even with `num_workers`.
18. **CUDA context initialization cost** – The first CUDA call incurs a hidden 2-5 second overhead, hurting cold-start inference.
19. **Memory fragmentation** – Repeated allocations/deallocations fragment VRAM, causing `CUDA out of memory` even with sufficient free space.
20. **Autograd tape memory** – The backward graph holds intermediate activations; activation checkpointing trades compute for memory but slows training.
21. **Tensor copy overhead** – Implicit `to(device)` copies in the forward pass are frequently overlooked and add significant latency.
22. **Sparse tensor support gaps** – Sparse operations are incomplete compared to dense; many backends fall back to dense computation silently.
23. **Device synchronization points** – Implicit `item()` calls or `cpu()` conversions force costly device-host synchronization, stalling the pipeline.
24. **Dynamic shape penalty** – Recompiling for each new sequence length in `torch.compile` negates JIT benefits for variable-length inputs.

---

### Category 3: NumPy – CPU-side Numerical Bottlenecks (25–36)

25. **No GPU support natively** – Requires external libraries (CuPy, JAX, PyTorch) for GPU acceleration; CPU-only limits large-scale processing.
26. **Memory overhead for small arrays** – Each ndarray has significant object overhead; millions of small tensors waste RAM.
27. **Double-precision default** – Default float64 doubles memory; many LLM ops only need float32/bf16.
28. **Copy-on-slice inconsistency** – Slices return views, but advanced indexing returns copies – leading to unexpected memory spikes.
29. **Strided access inefficiency** – Non-contiguous memory access (e.g., transposed tensors) kills cache locality.
30. **Global interpreter lock (GIL) blocking** – Multi-threaded NumPy ops are GIL-limited; true parallelism requires multiprocessing.
31. **Pickle serialization size** – NumPy's pickle format is not space-efficient compared to Safetensors; large arrays bloat checkpoints.
32. **No native bfloat16 support** – bfloat16 must be emulated via `astype`, losing the native hardware acceleration.
33. **Slow `np.where` on large masks** – Conditional operations on large arrays (e.g., for masking logits) become a CPU bottleneck.
34. **Lack of automatic differentiation** – Must be paired with autograd frameworks; no native gradient tracking.
35. **Memory pinned to host** – Data stays in CPU DRAM; transferring to GPU incurs PCIe bandwidth penalties.
36. **Dependency on BLAS/LAPACK** – Performance is library-dependent; misconfigured OpenBLAS vs. MKL can cause 10x slowdowns.

---

### Category 4: Hugging Face Transformers – Library-Level Constraints (37–48)

37. **Tokenization speed mismatch** – Tokenizers (Rust-backed) are fast, but Python serialization adds 20-30% overhead per batch.
38. **Padding and truncation waste** – Static padding to max length causes massive compute waste for short sequences.
39. **`generate()` inefficiency** – The legacy generation loop is Python-driven, not fully kernel-fused, leading to idle GPU cycles.
40. **Cache collision in pipelines** – Pipeline objects cache tokenizers and models; switching models requires manual cache clearing.
41. **Slow `from_pretrained` on sharded models** – Downloading and loading dozens of sharded safetensor files is I/O-bound.
42. **Device placement confusion** – Models can be partially on CPU/GPU; users often inadvertently offload layers, causing cross-device sync penalties.
43. **`accelerate` offloading overhead** – CPU/disk offloading works but adds milliseconds per layer, crippling latency-sensitive inference.
44. **Hardcoded max length assumptions** – Many pretrained models have fixed positional encodings; extending context requires costly fine-tuning.
45. **Tokenizer special tokens mismatch** – Adding new tokens requires full embedding matrix resizing, breaking sharded checkpoint integrity.
46. **Logit processing overhead** – Custom stopping criteria, repetition penalties, and logit biases are applied in Python, not CUDA.
47. **Attention mask propagation bugs** – Incorrect mask handling in custom model modifications leads to silent correctness issues.
48. **Configuration explosion** – The `config.json` has over 100 parameters; misconfiguring one (e.g., `rope_scaling`) causes hard-to-debug crashes.

---

### Category 5: vLLM – Inference Serving Limitations (49–60)

49. **PagedAttention fragmentation** – Physical KV-block fragmentation grows over long-running deployments, reducing effective batch size.
50. **Prefix caching inefficiency** – Exact-match prefix caching fails for slight input variations, limiting reuse.
51. **Triton kernel compilation lag** – First-inference latency suffers from JIT compilation of Triton kernels (2-5 seconds).
52. **MoE routing overhead** – For Mixture of Experts, the all-to-all communication and routing decisions add 20-30% latency per token.
53. **Continuous batching starvation** – Long-running requests can starve short ones if scheduling priorities are misconfigured.
54. **CUDA graph limitations** – CUDA graphs capture static shapes; dynamic batching forces graph re-recording, negating the benefit.
55. **KV cache memory over-reservation** – Reserving memory for max sequence length per request wastes capacity for short outputs.
56. **Tokenizer not integrated** – Tokenization runs on CPU in Python, creating a pipeline bubble before GPU kernels launch.
57. **Speculative decoding overhead** – The draft-verify phase adds latency and is only beneficial at high batch sizes or low temperatures.
58. **Multi-LoRA switching cost** – Hot-swapping LoRA adapters requires weight reloading and kernel recompilation, adding 10-50ms per switch.
59. **Chunked prefill latency** – Prefill chunks consume batch slots, delaying decode-phase tokens for other requests.
60. **Chunked prefill memory fragmentation** – Splitting long prefill requests increases memory allocator fragmentation over time.

---

### Category 6: DeepSpeed – Distributed Training Constraints (61–72)

61. **ZeRO stage 3 all-gather overhead** – Each forward pass requires gathering partitioned weights, adding 10-30% communication latency.
62. **Offloading to CPU/NVMe latency** – ZeRO-Offload moves data across PCIe; speeds are capped by memory bandwidth, not compute.
63. **Adam optimizer state duplication** – Even with ZeRO, the optimizer state footprint is 12x the model size (fp32 copies of parameters, momentum, variance).
64. **Gradient checkpointing with ZeRO** – Recomputation and communication overlap poorly, causing GPU idle time.
65. **Autotuning inadequacy** – DeepSpeed's autotuner rarely finds the global optimum; manual tuning remains essential.
66. **MoE in DeepSpeed** – Expert parallelism has uneven memory and communication loads, leading to load-imbalance bubbles.
67. **Host memory pressure** – Prefetching optimizer states to CPU RAM during offloading consumes hundreds of GB of DRAM.
68. **Z3+ offload configuration complexity** – `stage3_max_live_parameters`, `prefetch_bucket_size` — over 20 hyperparameters; wrong values crash training.
69. **Checkpointing speed** – Saving ZeRO partitioned checkpoints is 2-3x slower than single-GPU saves due to I/O coordination overhead.
70. **Resume from checkpoint failures** – Restoring a distributed checkpoint requires exact rank mapping; node reordering breaks resumption.
71. **PyTorch `compile` incompatibility** – DeepSpeed is not fully compatible with `torch.compile`, forcing eager mode.
72. **All-reduce vs. reduce-scatter trade-offs** – Choosing the wrong collective for the model size and cluster topology hurts scalability.

---

### Category 7: Quantization – GPTQ / AWQ / GGUF (73–84)

73. **GPTQ calibration set sensitivity** – Quantization quality depends heavily on a small calibration dataset; out-of-domain data degrades accuracy.
74. **AWQ group size trade-off** – Smaller groups (e.g., 32) retain accuracy but increase memory overhead and dequantization cost.
75. **GGUF CPU inference limits** – Runs on CPU; memory bandwidth (DDR) is 5-10x slower than HBM on GPUs, capping tokens/sec.
76. **W4A16 asymmetry** – Weights are 4-bit, but activations remain FP16, so KV-cache still dominates memory for long sequences.
77. **Dequantization overhead** – Each matrix multiplication requires on-the-fly dequantization; this consumes compute that could go to FLOPs.
78. **FP8 training instability** – FP8 dynamic scaling is sensitive; gradient underflow/overflow is frequent without careful loss scaling.
79. **AWQ-per-token vs per-channel** – Per-token activation quantization introduces CPU-side overhead for scaling factors.
80. **GPTQ group-size mismatch** – Different layers need different group sizes; global group size leads to suboptimal compression per layer.
81. **KV-cache quantization error** – Quantizing the KV cache (e.g., to INT8) compounds errors over long generations, causing quality collapse.
82. **No support for attention scores** – Attention scores are often quantized post-softmax; the softmax distribution is sensitive to precision loss.
83. **Mixed-precision compatibility** – Quantized models often cannot run with `torch.compile` or FlashAttention due to dtype mismatches.
84. **Bit-packing overhead** – Packing 4-bit weights into bytes requires shuffling; unpacking adds CPU/GPU cycles on every forward pass.

---

### Category 8: CUDA & Kernel-Level Bottlenecks (85–96)

85. **Kernel launch latency** – Launching thousands of small kernels (e.g., elementwise ops) creates a CPU-side launch bottleneck (microseconds per kernel).
86. **Warp divergence** – Dynamic branch paths in attention masks cause SIMD inefficiency; up to 50% of warps can be idle.
87. **Bank conflicts in shared memory** – Shared memory bank conflicts during softmax and reduction degrade performance by 20-40%.
88. **L2 cache pressure** – Large weight matrices thrash L2; cache hit rates drop below 50% for batch sizes > 32.
89. **Memory coalescing failures** – Strided accesses to KV-cache (by sequence) fail coalescing, reducing DRAM bandwidth utilization.
90. **No asynchronous prefetching** – Software-managed prefetching is limited; hardware prefetchers fail on strided tensor patterns.
91. **Tensor Core utilization gap** – Tensor Cores require specific shapes (multiples of 8/16) and data types; mismatches fall back to CUDA Cores.
92. **Dynamic parallelism restrictions** – Launching kernels from within a kernel is unsupported on most consumer GPUs.
93. **Page migration overhead** – Unified Memory causes page faults when accessing GPU; migrates pages lazily, stalling execution.
94. **NCCL collective contention** – NCCL uses reserved SM resources; all-reduce steals compute capacity from kernels during training.
95. **Register pressure** – Large kernels (e.g., FlashAttention) exceed register file limits, forcing spills to local memory (L1→VRAM).
96. **Driver overhead for memory allocation** – `cudaMalloc` is synchronous and expensive; pre-allocating memory pools is required but complex.

---

### Category 9: KV-Caching & Long-Context Limitations (97–108)

97. **Memory scales linearly with context** – Each token stored is 2-4 bytes per layer; 1M tokens require 100+ GB for a 70B model.
98. **Prefix caching only for exact matches** – No semantic or fuzzy prefix matching; adjacent queries waste cache.
99. **KV-cache recomputation on scheduler preemption** – vLLM/TRT-LLM may discard cache for preempted requests, forcing recomputation.
100. **FlashAttention cache layout constraints** – Requires page-aligned contiguous blocks; fragmentation reduces occupancy.
101. **Sliding window attention limitations** – Window sizes (e.g., 4k) discard long-range dependencies, limiting in-context learning.
102. **Streaming LLM cache eviction policy** – Evicting tokens (e.g., H2O) is heuristic-based; suboptimal eviction degrades generation quality.
103. **Cache transfer across nodes** – Distributed inference requires moving KV-cache over the network; bandwidth is a major bottleneck.
104. **Quantized cache accuracy drop** – INT8 KV cache still has a 1-2% perplexity degradation compared to FP16, per layer.
105. **Multi-query / Grouped-query attention** – Sharing KV heads reduces memory but introduces quality tradeoffs for complex reasoning.
106. **Prompt caching not reused across users** – In multi-tenant systems, each user's prompt is unique, leading to low cache hit rates.
107. **Cache memory fragmentation** – Variable-length sequences create holes in the paged memory pool, requiring compaction (costly).
108. **Context window extension** – RoPE scaling beyond pretraining limits introduces positional OOD errors; models become unstable.

---

### Category 10: Mixture of Experts (MoE) – Sparsity Bottlenecks (109–120)

109. **Expert routing imbalance** – Load imbalance leads to some experts over-utilized, others idle; overall capacity wasted.
110. **All-to-all communication cost** – Tokens dispatched to experts across nodes require all-to-all collectives, bandwidth sinks.
111. **Expert capacity factor tuning** – Setting capacity factor too low drops tokens; too high wastes computation.
112. **No native MoE in FlashAttention** – FlashAttention does not support expert-specific attention, forcing custom kernels.
113. **Device memory for all experts** – Even with routing, all expert weights must reside in memory; 8 experts = 8x memory.
114. **Expert switching overhead** – Changing expert routing mid-generation incurs cache misses in weight loading.
115. **Fine-tuning MoE instability** – Gradient noise increases with sparsity; requires higher batch sizes to stabilize.
116. **Inference batching inefficiency** – Different experts activated per token create variable compute loads, complicating continuous batching.
117. **Shared expert granularity** – Deciding shared vs. routed experts is non-trivial; misconfiguration increases compute.
118. **Loss-free routing impossible** – Auxiliary load-balancing losses corrupt the primary loss surface, hurting convergence.
119. **Expert duplication overhead** – In large-scale training, top experts must be replicated across nodes, doubling memory.
120. **Cold-start inference latency** – MoE routers are small but add an extra DNN inference step per token (5-10% overhead).

---

### Category 11: Data Loading & I/O Pipeline Constraints (121–132)

121. **Storage bandwidth bottlenecks** – Loading multi-terabyte datasets from SSDs (5-7 GB/s) cannot keep up with GPU FLOPs (tens of TB/s).
122. **Disk I/O vs CPU preprocessing** – CPU decompression (e.g., Snappy, Zstandard) becomes the bottleneck before GPU sees data.
123. **Network storage latency** – Loading from cloud/NFS adds 10-100ms latency per file, causing GPU starvation.
124. **Shuffling overhead** – Global shuffling requires reading entire dataset into memory; distributed shuffling requires coordination.
125. **Tokenization re-computation** – Every epoch re-tokenizes raw text; even cached `.bin` files still require I/O and memory mapping.
126. **Data augmentation not GPU-native** – Most augmentations run on CPU; moving them to GPU consumes compute budget.
127. **Checkpoint I/O blocking training** – Saving 100GB checkpoints stalls training for minutes; asynchronous saving risks corrupting in-flight data.
128. **File format fragmentation** – `.arrow`, `.parquet`, `.jsonl`, `.bin` – converting between formats wastes time and disk space.
129. **Small file problem** – Datasets split into millions of small files paralyze filesystem metadata operations.
130. **Memory-mapped file coherence** – Reading memory-mapped files across nodes without cache coherence causes stale reads.
131. **Prefetch queue underflow** – DataLoader prefetching fails when preprocessing is slower than GPU consumption, causing idle SMs.
132. **Mixed precision conversion in dataloader** – Converting text to FP16/bf16 on-the-fly adds CPU-side FP operations, delaying batch delivery.

---

### Category 12: System-Level, Power, & Deployment Constraints (133–144)

133. **Power capping throttles** – Data center power limits force dynamic voltage/frequency scaling (DVFS), reducing clock speeds by 20%.
134. **Thermal throttling cascade** – Hot GPUs warm neighboring CPUs, causing both to throttle simultaneously (global heat soak).
135. **PCIe lane sharing saturation** – Multiple GPUs + NVMe drives share CPU PCIe lanes; x16 becomes x8/x4, halving bandwidth.
136. **Chipset uplink contention** – SSDs and NICs connected via chipset fight over the DMI x4 uplink (≈4 GB/s) to the CPU.
137. **Remote NUMA memory access** – CPU memory on non-local sockets adds 30-50ns latency; affects offloading performance.
138. **Copper signaling limits** – At PCIe 6.0 speeds, signal integrity limits trace length, forcing physical proximity of memory and compute.
139. **NCCL topology unawareness** – Bad network topology (leaf-spine misconfiguration) causes hidden all-reduce bottlenecks.
140. **Orchestration overhead (Kubernetes)** – Container networking, sidecar proxies, and API server requests steal 5-10% of CPU cores.
141. **Security isolation overhead** – TEE (Trusted Execution Environment) encryption/decryption adds 10-20% latency per request.
142. **Diagnostic instrumentation** – Profiling (e.g., PyTorch Profiler, NVIDIA Nsight) adds 10-15% overhead, skewing production metrics.
143. **Cold-start container pull** – Pulling multi-GB inference images from registries adds 30-60 seconds to autoscaling events.
144. **Version mismatch hell** – CUDA 11.8 vs 12.x, PyTorch 2.0 vs 2.1, Triton, cuDNN – incompatibility matrix leads to silent performance regressions.
