## 1. Verified Statistics and Metrics

**144** — UAP reports analyzed in the 2021 ODNI Preliminary Assessment, mostly U.S. Navy reports from 2004–2021 — **ODNI 2021 Preliminary Assessment**

**143 of 144** — Reports unexplained at the time of the 2021 assessment — **ODNI 2021 Preliminary Assessment**

**1 of 144** — Report identified as a large deflating balloon — **ODNI 2021 Preliminary Assessment**

**80 of 144** — Reports involving multiple sensors, including radar, infrared, electro-optical, or visual — **ODNI 2021 Preliminary Assessment**

**18 incidents / 21 reports** — Reports showing unusual flight characteristics such as station-keeping in winds aloft, moving against the wind, abrupt maneuvers, or considerable speed without discernible propulsion — **ODNI 2021 Preliminary Assessment**

**11** — Documented pilot-reported near-misses with UAP — **ODNI / public UAP reporting in document**

**757** — New UAP reports received from May 1, 2023 to June 1, 2024 — **AARO annual report**

**485** — New reports from incidents occurring during May 2023–June 2024 — **AARO annual report**

**272** — Incident reports from 2021–2022 submitted late to AARO — **AARO annual report**

**292** — Total cases resolved to common/prosaic objects by publication date — **AARO annual report**

**118** — Cases resolved during the reporting period to balloons, birds, or drones — **AARO annual report**

**174** — Cases queued for closure as prosaic after the reporting period — **AARO annual report**

**21** — Cases requiring further data or long-term study from the recent AARO batch — **AARO annual report**

**~900** — Reports in AARO’s active archive lacking sufficient data for current analysis — **AARO annual report**

**1,652** — Total UAP incidents reported to AARO since inception, as of June 2024 — **AARO annual report**

**38.4%** — Largest reported shape category: lights with no discernible shape — **AARO annual report**

**14.4% / 109 of 757** — Reports where the object was characterized as a solid object — **AARO annual report**

**6.5% / 49 of 757** — UAP incidents reported in the space domain, defined as ≥100 km altitude — **AARO annual report**

**2.8% / 21 of 757** — Fraction requiring ongoing investigation in the latest report — **AARO annual report**

**0** — Verifiable evidence of extraterrestrial beings or technology found by AARO to date — **AARO**

**0** — AARO reports indicating adverse health effects on observers — **AARO**

**2** — Confirmed flight-safety concerns from U.S. military aircrews — **AARO**

**3** — Reports of pilots being trailed or shadowed by UAP — **AARO**

**0** — Confirmation that UAP activity is attributable to foreign adversaries — **AARO**

**163 of 366** — Cases attributable to balloons — **ODNI 2022 / AARO reporting as stated in document**

**26 of 366** — Cases attributable to drone systems — **ODNI 2022 / AARO reporting as stated in document**

**6 of 366** — Cases attributable to birds, weather, or airborne debris — **ODNI 2022 / AARO reporting as stated in document**

**510** — UAP analyses in the 2022 ODNI report — **ODNI 2022 report**

**247** — UAP reports in the 2022 ODNI report from June 2021–March 2022 — **ODNI 2022 report**

**119** — Additional archival reports from the previous 17 years — **ODNI 2022 report**

**12,618** — Total sightings investigated by Project Blue Book, 1947–1969 — **Project Blue Book**

**701** — Project Blue Book cases that remained unidentified — **Project Blue Book**

**5.6%** — Project Blue Book unresolved percentage — **Project Blue Book**

**~5%** — Historical unresolved fraction compared across Project Blue Book and later UAP datasets — **Project Blue Book / AARO comparison in document**

**NASA UAP study, 2023** — No evidence of extraterrestrial origins; emphasized lack of high-quality, reproducible, calibrated multi-sensor data — **NASA UAP Independent Study Team 2023**

**NASA UAP study, 2023** — Recommended rigorous scientific framework, standardized reporting, AI/ML for pattern detection, and use of Earth-observing satellites for environmental context — **NASA UAP Independent Study Team 2023**

**301** — High-quality witness reports from 1947–2016 in a peer-reviewed dataset — **Peer-reviewed dataset named only generically in document**

**>100,000** — Reports filtered to create the 301-report peer-reviewed dataset — **Peer-reviewed dataset named only generically in document**

**0.15°** — Minimum angular size inclusion criterion for reliability — **Peer-reviewed dataset named only generically in document**

**6** — Primary UAP shape categories: sphere, disc, triangle, boomerang, diamond, oval — **Peer-reviewed dataset named only generically in document**

**300 ft / ~91 m** — Median length of largest shapes such as diamond, rectangle, or boomerang — **Peer-reviewed dataset named only generically in document**

**170 ft / ~52 m** — Median length of triangle-shaped UAP — **Peer-reviewed dataset named only generically in document**

**20 ft / ~6 m** — Median diameter of smallest shapes, spheres — **Peer-reviewed dataset named only generically in document**

**16** — Reports of objects hovering, traveling >Mach 1, and making no sound — **Peer-reviewed dataset named only generically in document**

**316 ft** — Median size of disc-shaped objects across five major studies — **[SOURCE UNVERIFIED]**

**100g to thousands of g** — Estimated accelerations in open analyses of high-quality UAP cases — **Knuth et al. 2019 / open analyses as stated in document**

**>5000g** — Upper-bound acceleration estimates from some UAP analyses — **[SOURCE UNVERIFIED]**

**40g** — Lower-bound observed acceleration baseline for anomalous events — **[SOURCE UNVERIFIED]**

**29.4 km/s² / ~3000g** — Acceleration estimate from the 2004 Nimitz encounter — **[SOURCE UNVERIFIED]**

**9g** — Sustained human pilot limit for current advanced fighter aircraft — **[SOURCE UNVERIFIED]**

**13.5g** — Structural maximum airframe limit for the F-35 Lightning II — **[SOURCE UNVERIFIED]**

**1–9 GW** — Estimated power required to achieve observed accelerations assuming 1-ton mass — **[SOURCE UNVERIFIED]**

**12 m** — Estimated length for the 2004 Nimitz “Tic Tac” object — **[SOURCE UNVERIFIED]**

**~80,000 ft to sea level** — Nimitz-related rapid descent estimate — **[SOURCE UNVERIFIED]**

**~0.78 s** — Time estimate used in Nimitz-related descent acceleration calculation — **[SOURCE UNVERIFIED]**

**887 km/h / ~Mach 0.72** — GOFAST video speed estimate — **[SOURCE UNVERIFIED]**

**18 m / ~59 ft** — GOFAST UAP length estimate from sensor data — **[SOURCE UNVERIFIED]**

**~5,800 km/h / ~Mach 4.7** — Speed estimate from a drone video analysis — **[SOURCE UNVERIFIED]**

**Mach 1 / ~767 mph / 1,235 km/h** — Speed threshold noted for high-performance objects — **[SOURCE UNVERIFIED]**

**343 m/s** — Approximate speed of sound at sea level used for sonic-boom discussion — **[SOURCE UNVERIFIED]**

**1,280×1,024** — Resolution of MWIR cooled thermal sensors — **[SOURCE UNVERIFIED]**

**640×512** — EO sensor resolution / MWIR thermal imager resolution as listed — **[SOURCE UNVERIFIED]**

**1920×1080 / 1080p** — Full HD EO sensor resolution — **[SOURCE UNVERIFIED]**

**26–40 GHz** — Radar frequency range of a publicly released drone RCS dataset — **[SOURCE UNVERIFIED]**

**20 km** — Maximum range of laser range finders in some military camera systems — **[SOURCE UNVERIFIED]**

**~50 μRad RMS / <50 μRad** — Image stabilization or geo-location precision figure for military-grade airborne camera systems — **[SOURCE UNVERIFIED]**

**0.92°×0.73° to 35.49°×28.72°** — EO/IR pod field-of-view range — **[SOURCE UNVERIFIED]**

**<1 m²** — Mean radar cross section in P-band and X-band for stealth drones — **[SOURCE UNVERIFIED]**

**9,600** — Electromagnetic RCS signatures in a public drone dataset — **[SOURCE UNVERIFIED]**

**36,000** — Approximate number of I/Q samples in a radar pulse — **[SOURCE UNVERIFIED]**

**8** — Number of FLIR Boson 640 IR cameras used in a Galileo observatory — **Galileo Project as stated in document**

**500,000** — Aerial trajectories recorded by the Galileo IR array in 5 months — **Galileo Project as stated in document**

**16%** — Potential anomalous flags from 500k Galileo detector trajectories — **Galileo Project as stated in document**

**36%** — Galileo IR frame-by-frame detection success rate in initial tests — **Galileo Project as stated in document**

**10,000–30,000 ft** — Altitude of metallic orb-shaped UAP in AARO data — **AARO**

**24 seconds** — Length of MQ-9 video of a metallic sphere in the Middle East — **AARO public video as stated in document**

**422** — Metallic sphere reports in the Enigma dataset — **Enigma dataset as stated in document**

**5 miles** — Proximity to military installations for 422 metallic sphere sightings — **Enigma dataset as stated in document**

**8,000** — U.S. UAP reports via Enigma between Dec 2022–June 2025 — **Enigma dataset as stated in document**

**1 a.m.–4 a.m.** — Time window for 8k mostly U.S. sightings — **Enigma dataset as stated in document**

**9,000+** — Recorded USO sightings within 10 miles of U.S. shorelines as of Aug 2025 / June 2025 — **[SOURCE UNVERIFIED]**

**~500** — USO sightings within 5 miles of coastline — **[SOURCE UNVERIFIED]**

**150 / >150** — Reports of transmedium movement into or out of water — **[SOURCE UNVERIFIED]**

**389** — USO reports in California — **[SOURCE UNVERIFIED]**

**306** — USO reports in Florida — **[SOURCE UNVERIFIED]**

**≤0.3** — Enigma credibility-score threshold for USO reports — **Enigma as stated in document**

**>26,000** — Canadian UFO sightings recorded since 1989 — **[SOURCE UNVERIFIED]**

**1,008** — Canadian UAP reports received in 2024 — **[SOURCE UNVERIFIED]**

**1,052** — Canadian UAP reports received in 2025 — **[SOURCE UNVERIFIED]**

**307** — Ontario Canadian UAP report count — **[SOURCE UNVERIFIED]**

**210** — Québec Canadian UAP report count — **[SOURCE UNVERIFIED]**

**131** — British Columbia Canadian UAP report count — **[SOURCE UNVERIFIED]**

**~200** — Average number of UAP reports submitted to the Canadian government per year — **[SOURCE UNVERIFIED]**

**70%** — Canadian reports occurring between dusk and midnight — **[SOURCE UNVERIFIED]**

**52%** — Canadian reports described as simple light in the sky — **[SOURCE UNVERIFIED]**

**11%** — Canadian reports described as sphere-shaped — **[SOURCE UNVERIFIED]**

**5%** — Canadian reports described as triangle or disc-shaped — **[SOURCE UNVERIFIED]**

**4%** — Canadian reports described as cylinder or cigar-shaped — **[SOURCE UNVERIFIED]**

**3%** — Canadian cases deemed unexplained in 2025 — **[SOURCE UNVERIFIED]**

**12.3%** — Canadian case proportion identified as possible “plasma” or “other” — **[SOURCE UNVERIFIED]**

**23 hr 56 min 4.09 sec** — Sidereal day duration relevant for astronomical calibration — **[SOURCE UNVERIFIED]**

**5,700–6,300 km** — Van Allen radiation belt altitude range as stated — **[SOURCE UNVERIFIED]**

**GPS L1 1575.42 MHz** — GPS legacy carrier frequency — **[SOURCE UNVERIFIED]**

**VLF 3–30 kHz** — Band relevant for submarine communications tracking — **[SOURCE UNVERIFIED]**

**ELF 3–3000 Hz** — Extremely Low Frequency range listed for wave generation — **[SOURCE UNVERIFIED]**

**ULF 1–100 mHz** — Plasma-wave frequency range listed — **[SOURCE UNVERIFIED]**

**TRL ≥6** — Technology readiness level threshold listed for adoption — **[SOURCE UNVERIFIED]**

**99.9999%** — Desired confidence level for rejecting null hypotheses — **[SOURCE UNVERIFIED]**

**99%** — Data-cleaning threshold for entry into master databases — **[SOURCE UNVERIFIED]**

**$2B** — Enigma market cap — **[SOURCE UNVERIFIED]**

---

## 2. Real Equations Correctly Applied

( Z = \int L(\theta)\pi(\theta)d\theta ) — Bayesian evidence / marginal likelihood — Applies to comparing mundane vs exotic explanations using likelihoods and priors.

( \frac{P(D|H_0)P(H_0)}{P(D)} ) — Bayes’ theorem component for posterior probability — Applies to updating the probability of a null/prosaic hypothesis after evidence.

( BER = \frac{\int L(D|H_{mundane})\pi(H_{mundane})dH}{\int L(D|H_{exotic})\pi(H_{exotic})dH} ) — Bayes-factor-style model comparison — Applies as a valid structure for ranking mundane vs exotic hypotheses; “BER” label retained but ratio form is the real component.

( a = \frac{\Delta v}{\Delta t} ) — Acceleration — Applies to estimating UAP kinematics from velocity change over time.

( v \approx \frac{r\theta}{\Delta t} ) — Tangential speed from angular displacement and range — Applies because apparent angular motion cannot determine physical velocity without range.

( KE = \frac{1}{2}mv^2 ) — Kinetic energy — Applies to estimating energy implications of high-speed objects if mass and velocity are known.

( \Delta f = \frac{2vf_0}{c} ) — Radar Doppler shift for monostatic radar — Applies to estimating radial velocity from radar frequency shift.

( F_D = \frac{1}{2}\rho v^2 C_d A ) — Drag force — Applies to testing balloon, drone payload, debris, or transmedium claims against expected air/water resistance. The document’s added “suppression” and exotic terms are stripped.

( P = F \cdot v ) — Mechanical power — Applies to estimating power required for acceleration under force at velocity.

( F_{lift} = mg ) — Hover force balance — Applies to testing whether lift, buoyancy, thrust, or tether forces can support an observed object.

( T = 2\pi\sqrt{\frac{L}{g}} ) — Simple pendulum period — Applies to testing whether sway matches a tethered or suspended payload.

( A = \epsilon c l ) — Beer–Lambert absorbance law — Applies to visibility loss through haze, smoke, humidity, pollution, or distance. The document’s added haze/compression terms are not part of the law and are stripped.

( \mathrm{SNR}*{dB} = 10\log*{10}\left(\frac{P_{signal}}{P_{noise}}\right) ) — Signal-to-noise ratio in decibels — Applies to evaluating sensor detectability and data quality.

( R_{max} \propto \sqrt[4]{P_tG_tG_r\sigma} ) — Simplified radar range proportionality — Applies to radar detection range dependence on transmit power, antenna gains, and radar cross section. Constants and denominator terms are omitted in the document.

( P(X=k)=\binom{n}{k}p^k(1-p)^{n-k} ) — Binomial probability mass function — Applies to probability-of-intercept or repeated detection models when trials are independent and detection probability is defined.

( \gamma = \frac{1}{\sqrt{1-v^2/c^2}} ) — Lorentz factor — Applies only to relativistic-speed discussions; not relevant to ordinary UAP cases unless velocities approach a significant fraction of light speed.

( d \approx 4.1\sqrt{h} ) — Radio horizon approximation — Applies to VHF propagation limits when antenna height is known. Units are not specified in the document.

( n\lambda/4 ) — Quarter-wave matching-layer thickness family — Applies to acoustic/sonar or electromagnetic impedance matching.

( S(\rho) = -\mathrm{Tr}(\rho\log\rho) ) — Von Neumann entropy — Applies to quantum-state entropy; not directly established as UAP-relevant in the document.

( -\sum p_i\log p_i ) — Shannon entropy — Applies to categorical uncertainty or spectral/mass-eigenstate probability distributions when probabilities are defined.

( R^2 ) — Coefficient of determination — Applies to model-fit evaluation for trajectory or regression analysis.

( \left(\sum_i \frac{1}{\sigma_i^2}\left(\frac{\partial \mu}{\partial \theta_i}\right)^2\right)^{-1} ) — Scalar Fisher-information inverse form — Applies to estimating parameter uncertainty when measurements, variances, and model sensitivities are defined.

( \cos(\vec e_{text},\vec e_{sensor}) ) — Cosine similarity — Applies to comparing vector embeddings if text and sensor features are embedded in a shared space. The document does not establish that such an embedding is validated.

( \frac{\Delta x}{\Delta t_{gap}} ) — Average velocity over a time gap — Applies to velocity-discontinuity checks if positions and timestamps are known.

( \Delta RCS/\Delta t ) — Rate of radar-cross-section change — Applies to tracking apparent radar-size variability if calibrated RCS time series exist.

( \Delta T_{expected}-\Delta T_{obs} ) — Thermal mismatch residual — Applies to comparing expected heating against observed infrared/thermal signatures if models and measurements are defined.

( N(t)\propto t^{-\kappa} ) — Power-law trend form — Applies only if historical report counts fit a power-law distribution. The document provides no fit.

( \ddot{x}+2\zeta\omega\dot{x}+\omega^2x = F(t) ) — Forced damped oscillator form — Applies to tether, sway, stabilization, or tracking models if force and displacement data exist.

---

## 3. Falsifiable Hypotheses

A humanoid silhouette is a structural hypothesis, not evidence of biology — Test by tracking repeatable geometric keypoints across raw frames and multiple viewing angles — Falsified if body-like proportions fail to persist under rotation, frame-by-frame tracking, or second-angle reconstruction.

The Austin object’s apparent hover may be wind-relative drift — Test by reconstructing wind speed and direction at altitude, object angular motion, range, and projected area — Falsified if motion remains inconsistent with wind, drag, buoyancy, tethering, and drone-payload models.

Silence may be expected from distance, wind, and atmospheric attenuation — Test by estimating range, ambient noise, wind, source acoustic power, and air absorption — Falsified if predicted received sound level exceeds ambient noise by a detectable margin while witnesses report silence.

Shape-changing may be optical/material rather than physical morphing — Test whether apparent morphology changes correlate with viewing angle, illumination, exposure, compression, and reflectivity — Falsified if raw multi-angle imagery shows physical shape changes independent of optical conditions.

False humanoid limbs may arise from shadow, penumbra, or contrast edges — Test raw frames against Sun angle, backlighting geometry, exposure, and edge-detection stability — Falsified if appendage boundaries remain geometrically stable under lighting correction and across independent views.

Reflective shimmer may be angle-dependent reflectance — Test brightness changes against object orientation, Sun angle, camera angle, and material reflectance models — Falsified if brightness changes do not track angle or illumination but track intrinsic motion/energy output.

A suspended humanoid payload may behave like a pendulum-plus-drag system — Test observed sway period against (T=2\pi\sqrt{L/g}), wind profile, tether length, and drone motion — Falsified if sway period and damping cannot match any plausible tether length, payload mass, or wind forcing.

Apparent acceleration cannot be solved without range — Test by obtaining distance from parallax, known-size reference, focus metadata, radar, lidar, or multi-angle triangulation — Falsified only if range is known and acceleration remains anomalous after sensor/platform-motion correction.

Virality may increase narrative complexity faster than evidence — Test claim versions over time against timestamps and raw evidence availability — Falsified if later claims add no unsupported details beyond original evidence.

AI/ML classifiers trained on resolved balloons, drones, kites, birds, fabric, and aircraft may classify the object as mundane — Test using raw video and a validated classifier with calibrated false-positive/false-negative rates — Falsified if model confidently rejects all trained mundane classes under validated conditions.

Multi-sensor confirmation should reduce ambiguity — Test by combining independent optical, infrared, radar, acoustic, ADS-B, weather, and second-angle data — Falsified if independent sensors contradict the existence, location, motion, or timing of the object.

Some high-kinematic UAP estimates may be inflated by range uncertainty — Test by propagating range uncertainty through angular-rate-derived speed and acceleration — Falsified if extreme speeds/accelerations remain under conservative range bounds and platform-motion correction.

Lack of sonic boom in alleged supersonic cases may indicate the velocity estimate is wrong or the interaction model is incomplete — Test calibrated speed, altitude, atmospheric conditions, acoustic records, and shock propagation — Falsified if independently confirmed supersonic atmospheric travel produces no expected acoustic/pressure signature under standard conditions.

Environmental covariances may correlate with unresolved reports — Test UAP reports against weather, visibility, atmospheric optics, military activity, EM environment, and satellite context — Falsified if controlled datasets show no significant association beyond reporting/sensor bias.

Sensor artifacts may explain some cases — Test with sensor calibration, raw telemetry, platform state, optical path, gimbal state, compression chain, and known artifact signatures — Falsified if artifact models fail while independent sensors confirm a physical object.

A small unresolved subset may remain after prosaic resolution — Test by applying standardized, calibrated, multi-sensor review to all cases — Falsified if all unresolved cases resolve to known categories when sufficient data is obtained.

---

## 4. Operational Analytical Frameworks

Layered falsification stack for Austin humanoid UAP — Inputs required: raw frames, timestamps, GPS/location, camera metadata, weather, wind profile, Sun angle, azimuth, ADS-B, drone-event records, independent camera angles — Output produced: surviving explanation layers after air, light, material, camera, and human-perception tests.

Bayesian model comparison for UAP explanations — Inputs required: hypotheses such as balloon, drone, kite, aircraft, hoax, sensor artifact, unknown; likelihoods; priors; observed data — Output produced: ranked hypothesis evidence or Bayes-factor-style comparison.

Fisher-matrix / metadata-fragility analysis — Inputs required: parameter uncertainties for distance, time, location, angle, raw frame timing, platform motion, sensor calibration — Output produced: uncertainty estimate showing which missing variable most weakens confidence.

Frame-by-frame trajectory reconstruction — Inputs required: raw video frames, camera parameters, timestamps, platform motion, object centroid/keypoints, background references — Output produced: angular trajectory, apparent velocity, acceleration bounds, and uncertainty.

Multi-angle reconstruction — Inputs required: two or more independent camera views, baseline separation, time synchronization, camera calibration — Output produced: range, 3D position, velocity, size estimate, reconstruction confidence.

Shape–motion–illumination–metadata graph — Inputs required: silhouette graph, motion graph, illumination graph, metadata graph — Output produced: structured UAP fingerprint for comparison or classification.

UAP feature-vector classification — Inputs required: reflectivity, angular stability, shape persistence, acceleration, wind alignment, sound, shadow behavior, metadata quality — Output produced: classification score against mundane and unresolved categories.

Material/reflectivity assessment — Inputs required: wavelength-dependent brightness, viewing angle, illumination angle, exposure, surface-color/reflectance estimates — Output produced: candidate material behavior such as foil, polymer, metallic coating, fabric, or unknown.

Acoustic plausibility analysis — Inputs required: source noise estimate, distance, wind, air absorption, ambient noise, observer location — Output produced: predicted audibility or inaudibility.

Pendulum payload test — Inputs required: observed sway period, estimated tether length, wind profile, damping, payload size/mass estimate — Output produced: match/mismatch score for drone-suspended or tethered payload hypothesis.

Beer–Lambert / visibility-distortion analysis — Inputs required: path length, atmospheric attenuation/haze/smoke/humidity/pollution proxy, camera compression data — Output produced: expected edge-clarity degradation.

NASA-style UAP scientific framework — Inputs required: standardized reports, calibrated multi-sensor data, environmental context, AI/ML pattern detection, reproducible observations — Output produced: scientifically usable UAP case characterization.

AARO-style prosaic resolution workflow — Inputs required: case reports, sensor data, object type candidates, aviation/drone/balloon/bird/weather data, classified-program review where available — Output produced: resolved prosaic category or unresolved case requiring more data.

ODNI five-bin classification — Inputs required: case data sufficient to assign clutter, natural atmospheric phenomenon, U.S. government/industry development, foreign adversary system, or other — Output produced: explanatory bin.

Public dataset statistical analysis — Inputs required: NUFORC, Enigma, Canadian reports, Project Blue Book or other report databases with location/time/object descriptors — Output produced: reporting patterns, clustering, unresolved fractions, and reporting-bias estimates.

Galileo-style multi-instrument observatory — Inputs required: calibrated IR/optical camera array, trajectory detection pipeline, environmental context, frame-by-frame detection metrics — Output produced: large-scale trajectory dataset and anomalous-candidate flags.

Sensor-fusion covariance minimization — Inputs required: radar, EO, IR, acoustic, platform state, calibration covariance matrices — Output produced: fused estimate with uncertainty bounds.

Null-hypothesis rejection via Monte Carlo sensor simulation — Inputs required: prosaic-object models, sensor models, noise distributions, observation geometry — Output produced: probability that a mundane object could produce the observed data.

---

## 5. Named Technologies and Systems

AARO — U.S. All-domain Anomaly Resolution Office; receives, analyzes, and resolves UAP reports — Relevant as official source for modern UAP case counts and resolutions.

ODNI — Office of the Director of National Intelligence; issued 2021 Preliminary Assessment and 2022 UAP report — Relevant as official source for early modern UAP statistics.

NASA UAP Independent Study Team — 2023 NASA study group — Relevant for scientific recommendations, data-quality requirements, and lack of ET evidence.

NUFORC — Public UFO report database — Relevant as large public sighting dataset.

Project Blue Book — U.S. Air Force UFO investigation, 1947–1969 — Relevant historical baseline with 12,618 cases and 701 unidentified cases.

Galileo Project / Galileo IR array — Observatory concept using multiple IR cameras; document states 8 FLIR Boson 640 cameras and 500,000 trajectories in 5 months — Relevant as calibrated civilian scientific detection approach.

FLIR — Forward-looking infrared imaging — Relevant to public UAP videos and thermal signature analysis.

MWIR cooled thermal sensors — Listed resolution 1,280×1,024 or 512×640 — Relevant for infrared detection and temperature/heat-signature assessment.

EO sensors — Electro-optical sensors listed at 640×512 and 1920×1080 — Relevant for visual tracking and resolution limits.

Radar — Uses range, Doppler, RCS, SNR, and tracking — Relevant for range/velocity confirmation.

Doppler radar — Uses (\Delta f = 2vf_0/c) — Relevant for radial velocity estimation.

Laser range finder / LRF — Listed maximum range 20 km for some systems — Relevant for resolving distance ambiguity.

ADS-B — Aircraft position/broadcast data — Relevant for excluding aircraft and reconstructing air traffic context.

EXIF metadata — Camera file metadata including timestamps, device data, and sometimes GPS — Relevant for authenticity and reconstruction.

GPS L1 — 1575.42 MHz carrier — Relevant to geolocation and timing context.

I/Q radar data — In-phase/quadrature raw radar return samples — Relevant for detailed radar signal analysis.

HRR — High Range Resolution radar mode — Relevant for radar profile characterization.

SAR — Synthetic Aperture Radar — Relevant for detailed radar imaging.

ELINT — Electronic intelligence; intercepting radar or electronic emissions — Relevant for identifying emitters and systems.

MADL — F-35 stealth data-sharing link — Relevant to secure sensor-fusion transmission.

AN/ASQ-228 ATFLIR — Advanced targeting FLIR pod used in Nimitz-related video analysis as stated — Relevant to sensor source for Nimitz video.

AN/AAQ-37 — F-35 Distributed Aperture System for 360° coverage — Relevant as named aircraft sensor suite.

AN/AAQ-40 — F-35 Electro-Optical Targeting System — Relevant as named EO targeting sensor.

AN/APG-81 / APG-81 AESA — F-35 primary AESA radar — Relevant as named radar/sensor-fusion system.

F-35 Lightning II — Fighter aircraft with listed 13.5g structural maximum in document — Relevant as comparison baseline and sensor platform.

MQ-9 — Drone platform associated with 24-second metallic sphere video in document — Relevant as named sensor platform.

VLF 3–30 kHz — Very Low Frequency band — Relevant for submarine communications / USO-context claims.

ELF 3–3000 Hz — Extremely Low Frequency band — Relevant for wave generation / submarine or ionospheric context as stated.

ULF 1–100 mHz — Ultra Low Frequency range — Relevant for plasma-wave modulation claims as stated.

Hyperspectral solar-glint imaging — Named technique for underwater detection — Relevant to USO/underwater-object search.

Computational Electromagnetics / CEM — Tools for polarimetric signature generation — Relevant to RCS modeling.

Random Forest — AI algorithm for analyzing eyewitness statement variables — Relevant to structured classification.

Kernel Density Estimation / KDE — Statistical method for “pattern of life” analysis — Relevant for spatial/temporal clustering.

Mean Average Precision / mAP — Object detection metric — Relevant for evaluating ML detection performance.

Bit Error Rate / BER — Communications/classification error metric — Relevant to classifier or signal-performance analysis.

RCS drone dataset — Public drone radar-cross-section dataset, 26–40 GHz and 9,600 signatures as stated — Relevant baseline for drone identification.

---

## 6. Genuine Open Scientific Questions

What minimum dataset quality is required to move from “unidentified” to “characterized”? — Remains unresolved because many cases lack calibrated, reproducible, multi-sensor data — Would be resolved by standardized thresholds for calibration, metadata, multi-angle coverage, and uncertainty.

Which missing variable most destroys confidence: distance, time, location, angle, or raw frames? — Remains unresolved because public cases often lack complete telemetry — Would be resolved by raw sensor data, camera metadata, platform state, and uncertainty propagation.

What precise range calibration explains the highest kinematic estimates without violating energy/momentum conservation? — Remains unresolved because range is often uncertain — Would be resolved by radar/lidar/parallax/triangulation range with synchronized timing.

How much do optical/parallax artifacts contribute to remaining video-based mysteries? — Remains unresolved because many videos are single-sensor or lack full geometry — Would be resolved by platform telemetry, camera model, object range, and independent views.

Can standardized multi-instrument arrays confirm or falsify the unresolved subset? — Remains unresolved because UAP observations are usually non-reproducible and opportunistic — Would be resolved by calibrated observatories collecting radar, optical, IR, acoustic, weather, and timing data.

What environmental covariances correlate most strongly with unresolved cases? — Remains unresolved because weather, atmosphere, EM fields, and observational context are inconsistently recorded — Would be resolved by linking reports to satellite, weather, EM, and visibility datasets.

Can AI trained on resolved cases reliably flag novel anomalies in real time with low false positives? — Remains unresolved because training data, labels, and false-positive baselines are incomplete — Would be resolved by validated datasets of resolved and unresolved cases plus prospective testing.

Is the reporting surge caused by phenomenon changes or by detection/reporting improvements? — Remains unresolved because stigma, policy, media attention, and sensor coverage changed together — Would be resolved by controlled reporting-rate models normalized by observer density, sensor density, and reporting incentives.

Why does a small unexplained fraction persist across decades despite improved sensors? — Remains unresolved because “unexplained” can mean insufficient data, rare natural phenomena, adversarial technology, sensor artifact, or genuine unknown — Would be resolved by complete case data and consistent resolution criteria across eras.

What material science constraints arise from alleged non-heating high-speed flight? — Remains unresolved because velocity, range, material, and thermal measurements are uncertain — Would be resolved by calibrated IR/thermal data, speed/range confirmation, and atmospheric-interaction modeling.

Do high-speed cases truly lack sonic booms or are speeds overestimated? — Remains unresolved because acoustic records and range-calibrated speeds are usually absent — Would be resolved by synchronized acoustic sensors and independently confirmed supersonic trajectories.

Can Earth-observing satellite archives retroactively contextualize historical UAP events? — Remains unresolved because event timing/location precision may be insufficient — Would be resolved by exact timestamps/locations and access to satellite environmental records.

Is there a detectable statistical signature distinguishing foreign technology, classified U.S. technology, natural phenomena, and true unknowns? — Remains unresolved because classified and adversarial baselines are incomplete — Would be resolved by shared feature sets, resolved training labels, and controlled classification.

How do human factors such as training, expectation, and caption priming affect multi-observer consistency? — Remains unresolved because observer priors are rarely measured — Would be resolved by controlled perception studies and report-version histories.

What role do public sighting patterns play in biasing military-focused datasets? — Remains unresolved because public and military datasets differ in observer population, sensor availability, and reporting incentives — Would be resolved by normalized cross-dataset statistical comparison.

Can reporting templates and metadata standards reduce unresolved rates? — Remains unresolved because many historical reports lack metadata — Would be resolved by prospective comparison of standardized vs non-standardized reporting outcomes.

What single mundane test would collapse a given anomaly fastest? — Remains unresolved case-by-case because missing variables differ by sighting — Would be resolved by falsification-gradient analysis over wind, light, drone, balloon, metadata, and sensor-artifact hypotheses.

Was there radar, infrared, acoustic, magnetometer, ADS-B, or second-angle correlation for the Austin humanoid claim? — Remains unresolved because the public claim lacks corroborating sensor data in the document — Would be resolved by raw footage, timestamp, location, sensor logs, ADS-B, weather, and independent videos.

Does the Austin object’s drift match wind speed and direction at altitude? — Remains unresolved because altitude/range and wind profile are not provided — Would be resolved by weather soundings, estimated altitude, object trajectory, and frame timing.

Are Austin “appendages” real object edges or penumbra/compression artifacts? — Remains unresolved because raw frames and lighting geometry are not provided — Would be resolved by raw video, exposure data, Sun angle, edge stability, and second-angle imagery.

Does the Austin object contain pendulum-period signatures consistent with a tethered payload? — Remains unresolved because frame-by-frame sway period and tether geometry are not provided — Would be resolved by raw video tracking and pendulum-model comparison.

Can the Austin object be encoded as a shape-motion-light-metadata graph and matched to known mundane classes? — Remains unresolved because raw data and reference classifier are absent — Would be resolved by extracted graph features and a validated comparison dataset.
