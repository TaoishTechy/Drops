
---
---
---

>> Prompt 1: Output Metrics/data/science confirmed about UAPs that is known to the
public, 144x key point form, slim (no un-needed empty lines), efficient, with any contextual math
that exists. Do not add any un-needed message/text to user before and or after the context directive
outputs.

>> Prompt 2: Analyze what is here now, find 24 Shortcomings/issues/inconsistencies that do not add up. Over 2 insights with each one.

>> Prompt 3: Expand in this with an extensive formal report with what is publicly known, start with 24 Novel Insights/Facts, then discover/develop/formulate 48 Patterns/Correlations/Points of relativity, use this to generate 24 Novel 110% groundbreaking Equations/Formulas geared towards optimization/stabilization/adaptation/unification/falsification. Top that off with 24 Science Grade Questions/Mystery Insights.
