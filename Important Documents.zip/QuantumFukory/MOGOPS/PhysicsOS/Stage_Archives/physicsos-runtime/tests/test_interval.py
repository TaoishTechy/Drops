"""Test Interval arithmetic."""
import sys, os, math, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.interval import Interval


class TestIntervalConstruction(unittest.TestCase):
    """Test Interval creation and constructors."""

    def test_basic_construction(self):
        iv = Interval(1.0, 5.0)
        self.assertAlmostEqual(iv.lower, 1.0)
        self.assertAlmostEqual(iv.upper, 5.0)

    def test_exact_construction(self):
        iv = Interval.exact(3.0)
        self.assertAlmostEqual(iv.lower, 3.0)
        self.assertAlmostEqual(iv.upper, 3.0)
        self.assertAlmostEqual(iv.width, 0.0)
        self.assertAlmostEqual(iv.midpoint, 3.0)

    def test_from_value_with_half_width(self):
        iv = Interval.from_value(10.0, half_width=2.0)
        self.assertAlmostEqual(iv.lower, 8.0)
        self.assertAlmostEqual(iv.upper, 12.0)
        self.assertAlmostEqual(iv.midpoint, 10.0)

    def test_from_value_no_half_width(self):
        iv = Interval.from_value(7.0)
        self.assertAlmostEqual(iv.lower, 7.0)
        self.assertAlmostEqual(iv.upper, 7.0)

    def test_inverted_interval_raises(self):
        with self.assertRaises(ValueError):
            Interval(5.0, 3.0)

    def test_empty_interval(self):
        iv = Interval.empty()
        self.assertTrue(iv.is_empty)
        self.assertAlmostEqual(iv.width, 0.0)

    def test_entire_interval(self):
        iv = Interval.entire()
        self.assertEqual(iv.lower, float('-inf'))
        self.assertEqual(iv.upper, float('inf'))

    def test_hull_of_values(self):
        iv = Interval.hull([3.0, 7.0, 1.0, 9.0])
        self.assertAlmostEqual(iv.lower, 1.0)
        self.assertAlmostEqual(iv.upper, 9.0)

    def test_hull_of_empty_list(self):
        iv = Interval.hull([])
        self.assertTrue(iv.is_empty)


class TestIntervalAddition(unittest.TestCase):
    """Test interval addition (__add__)."""

    def test_add_intervals(self):
        a = Interval(1.0, 3.0)
        b = Interval(2.0, 5.0)
        result = a + b
        self.assertAlmostEqual(result.lower, 3.0)
        self.assertAlmostEqual(result.upper, 8.0)

    def test_add_scalar(self):
        a = Interval(1.0, 3.0)
        result = a + 2.0
        self.assertAlmostEqual(result.lower, 3.0)
        self.assertAlmostEqual(result.upper, 5.0)

    def test_radd_scalar(self):
        a = Interval(1.0, 3.0)
        result = 2.0 + a
        self.assertAlmostEqual(result.lower, 3.0)
        self.assertAlmostEqual(result.upper, 5.0)

    def test_add_empty_returns_empty(self):
        a = Interval.empty()
        b = Interval(1.0, 3.0)
        result = a + b
        self.assertTrue(result.is_empty)


class TestIntervalSubtraction(unittest.TestCase):
    """Test interval subtraction (__sub__)."""

    def test_sub_intervals(self):
        a = Interval(5.0, 10.0)
        b = Interval(1.0, 3.0)
        result = a - b
        self.assertAlmostEqual(result.lower, 2.0)
        self.assertAlmostEqual(result.upper, 9.0)

    def test_sub_scalar(self):
        a = Interval(5.0, 10.0)
        result = a - 2.0
        self.assertAlmostEqual(result.lower, 3.0)
        self.assertAlmostEqual(result.upper, 8.0)

    def test_rsub_scalar(self):
        a = Interval(1.0, 3.0)
        result = 5.0 - a
        self.assertAlmostEqual(result.lower, 2.0)
        self.assertAlmostEqual(result.upper, 4.0)

    def test_sub_empty_returns_empty(self):
        a = Interval.empty()
        b = Interval(1.0, 3.0)
        self.assertTrue((a - b).is_empty)


class TestIntervalMultiplication(unittest.TestCase):
    """Test interval multiplication (__mul__)."""

    def test_mul_positive_intervals(self):
        a = Interval(2.0, 4.0)
        b = Interval(1.0, 3.0)
        result = a * b
        self.assertAlmostEqual(result.lower, 2.0)
        self.assertAlmostEqual(result.upper, 12.0)

    def test_mul_negative_intervals(self):
        a = Interval(-4.0, -2.0)
        b = Interval(1.0, 3.0)
        result = a * b
        self.assertAlmostEqual(result.lower, -12.0)
        self.assertAlmostEqual(result.upper, -2.0)

    def test_mul_straddling_interval(self):
        a = Interval(-2.0, 3.0)
        b = Interval(-1.0, 4.0)
        result = a * b
        self.assertAlmostEqual(result.lower, -8.0)
        self.assertAlmostEqual(result.upper, 12.0)

    def test_mul_scalar_positive(self):
        a = Interval(1.0, 3.0)
        result = a * 2.0
        self.assertAlmostEqual(result.lower, 2.0)
        self.assertAlmostEqual(result.upper, 6.0)

    def test_mul_scalar_negative(self):
        a = Interval(1.0, 3.0)
        result = a * -2.0
        self.assertAlmostEqual(result.lower, -6.0)
        self.assertAlmostEqual(result.upper, -2.0)

    def test_mul_empty_returns_empty(self):
        a = Interval.empty()
        b = Interval(1.0, 3.0)
        self.assertTrue((a * b).is_empty)


class TestIntervalDivision(unittest.TestCase):
    """Test interval division (__truediv__)."""

    def test_div_positive_intervals(self):
        a = Interval(6.0, 12.0)
        b = Interval(2.0, 3.0)
        result = a / b
        self.assertAlmostEqual(result.lower, 2.0)
        self.assertAlmostEqual(result.upper, 6.0)

    def test_div_by_zero_interval_raises(self):
        a = Interval(1.0, 5.0)
        b = Interval(-1.0, 1.0)
        with self.assertRaises(ZeroDivisionError):
            _ = a / b

    def test_div_by_exact_zero_raises(self):
        a = Interval(1.0, 5.0)
        b = Interval.exact(0.0)
        with self.assertRaises(ZeroDivisionError):
            _ = a / b

    def test_div_by_scalar(self):
        a = Interval(6.0, 12.0)
        result = a / 3.0
        self.assertAlmostEqual(result.lower, 2.0)
        self.assertAlmostEqual(result.upper, 4.0)

    def test_div_by_scalar_zero_raises(self):
        a = Interval(1.0, 5.0)
        with self.assertRaises(ZeroDivisionError):
            _ = a / 0.0

    def test_div_empty_returns_empty(self):
        a = Interval.empty()
        b = Interval(1.0, 3.0)
        self.assertTrue((a / b).is_empty)


class TestIntervalNegation(unittest.TestCase):
    """Test interval negation (__neg__)."""

    def test_negate_positive(self):
        a = Interval(1.0, 3.0)
        result = -a
        self.assertAlmostEqual(result.lower, -3.0)
        self.assertAlmostEqual(result.upper, -1.0)

    def test_negate_straddling(self):
        a = Interval(-2.0, 5.0)
        result = -a
        self.assertAlmostEqual(result.lower, -5.0)
        self.assertAlmostEqual(result.upper, 2.0)

    def test_negate_empty(self):
        self.assertTrue((-Interval.empty()).is_empty)


class TestIntervalOverlapsAndIntersection(unittest.TestCase):
    """Test overlaps and intersection methods."""

    def test_overlapping_intervals(self):
        a = Interval(1.0, 5.0)
        b = Interval(3.0, 8.0)
        self.assertTrue(a.overlaps(b))
        self.assertTrue(b.overlaps(a))

    def test_non_overlapping_intervals(self):
        a = Interval(1.0, 3.0)
        b = Interval(4.0, 6.0)
        self.assertFalse(a.overlaps(b))

    def test_adjacent_intervals(self):
        a = Interval(1.0, 3.0)
        b = Interval(3.0, 5.0)
        self.assertTrue(a.overlaps(b))

    def test_intersection_of_overlapping(self):
        a = Interval(1.0, 5.0)
        b = Interval(3.0, 8.0)
        result = a.intersection(b)
        self.assertAlmostEqual(result.lower, 3.0)
        self.assertAlmostEqual(result.upper, 5.0)

    def test_intersection_of_non_overlapping_is_empty(self):
        a = Interval(1.0, 3.0)
        b = Interval(4.0, 6.0)
        result = a.intersection(b)
        self.assertTrue(result.is_empty)

    def test_empty_interval_does_not_overlap(self):
        a = Interval.empty()
        b = Interval(1.0, 5.0)
        self.assertFalse(a.overlaps(b))
        self.assertFalse(b.overlaps(a))


class TestIntervalContains(unittest.TestCase):
    """Test contains method."""

    def test_contains_middle(self):
        iv = Interval(1.0, 5.0)
        self.assertTrue(iv.contains(3.0))

    def test_contains_lower_bound(self):
        iv = Interval(1.0, 5.0)
        self.assertTrue(iv.contains(1.0))

    def test_contains_upper_bound(self):
        iv = Interval(1.0, 5.0)
        self.assertTrue(iv.contains(5.0))

    def test_does_not_contain_outside(self):
        iv = Interval(1.0, 5.0)
        self.assertFalse(iv.contains(0.0))
        self.assertFalse(iv.contains(6.0))


class TestIntervalEquality(unittest.TestCase):
    """Test __eq__ method."""

    def test_equal_intervals(self):
        self.assertEqual(Interval(1.0, 5.0), Interval(1.0, 5.0))

    def test_unequal_intervals(self):
        self.assertNotEqual(Interval(1.0, 5.0), Interval(1.0, 6.0))

    def test_empty_intervals_equal(self):
        self.assertEqual(Interval.empty(), Interval.empty())

    def test_interval_not_equal_to_non_interval(self):
        self.assertNotEqual(Interval(1.0, 5.0), 42)


class TestIntervalUnion(unittest.TestCase):
    """Test union method."""

    def test_union_of_overlapping(self):
        a = Interval(1.0, 5.0)
        b = Interval(3.0, 8.0)
        result = a.union(b)
        self.assertAlmostEqual(result.lower, 1.0)
        self.assertAlmostEqual(result.upper, 8.0)

    def test_union_with_empty(self):
        a = Interval.empty()
        b = Interval(1.0, 5.0)
        self.assertEqual(a.union(b), b)

    def test_empty_union_returns_other(self):
        a = Interval(1.0, 5.0)
        b = Interval.empty()
        self.assertEqual(a.union(b), a)


class TestIntervalToUncertainty(unittest.TestCase):
    """Test to_uncertainty conversion."""

    def test_converts_correctly(self):
        iv = Interval(2.0, 8.0)
        unc = iv.to_uncertainty(confidence=0.95)
        self.assertAlmostEqual(unc.lower, 2.0)
        self.assertAlmostEqual(unc.upper, 8.0)
        self.assertAlmostEqual(unc.confidence, 0.95)


if __name__ == "__main__":
    unittest.main()
