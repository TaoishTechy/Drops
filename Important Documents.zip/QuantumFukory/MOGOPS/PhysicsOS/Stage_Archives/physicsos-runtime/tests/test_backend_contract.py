"""Test backend contracts, validation, and verification."""
import sys, os, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.backend_contract import (
    BackendContract, ContractResult, validate_backend_contract,
)
from backend.cpu_backend import make_cpu_contract, cpu_compute
from backend.simulated_analog_backend import make_analog_contract, analog_compute
from backend.simulated_gpu_backend import make_gpu_contract, gpu_compute
from backend.verifier import verify_backend_result, VerificationResult


class TestCPUContract(unittest.TestCase):
    """Test CPU backend contract."""

    def test_cpu_contract_creation(self):
        contract = make_cpu_contract()
        self.assertEqual(contract.backend_id, "cpu_0")
        self.assertEqual(contract.backend_type, "cpu")
        self.assertTrue(contract.exact_security_allowed)
        self.assertAlmostEqual(contract.reproducibility_score, 1.0)

    def test_cpu_precision_range(self):
        contract = make_cpu_contract()
        self.assertAlmostEqual(contract.precision_range[0], 0.0)
        self.assertAlmostEqual(contract.precision_range[1], 1e-15)

    def test_cpu_calibration_never_expires(self):
        contract = make_cpu_contract()
        self.assertTrue(contract.calibration_valid)

    def test_cpu_contract_accepted(self):
        contract = make_cpu_contract()
        result = validate_backend_contract(contract, result_uncertainty=1e-16, policy_max_uncertainty=0.1)
        self.assertTrue(result.accepted)
        self.assertEqual(result.calibration_status, "VALID")


class TestAnalogContractExpired(unittest.TestCase):
    """Test analog contract with expired calibration is rejected."""

    def test_expired_calibration_rejected(self):
        contract = make_analog_contract(calibration_age=200.0, calibration_max_age=120.0)
        self.assertFalse(contract.calibration_valid)
        result = validate_backend_contract(contract, result_uncertainty=0.05, policy_max_uncertainty=0.1)
        self.assertFalse(result.accepted)
        self.assertIn("Calibration expired", result.reason)
        self.assertEqual(result.calibration_status, "EXPIRED")

    def test_analog_verifier_required_fails(self):
        contract = make_analog_contract(calibration_age=30.0, calibration_max_age=120.0)
        result = validate_backend_contract(contract, result_uncertainty=0.05, policy_max_uncertainty=0.1)
        self.assertFalse(result.accepted)
        self.assertIn("Verifier check required", result.reason)


class TestAnalogContractValid(unittest.TestCase):
    """Test analog contract with valid calibration is accepted (unless verifier needed)."""

    def test_valid_calibration_passes_cal_check(self):
        contract = make_analog_contract(calibration_age=30.0, calibration_max_age=120.0)
        self.assertTrue(contract.calibration_valid)
        # But verifier_required will still cause rejection
        self.assertTrue(contract.verifier_required)

    def test_precision_range(self):
        contract = make_analog_contract()
        self.assertAlmostEqual(contract.precision_range[0], 0.01)
        self.assertAlmostEqual(contract.precision_range[1], 0.1)

    def test_not_security_allowed(self):
        contract = make_analog_contract()
        self.assertFalse(contract.exact_security_allowed)

    def test_has_noise_and_drift_models(self):
        contract = make_analog_contract()
        self.assertIsNotNone(contract.noise_model)
        self.assertIsNotNone(contract.drift_model)

    def test_has_failure_modes(self):
        contract = make_analog_contract()
        self.assertTrue(len(contract.failure_modes) > 0)


class TestGPUContract(unittest.TestCase):
    """Test GPU backend contract."""

    def test_gpu_contract_creation(self):
        contract = make_gpu_contract()
        self.assertEqual(contract.backend_id, "sim_gpu_0")
        self.assertEqual(contract.backend_type, "gpu")

    def test_gpu_precision_range(self):
        contract = make_gpu_contract()
        self.assertAlmostEqual(contract.precision_range[0], 1e-7)
        self.assertAlmostEqual(contract.precision_range[1], 1e-6)

    def test_gpu_calibration_valid(self):
        contract = make_gpu_contract()
        self.assertTrue(contract.calibration_valid)

    def test_gpu_contract_accepted(self):
        contract = make_gpu_contract()
        result = validate_backend_contract(contract, result_uncertainty=1e-7, policy_max_uncertainty=1e-5)
        self.assertTrue(result.accepted)

    def test_gpu_not_security_allowed(self):
        contract = make_gpu_contract()
        self.assertFalse(contract.exact_security_allowed)

    def test_gpu_has_failure_modes(self):
        contract = make_gpu_contract()
        self.assertTrue(len(contract.failure_modes) > 0)


class TestBackendContractProperties(unittest.TestCase):
    """Test BackendContract property methods and repr."""

    def test_calibration_valid_property(self):
        c = BackendContract(backend_id="t", backend_type="cpu", precision_range=(0, 0.1),
                            calibration_age_seconds=50, calibration_max_age_seconds=100)
        self.assertTrue(c.calibration_valid)

    def test_calibration_expired_property(self):
        c = BackendContract(backend_id="t", backend_type="cpu", precision_range=(0, 0.1),
                            calibration_age_seconds=150, calibration_max_age_seconds=100)
        self.assertFalse(c.calibration_valid)

    def test_precision_string(self):
        c = BackendContract(backend_id="t", backend_type="cpu", precision_range=(0.01, 0.1))
        self.assertIn("0.01", c.precision_string)
        self.assertIn("0.1", c.precision_string)

    def test_repr_shows_calibrated(self):
        c = BackendContract(backend_id="test_id", backend_type="cpu", precision_range=(0, 0.1),
                            calibration_age_seconds=10, calibration_max_age_seconds=100)
        r = repr(c)
        self.assertIn("CALIBRATED", r)
        self.assertIn("test_id", r)

    def test_repr_shows_expired(self):
        c = BackendContract(backend_id="test_id", backend_type="cpu", precision_range=(0, 0.1),
                            calibration_age_seconds=200, calibration_max_age_seconds=100)
        r = repr(c)
        self.assertIn("EXPIRED", r)


class TestValidateBackendContractUncertainty(unittest.TestCase):
    """Test validate_backend_contract with various uncertainty scenarios."""

    def test_high_uncertainty_rejected(self):
        contract = make_cpu_contract()
        result = validate_backend_contract(contract, result_uncertainty=1.0, policy_max_uncertainty=0.1)
        self.assertFalse(result.accepted)
        self.assertIn("Uncertainty", result.reason)

    def test_exact_uncertainty_accepted(self):
        contract = make_cpu_contract()
        result = validate_backend_contract(contract, result_uncertainty=0.0, policy_max_uncertainty=0.1)
        self.assertTrue(result.accepted)

    def test_default_failure_modes_empty(self):
        c = BackendContract(backend_id="t", backend_type="cpu", precision_range=(0, 0.1))
        self.assertEqual(c.failure_modes, [])


class TestVerifyBackendResult(unittest.TestCase):
    """Test verify_backend_result function."""

    def test_passing_verification(self):
        contract = make_cpu_contract()
        result = verify_backend_result(
            contract=contract,
            result=5.0,
            expected_range=(4.0, 6.0),
            uncertainty=1e-16,
        )
        self.assertTrue(result.passed)
        self.assertAlmostEqual(result.confidence, 1.0)

    def test_result_out_of_range(self):
        contract = make_cpu_contract()
        result = verify_backend_result(
            contract=contract,
            result=10.0,
            expected_range=(4.0, 6.0),
            uncertainty=1e-16,
        )
        self.assertFalse(result.passed)
        self.assertIn("outside expected range", result.failures[0])

    def test_expired_calibration_fails(self):
        contract = make_analog_contract(calibration_age=200.0, calibration_max_age=120.0)
        result = verify_backend_result(
            contract=contract,
            result=5.0,
            expected_range=(4.0, 6.0),
            uncertainty=0.05,
        )
        self.assertFalse(result.passed)
        self.assertIn("Calibration", " ".join(result.failures))

    def test_precision_out_of_range_fails(self):
        contract = make_cpu_contract()
        result = verify_backend_result(
            contract=contract,
            result=5.0,
            expected_range=(4.0, 6.0),
            uncertainty=0.01,
        )
        self.assertFalse(result.passed)
        self.assertIn("precision", " ".join(result.failures))

    def test_checks_performed_populated(self):
        contract = make_cpu_contract()
        result = verify_backend_result(
            contract=contract,
            result=5.0,
            expected_range=(4.0, 6.0),
            uncertainty=1e-16,
        )
        self.assertEqual(len(result.checks_performed), 3)


class TestBackendComputations(unittest.TestCase):
    """Test that backend compute functions return floats."""

    def test_cpu_compute_returns_input(self):
        self.assertAlmostEqual(cpu_compute(5.0), 5.0)

    def test_analog_compute_returns_float(self):
        result = analog_compute(5.0, noise_scale=0.0)
        self.assertAlmostEqual(result, 5.0)

    def test_gpu_compute_returns_float(self):
        result = gpu_compute(5.0)
        self.assertIsInstance(result, float)


if __name__ == "__main__":
    unittest.main()
