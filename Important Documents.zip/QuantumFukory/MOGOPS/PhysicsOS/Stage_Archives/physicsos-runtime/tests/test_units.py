"""Test SI unit dimensional analysis."""
import sys, os, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.units import (
    Unit, DimensionalError,
    DIMENSIONLESS, METER, SECOND, KILOGRAM, AMPERE, KELVIN, MOLE, CANDELA,
    VELOCITY, ACCELERATION, NEWTON, JOULE, WATT, HERTZ, VOLT, OHM, FARAD, TESLA,
)


class TestCompatibleUnitsAddition(unittest.TestCase):
    """Test that compatible units can be added."""

    def test_meter_plus_meter(self):
        result = METER + METER
        self.assertEqual(result, METER)

    def test_second_plus_second(self):
        result = SECOND + SECOND
        self.assertEqual(result, SECOND)

    def test_velocity_plus_velocity(self):
        result = VELOCITY + VELOCITY
        self.assertEqual(result, VELOCITY)

    def test_dimensionless_plus_dimensionless(self):
        result = DIMENSIONLESS + DIMENSIONLESS
        self.assertEqual(result, DIMENSIONLESS)


class TestIncompatibleUnitsRaiseError(unittest.TestCase):
    """Test that incompatible units raise DimensionalError."""

    def test_meter_plus_second_raises(self):
        with self.assertRaises(DimensionalError):
            _ = METER + SECOND

    def test_meter_minus_kilogram_raises(self):
        with self.assertRaises(DimensionalError):
            _ = METER - KILOGRAM

    def test_joule_plus_meter_raises(self):
        with self.assertRaises(DimensionalError):
            _ = JOULE + METER

    def test_velocity_plus_second_raises(self):
        with self.assertRaises(DimensionalError):
            _ = VELOCITY + SECOND


class TestUnitMultiplication(unittest.TestCase):
    """Test unit multiplication (m/s * s = m)."""

    def test_velocity_times_second_equals_meter(self):
        result = VELOCITY * SECOND
        self.assertEqual(result, METER)

    def test_meter_times_meter_equals_meter_squared(self):
        result = METER * METER
        expected = Unit(m=2)
        self.assertEqual(result, expected)

    def test_meter_times_kilogram(self):
        result = METER * KILOGRAM
        expected = Unit(kg=1, m=1)
        self.assertEqual(result, expected)

    def test_multiply_by_scalar_returns_same_unit(self):
        result = METER * 5
        self.assertEqual(result, METER)

    def test_multiply_dimensionless_anything(self):
        self.assertEqual(DIMENSIONLESS * METER, METER)


class TestUnitDivision(unittest.TestCase):
    """Test unit division (m / s = m*s^-1)."""

    def test_meter_divided_by_second_equals_velocity(self):
        result = METER / SECOND
        self.assertEqual(result, VELOCITY)

    def test_velocity_divided_by_second_equals_acceleration(self):
        result = VELOCITY / SECOND
        self.assertEqual(result, ACCELERATION)

    def test_joule_divided_by_meter_equals_newton(self):
        result = JOULE / METER
        self.assertEqual(result, NEWTON)

    def test_watt_divided_by_velocity_equals_newton(self):
        result = WATT / VELOCITY
        self.assertEqual(result, NEWTON)

    def test_meter_divided_by_meter_equals_dimensionless(self):
        result = METER / METER
        self.assertEqual(result, DIMENSIONLESS)


class TestUnitPower(unittest.TestCase):
    """Test unit exponentiation (m^2)."""

    def test_meter_squared(self):
        result = METER ** 2
        expected = Unit(m=2)
        self.assertEqual(result, expected)

    def test_meter_cubed(self):
        result = METER ** 3
        expected = Unit(m=3)
        self.assertEqual(result, expected)

    def test_second_negative_power(self):
        result = SECOND ** -1
        expected = Unit(s=-1)
        self.assertEqual(result, expected)

    def test_zero_power(self):
        result = METER ** 0
        self.assertEqual(result, DIMENSIONLESS)

    def test_non_integer_power_raises(self):
        with self.assertRaises(TypeError):
            _ = METER ** 0.5

    def test_complex_unit_power(self):
        result = VELOCITY ** 2
        # m*s^-1 squared = m^2 * s^-2
        expected = Unit(m=2, s=-2)
        self.assertEqual(result, expected)


class TestPredefinedUnits(unittest.TestCase):
    """Test predefined unit constants are correct."""

    def test_meter(self):
        self.assertEqual(METER, Unit(m=1))

    def test_second(self):
        self.assertEqual(SECOND, Unit(s=1))

    def test_velocity(self):
        self.assertEqual(VELOCITY, Unit(m=1, s=-1))

    def test_acceleration(self):
        self.assertEqual(ACCELERATION, Unit(m=1, s=-2))

    def test_newton(self):
        self.assertEqual(NEWTON, Unit(kg=1, m=1, s=-2))

    def test_joule(self):
        self.assertEqual(JOULE, Unit(kg=1, m=2, s=-2))

    def test_watt(self):
        self.assertEqual(WATT, Unit(kg=1, m=2, s=-3))

    def test_hertz(self):
        self.assertEqual(HERTZ, Unit(s=-1))

    def test_dimensionless(self):
        self.assertEqual(DIMENSIONLESS, Unit())
        self.assertTrue(DIMENSIONLESS.is_dimensionless)


class TestUnitCompatibility(unittest.TestCase):
    """Test Unit.compatible method."""

    def test_same_unit_compatible(self):
        self.assertTrue(METER.compatible(METER))

    def test_velocity_with_same_dims(self):
        v1 = Unit(m=1, s=-1)
        v2 = Unit(m=1, s=-1)
        self.assertTrue(v1.compatible(v2))

    def test_meter_incompatible_with_second(self):
        self.assertFalse(METER.compatible(SECOND))

    def test_dimensionless_only_compatible_with_dimensionless(self):
        self.assertTrue(DIMENSIONLESS.compatible(DIMENSIONLESS))
        self.assertFalse(DIMENSIONLESS.compatible(METER))


class TestUnitProperties(unittest.TestCase):
    """Test Unit properties and edge cases."""

    def test_is_dimensionless_true(self):
        self.assertTrue(Unit().is_dimensionless)

    def test_is_dimensionless_false(self):
        self.assertFalse(METER.is_dimensionless)

    def test_hash_is_consistent(self):
        h1 = hash(METER)
        h2 = hash(METER)
        self.assertEqual(h1, h2)

    def test_repr_meter(self):
        self.assertIn("m", repr(METER))

    def test_repr_velocity(self):
        r = repr(VELOCITY)
        self.assertIn("m", r)
        self.assertIn("s", r)

    def test_repr_dimensionless(self):
        self.assertEqual(repr(DIMENSIONLESS), "dimensionless")

    def test_repr_joule(self):
        r = repr(JOULE)
        self.assertIn("kg", r)
        self.assertIn("m", r)
        self.assertIn("s", r)

    def test_equality_with_non_unit(self):
        self.assertNotEqual(METER, 5)
        self.assertNotEqual(METER, "meter")


class TestUnitSubtraction(unittest.TestCase):
    """Test unit subtraction."""

    def test_meter_minus_meter(self):
        result = METER - METER
        self.assertEqual(result, METER)

    def test_incompatible_subtraction_raises(self):
        with self.assertRaises(DimensionalError):
            _ = METER - SECOND


class TestComplexUnitCompositions(unittest.TestCase):
    """Test derived unit compositions."""

    def test_newton_is_kg_m_s2(self):
        self.assertEqual(NEWTON, KILOGRAM * METER * SECOND ** -2)

    def test_joule_is_newton_meter(self):
        self.assertEqual(JOULE, NEWTON * METER)

    def test_watt_is_joule_per_second(self):
        self.assertEqual(WATT, JOULE / SECOND)

    def test_volt_is_watt_per_ampere(self):
        self.assertEqual(VOLT, WATT / AMPERE)

    def test_ohm_is_volt_per_ampere(self):
        self.assertEqual(OHM, VOLT / AMPERE)

    def test_farad_is_ampere_squared_second_per_kg_per_meter_squared(self):
        self.assertEqual(FARAD, Unit(kg=-1, m=-2, s=4, A=2))

    def test_tesla_is_kg_per_second_squared_per_ampere(self):
        self.assertEqual(TESLA, Unit(kg=1, s=-2, A=-1))


if __name__ == "__main__":
    unittest.main()
