"""Test memory system: ExactObject, ApproxField, and handle_memory_pressure."""
import sys, os, hashlib, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.uncertainty import Uncertainty
from core.provenance import ProvenanceChain
from memory.exact_object import ExactObject
from memory.approximate_field import ApproxField, CoarseningPolicy
from memory.no_oom_degrader import handle_memory_pressure, DegradationReport, DegradationAction


class TestExactObjectIntegrity(unittest.TestCase):
    """Test ExactObject creation and integrity verification."""

    def test_creation_with_correct_hash(self):
        data = b"hello physics"
        hash_val = hashlib.sha256(data).hexdigest()
        obj = ExactObject(
            object_id="obj1",
            bytes_data=data,
            integrity_hash=hash_val,
            provenance=ProvenanceChain(source="test"),
        )
        self.assertTrue(obj.verify_integrity())

    def test_tampered_data_fails_integrity(self):
        data = b"hello physics"
        hash_val = hashlib.sha256(data).hexdigest()
        obj = ExactObject(
            object_id="obj2",
            bytes_data=b"tampered!!!",
            integrity_hash=hash_val,
            provenance=ProvenanceChain(source="test"),
        )
        self.assertFalse(obj.verify_integrity())

    def test_memory_size_auto_computed(self):
        data = b"test data" * 100
        obj = ExactObject(
            object_id="obj3",
            bytes_data=data,
            integrity_hash=hashlib.sha256(data).hexdigest(),
            provenance=ProvenanceChain(source="test"),
        )
        self.assertEqual(obj.memory_size_bytes, len(data))

    def test_memory_size_explicit(self):
        obj = ExactObject(
            object_id="obj4",
            bytes_data=b"x",
            integrity_hash=hashlib.sha256(b"x").hexdigest(),
            provenance=ProvenanceChain(source="test"),
            memory_size_bytes=1024,
        )
        self.assertEqual(obj.memory_size_bytes, 1024)

    def test_can_degrade_defaults_false(self):
        obj = ExactObject(
            object_id="obj5",
            bytes_data=b"data",
            integrity_hash=hashlib.sha256(b"data").hexdigest(),
            provenance=ProvenanceChain(source="test"),
        )
        self.assertFalse(obj.can_degrade)


class TestApproxFieldCoarsening(unittest.TestCase):
    """Test ApproxField coarsening reduces fidelity and increases uncertainty."""

    def test_coarsen_reduces_fidelity(self):
        field = ApproxField(
            field_id="field1",
            shape=(10, 10),
            basis="fourier",
            fidelity_level=10,
            uncertainty=Uncertainty(4.9, 5.1, confidence=0.95),
        )
        saved = field.coarsen(levels=2)
        self.assertLess(field.fidelity_level, 10)
        self.assertGreater(saved, 0)

    def test_coarsen_increases_uncertainty_width(self):
        field = ApproxField(
            field_id="field2",
            shape=(10, 10),
            basis="fourier",
            fidelity_level=10,
            uncertainty=Uncertainty(4.9, 5.1, confidence=0.95),
        )
        old_width = field.uncertainty.width
        field.coarsen(levels=3)
        self.assertGreater(field.uncertainty.width, old_width)

    def test_coarsen_reduces_confidence(self):
        field = ApproxField(
            field_id="field3",
            shape=(10, 10),
            basis="fourier",
            fidelity_level=10,
            uncertainty=Uncertainty(4.9, 5.1, confidence=0.95),
        )
        old_conf = field.uncertainty.confidence
        field.coarsen(levels=2)
        self.assertLess(field.uncertainty.confidence, old_conf)

    def test_coarsen_memory_size_decreases(self):
        field = ApproxField(
            field_id="field4",
            shape=(10, 10),
            basis="fourier",
            fidelity_level=10,
            uncertainty=Uncertainty(4.9, 5.1, confidence=0.95),
        )
        old_size = field.memory_size_bytes
        field.coarsen(levels=3)
        self.assertLess(field.memory_size_bytes, old_size)

    def test_coarsen_returns_bytes_saved(self):
        field = ApproxField(
            field_id="field5",
            shape=(10, 10),
            basis="fourier",
            fidelity_level=10,
            uncertainty=Uncertainty(4.9, 5.1, confidence=0.95),
        )
        saved = field.coarsen(levels=2)
        self.assertEqual(saved, 2 * field.coarsening_policy.memory_per_fidelity_level)

    def test_cannot_coarsen_below_min(self):
        field = ApproxField(
            field_id="field6",
            shape=(10, 10),
            basis="fourier",
            fidelity_level=2,
            uncertainty=Uncertainty(4.9, 5.1, confidence=0.5),
            coarsening_policy=CoarseningPolicy(min_fidelity=1),
        )
        field.coarsen(levels=1)
        self.assertGreaterEqual(field.fidelity_level, 1)


class TestApproxFieldCanCoarsen(unittest.TestCase):
    """Test ApproxField.can_coarsen boundary conditions."""

    def test_can_coarsen_when_degradable_and_above_min(self):
        field = ApproxField(
            field_id="f1",
            shape=(5, 5),
            basis="fourier",
            fidelity_level=5,
            uncertainty=Uncertainty(0, 1, confidence=0.9),
            can_degrade=True,
            coarsening_policy=CoarseningPolicy(min_fidelity=1),
        )
        self.assertTrue(field.can_coarsen)

    def test_cannot_coarsen_when_at_min_fidelity(self):
        field = ApproxField(
            field_id="f2",
            shape=(5, 5),
            basis="fourier",
            fidelity_level=1,
            uncertainty=Uncertainty(0, 1, confidence=0.9),
            can_degrade=True,
            coarsening_policy=CoarseningPolicy(min_fidelity=1),
        )
        self.assertFalse(field.can_coarsen)

    def test_cannot_coarsen_when_not_degradable(self):
        field = ApproxField(
            field_id="f3",
            shape=(5, 5),
            basis="fourier",
            fidelity_level=10,
            uncertainty=Uncertainty(0, 1, confidence=0.9),
            can_degrade=False,
        )
        self.assertFalse(field.can_coarsen)

    def test_coarsen_when_cannot_returns_zero(self):
        field = ApproxField(
            field_id="f4",
            shape=(5, 5),
            basis="fourier",
            fidelity_level=1,
            uncertainty=Uncertainty(0, 1, confidence=0.9),
            can_degrade=True,
            coarsening_policy=CoarseningPolicy(min_fidelity=1),
        )
        saved = field.coarsen(levels=1)
        self.assertEqual(saved, 0)


class TestHandleMemoryPressurePreservesExact(unittest.TestCase):
    """Test handle_memory_pressure preserves exact objects."""

    def _make_exact(self, oid):
        data = f"data_{oid}".encode()
        return ExactObject(
            object_id=oid,
            bytes_data=data,
            integrity_hash=hashlib.sha256(data).hexdigest(),
            provenance=ProvenanceChain(source="test"),
        )

    def test_exact_object_preserved(self):
        exact = self._make_exact("e1")
        report = handle_memory_pressure([exact], pressure=0.9, target_pressure=0.7)
        exact_actions = [a for a in report.actions if a.object_id == "e1"]
        self.assertEqual(len(exact_actions), 1)
        self.assertEqual(exact_actions[0].action, "preserved")

    def test_multiple_exact_all_preserved(self):
        objs = [self._make_exact(f"e{i}") for i in range(5)]
        report = handle_memory_pressure(objs, pressure=0.95, target_pressure=0.7)
        preserved = [a for a in report.actions if a.action == "preserved"]
        self.assertEqual(len(preserved), 5)


class TestHandleMemoryPressureCoarsensApprox(unittest.TestCase):
    """Test handle_memory_pressure coarsens approximate fields."""

    def _make_approx(self, fid, fidelity=10, priority=0):
        return ApproxField(
            field_id=fid,
            shape=(10, 10),
            basis="fourier",
            fidelity_level=fidelity,
            uncertainty=Uncertainty(4.9, 5.1, confidence=0.95),
            can_degrade=True,
            priority=priority,
        )

    def test_approx_field_coarsened_under_pressure(self):
        approx = self._make_approx("a1", fidelity=10)
        report = handle_memory_pressure([approx], pressure=0.95, target_pressure=0.7)
        coarsened = [a for a in report.actions if a.action == "coarsened"]
        self.assertTrue(len(coarsened) > 0)
        self.assertLess(coarsened[0].new_fidelity, coarsened[0].old_fidelity)

    def test_low_priority_coarsened_first(self):
        low = self._make_approx("low", fidelity=10, priority=0)
        high = self._make_approx("high", fidelity=10, priority=10)
        report = handle_memory_pressure([low, high], pressure=0.95, target_pressure=0.7)
        # The low-priority field should be coarsened (if any coarsening occurs)
        coarsened_ids = {a.object_id for a in report.actions if a.action == "coarsened"}
        # At least low should be in there since it's sorted first by priority
        if coarsened_ids:
            self.assertIn("low", coarsened_ids)

    def test_non_degradable_approx_protected(self):
        approx = ApproxField(
            field_id="protected",
            shape=(10, 10),
            basis="fourier",
            fidelity_level=10,
            uncertainty=Uncertainty(4.9, 5.1, confidence=0.95),
            can_degrade=False,
        )
        report = handle_memory_pressure([approx], pressure=0.95, target_pressure=0.7)
        protected = [a for a in report.actions if a.action == "protected"]
        self.assertEqual(len(protected), 1)
        self.assertEqual(protected[0].object_id, "protected")

    def test_mixed_exact_and_approx(self):
        exact_data = b"exact_data"
        exact = ExactObject(
            object_id="exact1",
            bytes_data=exact_data,
            integrity_hash=hashlib.sha256(exact_data).hexdigest(),
            provenance=ProvenanceChain(source="test"),
        )
        approx = self._make_approx("approx1", fidelity=10)
        report = handle_memory_pressure([exact, approx], pressure=0.95, target_pressure=0.7)
        actions_by_type = {a.action for a in report.actions}
        self.assertIn("preserved", actions_by_type)
        self.assertTrue(len(report.actions) >= 2)

    def test_no_pressure_no_coarsening(self):
        approx = self._make_approx("a1", fidelity=10)
        report = handle_memory_pressure([approx], pressure=0.5, target_pressure=0.7)
        coarsened = [a for a in report.actions if a.action == "coarsened"]
        self.assertEqual(len(coarsened), 0)

    def test_report_contains_pressure_info(self):
        approx = self._make_approx("a1", fidelity=10)
        report = handle_memory_pressure([approx], pressure=0.95, target_pressure=0.7)
        self.assertIsInstance(report, DegradationReport)
        self.assertAlmostEqual(report.pressure_before, 0.95)
        self.assertAlmostEqual(report.target_pressure, 0.7)


class TestDegradationReport(unittest.TestCase):
    """Test DegradationReport string representation."""

    def test_str_contains_preserved(self):
        report = DegradationReport(pressure_before=0.9, pressure_after=0.8, target_pressure=0.7)
        report.add(DegradationAction(object_id="obj1", object_type="exact", action="preserved"))
        s = str(report)
        self.assertIn("PRESERVED", s)
        self.assertIn("obj1", s)

    def test_str_contains_coarsened(self):
        report = DegradationReport(pressure_before=0.9, pressure_after=0.8, target_pressure=0.7)
        report.add(DegradationAction(
            object_id="f1", object_type="approx", action="coarsened",
            old_fidelity=10, new_fidelity=8, memory_saved=2048,
        ))
        s = str(report)
        self.assertIn("COARSENED", s)
        self.assertIn("10", s)
        self.assertIn("8", s)


if __name__ == "__main__":
    unittest.main()
