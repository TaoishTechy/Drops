"""Test ZeroType, zero_allowed, zero_policy, and check_zero_at_boundary."""
import sys, os, math, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.domain import Domain
from core.typed_zero import ZeroType, ZERO_POLICY_TABLE, zero_allowed, zero_allowed_info
from core.typed_nan import NaNType
from core.typed_value import TypedValue
from core.uncertainty import Uncertainty
from core.provenance import ProvenanceChain
from policy.zero_policy import check_zero_at_boundary, ZeroCheckResult


class TestZeroTypeEnum(unittest.TestCase):
    """Test ZeroType enumeration values."""

    def test_all_zero_types_exist(self):
        expected = {
            "EXACT_SYMBOLIC_ZERO", "MEASURED_ABSENCE", "HARDWARE_GROUND",
            "NULL_CAPABILITY", "COMPUTATIONAL_OPERAND_ZERO", "UNTYPED_ZERO",
        }
        actual = {zt.name for zt in ZeroType}
        self.assertEqual(actual, expected)

    def test_zero_type_values_are_strings(self):
        for zt in ZeroType:
            self.assertIsInstance(zt.value, str)
            self.assertTrue(len(zt.value) > 0)


class TestUntypedZeroRejected(unittest.TestCase):
    """UNTYPED_ZERO must be rejected in every domain."""

    def test_rejected_in_formal_proof(self):
        self.assertFalse(zero_allowed(ZeroType.UNTYPED_ZERO, Domain.FORMAL_PROOF))

    def test_rejected_in_physics_numeric(self):
        self.assertFalse(zero_allowed(ZeroType.UNTYPED_ZERO, Domain.PHYSICS_NUMERIC))

    def test_rejected_in_security_authority(self):
        self.assertFalse(zero_allowed(ZeroType.UNTYPED_ZERO, Domain.SECURITY_AUTHORITY))

    def test_rejected_in_memory_access(self):
        self.assertFalse(zero_allowed(ZeroType.UNTYPED_ZERO, Domain.MEMORY_ACCESS))

    def test_rejected_in_sensor_data(self):
        self.assertFalse(zero_allowed(ZeroType.UNTYPED_ZERO, Domain.SENSOR_DATA))

    def test_rejected_in_all_domains(self):
        for domain in Domain:
            self.assertFalse(
                zero_allowed(ZeroType.UNTYPED_ZERO, domain),
                f"UNTYPED_ZERO should be rejected in {domain.value}"
            )


class TestExactSymbolicZeroInFormalProof(unittest.TestCase):
    """EXACT_SYMBOLIC_ZERO should be accepted in FORMAL_PROOF."""

    def test_allowed_in_formal_proof(self):
        self.assertTrue(zero_allowed(ZeroType.EXACT_SYMBOLIC_ZERO, Domain.FORMAL_PROOF))

    def test_only_exact_symbolic_in_formal_proof(self):
        allowed = ZERO_POLICY_TABLE[Domain.FORMAL_PROOF]
        self.assertEqual(allowed, {ZeroType.EXACT_SYMBOLIC_ZERO})


class TestMeasuredAbsenceInNumericDomains(unittest.TestCase):
    """MEASURED_ABSENCE should be accepted in PHYSICS_NUMERIC and SENSOR_DATA."""

    def test_allowed_in_physics_numeric(self):
        self.assertTrue(zero_allowed(ZeroType.MEASURED_ABSENCE, Domain.PHYSICS_NUMERIC))

    def test_allowed_in_sensor_data(self):
        self.assertTrue(zero_allowed(ZeroType.MEASURED_ABSENCE, Domain.SENSOR_DATA))

    def test_rejected_in_formal_proof(self):
        self.assertFalse(zero_allowed(ZeroType.MEASURED_ABSENCE, Domain.FORMAL_PROOF))

    def test_rejected_in_security_authority(self):
        self.assertFalse(zero_allowed(ZeroType.MEASURED_ABSENCE, Domain.SECURITY_AUTHORITY))


class TestNullCapabilityInSecurityDomains(unittest.TestCase):
    """NULL_CAPABILITY should be accepted in SECURITY_AUTHORITY and MEMORY_ACCESS."""

    def test_allowed_in_security_authority(self):
        self.assertTrue(zero_allowed(ZeroType.NULL_CAPABILITY, Domain.SECURITY_AUTHORITY))

    def test_allowed_in_memory_access(self):
        self.assertTrue(zero_allowed(ZeroType.NULL_CAPABILITY, Domain.MEMORY_ACCESS))

    def test_only_null_in_security(self):
        allowed = ZERO_POLICY_TABLE[Domain.SECURITY_AUTHORITY]
        self.assertEqual(allowed, {ZeroType.NULL_CAPABILITY})

    def test_only_null_in_memory(self):
        allowed = ZERO_POLICY_TABLE[Domain.MEMORY_ACCESS]
        self.assertEqual(allowed, {ZeroType.NULL_CAPABILITY})

    def test_rejected_in_physics_numeric(self):
        self.assertFalse(zero_allowed(ZeroType.NULL_CAPABILITY, Domain.PHYSICS_NUMERIC))


class TestHardwareGroundInPhysicsNumeric(unittest.TestCase):
    """HARDWARE_GROUND should be accepted in PHYSICS_NUMERIC."""

    def test_allowed_in_physics_numeric(self):
        self.assertTrue(zero_allowed(ZeroType.HARDWARE_GROUND, Domain.PHYSICS_NUMERIC))

    def test_rejected_in_formal_proof(self):
        self.assertFalse(zero_allowed(ZeroType.HARDWARE_GROUND, Domain.FORMAL_PROOF))

    def test_rejected_in_security_authority(self):
        self.assertFalse(zero_allowed(ZeroType.HARDWARE_GROUND, Domain.SECURITY_AUTHORITY))


class TestWrongZeroTypeRejected(unittest.TestCase):
    """Zero types not in a domain's policy should be rejected."""

    def test_exact_symbolic_rejected_in_security_authority(self):
        self.assertFalse(zero_allowed(ZeroType.EXACT_SYMBOLIC_ZERO, Domain.SECURITY_AUTHORITY))

    def test_measured_absence_rejected_in_security(self):
        self.assertFalse(zero_allowed(ZeroType.MEASURED_ABSENCE, Domain.SECURITY_AUTHORITY))

    def test_hardware_ground_rejected_in_memory_access(self):
        self.assertFalse(zero_allowed(ZeroType.HARDWARE_GROUND, Domain.MEMORY_ACCESS))

    def test_computational_operand_rejected_in_formal_proof(self):
        self.assertFalse(zero_allowed(ZeroType.COMPUTATIONAL_OPERAND_ZERO, Domain.FORMAL_PROOF))


class TestZeroAllowedInfo(unittest.TestCase):
    """Test zero_allowed_info returns descriptive reason strings."""

    def test_allowed_message(self):
        msg = zero_allowed_info(ZeroType.EXACT_SYMBOLIC_ZERO, Domain.FORMAL_PROOF)
        self.assertIn("ALLOWED", msg)
        self.assertIn("exact_symbolic_zero", msg)
        self.assertIn("formal_proof", msg)

    def test_rejected_message(self):
        msg = zero_allowed_info(ZeroType.UNTYPED_ZERO, Domain.FORMAL_PROOF)
        self.assertIn("REJECTED", msg)
        self.assertIn("untyped_zero", msg)


class TestCheckZeroAtBoundary(unittest.TestCase):
    """Test check_zero_at_boundary from policy/zero_policy.py."""

    def _make_zero_value(self, zero_type=None):
        """Helper: create a zero TypedValue with optional zero_type."""
        return TypedValue(
            value=0.0,
            uncertainty=Uncertainty.exact(0.0),
            domain=Domain.PHYSICS_NUMERIC,
            provenance=ProvenanceChain(source="test"),
            zero_type=zero_type,
        )

    def test_nonzero_value_passes_through(self):
        tv = TypedValue(
            value=5.0,
            uncertainty=Uncertainty.from_point(5.0, 0.1),
            domain=Domain.PHYSICS_NUMERIC,
            provenance=ProvenanceChain(source="test"),
        )
        result = check_zero_at_boundary(tv, Domain.SENSOR_DATA)
        self.assertTrue(result.allowed)
        self.assertIn("not zero", result.reason)

    def test_untyped_zero_rejected_returns_nan(self):
        tv = self._make_zero_value(zero_type=None)
        result = check_zero_at_boundary(tv, Domain.FORMAL_PROOF)
        self.assertFalse(result.allowed)
        self.assertIn("untyped zero", result.reason)
        self.assertIsNotNone(result.value)
        self.assertTrue(result.value.is_nan())
        self.assertEqual(result.value.nan_type, NaNType.DOMAIN)

    def test_allowed_typed_zero_passes(self):
        tv = self._make_zero_value(zero_type=ZeroType.EXACT_SYMBOLIC_ZERO)
        result = check_zero_at_boundary(tv, Domain.FORMAL_PROOF)
        self.assertTrue(result.allowed)
        self.assertIn("ALLOWED", result.reason)

    def test_wrong_typed_zero_rejected(self):
        tv = self._make_zero_value(zero_type=ZeroType.HARDWARE_GROUND)
        result = check_zero_at_boundary(tv, Domain.FORMAL_PROOF)
        self.assertFalse(result.allowed)
        self.assertIsNotNone(result.value)
        self.assertTrue(result.value.is_nan())

    def test_measured_absence_allowed_in_physics(self):
        tv = self._make_zero_value(zero_type=ZeroType.MEASURED_ABSENCE)
        result = check_zero_at_boundary(tv, Domain.PHYSICS_NUMERIC)
        self.assertTrue(result.allowed)

    def test_null_capability_allowed_in_security(self):
        tv = self._make_zero_value(zero_type=ZeroType.NULL_CAPABILITY)
        result = check_zero_at_boundary(tv, Domain.SECURITY_AUTHORITY)
        self.assertTrue(result.allowed)

    def test_hardware_ground_allowed_in_physics(self):
        tv = self._make_zero_value(zero_type=ZeroType.HARDWARE_GROUND)
        result = check_zero_at_boundary(tv, Domain.PHYSICS_NUMERIC)
        self.assertTrue(result.allowed)

    def test_result_value_preserved_on_allow(self):
        tv = self._make_zero_value(zero_type=ZeroType.EXACT_SYMBOLIC_ZERO)
        result = check_zero_at_boundary(tv, Domain.FILESYSTEM_EXACT)
        self.assertTrue(result.allowed)
        self.assertIs(result.value, tv)


if __name__ == "__main__":
    unittest.main()
