"""Test replay system: ReplayLog, serialize_typed_value, DeterministicRunner."""
import sys, os, json, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.domain import Domain
from core.typed_value import TypedValue
from core.typed_nan import NaNType
from core.typed_zero import ZeroType
from replay.replay_log import ReplayLog
from replay.event_record import ReplayEvent, serialize_typed_value
from replay.deterministic_runner import DeterministicRunner


class TestReplayLogRecord(unittest.TestCase):
    """Test ReplayLog recording and event count."""

    def test_empty_log(self):
        log = ReplayLog("test_empty")
        self.assertEqual(len(log), 0)

    def test_record_single_event(self):
        log = ReplayLog("test_single")
        log.record("add", [1, 2], [3])
        self.assertEqual(len(log), 1)

    def test_record_multiple_events(self):
        log = ReplayLog("test_multi")
        log.record("op1", [1], [2])
        log.record("op2", [3], [4])
        log.record("op3", [5], [6])
        self.assertEqual(len(log), 3)

    def test_record_assigns_incrementing_ids(self):
        log = ReplayLog("test_ids")
        e1 = log.record("a", [1], [2])
        e2 = log.record("b", [3], [4])
        self.assertIn("0", e1.event_id)
        self.assertIn("1", e2.event_id)

    def test_record_with_typed_values(self):
        log = ReplayLog("test_tv")
        tv = TypedValue.from_float(5.0)
        event = log.record("create", [tv], [tv])
        self.assertEqual(len(event.inputs), 1)
        self.assertIsInstance(event.inputs[0], dict)
        self.assertIn("value", event.inputs[0])
        self.assertEqual(event.inputs[0]["value"], 5.0)

    def test_record_with_policy_snapshot(self):
        log = ReplayLog("test_policy")
        event = log.record("compute", [1], [2], policy_snapshot={"max_uncertainty": 0.1})
        self.assertEqual(event.policy_snapshot, {"max_uncertainty": 0.1})

    def test_record_with_backend_snapshot(self):
        log = ReplayLog("test_backend")
        event = log.record("compute", [1], [2], backend_snapshot={"type": "cpu"})
        self.assertEqual(event.backend_contract_snapshot, {"type": "cpu"})

    def test_record_provenance_hash_populated(self):
        log = ReplayLog("test_prov_hash")
        tv = TypedValue.from_float(3.0)
        event = log.record("op", [tv], [tv])
        self.assertTrue(len(event.provenance_hash) > 0)


class TestReplayLogSaveLoad(unittest.TestCase):
    """Test ReplayLog save and load roundtrip."""

    def test_save_and_load_roundtrip(self):
        log = ReplayLog("roundtrip_test")
        log.record("add", [TypedValue.from_float(1.0)], [TypedValue.from_float(2.0)])
        log.record("mul", [TypedValue.from_float(3.0)], [TypedValue.from_float(9.0)])

        with tempfile.NamedTemporaryFile(suffix=".json", mode="w", delete=False) as f:
            filepath = f.name
        try:
            log.save(filepath)

            loaded = ReplayLog.load(filepath)
            self.assertEqual(len(loaded), 2)
            self.assertEqual(loaded.log_id, "roundtrip_test")
            self.assertEqual(loaded.events[0].operation, "add")
            self.assertEqual(loaded.events[1].operation, "mul")
        finally:
            os.unlink(filepath)

    def test_save_creates_valid_json(self):
        log = ReplayLog("json_test")
        log.record("op", [1], [2])
        with tempfile.NamedTemporaryFile(suffix=".json", mode="w", delete=False) as f:
            filepath = f.name
        try:
            log.save(filepath)
            with open(filepath) as f:
                data = json.load(f)
            self.assertIn("log_id", data)
            self.assertIn("events", data)
            self.assertEqual(data["event_count"], 1)
        finally:
            os.unlink(filepath)

    def test_loaded_event_ids_preserved(self):
        log = ReplayLog("id_test")
        e = log.record("op", [1], [2])
        original_id = e.event_id
        with tempfile.NamedTemporaryFile(suffix=".json", mode="w", delete=False) as f:
            filepath = f.name
        try:
            log.save(filepath)
            loaded = ReplayLog.load(filepath)
            self.assertEqual(loaded.events[0].event_id, original_id)
        finally:
            os.unlink(filepath)


class TestSerializeTypedValue(unittest.TestCase):
    """Test serialize_typed_value function."""

    def test_serializes_basic_value(self):
        tv = TypedValue.from_float(5.0, half_width=0.1)
        d = serialize_typed_value(tv)
        self.assertEqual(d["value"], 5.0)
        self.assertIn("uncertainty", d)
        self.assertEqual(d["domain"], "physics_numeric")

    def test_serializes_zero_with_type(self):
        tv = TypedValue.from_float(0.0).with_zero_type(ZeroType.MEASURED_ABSENCE)
        d = serialize_typed_value(tv)
        self.assertEqual(d["zero_type"], "measured_absence")

    def test_serializes_nan(self):
        tv = TypedValue.typed_nan(NaNType.DIVERGENT, "overflow", Domain.PHYSICS_NUMERIC)
        d = serialize_typed_value(tv)
        self.assertIsNone(d["value"])
        self.assertEqual(d["nan_type"], "nan_divergent")

    def test_serializes_units(self):
        from core.units import METER
        tv = TypedValue.from_float(10.0, units=METER)
        d = serialize_typed_value(tv)
        self.assertIn("units", d)
        self.assertIn("m", d["units"])

    def test_serializes_provenance_hash(self):
        tv = TypedValue.from_float(3.0)
        d = serialize_typed_value(tv)
        self.assertIn("provenance_hash", d)
        self.assertTrue(len(d["provenance_hash"]) > 0)

    def test_serializes_backend_type(self):
        tv = TypedValue.from_float(3.0)
        d = serialize_typed_value(tv)
        self.assertEqual(d["backend"], "cpu")

    def test_serializes_nan_value_none(self):
        tv = TypedValue.typed_nan(NaNType.DOMAIN, "test", Domain.PHYSICS_NUMERIC)
        d = serialize_typed_value(tv)
        self.assertIsNone(d["value"])


class TestDeterministicRunnerRunAndRecord(unittest.TestCase):
    """Test DeterministicRunner.run_and_record."""

    def test_run_records_event(self):
        runner = DeterministicRunner()
        outputs = runner.run_and_record("double", lambda x: x * 2, 5)
        self.assertEqual(outputs, [10])
        self.assertEqual(len(runner.log), 1)

    def test_run_records_operation_name(self):
        runner = DeterministicRunner()
        runner.run_and_record("add_one", lambda x: x + 1, 9)
        self.assertEqual(runner.log.events[0].operation, "add_one")

    def test_run_with_multiple_args(self):
        runner = DeterministicRunner()
        outputs = runner.run_and_record("add", lambda a, b: a + b, 3, 7)
        self.assertEqual(outputs, [10])

    def test_run_with_typed_value(self):
        runner = DeterministicRunner()
        tv = TypedValue.from_float(5.0)
        outputs = runner.run_and_record("identity", lambda x: x, tv)
        self.assertEqual(len(outputs), 1)

    def test_run_with_policy_snapshot(self):
        runner = DeterministicRunner()
        runner.run_and_record(
            "compute", lambda x: x, 1,
            policy_snapshot={"max_u": 0.1},
        )
        self.assertEqual(runner.log.events[0].policy_snapshot, {"max_u": 0.1})

    def test_multiple_runs_accumulate(self):
        runner = DeterministicRunner()
        runner.run_and_record("op1", lambda: 1)
        runner.run_and_record("op2", lambda: 2)
        runner.run_and_record("op3", lambda: 3)
        self.assertEqual(len(runner.log), 3)


class TestDeterministicRunnerReplay(unittest.TestCase):
    """Test DeterministicRunner.replay matches."""

    def test_replay_matches_deterministic(self):
        runner = DeterministicRunner()
        add_fn = lambda a, b: a + b
        runner.run_and_record("add", add_fn, 3, 7)
        matches, current, recorded = runner.replay("add", add_fn, 3, 7)
        self.assertTrue(matches)

    def test_replay_finds_event_by_id(self):
        runner = DeterministicRunner()
        fn = lambda x: x * 2
        runner.run_and_record("double", fn, 5)
        event_id = runner.log.events[0].event_id
        matches, _, _ = runner.replay(event_id, fn, 5)
        self.assertTrue(matches)

    def test_replay_mismatch_detects_difference(self):
        runner = DeterministicRunner()
        original_fn = lambda x: x + 1
        runner.run_and_record("inc", original_fn, 10)
        different_fn = lambda x: x + 100
        matches, current, recorded = runner.replay("inc", different_fn, 10)
        self.assertFalse(matches)

    def test_replay_missing_event_raises(self):
        runner = DeterministicRunner()
        with self.assertRaises(ValueError):
            runner.replay("nonexistent", lambda x: x, 1)

    def test_verify_full_replay(self):
        runner = DeterministicRunner()
        runner.run_and_record("op", lambda: 42)
        result = runner.verify_full_replay({"op": lambda: 42})
        self.assertIsInstance(result, bool)


if __name__ == "__main__":
    unittest.main()
