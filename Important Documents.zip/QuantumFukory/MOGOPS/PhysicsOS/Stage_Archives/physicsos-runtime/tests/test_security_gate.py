"""Test exact_security_gate and approximate_science_gate."""
import sys, os, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.domain import Domain
from core.typed_value import TypedValue, BackendInfo
from core.uncertainty import Uncertainty
from core.provenance import ProvenanceChain
from core.typed_nan import NaNType
from policy.exact_security_gate import exact_security_gate, AccessDecision
from policy.approximate_science_gate import approximate_science_gate, ApproximationPolicy


def _make_security_value(
    domain=Domain.SECURITY_AUTHORITY,
    security_unc=0.0,
    is_exact=True,
    prov_valid=True,
    nan_type=None,
):
    """Helper to build a TypedValue for security gate testing."""
    prov = ProvenanceChain(source="test")
    if not prov_valid:
        prov.entries.clear()
    return TypedValue(
        value=1.0 if nan_type is None else None,
        uncertainty=Uncertainty(lower=1.0, upper=1.0, confidence=1.0, security=security_unc),
        domain=domain,
        provenance=prov,
        backend=BackendInfo.runtime() if is_exact else BackendInfo.simulated_analog(),
        nan_type=nan_type,
    )


class TestExactSecurityGateAllow(unittest.TestCase):
    """Test that exact security values produce ALLOW decisions."""

    def test_exact_value_allows(self):
        tv = _make_security_value()
        result = exact_security_gate(tv, "test_decision")
        self.assertEqual(result.decision, AccessDecision.ALLOW)
        self.assertIn("authorized", result.reason)

    def test_exact_value_with_other_uncertainty_still_allows(self):
        tv = _make_security_value()
        tv.uncertainty = Uncertainty(
            lower=1.0, upper=1.0, confidence=0.9,
            measurement=0.01, rounding=0.01, model=0.01,
        )
        result = exact_security_gate(tv, "test_decision")
        self.assertEqual(result.decision, AccessDecision.ALLOW)


class TestExactSecurityGateDenyNaN(unittest.TestCase):
    """Test that NaN values are denied."""

    def test_nan_value_denied(self):
        tv = _make_security_value(nan_type=NaNType.DOMAIN)
        result = exact_security_gate(tv, "test_decision")
        self.assertEqual(result.decision, AccessDecision.DENY)
        self.assertIn("NaN", result.reason)

    def test_divergent_nan_denied(self):
        tv = _make_security_value(nan_type=NaNType.DIVERGENT)
        result = exact_security_gate(tv, "test_decision")
        self.assertEqual(result.decision, AccessDecision.DENY)

    def test_unauthorized_nan_denied(self):
        tv = _make_security_value(nan_type=NaNType.UNAUTHORIZED)
        result = exact_security_gate(tv, "test_decision")
        self.assertEqual(result.decision, AccessDecision.DENY)


class TestExactSecurityGateDenyWrongDomain(unittest.TestCase):
    """Test that non-SECURITY_AUTHORITY domains are denied."""

    def test_physics_numeric_denied(self):
        tv = _make_security_value(domain=Domain.PHYSICS_NUMERIC)
        result = exact_security_gate(tv, "test_decision")
        self.assertEqual(result.decision, AccessDecision.DENY)
        self.assertIn("Domain mismatch", result.reason)

    def test_sensor_data_denied(self):
        tv = _make_security_value(domain=Domain.SENSOR_DATA)
        result = exact_security_gate(tv, "test_decision")
        self.assertEqual(result.decision, AccessDecision.DENY)

    def test_human_display_denied(self):
        tv = _make_security_value(domain=Domain.HUMAN_DISPLAY)
        result = exact_security_gate(tv, "test_decision")
        self.assertEqual(result.decision, AccessDecision.DENY)


class TestExactSecurityGateDenySecurityUncertainty(unittest.TestCase):
    """Test that non-zero security uncertainty is denied."""

    def test_security_uncertainty_denied(self):
        tv = _make_security_value(security_unc=0.01)
        result = exact_security_gate(tv, "test_decision")
        self.assertEqual(result.decision, AccessDecision.DENY)
        self.assertIn("Security uncertainty", result.reason)

    def test_large_security_uncertainty_denied(self):
        tv = _make_security_value(security_unc=1.0)
        result = exact_security_gate(tv, "test_decision")
        self.assertEqual(result.decision, AccessDecision.DENY)


class TestExactSecurityGateDenyInexactBackend(unittest.TestCase):
    """Test that inexact backends are denied."""

    def test_analog_backend_denied(self):
        tv = _make_security_value(is_exact=False)
        result = exact_security_gate(tv, "test_decision")
        self.assertEqual(result.decision, AccessDecision.DENY)
        self.assertIn("Inexact backend", result.reason)


class TestExactSecurityGateDenyInvalidProvenance(unittest.TestCase):
    """Test that invalid provenance is denied."""

    def test_empty_provenance_denied(self):
        tv = _make_security_value(prov_valid=False)
        result = exact_security_gate(tv, "test_decision")
        self.assertEqual(result.decision, AccessDecision.DENY)
        self.assertIn("Invalid provenance", result.reason)


class TestApproximateScienceGateAccepted(unittest.TestCase):
    """Test that acceptable approximate values pass."""

    def test_low_uncertainty_accepted(self):
        tv = TypedValue.from_float(5.0, half_width=0.01)
        policy = ApproximationPolicy(max_uncertainty=1.0, min_confidence=0.5)
        result = approximate_science_gate(tv, policy)
        self.assertTrue(result.accepted)

    def test_sensor_data_accepted(self):
        tv = TypedValue.from_float(3.0, half_width=0.05, domain=Domain.SENSOR_DATA)
        policy = ApproximationPolicy(max_uncertainty=0.5, min_confidence=0.5)
        result = approximate_science_gate(tv, policy)
        self.assertTrue(result.accepted)

    def test_physics_numeric_accepted(self):
        tv = TypedValue.from_float(10.0, domain=Domain.PHYSICS_NUMERIC)
        policy = ApproximationPolicy(max_uncertainty=0.1, min_confidence=0.5)
        result = approximate_science_gate(tv, policy)
        self.assertTrue(result.accepted)


class TestApproximateScienceGateDenied(unittest.TestCase):
    """Test rejection cases for approximate science gate."""

    def test_nan_rejected(self):
        nan_tv = TypedValue.typed_nan(NaNType.DOMAIN, "test", Domain.PHYSICS_NUMERIC)
        policy = ApproximationPolicy()
        result = approximate_science_gate(nan_tv, policy)
        self.assertFalse(result.accepted)
        self.assertIn("NaN", result.reason)

    def test_security_domain_rejected(self):
        tv = TypedValue.from_float(1.0, domain=Domain.SECURITY_AUTHORITY)
        policy = ApproximationPolicy()
        result = approximate_science_gate(tv, policy)
        self.assertFalse(result.accepted)
        self.assertIn("security_authority", result.reason)

    def test_high_uncertainty_rejected(self):
        tv = TypedValue(
            value=5.0,
            uncertainty=Uncertainty(4.0, 6.0, confidence=0.9, measurement=0.5),
            domain=Domain.PHYSICS_NUMERIC,
            provenance=ProvenanceChain(source="test"),
        )
        policy = ApproximationPolicy(max_uncertainty=0.1)
        result = approximate_science_gate(tv, policy)
        self.assertFalse(result.accepted)
        self.assertIn("Uncertainty", result.reason)

    def test_low_confidence_rejected(self):
        tv = TypedValue(
            value=5.0,
            uncertainty=Uncertainty(4.95, 5.05, confidence=0.1),
            domain=Domain.PHYSICS_NUMERIC,
            provenance=ProvenanceChain(source="test"),
        )
        policy = ApproximationPolicy(max_uncertainty=1.0, min_confidence=0.5)
        result = approximate_science_gate(tv, policy)
        self.assertFalse(result.accepted)
        self.assertIn("Confidence", result.reason)


class TestApproximationPolicyDefaults(unittest.TestCase):
    """Test ApproximationPolicy default behavior."""

    def test_default_allows_all_non_security_domains(self):
        policy = ApproximationPolicy()
        self.assertNotIn(Domain.SECURITY_AUTHORITY, policy.allowed_domains)
        self.assertIn(Domain.PHYSICS_NUMERIC, policy.allowed_domains)
        self.assertIn(Domain.SENSOR_DATA, policy.allowed_domains)
        self.assertIn(Domain.ML_INFERENCE, policy.allowed_domains)

    def test_restricted_allowed_domains(self):
        policy = ApproximationPolicy(allowed_domains=[Domain.PHYSICS_NUMERIC])
        tv = TypedValue.from_float(1.0, domain=Domain.SENSOR_DATA)
        result = approximate_science_gate(tv, policy)
        self.assertFalse(result.accepted)
        self.assertIn("not in allowed", result.reason)


if __name__ == "__main__":
    unittest.main()
