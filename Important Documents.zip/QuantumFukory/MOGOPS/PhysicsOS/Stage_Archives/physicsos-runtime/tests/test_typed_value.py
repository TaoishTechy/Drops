"""Test TypedValue creation and operations."""
import sys, os, math, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.domain import Domain
from core.typed_zero import ZeroType
from core.typed_nan import NaNType
from core.uncertainty import Uncertainty
from core.interval import Interval
from core.provenance import ProvenanceChain
from core.units import METER, SECOND, VELOCITY, DimensionalError
from core.typed_value import TypedValue, BackendInfo, physics_add, physics_divide


class TestTypedValueFromFloat(unittest.TestCase):
    """Test TypedValue.from_float factory method."""

    def test_nonzero_creates_typed_value(self):
        tv = TypedValue.from_float(5.0)
        self.assertEqual(tv.value, 5.0)
        self.assertEqual(tv.domain, Domain.PHYSICS_NUMERIC)
        self.assertFalse(tv.is_zero())
        self.assertFalse(tv.is_nan())
        self.assertIsNone(tv.zero_type)

    def test_nonzero_with_domain(self):
        tv = TypedValue.from_float(3.14, domain=Domain.SENSOR_DATA)
        self.assertEqual(tv.value, 3.14)
        self.assertEqual(tv.domain, Domain.SENSOR_DATA)

    def test_nonzero_with_half_width(self):
        tv = TypedValue.from_float(10.0, half_width=0.5)
        self.assertAlmostEqual(tv.uncertainty.lower, 9.5)
        self.assertAlmostEqual(tv.uncertainty.upper, 10.5)

    def test_zero_creates_computational_operand_zero(self):
        tv = TypedValue.from_float(0.0)
        self.assertEqual(tv.value, 0.0)
        self.assertEqual(tv.zero_type, ZeroType.COMPUTATIONAL_OPERAND_ZERO)
        self.assertTrue(tv.is_zero())
        self.assertFalse(tv.is_nan())

    def test_with_units(self):
        tv = TypedValue.from_float(9.8, units=METER)
        self.assertEqual(tv.units, METER)


class TestWithDomain(unittest.TestCase):
    """Test TypedValue.with_domain creates new value with different domain."""

    def test_changes_domain(self):
        tv = TypedValue.from_float(1.0, domain=Domain.PHYSICS_NUMERIC)
        new_tv = tv.with_domain(Domain.SENSOR_DATA)
        self.assertEqual(new_tv.domain, Domain.SENSOR_DATA)
        self.assertEqual(new_tv.value, 1.0)

    def test_preserves_other_fields(self):
        tv = TypedValue.from_float(7.0, half_width=0.1)
        new_tv = tv.with_domain(Domain.ML_INFERENCE)
        self.assertEqual(new_tv.value, 7.0)
        self.assertEqual(new_tv.units, tv.units)

    def test_provenance_includes_domain_change(self):
        tv = TypedValue.from_float(2.0)
        new_tv = tv.with_domain(Domain.FORMAL_PROOF)
        ops = [e.operation for e in new_tv.provenance.entries]
        self.assertIn("domain_change", ops)


class TestWithZeroType(unittest.TestCase):
    """Test TypedValue.with_zero_type assigns zero type."""

    def test_assigns_zero_type(self):
        tv = TypedValue(
            value=0.0,
            uncertainty=Uncertainty.exact(0.0),
            domain=Domain.PHYSICS_NUMERIC,
            provenance=ProvenanceChain(source="test"),
        )
        typed = tv.with_zero_type(ZeroType.MEASURED_ABSENCE)
        self.assertEqual(typed.zero_type, ZeroType.MEASURED_ABSENCE)

    def test_value_still_zero(self):
        tv = TypedValue(
            value=0.0,
            uncertainty=Uncertainty.exact(0.0),
            domain=Domain.PHYSICS_NUMERIC,
            provenance=ProvenanceChain(source="test"),
        )
        typed = tv.with_zero_type(ZeroType.HARDWARE_GROUND)
        self.assertTrue(typed.is_zero())

    def test_provenance_records_assignment(self):
        tv = TypedValue.from_float(0.0)
        typed = tv.with_zero_type(ZeroType.NULL_CAPABILITY)
        ops = [e.operation for e in typed.provenance.entries]
        self.assertIn("zero_type_assign", ops)


class TestWithNanType(unittest.TestCase):
    """Test TypedValue.with_nan_type creates NaN value."""

    def test_creates_nan_value(self):
        tv = TypedValue.from_float(5.0)
        nan_tv = tv.with_nan_type(NaNType.DIVERGENT, reason="overflow")
        self.assertTrue(nan_tv.is_nan())
        self.assertEqual(nan_tv.nan_type, NaNType.DIVERGENT)
        self.assertIsNone(nan_tv.value)

    def test_nan_has_infinite_uncertainty(self):
        tv = TypedValue.from_float(3.0)
        nan_tv = tv.with_nan_type(NaNType.UNMEASURED)
        self.assertEqual(nan_tv.uncertainty.lower, float('-inf'))
        self.assertEqual(nan_tv.uncertainty.upper, float('inf'))

    def test_nan_not_zero(self):
        tv = TypedValue.from_float(0.0)
        nan_tv = tv.with_nan_type(NaNType.TIMEOUT)
        self.assertFalse(nan_tv.is_zero())
        self.assertTrue(nan_tv.is_nan())

    def test_clears_zero_type(self):
        tv = TypedValue.from_float(0.0)
        nan_tv = tv.with_nan_type(NaNType.HARDWARE_FAULT)
        self.assertIsNone(nan_tv.zero_type)


class TestTypedNan(unittest.TestCase):
    """Test TypedValue.typed_nan classmethod."""

    def test_creates_nan(self):
        nan_tv = TypedValue.typed_nan(
            nan_type=NaNType.DOMAIN,
            reason="test",
            domain=Domain.FORMAL_PROOF,
        )
        self.assertTrue(nan_tv.is_nan())
        self.assertEqual(nan_tv.nan_type, NaNType.DOMAIN)
        self.assertEqual(nan_tv.domain, Domain.FORMAL_PROOF)

    def test_with_operands(self):
        a = TypedValue.from_float(1.0)
        b = TypedValue.from_float(0.0)
        nan_tv = TypedValue.typed_nan(
            nan_type=NaNType.DIVERGENT,
            reason="diverge",
            domain=Domain.PHYSICS_NUMERIC,
            operands=[a, b],
        )
        self.assertTrue(nan_tv.is_nan())
        ops = [e.operation for e in nan_tv.provenance.entries]
        self.assertIn("operand", ops)

    def test_with_custom_provenance(self):
        prov = ProvenanceChain(source="custom")
        nan_tv = TypedValue.typed_nan(
            nan_type=NaNType.UNAUTHORIZED,
            reason="denied",
            domain=Domain.SECURITY_AUTHORITY,
            provenance=prov,
        )
        self.assertTrue(nan_tv.provenance.valid)


class TestIsZeroAndIsNan(unittest.TestCase):
    """Test is_zero and is_nan predicates."""

    def test_positive_value_not_zero(self):
        tv = TypedValue.from_float(42.0)
        self.assertFalse(tv.is_zero())

    def test_zero_value_is_zero(self):
        tv = TypedValue.from_float(0.0)
        self.assertTrue(tv.is_zero())

    def test_negative_value_not_zero(self):
        tv = TypedValue.from_float(-1.0)
        self.assertFalse(tv.is_zero())

    def test_nan_is_not_zero(self):
        nan_tv = TypedValue.typed_nan(NaNType.DOMAIN, "test", Domain.PHYSICS_NUMERIC)
        self.assertFalse(nan_tv.is_zero())

    def test_nan_is_nan(self):
        nan_tv = TypedValue.typed_nan(NaNType.DIVERGENT, "test", Domain.PHYSICS_NUMERIC)
        self.assertTrue(nan_tv.is_nan())

    def test_regular_value_not_nan(self):
        tv = TypedValue.from_float(1.0)
        self.assertFalse(tv.is_nan())


class TestPhysicsAdd(unittest.TestCase):
    """Test physics_add with interval arithmetic."""

    def test_basic_addition(self):
        a = TypedValue.from_float(3.0, half_width=0.1)
        b = TypedValue.from_float(5.0, half_width=0.1)
        result = physics_add(a, b)
        self.assertAlmostEqual(result.value, 8.0)
        self.assertAlmostEqual(result.uncertainty.lower, 8.0 - 0.2, places=10)
        self.assertAlmostEqual(result.uncertainty.upper, 8.0 + 0.2, places=10)

    def test_addition_preserves_domain(self):
        a = TypedValue.from_float(1.0, domain=Domain.SENSOR_DATA)
        b = TypedValue.from_float(2.0, domain=Domain.SENSOR_DATA)
        result = physics_add(a, b)
        self.assertEqual(result.domain, Domain.SENSOR_DATA)

    def test_addition_with_custom_domain(self):
        a = TypedValue.from_float(1.0)
        b = TypedValue.from_float(2.0)
        result = physics_add(a, b, domain=Domain.ML_INFERENCE)
        self.assertEqual(result.domain, Domain.ML_INFERENCE)

    def test_confidence_takes_minimum(self):
        a = TypedValue.from_float(1.0, half_width=0.0)
        b = TypedValue.from_float(2.0, half_width=0.0)
        a.uncertainty = Uncertainty(1.0, 1.0, confidence=0.9)
        b.uncertainty = Uncertainty(2.0, 2.0, confidence=0.7)
        result = physics_add(a, b)
        self.assertAlmostEqual(result.uncertainty.confidence, 0.7)

    def test_compatible_units_added(self):
        a = TypedValue.from_float(3.0, units=METER)
        b = TypedValue.from_float(2.0, units=METER)
        result = physics_add(a, b)
        self.assertEqual(result.units, METER)

    def test_incompatible_units_raises(self):
        a = TypedValue.from_float(3.0, units=METER)
        b = TypedValue.from_float(2.0, units=SECOND)
        with self.assertRaises(DimensionalError):
            physics_add(a, b)


class TestPhysicsDivide(unittest.TestCase):
    """Test physics_divide with typed zero checking."""

    def test_normal_division(self):
        a = TypedValue.from_float(10.0, half_width=0.1)
        b = TypedValue.from_float(2.0, half_width=0.1)
        result = physics_divide(a, b)
        # Interval arithmetic: [9.9,10.1] / [1.9,2.1] => midpoint near 5.015
        self.assertAlmostEqual(result.value, 5.0, places=1)
        self.assertTrue(result.uncertainty.lower < 5.0)
        self.assertTrue(result.uncertainty.upper > 5.0)

    def test_divide_by_forbidden_zero_returns_nan(self):
        """Division by a zero typed as EXACT_SYMBOLIC_ZERO in PHYSICS_NUMERIC domain."""
        a = TypedValue.from_float(5.0)
        b = TypedValue.from_float(0.0).with_zero_type(ZeroType.EXACT_SYMBOLIC_ZERO)
        result = physics_divide(a, b, domain=Domain.PHYSICS_NUMERIC)
        self.assertTrue(result.is_nan())
        self.assertEqual(result.nan_type, NaNType.DOMAIN)
        self.assertIn("forbidden_zero", result.provenance.entries[-1].description)

    def test_divide_by_untyped_zero_returns_nan(self):
        a = TypedValue.from_float(5.0)
        b = TypedValue(value=0.0, uncertainty=Uncertainty.exact(0.0),
                       domain=Domain.PHYSICS_NUMERIC, provenance=ProvenanceChain(source="test"))
        result = physics_divide(a, b)
        self.assertTrue(result.is_nan())
        self.assertEqual(result.nan_type, NaNType.DOMAIN)

    def test_divide_by_allowed_typed_zero_returns_divergent_nan(self):
        """Division by a correctly-typed zero still diverges (returns DIVERGENT NaN)."""
        a = TypedValue.from_float(5.0)
        b = TypedValue.from_float(0.0).with_zero_type(ZeroType.MEASURED_ABSENCE)
        result = physics_divide(a, b, domain=Domain.PHYSICS_NUMERIC)
        self.assertTrue(result.is_nan())
        self.assertEqual(result.nan_type, NaNType.DIVERGENT)

    def test_divide_with_units(self):
        a = TypedValue.from_float(10.0, units=METER)
        b = TypedValue.from_float(2.0, units=SECOND)
        result = physics_divide(a, b)
        self.assertEqual(result.units, VELOCITY)


class TestBackendInfo(unittest.TestCase):
    """Test BackendInfo factory methods."""

    def test_runtime_backend(self):
        bi = BackendInfo.runtime()
        self.assertEqual(bi.backend_type, "cpu")
        self.assertTrue(bi.is_exact)

    def test_simulated_analog_backend(self):
        bi = BackendInfo.simulated_analog()
        self.assertEqual(bi.backend_type, "analog")
        self.assertFalse(bi.is_exact)

    def test_simulated_gpu_backend(self):
        bi = BackendInfo.simulated_gpu()
        self.assertEqual(bi.backend_type, "gpu")
        self.assertFalse(bi.is_exact)


if __name__ == "__main__":
    unittest.main()
