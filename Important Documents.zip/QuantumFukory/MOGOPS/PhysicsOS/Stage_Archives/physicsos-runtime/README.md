# PhysicsOS Stage 1 Runtime

> A typed-numerical runtime with uncertainty tracking, domain enforcement, and deterministic replay for physics and security-critical computing.

---

## What is PhysicsOS?

PhysicsOS is an operating-system-level infrastructure for **typed numerical computing**. Instead of treating all numbers as raw floating-point values, every number in PhysicsOS carries:

- **Uncertainty** — Interval bounds with confidence and component breakdown (measurement, rounding, model, hardware, time, security)
- **Domain** — Semantic context (formal proof, security authority, sensor data, ML inference, etc.)
- **Provenance** — Immutable audit trail of all operations that produced the value
- **Backend** — Which compute engine produced the result and whether it was exact
- **Units** — SI dimensional analysis (kg, m, s, A, K, mol, cd)
- **Zero Type** — Why this value is zero (exact symbolic, measured absence, hardware ground, etc.)
- **NaN Type** — Why this value is undefined (domain violation, divergence, unauthorized, etc.)

These metadata fields enable 10 novel mechanisms (Invention Cards IC-01 through IC-10) that prevent entire classes of bugs:

| IC | Mechanism | Problem Solved |
|----|-----------|---------------|
| IC-01 | Typed Zero Boundary Semantics | Silent zero corruption across domains |
| IC-02 | Typed NaN Recovery Policies | Undiagnosable NaN propagation |
| IC-03 | TypedValue ABI | Metadata loss at boundaries |
| IC-04 | Exact Security + Approximate Science | Inexact values authorizing security |
| IC-05 | Backend Contract Validator | Undetected backend drift/expiry |
| IC-06 | No-OOM Approximation Degradation | Out-of-memory crashes |
| IC-07 | Deterministic Replay | Non-reproducible physics results |
| IC-08 | Dimensional Analysis | Mars-Climate-Orbiter unit errors |
| IC-09 | Uncertainty Firewall | Unbounded noise propagation |
| IC-10 | Xi Efficiency Metric | Unmeasured safety overhead |

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        CLI / API Surface                     │
│                     cli.py / core/__init__.py                │
├─────────────┬──────────────┬──────────────┬─────────────────┤
│   Policy    │   Backend    │   Memory     │     Replay      │
│   Layer     │   Layer      │   Layer      │     Layer       │
│             │              │              │                 │
│ zero_policy │ backend_     │ exact_       │ replay_log      │
│ exact_      │ contract     │ object       │ deterministic_  │
│ security_   │ cpu_         │ approx_      │ runner          │
│ gate        │ simulated_   │ field        │ event_record    │
│ approx_     │ gpu_         │ no_oom_      │ uncertainty_    │
│ science_    │ simulated_   │ degrader     │ snapshot        │
│ gate        │ analog_      │ coarsening   │                 │
│ uncertainty │ verifier     │ memory_      │                 │
│ _firewall   │              │ pressure     │                 │
│ nan_policy  │              │              │                 │
├─────────────┴──────────────┴──────────────┴─────────────────┤
│                        Core Types                             │
│                                                              │
│  TypedValue · Uncertainty · Interval · Domain · ZeroType     │
│  NaNType · ProvenanceChain · Unit · BackendInfo              │
├──────────────────────────────────────────────────────────────┤
│                        Metrics                                │
│                                                              │
│  XiReport · OverheadTracker · BenchmarkRunner · Report        │
└──────────────────────────────────────────────────────────────┘
```

---

## Quick Start

```bash
# Run the demo suite
python cli.py demo all

# Run benchmarks
python cli.py bench

# Run benchmarks with JSON output
python cli.py bench --json results.json

# Run tests
python cli.py test

# Generate Stage 1 report
python cli.py report stage1
python cli.py report stage1 --out report.md
```

### Programmatic Usage

```python
from core import (
    TypedValue, Domain, Uncertainty, ZeroType, NaNType,
    Interval, ProvenanceChain, Unit, METER, SECOND, JOULE,
    physics_add, physics_divide,
)
from policy.zero_policy import check_zero_at_boundary
from policy.exact_security_gate import exact_security_gate
from policy.uncertainty_firewall import uncertainty_firewall, BoundaryPolicy

# Create a typed value from a float
v = TypedValue.from_float(9.80665, half_width=0.00001,
                          domain=Domain.PHYSICS_NUMERIC, units=ACCELERATION)

# Check if a zero can cross a boundary
zero_val = TypedValue(value=0, uncertainty=Uncertainty.exact(0),
                      domain=Domain.PHYSICS_NUMERIC,
                      provenance=ProvenanceChain(source="demo"),
                      zero_type=ZeroType.MEASURED_ABSENCE)
result = check_zero_at_boundary(zero_val, Domain.SECURITY_AUTHORITY)
print(result.allowed)   # False
print(result.reason)    # REJECTED: measured_absence not allowed in security_authority

# Security gate: only exact values in SECURITY_AUTHORITY can authorize
sec_val = TypedValue(value=1, uncertainty=Uncertainty.exact(1),
                     domain=Domain.SECURITY_AUTHORITY,
                     provenance=ProvenanceChain(source="auth"),
                     zero_type=ZeroType.NULL_CAPABILITY)
result = exact_security_gate(sec_val, "grant_access")
print(result.decision.value)  # allow

# Uncertainty firewall
noisy = TypedValue.from_float(25.7, half_width=5.0, domain=Domain.SENSOR_DATA)
policy = BoundaryPolicy(max_uncertainty=1.0, target_domain=Domain.PHYSICS_NUMERIC)
result = uncertainty_firewall(noisy, policy)
print(result.accepted)  # False (uncertainty too high)
```

---

## File Structure

```
physicsos-runtime/
├── cli.py                          # CLI entry point
├── README.md                       # This file
├── requirements.txt                # Dependencies
├── setup.py                        # Package setup
├── core/                           # Core type system
│   ├── __init__.py                 # Public API re-exports
│   ├── domain.py                   # Domain enum + compatibility
│   ├── typed_zero.py               # ZeroType + policy table
│   ├── typed_nan.py                # NaNType + recovery policies
│   ├── uncertainty.py              # Uncertainty interval + components
│   ├── interval.py                 # IEEE 1788-2015 interval arithmetic
│   ├── provenance.py               # ProvenanceChain (immutable audit trail)
│   ├── units.py                    # SI Unit + DimensionalError
│   └── typed_value.py              # TypedValue, BackendInfo, physics ops
├── policy/                         # Policy enforcement layer
│   ├── __init__.py
│   ├── zero_policy.py              # check_zero_at_boundary()
│   ├── nan_policy.py               # handle_typed_nan(), nan_info()
│   ├── exact_security_gate.py      # exact_security_gate()
│   ├── approximate_science_gate.py # approximate_science_gate()
│   ├── uncertainty_firewall.py     # uncertainty_firewall()
│   └── approximation_policy.py     # ApproximationConfig
├── backend/                        # Backend abstraction layer
│   ├── __init__.py
│   ├── backend_contract.py         # BackendContract + validation
│   ├── verifier.py                 # verify_backend_result()
│   ├── cpu_backend.py              # CPU (exact) backend
│   ├── simulated_gpu_backend.py    # Simulated GPU backend
│   └── simulated_analog_backend.py # Simulated analog backend
├── memory/                         # Memory management layer
│   ├── __init__.py
│   ├── exact_object.py             # ExactObject (never degrade)
│   ├── approximate_field.py        # ApproxField (coarsenable)
│   ├── no_oom_degrader.py          # handle_memory_pressure()
│   ├── coarsening.py               # Coarsening strategies
│   └── memory_pressure.py          # Pressure simulation
├── replay/                         # Deterministic replay layer
│   ├── __init__.py
│   ├── replay_log.py               # ReplayLog (append-only event store)
│   ├── deterministic_runner.py     # DeterministicRunner
│   ├── event_record.py             # ReplayEvent + serialization
│   └── uncertainty_snapshot.py     # UncertaintySnapshot
├── metrics/                        # Metrics and benchmarking
│   ├── __init__.py
│   ├── xi_metric.py                # compute_xi(), XiReport
│   ├── overhead_tracker.py         # OverheadTracker
│   ├── benchmark_runner.py         # BenchmarkRunner
│   └── report.py                   # Stage1ReportGenerator
├── demos/                          # Demo scripts (to be created)
│   ├── demo_equality.py
│   ├── demo_typed_zero.py
│   ├── demo_typed_nan.py
│   ├── demo_security_split.py
│   ├── demo_backend_contract.py
│   ├── demo_no_oom_degrade.py
│   ├── demo_replay.py
│   ├── demo_units.py
│   ├── demo_conservation.py
│   └── demo_xi_report.py
├── tests/                          # Unit tests (to be created)
└── docs/                           # Documentation
    ├── stage1_invention_disclosure.md   # IC-01 through IC-10
    ├── api_spec.md                     # Full API reference
    ├── benchmark_protocol.md           # B1-B10 benchmark protocol
    ├── patent_claim_map.md             # Feature → IC → Claim → Demo → Code
    └── stage1_results.md               # Results template
```

---

## Stage 1 Scope

### Included

- [x] Core type system (TypedValue, Uncertainty, Interval, Domain, ZeroType, NaNType, Provenance, Unit)
- [x] Physics arithmetic with interval propagation (`physics_add`, `physics_divide`)
- [x] Zero boundary policy enforcement (`check_zero_at_boundary`)
- [x] NaN recovery policies (`handle_typed_nan`)
- [x] Exact security gate (`exact_security_gate`)
- [x] Approximate science gate (`approximate_science_gate`)
- [x] Uncertainty firewall (`uncertainty_firewall`)
- [x] Backend contract validation (`validate_backend_contract`)
- [x] No-OOM memory degradation (`handle_memory_pressure`)
- [x] Deterministic replay (`ReplayLog`, `DeterministicRunner`)
- [x] SI dimensional analysis (`Unit`, `DimensionalError`)
- [x] Xi efficiency metric (`compute_xi`, `XiReport`)
- [x] Benchmark runner (`BenchmarkRunner`)
- [x] CLI entry point (`cli.py`)
- [x] Invention disclosure (IC-01 through IC-10)
- [x] API specification
- [x] Benchmark protocol (B1-B10)
- [x] Patent claim map
- [x] Simulated CPU, GPU, and analog backends

### Excluded (Future Stages)

- [ ] Linux kernel module for domain enforcement
- [ ] Real GPU backend (CuPy/CUDA)
- [ ] Real analog/FPGA hardware backends
- [ ] Real sensor integration (I2C/SPI)
- [ ] Formal verification in Lean/Coq
- [ ] C/Rust extension for performance
- [ ] Concurrent access and locking
- [ ] Conservation law debugger (framework exists, solver TBD)
- [ ] Property-based testing (Hypothesis)
- [ ] Container/k8s deployment

---

## Dependencies

PhysicsOS Stage 1 uses **only the Python standard library**. No third-party packages are required for the core runtime.

Optional:
- `pytest` — for running unit tests
- `psutil` — for real memory tracking in benchmarks (not required)

---

## License

[License placeholder — All rights reserved.]
