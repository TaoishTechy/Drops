# PhysicsOS Stage 1 API Specification

> **Version:** Stage 1 Runtime
> **Module:** `core/`, `policy/`, `backend/`, `memory/`, `replay/`, `metrics/`

---

## Table of Contents

1. [Core Types](#1-core-types)
   - [Domain](#domain)
   - [ZeroType](#zerotype)
   - [NaNType](#nantype)
   - [Uncertainty](#uncertainty)
   - [Interval](#interval)
   - [ProvenanceChain](#provenancechain)
   - [Unit & DimensionalError](#unit--dimensionalerror)
   - [BackendInfo](#backendinfo)
   - [TypedValue](#typedvalue)
2. [Policy Layer](#2-policy-layer)
   - [Zero Policy](#zero-policy)
   - [Exact Security Gate](#exact-security-gate)
   - [Approximate Science Gate](#approximate-science-gate)
   - [Uncertainty Firewall](#uncertainty-firewall)
   - [NaN Policy](#nan-policy)
   - [Approximation Policy](#approximation-policy)
3. [Backend Layer](#3-backend-layer)
   - [BackendContract](#backendcontract)
   - [validate_backend_contract](#validate_backend_contract)
   - [Backend Implementations](#backend-implementations)
4. [Memory Layer](#4-memory-layer)
   - [ExactObject](#exactobject)
   - [ApproxField](#approxfield)
   - [handle_memory_pressure](#handle_memory_pressure)
5. [Replay Layer](#5-replay-layer)
   - [ReplayLog](#replaylog)
   - [DeterministicRunner](#deterministicrunner)
   - [ReplayEvent](#replayevent)
6. [Metrics Layer](#6-metrics-layer)
   - [compute_xi & XiReport](#compute_xi--xireport)
   - [BenchmarkRunner](#benchmarkrunner)
   - [OverheadTracker](#overheadtracker)
7. [Predefined Constants](#7-predefined-constants)

---

## 1. Core Types

All core types are re-exported from `core/__init__.py`.

### Domain

```python
from core.domain import Domain, domain_compatible
```

**Enum Values:**

| Value | Description |
|-------|-------------|
| `FORMAL_PROOF` | Mathematically exact computations (proofs, formal verification) |
| `PHYSICS_NUMERIC` | Physics calculations with finite precision |
| `SECURITY_AUTHORITY` | Security authorization decisions (must be exact) |
| `MEMORY_ACCESS` | Memory addresses and pointers |
| `SENSOR_DATA` | Physical sensor readings (inherently approximate) |
| `FILESYSTEM_EXACT` | Exact filesystem operations |
| `FILESYSTEM_APPROX` | Approximate filesystem operations (compression, search) |
| `NETWORK_TELEMETRY` | Network measurement data |
| `ML_INFERENCE` | Machine learning model outputs |
| `HUMAN_DISPLAY` | Final output for human consumption (display sink) |

**Functions:**

```python
domain_compatible(a: Domain, b: Domain) -> bool
```
Returns `True` if two domains are compatible for cross-domain operations. Same domain is always compatible. `HUMAN_DISPLAY` and `FORMAL_PROOF` are compatible with anything.

---

### ZeroType

```python
from core.typed_zero import ZeroType, ZERO_POLICY_TABLE, zero_allowed, zero_allowed_info
```

**Enum Values:**

| Value | Description |
|-------|-------------|
| `EXACT_SYMBOLIC_ZERO` | Zero by mathematical definition |
| `MEASURED_ABSENCE` | Sensor returned no signal |
| `HARDWARE_GROUND` | Electrical ground reference |
| `NULL_CAPABILITY` | Zero as "no permission" (capability model) |
| `COMPUTATIONAL_OPERAND_ZERO` | Intermediate computation produced zero |
| `UNTYPED_ZERO` | Legacy/untyped zero (always rejected at boundaries) |

**Functions:**

```python
zero_allowed(zero_type: ZeroType, context: Domain) -> bool
```
Check if a zero of the given type is allowed in the specified domain.

```python
zero_allowed_info(zero_type: ZeroType, context: Domain) -> str
```
Return a human-readable reason string for the allow/reject decision.

**Policy Table:**

```python
ZERO_POLICY_TABLE: dict[Domain, set[ZeroType]]
```
Maps each domain to its set of permitted `ZeroType` values. See `core/typed_zero.py` for the full table.

---

### NaNType

```python
from core.typed_nan import NaNType, NAN_RECOVERY_POLICY, nan_recovery_policy, nan_description
```

**Enum Values:**

| Value | Description |
|-------|-------------|
| `DOMAIN` | Operation violated domain constraints (e.g., division by forbidden zero) |
| `DIVERGENT` | Computation diverged beyond representable bounds |
| `UNMEASURED` | Required measurement was not available |
| `UNAUTHORIZED` | Value lacked authorization for the requested context |
| `HARDWARE_FAULT` | Hardware backend reported an unrecoverable fault |
| `TIMEOUT` | Computation exceeded the allowed time budget |

**Functions:**

```python
nan_recovery_policy(nan_type: NaNType) -> str
```
Returns the recovery policy string for the given NaN type.

```python
nan_description(nan_type: NaNType) -> str
```
Returns a human-readable description of the NaN type.

**Recovery Policies:**

| NaNType | Recovery Policy |
|---------|----------------|
| `DOMAIN` | `raise_domain_error_with_operands` |
| `DIVERGENT` | `return_clamped_interval_or_raise` |
| `UNMEASURED` | `defer_to_policy_or_request_measurement` |
| `UNAUTHORIZED` | `deny_and_log_security_event` |
| `HARDWARE_FAULT` | `retry_with_different_backend_or_fail` |
| `TIMEOUT` | `retry_with_increased_timeout_or_return_approximation` |

---

### Uncertainty

```python
from core.uncertainty import Uncertainty
```

**Dataclass Fields:**

| Field | Type | Description |
|-------|------|-------------|
| `lower` | `float` | Lower bound of the uncertainty interval |
| `upper` | `float` | Upper bound of the uncertainty interval |
| `confidence` | `float` | Confidence level (0.0 to 1.0) |
| `measurement` | `float` | Measurement uncertainty component |
| `rounding` | `float` | Rounding uncertainty component |
| `model` | `float` | Model uncertainty component |
| `hardware` | `float` | Hardware uncertainty component |
| `time` | `float` | Time uncertainty component |
| `security` | `float` | Security uncertainty component |
| `covariance_id` | `Optional[str]` | Covariance group identifier |

**Properties:**

```python
.width -> float              # upper - lower
.midpoint -> float           # (lower + upper) / 2
.total() -> float            # RSS of measurement, rounding, model, hardware, time, security
.overlaps(other) -> bool     # True if intervals overlap
.overlap_fraction(other) -> float  # intersection / union ratio
```

**Class Methods:**

```python
Uncertainty.from_point(value, half_width=0.0, confidence=1.0, **kwargs) -> Uncertainty
Uncertainty.from_confidence(confidence) -> Uncertainty  # [0.0, 1.0] interval
Uncertainty.infinite() -> Uncertainty                     # [-inf, +inf], conf=0.0
Uncertainty.exact(value) -> Uncertainty                   # [value, value], conf=1.0
```

**Operators:**

```python
__add__(other: Uncertainty) -> Uncertainty  # Interval addition, min confidence
__mul__(scalar: float) -> Uncertainty       # Scale interval bounds
```

---

### Interval

```python
from core.interval import Interval
```

IEEE 1788-2015 inspired interval arithmetic.

**Constructor:**

```python
Interval(lower: float, upper: float, *, _allow_inverted: bool = False)
```
Raises `ValueError` if `lower > upper` (unless `_allow_inverted=True`).

**Properties:**

```python
.width -> float       # upper - lower (0.0 if empty)
.midpoint -> float    # (lower + upper) / 2 (NaN if empty)
.is_empty -> bool     # True if lower > upper
```

**Class Methods:**

```python
Interval.from_value(value, half_width=0.0) -> Interval
Interval.exact(value) -> Interval                    # [value, value]
Interval.empty() -> Interval                         # Special empty interval
Interval.entire() -> Interval                        # [-inf, +inf]
Interval.hull(values) -> Interval                    # Hull of a list of floats
```

**Operations:**

| Operator | Behavior |
|----------|----------|
| `a + b` | Interval addition: `[a.lower+b.lower, a.upper+b.upper]` |
| `a - b` | Interval subtraction: `[a.lower-b.upper, a.upper-b.lower]` |
| `a * b` | Interval multiplication (4-corner evaluation) |
| `a / b` | Interval division (raises `ZeroDivisionError` if b contains 0) |
| `-a` | Interval negation: `[-a.upper, -a.lower]` |
| `a == b` | True if bounds are equal (empty intervals are equal) |

**Methods:**

```python
.overlaps(other) -> bool
.intersection(other) -> Interval   # Empty interval if no overlap
.union(other) -> Interval
.contains(value: float) -> bool
.to_uncertainty(confidence=1.0) -> Uncertainty
```

---

### ProvenanceChain

```python
from core.provenance import ProvenanceEntry, ProvenanceChain
```

**ProvenanceEntry Fields:**

| Field | Type | Description |
|-------|------|-------------|
| `operation` | `str` | Name of the operation |
| `timestamp_ns` | `int` | Nanosecond timestamp |
| `description` | `str` | Human-readable description |
| `source_id` | `Optional[str]` | Optional source identifier |

**ProvenanceChain Methods:**

```python
ProvenanceChain(entries=None, source="initial") -> ProvenanceChain
.add(operation, description="", source_id=None) -> ProvenanceChain  # Immutable
.merge(other: ProvenanceChain) -> ProvenanceChain                  # Immutable concatenation
.valid -> bool              # True if non-empty and all entries have operations
.hash() -> str              # SHA-256 hash (first 16 hex chars)
.__len__() -> int           # Number of entries
```

---

### Unit & DimensionalError

```python
from core.units import (
    Unit, DimensionalError,
    DIMENSIONLESS, METER, SECOND, KILOGRAM, AMPERE, KELVIN, MOLE, CANDELA,
    VELOCITY, ACCELERATION, NEWTON, JOULE, WATT, HERTZ, VOLT, OHM, FARAD, TESLA,
)
```

**Unit Dataclass** (frozen):

| Field | Type | Description |
|-------|------|-------------|
| `kg` | `int` | Kilogram exponent |
| `m` | `int` | Meter exponent |
| `s` | `int` | Second exponent |
| `A` | `int` | Ampere exponent |
| `K` | `int` | Kelvin exponent |
| `mol` | `int` | Mole exponent |
| `cd` | `int` | Candela exponent |

**Unit Properties & Methods:**

```python
.is_dimensionless -> bool
.compatible(other: Unit) -> bool    # Same dimensional signature
.__add__(other) -> Unit             # Raises DimensionalError if incompatible
.__sub__(other) -> Unit             # Raises DimensionalError if incompatible
.__mul__(other: Unit) -> Unit       # Add exponents
.__truediv__(other: Unit) -> Unit   # Subtract exponents
.__pow__(exponent: int) -> Unit     # Scale exponents
.__eq__, __hash__, __repr__
```

**DimensionalError:** Raised when incompatible units are added or subtracted.

---

### BackendInfo

```python
from core.typed_value import BackendInfo
```

**Fields:**

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `backend_id` | `str` | `"runtime"` | Backend identifier |
| `backend_type` | `str` | `"cpu"` | Backend type string |
| `is_exact` | `bool` | `True` | Whether backend produces exact results |
| `precision_range` | `tuple` | `(0.0, 1e-15)` | `(min, max)` precision range |

**Class Methods:**

```python
BackendInfo.runtime() -> BackendInfo           # CPU exact, default
BackendInfo.simulated_analog() -> BackendInfo  # Analog, noise 0.01-0.1
BackendInfo.simulated_gpu() -> BackendInfo     # GPU, noise 1e-7 to 1e-6
```

---

### TypedValue

```python
from core.typed_value import TypedValue, BackendInfo, physics_add, physics_divide
```

**Fields:**

| Field | Type | Description |
|-------|------|-------------|
| `value` | `Any` | Raw numeric value (or `None` for NaN) |
| `uncertainty` | `Uncertainty` | Uncertainty interval and components |
| `domain` | `Domain` | Semantic domain |
| `provenance` | `ProvenanceChain` | Computation audit trail |
| `backend` | `BackendInfo` | Backend metadata |
| `units` | `Optional[Unit]` | SI dimensional signature |
| `zero_type` | `Optional[ZeroType]` | Typed zero classification |
| `nan_type` | `Optional[NaNType]` | Typed NaN classification |

**Methods:**

```python
.is_zero() -> bool               # True if value is zero (and not NaN)
.is_nan() -> bool                # True if nan_type is set
.interval() -> Interval           # Uncertainty as Interval
.with_domain(new_domain) -> TypedValue          # Immutable domain change
.with_zero_type(zt: ZeroType) -> TypedValue     # Immutable zero typing
.with_nan_type(nt: NaNType, reason="") -> TypedValue  # Immutable NaN assignment
```

**Class Methods:**

```python
TypedValue.from_float(value, domain=Domain.PHYSICS_NUMERIC,
                       half_width=0.0, units=None) -> TypedValue
```
Creates a TypedValue from a float. Automatically assigns `COMPUTATIONAL_OPERAND_ZERO` if value is 0.0.

```python
TypedValue.typed_nan(nan_type, reason, domain, provenance=None, operands=None) -> TypedValue
```
Creates a NaN TypedValue with the specified type, reason, and domain. Optionally merges operand provenance.

**Module Functions:**

```python
physics_add(a: TypedValue, b: TypedValue, domain=None) -> TypedValue
```
Add two TypedValues with interval arithmetic and unit compatibility checking. Returns a new TypedValue with merged provenance.

```python
physics_divide(a: TypedValue, b: TypedValue, domain=None) -> TypedValue
```
Divide two TypedValues with typed zero checking. Division by forbidden or untyped zero produces a typed NaN. Division by allowed typed zero produces a DIVERGENT NaN.

---

## 2. Policy Layer

### Zero Policy

```python
from policy.zero_policy import ZeroCheckResult, check_zero_at_boundary
```

```python
@dataclass
class ZeroCheckResult:
    allowed: bool
    reason: str
    value: TypedValue = None

def check_zero_at_boundary(value: TypedValue, target_domain: Domain) -> ZeroCheckResult
```

Checks whether a zero value may cross into the target domain. Non-zero values pass through. Untyped zeros are ALWAYS rejected (converted to DOMAIN NaN). Typed zeros are checked against `ZERO_POLICY_TABLE`.

---

### Exact Security Gate

```python
from policy.exact_security_gate import AccessDecision, SecurityResult, exact_security_gate
```

```python
class AccessDecision(Enum):
    ALLOW = "allow"
    DENY = "deny"

@dataclass
class SecurityResult:
    decision: AccessDecision
    reason: str
    value: TypedValue = None

def exact_security_gate(value: TypedValue, decision: str) -> SecurityResult
```

Authorization rules (all must be satisfied):
1. `value` is not NaN
2. `value.domain == SECURITY_AUTHORITY`
3. `value.uncertainty.security == 0`
4. `value.backend.is_exact == True`
5. `value.provenance.valid == True`

---

### Approximate Science Gate

```python
from policy.approximate_science_gate import ApproximationPolicy, GateResult, approximate_science_gate
```

```python
@dataclass
class ApproximationPolicy:
    max_uncertainty: float = 0.1
    min_confidence: float = 0.5
    allowed_domains: list = None  # Defaults to all except SECURITY_AUTHORITY

@dataclass
class GateResult:
    accepted: bool
    reason: str
    uncertainty_total: float = 0.0
    confidence: float = 0.0

def approximate_science_gate(value: TypedValue, policy: ApproximationPolicy) -> GateResult
```

Acceptance rules:
1. `value` is not NaN
2. `value.domain != SECURITY_AUTHORITY`
3. `value.domain` in `allowed_domains`
4. `uncertainty.total() <= max_uncertainty`
5. `uncertainty.confidence >= min_confidence`

---

### Uncertainty Firewall

```python
from policy.uncertainty_firewall import BoundaryPolicy, BoundaryResult, uncertainty_firewall
```

```python
@dataclass
class BoundaryPolicy:
    max_uncertainty: float
    target_domain: Domain
    name: str = "default"

@dataclass
class BoundaryResult:
    accepted: bool
    reason: str
    value: TypedValue = None

def uncertainty_firewall(value: TypedValue, policy: BoundaryPolicy) -> BoundaryResult
```

Rules:
1. NaN values are always rejected.
2. `uncertainty.total() > max_uncertainty` → rejected.
3. Accepted values are automatically re-domained to `target_domain`.

---

### NaN Policy

```python
from policy.nan_policy import NaNHandling, handle_typed_nan, nan_info
```

```python
@dataclass
class NaNHandling:
    allow_pass: bool
    recovery_policy: str
    reason: str

def handle_typed_nan(value: TypedValue, target_domain: Domain, allow_recovery: bool = True) -> TypedValue
```

Boundary NaN handling:
1. Non-NaN values pass through unchanged.
2. `UNAUTHORIZED` NaN is always blocked.
3. All NaN types are blocked at `SECURITY_AUTHORITY`.
4. Other NaN types pass through if `allow_recovery=True`.

```python
def nan_info(value: TypedValue) -> dict
```
Returns diagnostic info: `is_nan`, `nan_type`, `description`, `recovery_policy`, `domain`.

---

### Approximation Policy

```python
from policy.approximation_policy import ApproximationConfig
```

```python
@dataclass
class ApproximationConfig:
    default_max_uncertainty: float = 0.1
    default_min_confidence: float = 0.5
    degradation_pressure_threshold: float = 0.85
    degradation_target_pressure: float = 0.70
    replay_log_max_events: int = 100000
    benchmark_iterations: int = 100000
```

---

## 3. Backend Layer

### BackendContract

```python
from backend.backend_contract import BackendContract, ContractResult, validate_backend_contract
```

```python
@dataclass
class BackendContract:
    backend_id: str
    backend_type: Literal["cpu", "gpu", "analog", "simulated_analog", "fpga"]
    precision_range: tuple           # (min_precision, max_precision)
    noise_model: Optional[str] = None
    drift_model: Optional[str] = None
    calibration_age_seconds: float = 0.0
    calibration_max_age_seconds: float = 120.0
    verifier_required: bool = False
    failure_modes: List[str] = None
    reproducibility_score: float = 1.0
    exact_security_allowed: bool = False

    @property
    def calibration_valid -> bool
    @property
    def precision_string -> str

@dataclass
class ContractResult:
    accepted: bool
    reason: str
    backend_id: str = ""
    calibration_status: str = ""

def validate_backend_contract(contract: BackendContract, result_uncertainty: float,
                               policy_max_uncertainty: float = 0.1) -> ContractResult
```

Acceptance rules:
1. `result_uncertainty <= policy_max_uncertainty`
2. `calibration_age_seconds <= calibration_max_age_seconds`
3. Verifier check passed (if `verifier_required`)

---

### Backend Implementations

```python
from backend.cpu_backend import make_cpu_contract, cpu_compute
from backend.simulated_gpu_backend import make_gpu_contract, gpu_compute
from backend.simulated_analog_backend import make_analog_contract, analog_compute
from backend.verifier import VerificationResult, verify_backend_result
```

| Backend | Precision | Exact | Cal. Max Age |
|---------|-----------|-------|-------------|
| CPU | [0.0, 1e-15] | Yes | inf |
| GPU (sim) | [1e-7, 1e-6] | No | 300s |
| Analog (sim) | [0.01, 0.1] | No | 120s |

```python
def verify_backend_result(contract, result: float, expected_range: tuple,
                          uncertainty: float) -> VerificationResult
```

---

## 4. Memory Layer

### ExactObject

```python
from memory.exact_object import ExactObject
```

```python
@dataclass
class ExactObject:
    object_id: str
    bytes_data: bytes
    integrity_hash: str
    provenance: ProvenanceChain
    can_degrade: bool = False       # ALWAYS False for ExactObject
    priority: int = 0
    memory_size_bytes: int = 0      # Auto-computed from bytes_data

    def verify_integrity(self) -> bool  # SHA-256 check
```

---

### ApproxField

```python
from memory.approximate_field import ApproxField, CoarseningPolicy
```

```python
@dataclass
class CoarseningPolicy:
    min_fidelity: int = 1
    coarsen_step: int = 1
    memory_per_fidelity_level: int = 1024

@dataclass
class ApproxField:
    field_id: str
    shape: tuple
    basis: str
    fidelity_level: int
    uncertainty: Uncertainty
    backend_hint: str = "cpu"
    can_degrade: bool = True
    coarsening_policy: CoarseningPolicy
    priority: int = 0
    provenance: ProvenanceChain

    @property
    def memory_size_bytes -> int
    @property
    def can_coarsen -> bool

    def coarsen(levels=1) -> int  # Returns bytes saved
```

---

### handle_memory_pressure

```python
from memory.no_oom_degrader import handle_memory_pressure, DegradationReport, DegradationAction
```

```python
@dataclass
class DegradationAction:
    object_id: str
    object_type: str          # "exact" or "approx"
    action: str               # "preserved", "coarsened", "protected"
    old_fidelity: int = 0
    new_fidelity: int = 0
    memory_saved: int = 0

@dataclass
class DegradationReport:
    pressure_before: float
    pressure_after: float
    target_pressure: float
    actions: List[DegradationAction]

def handle_memory_pressure(objects: List[MemoryObject], pressure: float,
                           target_pressure: float = 0.70) -> DegradationReport
```

Algorithm:
1. Preserve all ExactObjects (cannot degrade).
2. Sort ApproxFields by priority (ascending), memory size (descending).
3. Coarsen lowest-priority fields until `pressure <= target_pressure`.
4. Log all actions.

---

## 5. Replay Layer

### ReplayLog

```python
from replay.replay_log import ReplayLog
```

```python
class ReplayLog:
    def __init__(log_id="default")
    def record(self, operation, inputs, outputs, policy_snapshot=None,
               backend_snapshot=None, uncertainty_snapshot=None) -> ReplayEvent
    def __len__() -> int
    def to_dict() -> dict
    def save(filepath: str)
    @classmethod
    def load(cls, filepath: str) -> ReplayLog
```

---

### DeterministicRunner

```python
from replay.deterministic_runner import DeterministicRunner
```

```python
class DeterministicRunner:
    def __init__(replay_log=None)
    def run_and_record(self, operation, func, *args, policy_snapshot=None,
                       backend_snapshot=None, uncertainty_snapshot=None) -> tuple
    def replay(self, operation_id, func, *args) -> (matches, current_outputs, recorded_outputs)
    def verify_full_replay(self, func_map: dict) -> bool
```

---

### ReplayEvent

```python
from replay.event_record import ReplayEvent, serialize_typed_value
```

```python
@dataclass
class ReplayEvent:
    event_id: str
    timestamp_ns: int
    operation: str
    inputs: List[Dict[str, Any]]
    outputs: List[Dict[str, Any]]
    policy_snapshot: Dict[str, Any]
    backend_contract_snapshot: Dict[str, Any]
    uncertainty_snapshot: Dict[str, Any]
    provenance_hash: str

def serialize_typed_value(tv: TypedValue) -> dict
```

---

## 6. Metrics Layer

### compute_xi & XiReport

```python
from metrics.xi_metric import compute_xi, XiReport, OverheadMetrics, format_xi_report
```

```python
@dataclass
class OverheadMetrics:
    useful_work: float = 0.0
    control_overhead: float = 0.0
    memory_overhead: float = 0.0
    error_overhead: float = 0.0
    calibration_overhead: float = 0.0
    translation_overhead: float = 0.0

@dataclass
class XiReport:
    useful_work: float
    control_overhead: float
    memory_overhead: float
    error_overhead: float
    calibration_overhead: float
    translation_overhead: float
    xi: float
    total_overhead: float

    @classmethod
    def from_metrics(m: OverheadMetrics) -> XiReport

def compute_xi(metrics: OverheadMetrics) -> float
    # Xi = W_useful / (W_useful + O_control + O_memory + O_error + O_calibration + O_translation)

def format_xi_report(report: XiReport) -> str
```

---

### BenchmarkRunner

```python
from metrics.benchmark_runner import BenchmarkRunner, BenchmarkResult
```

```python
@dataclass
class BenchmarkResult:
    benchmark: str
    operations: int
    runtime_ms: float
    memory_used_mb: float
    metadata_overhead_bytes_per_value: int
    decision_accuracy: float = 1.0
    false_accept_count: int = 0
    false_reject_count: int = 0
    xi: float = 0.0

class BenchmarkRunner:
    def run(self, name, func, iterations=100000, setup=None, teardown=None) -> BenchmarkResult
    def run_all(self, benchmarks: dict, iterations=100000) -> List[BenchmarkResult]
    def summary_table() -> str
    def to_json() -> str
```

The `func` callback may return a dict with keys: `correct`, `false_accept`, `false_reject`.

---

### OverheadTracker

```python
from metrics.overhead_tracker import OverheadTracker, OverheadEntry
```

```python
@dataclass
class OverheadEntry:
    category: str
    operation: str
    duration_ns: int
    memory_delta: int = 0

class OverheadTracker:
    def start(category: str, operation: str = "")
    def stop(category: str, operation: str = "", memory_delta: int = 0)
    def summary() -> Dict[str, int]        # Total ns per category
    def to_overhead_metrics(useful_work_ns: int) -> OverheadMetrics
```

Categories: `control`, `memory`, `error`, `calibration`, `translation`.

---

## 7. Predefined Constants

### SI Units

```python
from core.units import (
    DIMENSIONLESS,  # ()
    METER,          # m
    SECOND,         # s
    KILOGRAM,       # kg
    AMPERE,         # A
    KELVIN,         # K
    MOLE,           # mol
    CANDELA,        # cd
    VELOCITY,       # m * s^-1
    ACCELERATION,   # m * s^-2
    NEWTON,         # kg * m * s^-2
    JOULE,          # kg * m^2 * s^-2
    WATT,           # kg * m^2 * s^-3
    HERTZ,          # s^-1
    VOLT,           # kg * m^2 * s^-3 * A^-1
    OHM,            # kg * m^2 * s^-3 * A^-2
    FARAD,          # kg^-1 * m^-2 * s^4 * A^2
    TESLA,          # kg * s^-2 * A^-1
)
```
