# PhysicsOS Stage 1 Patent Claim Map

> **Document Type:** IP Feature → Invention Card → Claims → Demos → Code
> **Stage:** Stage 1 Runtime

---

## Overview

This document maps every IP-relevant feature in the PhysicsOS Stage 1 runtime to its invention card, potential patent claims, demo validation, and source code implementation.

---

## IC-01: Typed Zero Boundary Semantics

| Aspect | Details |
|--------|---------|
| **Feature** | Per-domain zero-type policy enforcement at runtime boundaries |
| **Invention Card** | IC-01 |
| **Claims** | |
| C-01.1 | Method for enforcing per-domain zero-value semantics at runtime boundaries |
| C-01.2 | Data structure combining numeric value with zero-type enum and domain tag |
| C-01.3 | Declarative policy table mapping domains to permitted zero-type subsets |
| **Demo** | `demo_typed_zero` |
| **Benchmark** | B2: Typed Zero Boundary Overhead |
| **Core Code** | `core/typed_zero.py` — `ZeroType`, `ZERO_POLICY_TABLE`, `zero_allowed()` |
| **Policy Code** | `policy/zero_policy.py` — `check_zero_at_boundary()`, `ZeroCheckResult` |
| **Data Structure** | `TypedValue.zero_type` field in `core/typed_value.py` |

---

## IC-02: Typed Undefined / Typed NaN Recovery Policies

| Aspect | Details |
|--------|---------|
| **Feature** | NaN values classified by failure semantics with per-type recovery policies |
| **Invention Card** | IC-02 |
| **Claims** | |
| C-02.1 | Method for classifying NaN values by failure semantics with recovery policies |
| C-02.2 | Boundary enforcement blocking security-critical NaN types from protected domains |
| C-02.3 | Provenance-traced NaN carrying operation, operand, and domain information |
| **Demo** | `demo_typed_nan` |
| **Benchmark** | B3: Typed NaN Handling Overhead |
| **Core Code** | `core/typed_nan.py` — `NaNType`, `NAN_RECOVERY_POLICY`, `nan_description()` |
| **Policy Code** | `policy/nan_policy.py` — `handle_typed_nan()`, `NaNHandling`, `nan_info()` |
| **Data Structure** | `TypedValue.nan_type` field, `TypedValue.typed_nan()` factory |

---

## IC-03: TypedValue ABI

| Aspect | Details |
|--------|---------|
| **Feature** | Universal numerical interchange format carrying uncertainty, domain, provenance, backend, units, zero-type, NaN-type |
| **Invention Card** | IC-03 |
| **Claims** | |
| C-03.1 | Universal numerical interchange format with multi-axis metadata |
| C-03.2 | Method for enforcing domain/backend-specific policies at runtime boundaries |
| C-03.3 | Provenance-traced numerical value supporting deterministic replay |
| **Demo** | `demo_equality` |
| **Benchmark** | B1: Contextual Equality, B4: Interval Arithmetic |
| **Core Code** | `core/typed_value.py` — `TypedValue`, `BackendInfo`, `physics_add()`, `physics_divide()` |
| **Supporting** | `core/uncertainty.py`, `core/interval.py`, `core/provenance.py`, `core/units.py`, `core/domain.py` |
| **Re-export** | `core/__init__.py` — public API surface |

---

## IC-04: Exact Security Plane + Approximate Science Plane

| Aspect | Details |
|--------|---------|
| **Feature** | Dual enforcement planes preventing approximate values from authorizing security decisions |
| **Invention Card** | IC-04 |
| **Claims** | |
| C-04.1 | Method for enforcing exact-only security authorization in mixed-precision systems |
| C-04.2 | Dual-plane architecture separating exact security from approximate science |
| C-04.3 | Runtime gate rejecting NaN and inexact-backend values from security paths |
| **Demo** | `demo_security_split` |
| **Benchmark** | B6: Exact Security Gate Overhead |
| **Code** | `policy/exact_security_gate.py` — `AccessDecision`, `SecurityResult`, `exact_security_gate()` |
| **Code** | `policy/approximate_science_gate.py` — `ApproximationPolicy`, `GateResult`, `approximate_science_gate()` |
| **Config** | `policy/approximation_policy.py` — `ApproximationConfig` |

---

## IC-05: Backend Contract Validator

| Aspect | Details |
|--------|---------|
| **Feature** | Declarative backend contracts with precision, calibration, and verification validation |
| **Invention Card** | IC-05 |
| **Claims** | |
| C-05.1 | Method for validating results against backend-specific contracts |
| C-05.2 | Runtime rejection of results from expired-calibration backends |
| C-05.3 | Declarative contract format with precision, noise, drift, failure mode metadata |
| **Demo** | `demo_backend_contract` |
| **Benchmark** | B7: Backend Contract Validation Overhead |
| **Code** | `backend/backend_contract.py` — `BackendContract`, `ContractResult`, `validate_backend_contract()` |
| **Code** | `backend/verifier.py` — `VerificationResult`, `verify_backend_result()` |
| **Backends** | `backend/cpu_backend.py`, `backend/simulated_gpu_backend.py`, `backend/simulated_analog_backend.py` |

---

## IC-06: No-OOM Approximation Degradation

| Aspect | Details |
|--------|---------|
| **Feature** | Two-tier memory model with graceful fidelity degradation under pressure |
| **Invention Card** | IC-06 |
| **Claims** | |
| C-06.1 | Method for preventing OOM via systematic coarsening of approximate objects |
| C-06.2 | Two-tier memory model: integrity-protected exact + degradable approximate |
| C-06.3 | Priority-based degradation algorithm preserving exact objects and logging fidelity loss |
| **Demo** | `demo_no_oom_degrade` |
| **Benchmark** | B8: No-OOM Degradation Time |
| **Code** | `memory/exact_object.py` — `ExactObject` |
| **Code** | `memory/approximate_field.py` — `ApproxField`, `CoarseningPolicy` |
| **Code** | `memory/no_oom_degrader.py` — `handle_memory_pressure()`, `DegradationReport`, `DegradationAction` |
| **Supporting** | `memory/coarsening.py`, `memory/memory_pressure.py` |

---

## IC-07: Deterministic Replay with Uncertainty Logs

| Aspect | Details |
|--------|---------|
| **Feature** | Append-only event log with policy/backend/uncertainty snapshots for deterministic replay |
| **Invention Card** | IC-07 |
| **Claims** | |
| C-07.1 | Deterministic replay logging policy state, backend contracts, and uncertainty snapshots |
| C-07.2 | Append-only event log format with JSON serialization and cross-platform replay |
| C-07.3 | Provenance-hash-based integrity verification of replay log inputs |
| **Demo** | `demo_replay` |
| **Benchmark** | B5: Provenance Chain Overhead, B9: Replay Log Size |
| **Code** | `replay/replay_log.py` — `ReplayLog` |
| **Code** | `replay/deterministic_runner.py` — `DeterministicRunner` |
| **Code** | `replay/event_record.py` — `ReplayEvent`, `serialize_typed_value()` |
| **Code** | `replay/uncertainty_snapshot.py` — `UncertaintySnapshot` |

---

## IC-08: Kernel-Level Dimensional Analysis

| Aspect | Details |
|--------|---------|
| **Feature** | SI-based runtime dimensional analysis enforced at arithmetic boundaries |
| **Invention Card** | IC-08 |
| **Claims** | |
| C-08.1 | Runtime dimensional analysis with SI unit signatures on numerical values |
| C-08.2 | Frozen dimensional dataclass with add-check, multiply, divide, exponentiation operations |
| C-08.3 | Method for preventing dimensionally inconsistent operations at runtime |
| **Demo** | `demo_units` |
| **Benchmark** | (Implicit in B4: Interval Arithmetic — unit checking in `physics_add`) |
| **Code** | `core/units.py` — `Unit`, `DimensionalError`, predefined constants |
| **Integration** | Checked in `physics_add()` and `physics_divide()` in `core/typed_value.py` |

---

## IC-09: Uncertainty Firewall

| Aspect | Details |
|--------|---------|
| **Feature** | Trust boundary enforcement based on uncertainty thresholds |
| **Invention Card** | IC-09 |
| **Claims** | |
| C-09.1 | Method for enforcing uncertainty limits at trust boundaries |
| C-09.2 | Runtime firewall rejecting values exceeding configurable uncertainty threshold |
| C-09.3 | Automatic domain reclassification of values passing uncertainty boundaries |
| **Demo** | (Covered in `demo_security_split`) |
| **Benchmark** | (Covered in B6: Exact Security Gate — firewall is implicit) |
| **Code** | `policy/uncertainty_firewall.py` — `BoundaryPolicy`, `BoundaryResult`, `uncertainty_firewall()` |
| **Dependency** | `Uncertainty.total()` RSS computation in `core/uncertainty.py` |

---

## IC-10: Calibration-Aware Xi Metric

| Aspect | Details |
|--------|---------|
| **Feature** | Efficiency metric categorizing overhead into control, memory, error, calibration, and translation |
| **Invention Card** | IC-10 |
| **Claims** | |
| C-10.1 | Calibration-aware efficiency metric for safety-instrumented numerical systems |
| C-10.2 | Method for categorizing overhead into 5 named components |
| C-10.3 | Benchmarking framework reporting Xi alongside traditional performance metrics |
| **Demo** | `demo_xi_report` |
| **Benchmark** | B10: Xi Report Overhead Accounting |
| **Code** | `metrics/xi_metric.py` — `compute_xi()`, `XiReport`, `OverheadMetrics`, `format_xi_report()` |
| **Code** | `metrics/overhead_tracker.py` — `OverheadTracker`, `OverheadEntry` |
| **Code** | `metrics/benchmark_runner.py` — `BenchmarkRunner`, `BenchmarkResult` |

---

## Cross-Reference Matrix

| IC | Core | Policy | Backend | Memory | Replay | Metrics | Demo | Bench |
|----|------|--------|---------|--------|--------|---------|------|-------|
| IC-01 | typed_zero.py | zero_policy.py | | | | | typed_zero | B2 |
| IC-02 | typed_nan.py | nan_policy.py | | | | | typed_nan | B3 |
| IC-03 | typed_value.py, uncertainty.py, interval.py, provenance.py, units.py, domain.py | | | | | | equality | B1, B4 |
| IC-04 | domain.py | exact_security_gate.py, approximate_science_gate.py, approximation_policy.py | | | | | security_split | B6 |
| IC-05 | typed_value.py (BackendInfo) | | backend_contract.py, verifier.py, cpu_backend.py, simulated_gpu_backend.py, simulated_analog_backend.py | | | | backend_contract | B7 |
| IC-06 | | | | exact_object.py, approximate_field.py, no_oom_degrader.py, coarsening.py, memory_pressure.py | | | no_oom_degrade | B8 |
| IC-07 | provenance.py | | | | replay_log.py, deterministic_runner.py, event_record.py, uncertainty_snapshot.py | | replay | B5, B9 |
| IC-08 | units.py | | | | | | units | B4 |
| IC-09 | uncertainty.py | uncertainty_firewall.py | | | | | security_split | B6 |
| IC-10 | | | | | | xi_metric.py, overhead_tracker.py, benchmark_runner.py | xi_report | B10 |

---

## Claim Dependency Graph

```
IC-03 (TypedValue ABI)
├── IC-01 (Typed Zero)     — extends TypedValue.zero_type
├── IC-02 (Typed NaN)      — extends TypedValue.nan_type
├── IC-04 (Security Plane) — gates on TypedValue fields
├── IC-05 (Backend Contract) — gates on TypedValue.backend
├── IC-06 (No-OOM)         — degrades ApproxField uncertainty (extends Uncertainty)
├── IC-07 (Replay)         — serializes TypedValue provenance
├── IC-08 (Units)          — extends TypedValue.units
├── IC-09 (Firewall)       — gates on TypedValue.uncertainty.total()
└── IC-10 (Xi Metric)      — measures overhead of IC-01 through IC-09
```

IC-03 is the foundational patent. IC-01, IC-02, and IC-08 are extensions to the data structure. IC-04, IC-05, and IC-09 are enforcement mechanisms. IC-06 and IC-07 are system-level mechanisms. IC-10 is the measurement framework.
