# PhysicsOS Stage 1 Invention Disclosure

> **Document Type:** Invention Disclosure
> **Stage:** Stage 1 Runtime (User-Space Prototype)
> **Date:** 2025
> **Classification:** Confidential — IP Review

---

## Invention Card IC-01: Typed Zero Boundary Semantics

### Problem
In conventional computing, the floating-point value `0.0` carries no semantic information about *why* it is zero. A zero that represents "exact symbolic zero" (as in a formal proof) is treated identically to a zero that represents "sensor measured nothing" or "hardware ground voltage." This conflation causes silent correctness failures when zeros cross domain boundaries — for example, passing a `COMPUTATIONAL_OPERAND_ZERO` into a security authorization check.

### Existing Failure Mode
- Floating-point `0.0` is used interchangeably in physics simulations, security checks, filesystem operations, and ML inference.
- Division by zero produces `inf` or `NaN` with no domain-specific recovery.
- Zero values from approximate backends (analog, GPU rounding) are accepted into exact domains (formal proof, security authority) without verification.

### Novel Mechanism
Attach a `ZeroType` enum to every zero value:
- `EXACT_SYMBOLIC_ZERO` — zero by mathematical definition
- `MEASURED_ABSENCE` — sensor returned no signal
- `HARDWARE_GROUND` — electrical ground reference
- `NULL_CAPABILITY` — zero as "no permission" (capability model)
- `COMPUTATIONAL_OPERAND_ZERO` — intermediate computation result
- `UNTYPED_ZERO` — legacy/untyped (always rejected at boundaries)

A per-domain policy table (`ZERO_POLICY_TABLE`) defines which ZeroTypes are allowed in each Domain. Boundary checks (`check_zero_at_boundary`) reject untyped and disallowed zeros, converting them to typed NaN with diagnostic provenance.

### Data Structure
```python
class ZeroType(Enum):
    EXACT_SYMBOLIC_ZERO = "exact_symbolic_zero"
    MEASURED_ABSENCE = "measured_absence"
    HARDWARE_GROUND = "hardware_ground"
    NULL_CAPABILITY = "null_capability"
    COMPUTATIONAL_OPERAND_ZERO = "computational_operand_zero"
    UNTYPED_ZERO = "untyped_zero"

ZERO_POLICY_TABLE: dict[Domain, set[ZeroType]]
```

### Example
```python
v = TypedValue(value=0, zero_type=ZeroType.MEASURED_ABSENCE,
               domain=Domain.SENSOR_DATA, ...)
result = check_zero_at_boundary(v, Domain.FORMAL_PROOF)
# REJECTED: measured_absence not allowed in formal_proof
```

### Advantages
- Prevents zero values from silently corrupting exact domains.
- Each rejection is a typed NaN with full provenance, enabling debugging.
- Policy table is declarative and extensible.

### Implementation Notes
- `core/typed_zero.py` defines `ZeroType` and `ZERO_POLICY_TABLE`.
- `policy/zero_policy.py` implements `check_zero_at_boundary()`.
- Zero typing is attached to `TypedValue.zero_type` field.

### Potential Claims
1. A method for enforcing per-domain zero-value semantics at runtime boundaries in a computing system.
2. A data structure combining a numeric value with a zero-type enumeration and domain tag.
3. A policy table mapping computation domains to permitted zero-type subsets.

### Prior-Art Risk
- Capability-based security systems (seL4, Capsicum) use null capabilities but do not classify numeric zeros.
- Ada/SPARK has strong typing but no per-zero-type semantics.
- **Risk Level:** LOW — no known system classifies floating-point zeros by semantic origin.

---

## Invention Card IC-02: Typed Undefined / Typed NaN Recovery Policies

### Problem
IEEE 754 `NaN` carries no information about *why* a computation failed. When NaN propagates through a system, debugging is extremely difficult. Different failure modes (domain violations, divergence, unauthorized access, hardware faults, timeouts) require different recovery strategies, but IEEE 754 treats them identically.

### Existing Failure Mode
- Division by zero, overflow, and missing data all produce the same `NaN`.
- NaN silently propagates through computations, corrupting downstream results.
- Security-critical failures (unauthorized access) are indistinguishable from physics failures (divergence).

### Novel Mechanism
Replace IEEE 754 NaN with typed NaN values (`NaNType` enum), each carrying:
- A semantic classification (DOMAIN, DIVERGENT, UNMEASURED, UNAUTHORIZED, HARDWARE_FAULT, TIMEOUT)
- A recovery policy string defining the recommended action
- Provenance chain showing which operation produced the NaN and which operands were involved

A boundary handler (`handle_typed_nan`) enforces domain-specific NaN policies: UNAUTHORIZED NaNs are always rejected; NaNs cannot enter SECURITY_AUTHORITY; other NaNs follow recovery policies.

### Data Structure
```python
class NaNType(Enum):
    DOMAIN = "nan_domain"
    DIVERGENT = "nan_divergent"
    UNMEASURED = "nan_unmeasured"
    UNAUTHORIZED = "nan_unauthorized"
    HARDWARE_FAULT = "nan_hardware_fault"
    TIMEOUT = "nan_timeout"

NAN_RECOVERY_POLICY: dict[NaNType, str]
```

### Example
```python
result = physics_divide(a, b_zero)
# result.nan_type == NaNType.DIVERGENT
# result.nan_type recovery: "return_clamped_interval_or_raise"

info = nan_info(result)
# {'is_nan': True, 'nan_type': 'nan_divergent',
#  'recovery_policy': 'return_clamped_interval_or_raise', ...}
```

### Advantages
- Each NaN carries diagnostic information and a recommended recovery path.
- Security-sensitive NaN types (UNAUTHORIZED) are hard-blocked at boundaries.
- Provenance chain enables forensic debugging of NaN origins.

### Implementation Notes
- `core/typed_nan.py` defines `NaNType` and recovery policies.
- `policy/nan_policy.py` implements `handle_typed_nan()` and `nan_info()`.
- `TypedValue.nan_type` field; `TypedValue.typed_nan()` factory method.

### Potential Claims
1. A method for classifying undefined/NaN values by failure semantics with per-type recovery policies.
2. A boundary enforcement mechanism that blocks security-critical NaN types from entering protected domains.
3. A provenance-traced NaN value carrying operation, operand, and domain information.

### Prior-Art Risk
- IEEE 754-2008 signaling NaNs carry payload bits but no standard semantic classification.
- Python's `math.nan` and NumPy NaNs have no typed semantics.
- Rust's `Option<T>` and Haskell's `Maybe` handle absence but not NaN-class-specific recovery.
- **Risk Level:** LOW-MEDIUM — payload NaNs exist in hardware, but software-level typed NaN with recovery policies appears novel.

---

## Invention Card IC-03: TypedValue ABI

### Problem
Numerical values crossing system boundaries (CPU↔GPU, user↔kernel, simulation↔display) carry only their raw bits. Uncertainty, domain provenance, backend metadata, and dimensional units are lost. This makes it impossible to enforce correctness policies at boundaries.

### Existing Failure Mode
- GPU-computed values (with rounding noise) are used in security decisions.
- Sensor data (with measurement uncertainty) is treated as exact in formal proofs.
- Physical quantities lose their units when crossing serialization boundaries.

### Novel Mechanism
The `TypedValue` is the universal interchange format for all numerical data in PhysicsOS. Every value carries:
- **value**: The raw numeric value (or None for NaN)
- **uncertainty**: Interval [lower, upper] with confidence and component breakdown
- **domain**: Semantic domain tag (FORMAL_PROOF, SECURITY_AUTHORITY, SENSOR_DATA, etc.)
- **provenance**: Immutable append-only chain of operations that produced this value
- **backend**: Backend metadata (type, exactness, precision range)
- **units**: SI dimensional analysis (kg, m, s, A, K, mol, cd)
- **zero_type**: Typed zero classification (IC-01)
- **nan_type**: Typed NaN classification (IC-02)

### Data Structure
```python
@dataclass
class TypedValue:
    value: Any
    uncertainty: Uncertainty
    domain: Domain
    provenance: ProvenanceChain
    backend: BackendInfo
    units: Optional[Unit]
    zero_type: Optional[ZeroType]
    nan_type: Optional[NaNType]
```

### Example
```python
v = TypedValue.from_float(9.80665, half_width=0.00001,
                          domain=Domain.PHYSICS_NUMERIC, units=ACCELERATION)
print(v)
# TypedValue(
#   value=9.80665
#   uncertainty=Uncertainty([9.80664, 9.80666], conf=1.000)
#   domain=physics_numeric
#   units=m * s^-2
#   backend=cpu
# )
```

### Advantages
- Single interchange format for all domains and backends.
- All metadata travels with the value — nothing is lost at boundaries.
- Enables IC-01 through IC-10 by providing the data structure they operate on.

### Implementation Notes
- `core/typed_value.py` — central data structure.
- `core/__init__.py` re-exports all public types.
- Factory methods: `from_float()`, `typed_nan()`, `with_domain()`, `with_zero_type()`.

### Potential Claims
1. A universal numerical interchange format carrying uncertainty, domain, provenance, backend, units, zero-type, and NaN-type metadata.
2. A method for enforcing domain- and backend-specific policies on numerical values at runtime boundaries.
3. A provenance-traced numerical value supporting deterministic replay.

### Prior-Art Risk
- FITS headers in astronomy carry metadata with data but not uncertainty-firewall enforcement.
- NumPy structured arrays carry named fields but no policy enforcement.
- MISRA-C requires type safety but no runtime uncertainty tracking.
- **Risk Level:** LOW — the combination of all metadata fields in a single enforceable ABI appears novel.

---

## Invention Card IC-04: Exact Security Plane + Approximate Science Plane

### Problem
In mixed-signal systems, approximate computations (analog sensors, GPU rounding, ML inference) are routinely used to make security decisions. This creates a fundamental correctness violation: security decisions require exact, provenance-traced values, but the system accepts inexact values.

### Existing Failure Mode
- ML-based intrusion detection systems make binary allow/deny decisions using floating-point values with unknown precision.
- Analog sensor readings directly authorize physical access control.
- GPU-computed cryptographic comparisons leak precision information.

### Novel Mechanism
Two enforcement planes:
1. **Exact Security Plane** — `exact_security_gate()` requires:
   - `domain == SECURITY_AUTHORITY`
   - `uncertainty.security == 0`
   - `backend.is_exact == True`
   - `provenance.valid == True`
   - NaN values are automatically denied.

2. **Approximate Science Plane** — `approximate_science_gate()` allows:
   - Any domain except SECURITY_AUTHORITY
   - `U_total <= U_policy` (configurable threshold)
   - `confidence >= min_confidence`
   - NaN values are rejected.

Values cannot cross from the approximate plane to the security plane without explicit exactness verification.

### Data Structure
```python
class AccessDecision(Enum):
    ALLOW = "allow"
    DENY = "deny"

@dataclass
class SecurityResult:
    decision: AccessDecision
    reason: str
    value: TypedValue

def exact_security_gate(value: TypedValue, decision: str) -> SecurityResult
def approximate_science_gate(value: TypedValue, policy: ApproximationPolicy) -> GateResult
```

### Example
```python
sensor_val = TypedValue.from_float(37.2, half_width=0.5, domain=Domain.SENSOR_DATA)
result = exact_security_gate(sensor_val, "door_unlock")
# DENY: Domain mismatch: sensor_data != security_authority

exact_val = TypedValue(value=1, uncertainty=Uncertainty.exact(1),
                       domain=Domain.SECURITY_AUTHORITY, ...)
result = exact_security_gate(exact_val, "door_unlock")
# ALLOW: Exact value authorized for door_unlock
```

### Advantages
- Formal separation prevents approximate values from authorizing security decisions.
- Each denial includes a detailed reason string for auditing.
- Configurable uncertainty thresholds for the science plane.

### Implementation Notes
- `policy/exact_security_gate.py`
- `policy/approximate_science_gate.py`
- `policy/approximation_policy.py` — `ApproximationConfig` dataclass

### Potential Claims
1. A method for enforcing that only exact, provenance-traced values can authorize security decisions in a mixed-precision computing system.
2. A dual-plane architecture separating exact security computations from approximate scientific computations.
3. A runtime gate that rejects NaN and inexact-backend values from security authorization paths.

### Prior-Art Risk
- seL4 enforces capability-based security but does not reason about numerical precision.
- MISRA-C requires deterministic behavior but does not classify values by domain.
- **Risk Level:** LOW — the combination of numerical precision checking with security authorization appears novel.

---

## Invention Card IC-05: Backend Contract Validator

### Problem
When computation results are returned from different backends (CPU, GPU, analog, FPGA), there is no systematic way to verify that the result's uncertainty is within acceptable bounds, that the backend's calibration is current, and that any required verification has passed.

### Existing Failure Mode
- Analog sensor drift goes undetected until physical failure.
- GPU floating-point precision varies between architectures but is assumed identical.
- FPGA timing violations produce subtly wrong results that pass acceptance tests.

### Novel Mechanism
A `BackendContract` specifies:
- Backend type and precision range
- Noise model and drift model
- Calibration age and maximum age
- Whether a verifier is required
- Known failure modes
- Reproducibility score
- Whether exact security operations are allowed

The `validate_backend_contract()` function checks:
- Result uncertainty ≤ policy maximum uncertainty
- Calibration age ≤ maximum calibration age
- Verifier status (when required)

Results from expired or out-of-spec backends are rejected at the boundary.

### Data Structure
```python
@dataclass
class BackendContract:
    backend_id: str
    backend_type: Literal["cpu", "gpu", "analog", "simulated_analog", "fpga"]
    precision_range: tuple
    noise_model: Optional[str]
    drift_model: Optional[str]
    calibration_age_seconds: float
    calibration_max_age_seconds: float
    verifier_required: bool
    failure_modes: List[str]
    reproducibility_score: float
    exact_security_allowed: bool

def validate_backend_contract(contract, result_uncertainty, policy_max_uncertainty) -> ContractResult
```

### Example
```python
analog = make_analog_contract(calibration_age=200)  # Expired!
result = validate_backend_contract(analog, 0.05, 0.1)
# REJECTED: Calibration expired: 200s > 120s
```

### Advantages
- Systematic verification of backend results against declared capabilities.
- Calibration expiry prevents stale analog/FPGA results from propagating.
- Failure mode enumeration enables proactive monitoring.

### Implementation Notes
- `backend/backend_contract.py` — `BackendContract`, `validate_backend_contract()`
- `backend/verifier.py` — `verify_backend_result()`
- `backend/cpu_backend.py`, `simulated_gpu_backend.py`, `simulated_analog_backend.py`

### Potential Claims
1. A method for validating computational results against a backend-specific contract specifying precision, calibration, and verification requirements.
2. A runtime system that rejects results from expired-calibration backends.
3. A declarative backend contract format combining precision range, noise model, drift model, and failure mode enumeration.

### Prior-Art Risk
- Hardware calibration management systems exist in industrial IoT but do not integrate with numerical uncertainty propagation.
- ROS2 has QoS policies but no calibration-aware uncertainty enforcement.
- **Risk Level:** LOW-MEDIUM — calibration tracking is known, but integration with numerical uncertainty contracts is novel.

---

## Invention Card IC-06: No-OOM Approximation Degradation

### Problem
Memory pressure in physics simulations causes out-of-memory (OOM) crashes, losing all computation state. Existing systems either crash or use opaque garbage collection that degrades unpredictably.

### Existing Failure Mode
- Large-scale simulations crash with OOM, losing hours of computation.
- GC-based systems degrade latency unpredictably.
- No systematic way to trade fidelity for memory.

### Novel Mechanism
Two-tier memory model:
1. **ExactObject** — Memory that must NEVER be degraded (security keys, provenance chains, calibration data). Integrity-hash protected.
2. **ApproxField** — Approximate field-memory with a fidelity level. Can be coarsened (reduced resolution) under memory pressure. Each coarsening step increases the field's uncertainty and decreases confidence.

When memory pressure exceeds a threshold, `handle_memory_pressure()`:
1. Preserves all ExactObjects (cannot degrade).
2. Sorts ApproxFields by priority (ascending) and memory size (descending).
3. Coarsens lowest-priority fields first.
4. Logs every fidelity reduction in a `DegradationReport`.
5. Stops when pressure reaches the target level.

### Data Structure
```python
@dataclass
class ExactObject:
    object_id: str
    bytes_data: bytes
    integrity_hash: str
    provenance: ProvenanceChain
    can_degrade: bool = False

@dataclass
class ApproxField:
    field_id: str
    shape: tuple
    fidelity_level: int
    uncertainty: Uncertainty
    can_degrade: bool = True
    coarsening_policy: CoarseningPolicy

def handle_memory_pressure(objects, pressure, target_pressure=0.70) -> DegradationReport
```

### Example
```python
objects = [
    ExactObject("security_key", b"...", integrity_hash="abc", ...),
    ApproxField("temperature_field", (100, 100), fidelity_level=10, ...),
    ApproxField("pressure_field", (100, 100), fidelity_level=8, ...),
]
report = handle_memory_pressure(objects, pressure=0.92)
# [PRESERVED] security_key (exact)
# [COARSENED] pressure_field: fidelity 8 -> 7 (1024 bytes saved)
# Pressure: 92.0% -> 70.0%
```

### Advantages
- System never crashes from OOM — it degrades gracefully.
- Exact objects (security, provenance) are always preserved.
- All fidelity loss is logged with uncertainty impact.
- Priority-based degradation respects application semantics.

### Implementation Notes
- `memory/exact_object.py` — `ExactObject`
- `memory/approximate_field.py` — `ApproxField`, `CoarseningPolicy`
- `memory/no_oom_degrader.py` — `handle_memory_pressure()`, `DegradationReport`
- `memory/memory_pressure.py` — `simulate_pressure()`, `pressure_color()`
- `memory/coarsening.py` — `simple_coarsen()`, `priority_coarsen()`

### Potential Claims
1. A method for preventing out-of-memory crashes by systematically coarsening approximate memory objects while preserving exact objects.
2. A two-tier memory model separating integrity-protected exact objects from degradable approximate fields.
3. A priority-based degradation algorithm that coarsens lowest-priority approximate fields first and logs all fidelity loss.

### Prior-Art Risk
- Memcached and Redis have LRU eviction but no fidelity-aware degradation.
- Database query planners reduce precision under memory pressure but not with typed uncertainty.
- **Risk Level:** LOW — fidelity-aware memory degradation with typed uncertainty tracking appears novel.

---

## Invention Card IC-07: Deterministic Replay with Uncertainty Logs

### Problem
When a physics simulation produces an unexpected result, reproducing the exact computation path is extremely difficult. Uncertainty propagation, backend selection, and policy decisions are not logged, making debugging a forensic challenge.

### Existing Failure Mode
- Non-deterministic GPU schedules produce different results on reruns.
- Floating-point non-associativity causes divergent results across platforms.
- Policy decisions (zero boundary checks, security gates) are not auditable.

### Novel Mechanism
An append-only `ReplayLog` records every computation event with:
- Operation name and inputs/outputs (serialized TypedValues)
- Provenance hash of inputs
- Policy snapshot (active uncertainty thresholds, domain policies)
- Backend contract snapshot (calibration state, precision range)
- Uncertainty snapshot (global uncertainty state at event time)

The `DeterministicRunner` wraps function calls, recording inputs and outputs. The `replay()` method re-executes a recorded operation and compares outputs with the original recording.

### Data Structure
```python
class ReplayLog:
    def record(self, operation, inputs, outputs, policy_snapshot, backend_snapshot, uncertainty_snapshot)
    def save(self, filepath)
    def load(cls, filepath) -> ReplayLog

class DeterministicRunner:
    def run_and_record(self, operation, func, *args, ...) -> tuple
    def replay(self, operation_id, func, *args) -> (matches, current_outputs, recorded_outputs)

@dataclass
class ReplayEvent:
    event_id: str
    timestamp_ns: int
    operation: str
    inputs: List[Dict]
    outputs: List[Dict]
    policy_snapshot: Dict
    backend_contract_snapshot: Dict
    uncertainty_snapshot: Dict
    provenance_hash: str
```

### Example
```python
runner = DeterministicRunner()
outputs = runner.run_and_record("physics_add", physics_add, a, b)
matches, current, recorded = runner.replay("physics_add", physics_add, a, b)
assert matches  # Deterministic replay verified
```

### Advantages
- Full audit trail of every computation with policy and backend state.
- JSON serialization enables cross-platform replay.
- Provenance hashes detect input tampering.

### Implementation Notes
- `replay/replay_log.py` — `ReplayLog`
- `replay/deterministic_runner.py` — `DeterministicRunner`
- `replay/event_record.py` — `ReplayEvent`, `serialize_typed_value()`
- `replay/uncertainty_snapshot.py` — `UncertaintySnapshot`

### Potential Claims
1. A method for deterministic replay of numerical computations that logs policy state, backend contracts, and uncertainty snapshots alongside inputs and outputs.
2. An append-only event log format for physics computations supporting JSON serialization and cross-platform replay.
3. A provenance-hash-based integrity check for replay log inputs.

### Prior-Art Risk
- Event sourcing (Apache Kafka, EventStoreDB) logs events but not numerical uncertainty context.
- rr (Mozilla) and Pernosco provide deterministic replay at the instruction level but not at the physics-semantic level.
- **Risk Level:** LOW — semantic-level replay with uncertainty and policy context appears novel.

---

## Invention Card IC-08: Kernel-Level Dimensional Analysis

### Problem
Physical quantities (lengths, times, masses) flow through computations as raw floating-point numbers. Adding a length to a time, or using a velocity as a force, produces silently wrong results. Existing dimensional analysis is optional and performed only at compile time (if at all).

### Existing Failure Mode
- Mars Climate Orbiter (1999): thrust in pound-force vs. newton-seconds caused $327M loss.
- Unit conversion errors in medical dosing systems.
- Physics engines silently accept dimensionally inconsistent equations.

### Novel Mechanism
An SI-based `Unit` dataclass represents physical dimensions as powers of 7 base units (kg, m, s, A, K, mol, cd). Arithmetic operations on units:
- **Add/Sub**: Requires compatible units (raises `DimensionalError` otherwise).
- **Mul/Div**: Computes resulting dimensional signature.
- **Pow**: Scales dimensional exponents.

`TypedValue` carries an optional `Unit`. When `physics_add()` or `physics_divide()` operate on TypedValues with units, dimensional compatibility is checked automatically.

### Data Structure
```python
@dataclass(frozen=True)
class Unit:
    kg: int = 0; m: int = 0; s: int = 0
    A: int = 0; K: int = 0; mol: int = 0; cd: int = 0

    def compatible(self, other) -> bool
    def __add__(self, other) -> Unit  # Raises DimensionalError if incompatible
    def __mul__(self, other) -> Unit

class DimensionalError(Exception): pass

# Predefined constants:
METER, SECOND, KILOGRAM, JOULE, NEWTON, WATT, VELOCITY, ACCELERATION, ...
```

### Example
```python
distance = TypedValue.from_float(100.0, units=METER)
time_val = TypedValue.from_float(9.58, units=SECOND)
result = physics_add(distance, time_val)
# DimensionalError: Cannot add m + s: incompatible units
```

### Advantages
- Dimensional errors are caught at runtime at the point of the operation.
- Frozen Unit dataclass ensures dimensional signatures are immutable.
- 16 predefined SI unit constants cover common physics quantities.

### Implementation Notes
- `core/units.py` — `Unit`, `DimensionalError`, predefined constants
- Checked in `physics_add()` and `physics_divide()` in `core/typed_value.py`

### Potential Claims
1. A runtime dimensional analysis system that attaches SI unit signatures to numerical values and enforces dimensional consistency at arithmetic boundaries.
2. A frozen dimensional dataclass supporting addition (with compatibility check), multiplication, division, and exponentiation of physical units.
3. A method for preventing Mars-Climate-Orbiter-type errors by rejecting dimensionally inconsistent operations at runtime.

### Prior-Art Risk
- Boost.Units (C++), Pint (Python), and Apache Commons Units (Java) provide compile-time/check-time dimensional analysis.
- F# provides units of measure as a language feature.
- **Risk Level:** MEDIUM — dimensional analysis is well-known; the novelty is integration with the TypedValue ABI and boundary enforcement.

---

## Invention Card IC-09: Uncertainty Firewall

### Problem
Data crossing trust boundaries (e.g., from an approximate sensor to an exact calculation, from a GPU to a security check) may carry unknown or excessive uncertainty. There is no systematic mechanism to enforce uncertainty limits at trust boundaries.

### Existing Failure Mode
- Sensor noise propagates into control systems without bounds checking.
- GPU rounding errors accumulate into financial calculations.
- Approximate ML model outputs are used in safety-critical decisions without uncertainty verification.

### Novel Mechanism
A `BoundaryPolicy` defines a named trust boundary with a maximum uncertainty threshold. The `uncertainty_firewall()` function:
1. Rejects NaN values (always).
2. Computes total uncertainty via RSS (root-sum-square) of all components.
3. Rejects values where `U_total > max_uncertainty`.
4. Re-domains accepted values to the target domain (automatic domain transition).

### Data Structure
```python
@dataclass
class BoundaryPolicy:
    max_uncertainty: float
    target_domain: Domain
    name: str = "default"

@dataclass
class BoundaryResult:
    accepted: bool
    reason: str
    value: TypedValue

def uncertainty_firewall(value: TypedValue, policy: BoundaryPolicy) -> BoundaryResult
```

### Example
```python
noisy_sensor = TypedValue.from_float(25.7, half_width=5.0, domain=Domain.SENSOR_DATA)
policy = BoundaryPolicy(max_uncertainty=1.0, target_domain=Domain.PHYSICS_NUMERIC, name="sensor_to_physics")
result = uncertainty_firewall(noisy_sensor, policy)
# REJECTED: Uncertainty 10.000000 exceeds boundary policy 1.0 at 'sensor_to_physics'
```

### Advantages
- Declarative uncertainty limits at trust boundaries.
- Automatic domain transition for accepted values.
- Rejection reason strings enable debugging and policy tuning.

### Implementation Notes
- `policy/uncertainty_firewall.py`
- `Uncertainty.total()` uses RSS of measurement, rounding, model, hardware, time, and security components.

### Potential Claims
1. A method for enforcing uncertainty limits at trust boundaries in a computing system.
2. A runtime firewall that rejects numerical values whose total uncertainty exceeds a configurable threshold.
3. A method for automatic domain reclassification of values that pass uncertainty boundaries.

### Prior-Art Risk
- Data diodes and firewalls exist for network security but do not reason about numerical uncertainty.
- Control theory has signal-to-noise ratio filtering but not per-domain uncertainty firewalls.
- **Risk Level:** LOW — uncertainty-aware trust boundaries appear novel.

---

## Invention Card IC-10: Calibration-Aware Xi Metric

### Problem
Systems that add safety checks, uncertainty tracking, and policy enforcement introduce runtime overhead. There is no standard metric for measuring the efficiency cost of these safety mechanisms, particularly when calibration overhead must be accounted for.

### Existing Failure Mode
- Safety checks are removed to improve performance ("optimization").
- No way to quantify the trade-off between safety overhead and useful computation.
- Calibration overhead is invisible in standard profiling tools.

### Novel Mechanism
The **Xi (xi) metric** measures efficiency as:

```
Xi = W_useful / (W_useful + O_control + O_memory + O_error + O_calibration + O_translation)
```

Where:
- `W_useful` — Time spent on actual computation
- `O_control` — Overhead from policy checks, domain enforcement
- `O_memory` — Overhead from uncertainty tracking, provenance chains
- `O_error` — Overhead from NaN handling, recovery policies
- `O_calibration` — Overhead from backend calibration verification
- `O_translation` — Overhead from unit conversion, domain transitions

The `OverheadTracker` provides hierarchical start/stop timing per category. The `XiReport` assembles a full efficiency breakdown. An `XiReport.from_metrics()` factory computes Xi from tracked overhead.

### Data Structure
```python
@dataclass
class OverheadMetrics:
    useful_work: float
    control_overhead: float
    memory_overhead: float
    error_overhead: float
    calibration_overhead: float
    translation_overhead: float

@dataclass
class XiReport:
    useful_work: float
    control_overhead: float
    memory_overhead: float
    error_overhead: float
    calibration_overhead: float
    translation_overhead: float
    xi: float
    total_overhead: float

def compute_xi(metrics: OverheadMetrics) -> float
def format_xi_report(report: XiReport) -> str
```

### Example
```python
tracker = OverheadTracker()
tracker.start("control", "zero_check")
check_zero_at_boundary(v, Domain.FORMAL_PROOF)
tracker.stop("control", "zero_check")

metrics = tracker.to_overhead_metrics(useful_work_ns=1_000_000)
report = XiReport.from_metrics(metrics)
print(f"Xi = {report.xi:.4f}")
# Xi = 0.8523
```

### Advantages
- Single number quantifying safety overhead cost.
- Component breakdown identifies which overhead category dominates.
- Calibration overhead is tracked separately, enabling cost-benefit analysis of calibration frequency.

### Implementation Notes
- `metrics/xi_metric.py` — `compute_xi()`, `XiReport`, `OverheadMetrics`, `format_xi_report()`
- `metrics/overhead_tracker.py` — `OverheadTracker`, `OverheadEntry`
- `metrics/benchmark_runner.py` — `BenchmarkRunner` (includes Xi in results)

### Potential Claims
1. A calibration-aware efficiency metric for safety-instrumented numerical computing systems.
2. A method for categorizing runtime overhead into control, memory, error, calibration, and translation components.
3. A benchmarking framework that reports Xi efficiency alongside traditional performance metrics.

### Prior-Art Risk
- Amdahl's Law and speedup metrics exist but do not categorize safety overhead.
- FLOPS and IPC metrics measure throughput but not safety efficiency.
- **Risk Level:** LOW — the Xi metric with calibration-aware overhead categorization appears novel.
