# PhysicsOS Stage 1 Benchmark Protocol

> **Version:** Stage 1 Runtime
> **Protocol ID:** B1–B10

---

## Overview

The PhysicsOS Stage 1 benchmark protocol measures the overhead of each core mechanism independently. Each benchmark targets a single invention card (IC) and reports:
- **Runtime** (ms) for N iterations
- **Xi** efficiency ratio (correct operations / total operations)
- **Decision accuracy** (correct / total, where applicable)
- **False accept/reject counts** (where applicable)
- **Metadata overhead** (estimated bytes per TypedValue)

All benchmarks use `BenchmarkRunner` from `metrics/benchmark_runner.py`.

---

## B1: Contextual Equality Overhead

**Invention Card:** IC-03 (TypedValue ABI)

**Purpose:** Measure the overhead of contextual equality comparison using uncertainty overlap fractions vs. naive floating-point equality.

**Protocol:**

1. Create two `TypedValue` instances: `a = from_float(0.1 + 0.2, half_width=1e-16)` and `b = from_float(0.3, half_width=1e-16)`.
2. Compute `a.uncertainty.overlap_fraction(b.uncertainty)`.
3. Report overlap > 0 as correct.

**Expected Properties:**
- `0.1 + 0.2 != 0.3` in IEEE 754, but their uncertainty intervals overlap.
- Overhead relative to `a == b` comparison on raw floats.

**Metrics Format:**
```json
{
  "benchmark": "contextual_equality",
  "operations": 100000,
  "runtime_ms": "<measured>",
  "decision_accuracy": 1.0,
  "xi": 1.0,
  "metadata_overhead_bytes_per_value": 64
}
```

---

## B2: Typed Zero Boundary Overhead

**Invention Card:** IC-01 (Typed Zero Boundary Semantics)

**Purpose:** Measure the overhead of checking whether a zero value is permitted at a domain boundary.

**Protocol:**

1. Create a zero `TypedValue` with `ZeroType.COMPUTATIONAL_OPERAND_ZERO` in `Domain.PHYSICS_NUMERIC`.
2. Call `check_zero_at_boundary(value, Domain.SENSOR_DATA)`.
3. Report result.allowed as correct if policy allows, incorrect if rejected unexpectedly.

**Expected Properties:**
- `COMPUTATIONAL_OPERAND_ZERO` is NOT in `SENSOR_DATA` policy → should be rejected.
- Overhead relative to a simple `if value == 0` check.

**Metrics Format:**
```json
{
  "benchmark": "typed_zero_boundary",
  "operations": 100000,
  "runtime_ms": "<measured>",
  "decision_accuracy": 1.0,
  "xi": 1.0,
  "metadata_overhead_bytes_per_value": 64
}
```

---

## B3: Typed NaN Handling Overhead

**Invention Card:** IC-02 (Typed Undefined / Typed NaN Recovery Policies)

**Purpose:** Measure the overhead of creating and classifying typed NaN values.

**Protocol:**

1. Create two `TypedValue` instances where the divisor is zero with a typed zero.
2. Call `physics_divide(a, b_zero)`.
3. Verify the result is NaN with the correct `NaNType.DIVERGENT`.
4. Call `nan_info(result)` and verify fields.

**Expected Properties:**
- Division by typed zero produces a `DIVERGENT` NaN.
- `nan_info()` returns correct type, description, and recovery policy.
- Overhead relative to `math.isnan()` check.

**Metrics Format:**
```json
{
  "benchmark": "typed_nan_handling",
  "operations": 100000,
  "runtime_ms": "<measured>",
  "decision_accuracy": 1.0,
  "xi": 1.0,
  "metadata_overhead_bytes_per_value": 64
}
```

---

## B4: Interval Arithmetic Overhead

**Invention Card:** IC-03 (TypedValue ABI) — Interval component

**Purpose:** Measure the overhead of IEEE 1788-2015 inspired interval arithmetic operations.

**Protocol:**

1. Create two intervals: `a = Interval(0.1 - 1e-16, 0.1 + 1e-16)`, `b = Interval(0.2 - 1e-16, 0.2 + 1e-16)`.
2. Compute `c = a + b`.
3. Verify the result interval bounds are correct: `[a.lower + b.lower, a.upper + b.upper]`.
4. Repeat for subtraction, multiplication, and division.

**Expected Properties:**
- Interval addition is exact (no information loss).
- Multiplication uses 4-corner evaluation.
- Division raises `ZeroDivisionError` if divisor contains zero.
- Overhead relative to raw float `+`, `-`, `*`, `/`.

**Metrics Format:**
```json
{
  "benchmark": "interval_arithmetic",
  "operations": 100000,
  "runtime_ms": "<measured>",
  "decision_accuracy": 1.0,
  "xi": 1.0,
  "metadata_overhead_bytes_per_value": 64
}
```

---

## B5: Provenance Chain Overhead

**Invention Card:** IC-07 (Deterministic Replay)

**Purpose:** Measure the overhead of building and hashing provenance chains.

**Protocol:**

1. Create a `TypedValue` from float.
2. Call `value.with_domain(Domain.SENSOR_DATA)` — this appends to the provenance chain.
3. Call `value.provenance.hash()` — SHA-256 computation.
4. Merge two provenance chains and verify validity.

**Expected Properties:**
- Provenance chains are immutable (each operation creates a new chain).
- Hash is deterministic for the same chain.
- Overhead relative to no-provenance tracking.

**Metrics Format:**
```json
{
  "benchmark": "provenance_chain",
  "operations": 100000,
  "runtime_ms": "<measured>",
  "decision_accuracy": 1.0,
  "xi": 1.0,
  "metadata_overhead_bytes_per_value": 64
}
```

---

## B6: Exact Security Gate Overhead

**Invention Card:** IC-04 (Exact Security Plane + Approximate Science Plane)

**Purpose:** Measure the overhead of the exact security gate evaluation.

**Protocol:**

1. Create an exact `TypedValue` in `SECURITY_AUTHORITY` with zero security uncertainty, exact backend, valid provenance.
2. Call `exact_security_gate(value, "test_decision")`.
3. Verify `decision == ALLOW`.
4. Also test denial cases: approximate value, wrong domain, invalid provenance.

**Expected Properties:**
- Exact value with valid provenance → ALLOW.
- Any violation → DENY with specific reason.
- No false accepts (security-critical).
- No false rejects (correctly authorized values must pass).

**Metrics Format:**
```json
{
  "benchmark": "exact_security_gate",
  "operations": 100000,
  "runtime_ms": "<measured>",
  "decision_accuracy": 1.0,
  "false_accept_count": 0,
  "false_reject_count": 0,
  "xi": 1.0,
  "metadata_overhead_bytes_per_value": 64
}
```

---

## B7: Backend Contract Validation Overhead

**Invention Card:** IC-05 (Backend Contract Validator)

**Purpose:** Measure the overhead of validating a backend contract.

**Protocol:**

1. Create a `BackendContract` for a CPU backend.
2. Compute a result uncertainty value.
3. Call `validate_backend_contract(contract, result_uncertainty, policy_max_uncertainty)`.
4. Verify acceptance/rejection as expected.
5. Also test with expired calibration (analog backend).

**Expected Properties:**
- CPU contract with valid calibration → ACCEPTED.
- Analog contract with expired calibration → REJECTED.
- Contract validation is fast (microseconds per call).

**Metrics Format:**
```json
{
  "benchmark": "backend_contract_validation",
  "operations": 100000,
  "runtime_ms": "<measured>",
  "decision_accuracy": 1.0,
  "xi": 1.0,
  "metadata_overhead_bytes_per_value": 64
}
```

---

## B8: No-OOM Degradation Time

**Invention Card:** IC-06 (No-OOM Approximation Degradation)

**Purpose:** Measure the time required for the no-OOM degradation algorithm to reduce memory pressure to the target level.

**Protocol:**

1. Create a list of memory objects: 2 `ExactObject` + 20 `ApproxField` with varying priorities.
2. Set initial pressure to 0.92 (92% memory usage).
3. Call `handle_memory_pressure(objects, pressure=0.92, target_pressure=0.70)`.
4. Measure elapsed time.
5. Verify: all ExactObjects preserved, ApproxFields coarsened, final pressure <= target.

**Expected Properties:**
- Exact objects are always preserved.
- Lowest-priority approximate fields are coarsened first.
- Degradation completes in < 10ms for 20 fields.
- Pressure reaches target level.

**Metrics Format:**
```json
{
  "benchmark": "no_oom_degradation",
  "operations": 1,
  "runtime_ms": "<measured>",
  "decision_accuracy": 1.0,
  "xi": 1.0,
  "metadata_overhead_bytes_per_value": 64,
  "raw_data": {
    "pressure_before": 0.92,
    "pressure_after": "<measured>",
    "objects_preserved": 2,
    "objects_coarsened": "<count>",
    "total_bytes_saved": "<count>"
  }
}
```

---

## B9: Deterministic Replay Log Size

**Invention Card:** IC-07 (Deterministic Replay with Uncertainty Logs)

**Purpose:** Measure the memory footprint and serialization size of the replay log.

**Protocol:**

1. Create a `ReplayLog`.
2. Record 10,000 computation events using `ReplayLog.record()`.
3. Measure:
   - In-memory log size (approximate via `sys.getsizeof` on event list).
   - Serialized JSON size via `ReplayLog.to_dict()`.
   - File size after `ReplayLog.save()`.
4. Verify: all events are loadable and event count matches.

**Expected Properties:**
- Each event is approximately 200-500 bytes serialized.
- 10,000 events produce a JSON file of approximately 2-5 MB.
- Load/save roundtrip is lossless.

**Metrics Format:**
```json
{
  "benchmark": "replay_log_size",
  "operations": 10000,
  "runtime_ms": "<measured>",
  "decision_accuracy": 1.0,
  "xi": 1.0,
  "metadata_overhead_bytes_per_value": 64,
  "raw_data": {
    "event_count": 10000,
    "json_size_bytes": "<measured>",
    "file_size_bytes": "<measured>",
    "bytes_per_event": "<measured>"
  }
}
```

---

## B10: Xi Report Overhead Accounting

**Invention Card:** IC-10 (Calibration-Aware Xi Metric)

**Purpose:** Measure the overhead of the overhead tracking and Xi computation pipeline.

**Protocol:**

1. Create an `OverheadTracker`.
2. For each iteration:
   a. `tracker.start("control", "gate_check")`
   b. Execute `exact_security_gate(value, "test")`
   c. `tracker.stop("control", "gate_check")`
   d. `tracker.start("memory", "provenance")`
   e. Execute `value.provenance.hash()`
   f. `tracker.stop("memory", "provenance")`
3. After N iterations, call `tracker.to_overhead_metrics(useful_work_ns)`.
4. Compute `XiReport.from_metrics(metrics)`.
5. Report Xi value and overhead breakdown.

**Expected Properties:**
- Xi should be > 0.5 (more than half the time is useful work).
- Control overhead dominates for security-critical paths.
- Calibration overhead is zero in Stage 1 (no real calibration).

**Metrics Format:**
```json
{
  "benchmark": "xi_report_overhead",
  "operations": 10000,
  "runtime_ms": "<measured>",
  "xi": "<computed>",
  "decision_accuracy": 1.0,
  "metadata_overhead_bytes_per_value": 64,
  "raw_data": {
    "overhead_breakdown": {
      "control_ns": "<measured>",
      "memory_ns": "<measured>",
      "error_ns": "<measured>",
      "calibration_ns": "<measured>",
      "translation_ns": "<measured>"
    }
  }
}
```

---

## Required Output Format

All benchmarks must produce output in the `BenchmarkResult` format:

```json
{
  "benchmark": "<name>",
  "operations": <int>,
  "runtime_ms": <float>,
  "memory_used_mb": <float>,
  "metadata_overhead_bytes_per_value": <int>,
  "decision_accuracy": <float>,
  "false_accept_count": <int>,
  "false_reject_count": <int>,
  "xi": <float>,
  "raw_data": {}
}
```

## Running Benchmarks

```bash
# Run all benchmarks via CLI
python cli.py bench

# Run with JSON output
python cli.py bench --json results.json

# Run programmatically
from metrics.benchmark_runner import BenchmarkRunner
runner = BenchmarkRunner()
runner.run("my_bench", my_func, iterations=100000)
print(runner.summary_table())
print(runner.to_json())
```
