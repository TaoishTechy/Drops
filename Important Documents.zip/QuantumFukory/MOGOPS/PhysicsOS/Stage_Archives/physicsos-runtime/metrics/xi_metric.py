"""Xi metric: measures the ratio of useful work to total work including overhead.

Xi = W_useful / (W_useful + O_control + O_memory + O_error + O_calibration + O_translation)
"""
from dataclasses import dataclass
from typing import Optional


@dataclass
class OverheadMetrics:
    """Accumulated overhead breakdown (all values in nanoseconds or compatible units)."""
    useful_work: float = 0.0
    control_overhead: float = 0.0
    memory_overhead: float = 0.0
    error_overhead: float = 0.0
    calibration_overhead: float = 0.0
    translation_overhead: float = 0.0


@dataclass
class XiReport:
    """Full Xi efficiency report with component breakdown."""
    useful_work: float
    control_overhead: float
    memory_overhead: float
    error_overhead: float
    calibration_overhead: float
    translation_overhead: float
    xi: float
    total_overhead: float = 0.0

    def __post_init__(self):
        self.total_overhead = (
            self.control_overhead
            + self.memory_overhead
            + self.error_overhead
            + self.calibration_overhead
            + self.translation_overhead
        )

    @classmethod
    def from_metrics(cls, m: OverheadMetrics) -> "XiReport":
        xi = compute_xi(m)
        return cls(
            useful_work=m.useful_work,
            control_overhead=m.control_overhead,
            memory_overhead=m.memory_overhead,
            error_overhead=m.error_overhead,
            calibration_overhead=m.calibration_overhead,
            translation_overhead=m.translation_overhead,
            xi=xi,
        )


def compute_xi(metrics: OverheadMetrics) -> float:
    """
    Compute the Xi efficiency ratio.

    Xi = W_useful / (W_useful + O_control + O_memory + O_error + O_calibration + O_translation)

    Returns 0.0 when the denominator is zero.
    """
    denom = (
        metrics.useful_work
        + metrics.control_overhead
        + metrics.memory_overhead
        + metrics.error_overhead
        + metrics.calibration_overhead
        + metrics.translation_overhead
    )
    if denom == 0:
        return 0.0
    return metrics.useful_work / denom


def format_xi_report(report: XiReport) -> str:
    """Format an XiReport as a human-readable string."""
    lines = [
        "Xi Efficiency Report",
        "=" * 50,
        f"Useful work:              {report.useful_work:>12.2f} units",
        f"Control overhead:         {report.control_overhead:>12.2f}",
        f"Memory overhead:          {report.memory_overhead:>12.2f}",
        f"Error overhead:           {report.error_overhead:>12.2f}",
        f"Calibration overhead:     {report.calibration_overhead:>12.2f}",
        f"Translation overhead:     {report.translation_overhead:>12.2f}",
        f"Total overhead:           {report.total_overhead:>12.2f}",
        "-" * 50,
        f"Xi = {report.useful_work:.2f} / ({report.useful_work:.2f} + {report.total_overhead:.2f})",
        f"Xi = {report.xi:.4f}",
    ]
    return "\n".join(lines)
