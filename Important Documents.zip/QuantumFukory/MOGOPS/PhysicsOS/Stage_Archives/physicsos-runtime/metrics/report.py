"""Stage 1 report generator: assembles demo results and benchmarks into a markdown report."""
from typing import List, Dict, Any
import json
from datetime import datetime


class Stage1ReportGenerator:
    """Generates markdown reports for Stage 1 demo and benchmark results."""

    def __init__(
        self,
        demo_results: Dict[str, bool] = None,
        benchmark_results: List[Dict] = None,
    ):
        self.demo_results = demo_results or {}
        self.benchmark_results = benchmark_results or []

    def generate(self) -> str:
        """Generate the full markdown report."""
        lines = []
        lines.append("# PhysicsOS Stage 1 Results")
        lines.append(f"Generated: {datetime.utcnow().isoformat()}Z")
        lines.append("")

        # Demo results
        lines.append("## Demo Results")
        all_pass = True
        for name, passed in self.demo_results.items():
            status = "PASS" if passed else "FAIL"
            lines.append(f"- [{status}] {name}")
            if not passed:
                all_pass = False
        lines.append("")
        lines.append(
            f"**Overall: {'ALL PASS' if all_pass else 'FAILURES DETECTED'}**"
        )
        lines.append("")

        # Benchmark results
        if self.benchmark_results:
            lines.append("## Benchmark Results")
            lines.append(
                f"{'Benchmark':<40} {'Ops':>12} {'Time(ms)':>12} {'Xi':>8}"
            )
            lines.append("-" * 74)
            for r in self.benchmark_results:
                lines.append(
                    f"{r['benchmark']:<40} {r['operations']:>12,} "
                    f"{r['runtime_ms']:>12.2f} {r['xi']:>8.4f}"
                )
            lines.append("")

        # Known limitations
        lines.append("## Known Limitations")
        lines.append("- Stage 1 is user-space only; no real kernel integration")
        lines.append("- Analog and GPU backends are simulated")
        lines.append("- Memory overhead estimates are approximate")
        lines.append("- No formal verification in Lean/Coq yet")
        lines.append("- No real hardware integration")
        lines.append("")

        # IP-relevant mechanisms
        lines.append("## IP-Relevant Mechanisms")
        lines.append("- IC-01: Typed Zero Boundary Semantics")
        lines.append("- IC-02: Typed Undefined / Typed NaN Recovery Policies")
        lines.append("- IC-03: TypedValue ABI (value, uncertainty, domain, provenance, backend)")
        lines.append("- IC-04: Exact Security Plane + Approximate Science Plane")
        lines.append("- IC-05: Backend Contract Validator")
        lines.append("- IC-06: No-OOM Approximation Degradation")
        lines.append("- IC-07: Deterministic Replay with Uncertainty Logs")
        lines.append("- IC-08: Kernel-Level Dimensional Analysis")
        lines.append("- IC-09: Uncertainty Firewall")
        lines.append("- IC-10: Calibration-Aware Xi Metric")

        return "\n".join(lines)

    def save(self, filepath: str):
        """Save the generated report to a markdown file."""
        with open(filepath, "w") as f:
            f.write(self.generate())
