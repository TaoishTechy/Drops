"""Metrics module for PhysicsOS Stage 1 runtime.

Provides Xi efficiency measurement, overhead tracking, benchmarking,
and report generation.
"""
from .xi_metric import OverheadMetrics, XiReport, compute_xi, format_xi_report
from .overhead_tracker import OverheadTracker, OverheadEntry
from .benchmark_runner import BenchmarkRunner, BenchmarkResult
from .report import Stage1ReportGenerator

__all__ = [
    "OverheadMetrics",
    "XiReport",
    "compute_xi",
    "format_xi_report",
    "OverheadTracker",
    "OverheadEntry",
    "BenchmarkRunner",
    "BenchmarkResult",
    "Stage1ReportGenerator",
]
