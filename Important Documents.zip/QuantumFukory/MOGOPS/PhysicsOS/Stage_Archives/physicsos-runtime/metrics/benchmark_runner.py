"""Benchmark runner: time operations and collect accuracy/metrics data."""
from dataclasses import dataclass, field
from typing import Dict, List, Any, Callable, Optional
import time
import json
import statistics


@dataclass
class BenchmarkResult:
    """Result of a single benchmark run."""
    benchmark: str
    operations: int
    runtime_ms: float
    memory_used_mb: float
    metadata_overhead_bytes_per_value: int
    decision_accuracy: float = 1.0
    false_accept_count: int = 0
    false_reject_count: int = 0
    xi: float = 0.0
    raw_data: Dict[str, Any] = field(default_factory=dict)


class BenchmarkRunner:
    """Run benchmarks and collect structured results."""

    def __init__(self):
        self.results: List[BenchmarkResult] = []

    def run(
        self,
        name: str,
        func: Callable,
        iterations: int = 100000,
        setup: Callable = None,
        teardown: Callable = None,
    ) -> BenchmarkResult:
        """Run a benchmark and record results."""
        if setup:
            setup()

        start = time.perf_counter_ns()
        false_accepts = 0
        false_rejects = 0
        correct = 0

        for _ in range(iterations):
            result = func()
            if isinstance(result, dict):
                correct += result.get("correct", 1)
                false_accepts += result.get("false_accept", 0)
                false_rejects += result.get("false_reject", 0)

        elapsed = time.perf_counter_ns() - start
        runtime_ms = elapsed / 1_000_000

        if teardown:
            teardown()

        accuracy = correct / iterations if iterations > 0 else 0
        xi = accuracy  # Simplified: correct operations / total operations

        result = BenchmarkResult(
            benchmark=name,
            operations=iterations,
            runtime_ms=runtime_ms,
            memory_used_mb=0,  # Would need psutil for real tracking
            metadata_overhead_bytes_per_value=64,  # Estimated TypedValue overhead
            decision_accuracy=accuracy,
            false_accept_count=false_accepts,
            false_reject_count=false_rejects,
            xi=xi,
        )

        self.results.append(result)
        return result

    def run_all(
        self, benchmarks: Dict[str, Dict[str, Any]], iterations: int = 100000
    ) -> List[BenchmarkResult]:
        """Run all benchmarks from a config dict."""
        results = []
        for name, config in benchmarks.items():
            result = self.run(
                name=name,
                func=config["func"],
                iterations=iterations,
                setup=config.get("setup"),
                teardown=config.get("teardown"),
            )
            results.append(result)
        return results

    def summary_table(self) -> str:
        """Format all results as a table."""
        if not self.results:
            return "No benchmark results."
        lines = []
        lines.append(
            f"{'Benchmark':<40} {'Ops':>12} {'Time(ms)':>12} {'Xi':>8} {'Accuracy':>10}"
        )
        lines.append("-" * 84)
        for r in self.results:
            lines.append(
                f"{r.benchmark:<40} {r.operations:>12,} "
                f"{r.runtime_ms:>12.2f} {r.xi:>8.4f} "
                f"{r.decision_accuracy:>10.4f}"
            )
        return "\n".join(lines)

    def to_json(self) -> str:
        """Serialize all results to JSON."""
        return json.dumps(
            [
                {
                    "benchmark": r.benchmark,
                    "operations": r.operations,
                    "runtime_ms": r.runtime_ms,
                    "memory_used_mb": r.memory_used_mb,
                    "metadata_overhead_bytes_per_value": r.metadata_overhead_bytes_per_value,
                    "decision_accuracy": r.decision_accuracy,
                    "false_accept_count": r.false_accept_count,
                    "false_reject_count": r.false_reject_count,
                    "xi": r.xi,
                }
                for r in self.results
            ],
            indent=2,
        )
