"""Overhead tracker: measures per-category runtime overhead."""
from dataclasses import dataclass, field
from typing import Dict, List, Optional
import time

from .xi_metric import OverheadMetrics


@dataclass
class OverheadEntry:
    """Single overhead measurement."""
    category: str
    operation: str
    duration_ns: int
    memory_delta: int = 0


class OverheadTracker:
    """Hierarchical overhead tracker with start/stop pairs."""

    def __init__(self):
        self.entries: List[OverheadEntry] = []
        self._start_times: Dict[str, int] = {}
        self._category_stack: List[str] = []

    def start(self, category: str, operation: str = ""):
        """Begin timing an overhead category."""
        self._category_stack.append(category)
        key = f"{category}:{operation}:{len(self._category_stack)}"
        self._start_times[key] = time.time_ns()

    def stop(self, category: str, operation: str = "", memory_delta: int = 0):
        """End timing an overhead category and record the entry."""
        key = f"{category}:{operation}:{len(self._category_stack) + 1}"
        if key not in self._start_times:
            key = f"{category}:{operation}:{len(self._category_stack)}"
        start = self._start_times.pop(key, None)
        if start is None:
            return
        duration = time.time_ns() - start
        self.entries.append(
            OverheadEntry(
                category=category,
                operation=operation,
                duration_ns=duration,
                memory_delta=memory_delta,
            )
        )
        if self._category_stack and self._category_stack[-1] == category:
            self._category_stack.pop()

    def summary(self) -> Dict[str, int]:
        """Return total nanoseconds per category."""
        totals = {}
        for e in self.entries:
            totals[e.category] = totals.get(e.category, 0) + e.duration_ns
        return totals

    def to_overhead_metrics(self, useful_work_ns: int) -> OverheadMetrics:
        """Convert tracked overhead to OverheadMetrics."""
        s = self.summary()
        return OverheadMetrics(
            useful_work=float(useful_work_ns),
            control_overhead=float(s.get("control", 0)),
            memory_overhead=float(s.get("memory", 0)),
            error_overhead=float(s.get("error", 0)),
            calibration_overhead=float(s.get("calibration", 0)),
            translation_overhead=float(s.get("translation", 0)),
        )
