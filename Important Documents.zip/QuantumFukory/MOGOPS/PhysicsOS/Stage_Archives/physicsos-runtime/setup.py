from setuptools import setup, find_packages

setup(
    name="physicsos-runtime",
    version="0.1.0",
    description="PhysicsOS Stage 1 Runtime - Typed numerical computing with uncertainty tracking, domain enforcement, and deterministic replay",
    author="PhysicsOS Team",
    license="Proprietary",
    python_requires=">=3.10",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "physicsos=cli:main",
        ],
    },
    extras_require={
        "test": ["pytest>=7.0"],
    },
)
