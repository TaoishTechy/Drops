from .backend_contract import BackendContract
import random
import time


def make_analog_contract(calibration_age: float = 30.0,
                          calibration_max_age: float = 120.0) -> BackendContract:
    return BackendContract(
        backend_id="sim_analog_0",
        backend_type="simulated_analog",
        precision_range=(0.01, 0.1),
        exact_security_allowed=False,
        reproducibility_score=0.85,
        calibration_max_age_seconds=calibration_max_age,
        calibration_age_seconds=calibration_age,
        noise_model="thermal + process_variation",
        drift_model="linear_0.001_per_hour",
        verifier_required=True,
        failure_modes=["drift_exceeded", "calibration_lost", "temperature_fault"],
    )


def analog_compute(value: float, noise_scale: float = 0.2) -> float:
    """Simulate analog computation with significant noise."""
    noise = random.gauss(0, noise_scale)
    return value + noise
