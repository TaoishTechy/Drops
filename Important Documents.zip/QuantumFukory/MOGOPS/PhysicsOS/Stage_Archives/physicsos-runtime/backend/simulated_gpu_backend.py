from .backend_contract import BackendContract
import random
import time


def make_gpu_contract() -> BackendContract:
    return BackendContract(
        backend_id="sim_gpu_0",
        backend_type="gpu",
        precision_range=(1e-7, 1e-6),
        exact_security_allowed=False,
        reproducibility_score=0.99,
        calibration_max_age_seconds=300.0,
        calibration_age_seconds=30.0,
        noise_model="rounding",
        failure_modes=["out_of_memory", "nvcc_error"],
    )


def gpu_compute(value: float) -> float:
    """Simulate GPU computation with tiny rounding noise."""
    noise = random.uniform(-1e-7, 1e-7)
    return value + noise
