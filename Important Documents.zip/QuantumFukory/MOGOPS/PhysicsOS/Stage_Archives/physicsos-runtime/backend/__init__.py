"""
PhysicsOS Stage 1 Runtime - Backend Module

This module provides the backend contract system for PhysicsOS, including:
- BackendContract: declares backend capabilities, precision, and constraints
- ContractResult: result of validating a backend against policy
- Backend factories: cpu, gpu, simulated_analog
- Verifier: cross-check backend results against expected ranges
"""

from .backend_contract import BackendContract, ContractResult, validate_backend_contract
from .cpu_backend import make_cpu_contract, cpu_compute
from .simulated_gpu_backend import make_gpu_contract, gpu_compute
from .simulated_analog_backend import make_analog_contract, analog_compute
from .verifier import VerificationResult, verify_backend_result

__all__ = [
    # Contract
    "BackendContract",
    "ContractResult",
    "validate_backend_contract",
    # CPU
    "make_cpu_contract",
    "cpu_compute",
    # GPU
    "make_gpu_contract",
    "gpu_compute",
    # Analog
    "make_analog_contract",
    "analog_compute",
    # Verifier
    "VerificationResult",
    "verify_backend_result",
]
