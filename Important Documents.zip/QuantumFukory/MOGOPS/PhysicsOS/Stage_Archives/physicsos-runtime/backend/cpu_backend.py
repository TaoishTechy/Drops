from .backend_contract import BackendContract


def make_cpu_contract() -> BackendContract:
    return BackendContract(
        backend_id="cpu_0",
        backend_type="cpu",
        precision_range=(0.0, 1e-15),
        exact_security_allowed=True,
        reproducibility_score=1.0,
        calibration_max_age_seconds=float('inf'),
    )


def cpu_compute(value: float) -> float:
    """Simulate CPU computation - exact result."""
    return value
