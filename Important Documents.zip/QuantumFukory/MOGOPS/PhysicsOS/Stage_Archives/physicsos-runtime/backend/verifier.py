from dataclasses import dataclass
from typing import Optional
from .backend_contract import BackendContract


@dataclass
class VerificationResult:
    passed: bool
    confidence: float
    checks_performed: list
    failures: list


def verify_backend_result(contract: BackendContract, result: float,
                           expected_range: tuple, uncertainty: float) -> VerificationResult:
    """
    Verify a backend result against expected range and uncertainty constraints.
    """
    checks = []
    failures = []

    # Check if result is within expected range
    in_range = expected_range[0] <= result <= expected_range[1]
    checks.append(f"range_check: {in_range}")
    if not in_range:
        failures.append(f"Result {result} outside expected range {expected_range}")

    # Check calibration
    cal_valid = contract.calibration_valid
    checks.append(f"calibration_check: {cal_valid}")
    if not cal_valid:
        failures.append("Calibration expired")

    # Check uncertainty is within precision range
    prec_ok = contract.precision_range[0] <= uncertainty <= contract.precision_range[1]
    checks.append(f"precision_check: {prec_ok}")
    if not prec_ok:
        failures.append(f"Uncertainty {uncertainty} outside precision range {contract.precision_range}")

    confidence = 1.0 if not failures else max(0.0, 1.0 - len(failures) * 0.3)

    return VerificationResult(
        passed=len(failures) == 0,
        confidence=confidence,
        checks_performed=checks,
        failures=failures,
    )
