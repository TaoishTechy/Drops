from dataclasses import dataclass
from typing import Optional, List, Literal


@dataclass
class BackendContract:
    backend_id: str
    backend_type: Literal["cpu", "gpu", "analog", "simulated_analog", "fpga"]
    precision_range: tuple  # (min_precision, max_precision)
    noise_model: Optional[str] = None
    drift_model: Optional[str] = None
    calibration_age_seconds: float = 0.0
    calibration_max_age_seconds: float = 120.0
    verifier_required: bool = False
    failure_modes: List[str] = None
    reproducibility_score: float = 1.0
    exact_security_allowed: bool = False

    def __post_init__(self):
        if self.failure_modes is None:
            self.failure_modes = []

    @property
    def calibration_valid(self) -> bool:
        return self.calibration_age_seconds <= self.calibration_max_age_seconds

    @property
    def precision_string(self) -> str:
        return f"[{self.precision_range[0]}, {self.precision_range[1]}]"

    def __repr__(self):
        status = "CALIBRATED" if self.calibration_valid else "EXPIRED"
        return f"BackendContract({self.backend_id}, {self.backend_type}, {status}, precision={self.precision_string})"


@dataclass
class ContractResult:
    accepted: bool
    reason: str
    backend_id: str = ""
    calibration_status: str = ""


def validate_backend_contract(contract: BackendContract, result_uncertainty: float,
                               policy_max_uncertainty: float = 0.1) -> ContractResult:
    """
    accept(result) :=
        U_result <= U_policy
        AND calibration_age <= max_age
        AND verifier_passed (if required)
    """
    reasons = []

    if result_uncertainty > policy_max_uncertainty:
        reasons.append(f"Uncertainty {result_uncertainty:.6f} exceeds policy {policy_max_uncertainty}")

    if not contract.calibration_valid:
        reasons.append(f"Calibration expired: {contract.calibration_age_seconds}s > {contract.calibration_max_age_seconds}s")

    if contract.verifier_required:
        reasons.append("Verifier check required but not implemented in Stage 1")

    if reasons:
        return ContractResult(
            accepted=False,
            reason="; ".join(reasons),
            backend_id=contract.backend_id,
            calibration_status="VALID" if contract.calibration_valid else "EXPIRED",
        )

    return ContractResult(
        accepted=True,
        reason="All checks passed",
        backend_id=contract.backend_id,
        calibration_status="VALID",
    )
