from dataclasses import dataclass, field
from typing import List, Optional
import hashlib
import time


@dataclass
class ProvenanceEntry:
    operation: str
    timestamp_ns: int
    description: str = ""
    source_id: Optional[str] = None


class ProvenanceChain:
    def __init__(self, entries: Optional[List[ProvenanceEntry]] = None, source: str = "initial"):
        self.entries: List[ProvenanceEntry] = entries if entries is not None else []
        if not self.entries:
            self.entries.append(ProvenanceEntry(
                operation="create",
                timestamp_ns=time.time_ns(),
                description=f"Initial creation: {source}"
            ))

    def add(self, operation: str, description: str = "", source_id: str = None) -> "ProvenanceChain":
        new_entries = self.entries.copy()
        new_entries.append(ProvenanceEntry(
            operation=operation,
            timestamp_ns=time.time_ns(),
            description=description,
            source_id=source_id,
        ))
        return ProvenanceChain(entries=new_entries)

    def merge(self, other: "ProvenanceChain") -> "ProvenanceChain":
        """Merge two provenance chains (e.g., when combining two values)."""
        return ProvenanceChain(entries=self.entries + [ProvenanceEntry(
            operation="merge",
            timestamp_ns=time.time_ns(),
            description=f"Merged with chain starting from {other.entries[0].operation if other.entries else 'empty'}"
        )] + other.entries)

    @property
    def valid(self) -> bool:
        """Check if the chain is non-empty and well-formed."""
        return len(self.entries) > 0 and all(e.operation for e in self.entries)

    def hash(self) -> str:
        """Deterministic hash of the provenance chain."""
        content = "|".join(f"{e.operation}:{e.timestamp_ns}:{e.description}" for e in self.entries)
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    def __len__(self):
        return len(self.entries)

    def __repr__(self):
        return f"ProvenanceChain(len={len(self.entries)}, hash={self.hash()})"
