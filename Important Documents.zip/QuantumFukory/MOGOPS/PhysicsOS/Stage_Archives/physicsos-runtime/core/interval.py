from .uncertainty import Uncertainty
import math


class Interval:
    """IEEE 1788-2015 inspired interval arithmetic."""

    # Sentinel marker for the empty interval
    _EMPTY_SENTINEL = object()

    def __init__(self, lower: float, upper: float, *, _allow_inverted: bool = False):
        if not _allow_inverted and lower > upper and not (math.isinf(lower) and math.isinf(upper)):
            raise ValueError(f"Interval lower ({lower}) must be <= upper ({upper})")
        self.lower = lower
        self.upper = upper

    @property
    def width(self):
        if self.is_empty:
            return 0.0
        return self.upper - self.lower

    @property
    def midpoint(self):
        if self.is_empty:
            return float('nan')
        return (self.lower + self.upper) / 2.0

    @property
    def is_empty(self):
        return self.lower > self.upper

    @classmethod
    def from_value(cls, value: float, half_width: float = 0.0):
        return cls(value - half_width, value + half_width)

    @classmethod
    def exact(cls, value: float):
        return cls(value, value)

    def overlaps(self, other: "Interval") -> bool:
        if self.is_empty or other.is_empty:
            return False
        return not (self.upper < other.lower or other.upper < self.lower)

    def intersection(self, other: "Interval") -> "Interval":
        if not self.overlaps(other):
            return Interval.empty()
        return Interval(max(self.lower, other.lower), min(self.upper, other.upper))

    def union(self, other: "Interval") -> "Interval":
        if self.is_empty:
            return other
        if other.is_empty:
            return self
        return Interval(min(self.lower, other.lower), max(self.upper, other.upper))

    def contains(self, value: float) -> bool:
        return self.lower <= value <= self.upper

    def to_uncertainty(self, confidence: float = 1.0) -> Uncertainty:
        return Uncertainty(lower=self.lower, upper=self.upper, confidence=confidence)

    def __add__(self, other):
        if isinstance(other, Interval):
            if self.is_empty or other.is_empty:
                return Interval.empty()
            return Interval(self.lower + other.lower, self.upper + other.upper)
        if self.is_empty:
            return Interval.empty()
        return Interval(self.lower + other, self.upper + other)

    def __radd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):
        if isinstance(other, Interval):
            if self.is_empty or other.is_empty:
                return Interval.empty()
            return Interval(self.lower - other.upper, self.upper - other.lower)
        if self.is_empty:
            return Interval.empty()
        return Interval(self.lower - other, self.upper - other)

    def __rsub__(self, other):
        if self.is_empty:
            return Interval.empty()
        return Interval(other - self.upper, other - self.lower)

    def __mul__(self, other):
        if isinstance(other, Interval):
            if self.is_empty or other.is_empty:
                return Interval.empty()
            products = [self.lower * other.lower, self.lower * other.upper,
                        self.upper * other.lower, self.upper * other.upper]
            return Interval(min(products), max(products))
        if self.is_empty:
            return Interval.empty()
        if other >= 0:
            return Interval(self.lower * other, self.upper * other)
        return Interval(self.upper * other, self.lower * other)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other):
        if isinstance(other, Interval):
            if other.lower <= 0 <= other.upper:
                raise ZeroDivisionError("Interval division by interval containing zero")
            if self.is_empty or other.is_empty:
                return Interval.empty()
            recip = Interval(1.0 / other.upper, 1.0 / other.lower)
            return self * recip
        if other == 0:
            raise ZeroDivisionError("Division by zero")
        if self.is_empty:
            return Interval.empty()
        if other > 0:
            return Interval(self.lower / other, self.upper / other)
        return Interval(self.upper / other, self.lower / other)

    def __neg__(self):
        if self.is_empty:
            return Interval.empty()
        return Interval(-self.upper, -self.lower)

    def __eq__(self, other):
        if isinstance(other, Interval):
            if self.is_empty and other.is_empty:
                return True
            return self.lower == other.lower and self.upper == other.upper
        return False

    def __repr__(self):
        if self.is_empty:
            return "Interval(empty)"
        return f"Interval([{self.lower}, {self.upper}])"

    @classmethod
    def empty(cls):
        """Create the empty interval (a valid IEEE 1788-2015 concept with lower > upper)."""
        obj = cls.__new__(cls)
        obj.lower = float('inf')
        obj.upper = float('-inf')
        return obj

    @classmethod
    def entire(cls):
        return cls(float('-inf'), float('inf'))

    @classmethod
    def hull(cls, values):
        if not values:
            return cls.empty()
        return cls(min(values), max(values))
