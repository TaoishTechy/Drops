"""
PhysicsOS Stage 1 Runtime - Core Types Module

This module provides the foundational type system for PhysicsOS, including:
- Domain enumeration and compatibility checking
- Typed zero (ZeroType) with per-domain policy enforcement
- Typed NaN (NaNType) with recovery policies
- Uncertainty quantification with interval bounds and confidence
- IEEE 1788-2015 inspired interval arithmetic
- SI unit dimensional analysis with DimensionalError
- Provenance tracking chains for computation auditability
- TypedValue: the central data container combining all of the above
"""

from .domain import Domain, domain_compatible
from .typed_zero import ZeroType, ZERO_POLICY_TABLE, zero_allowed, zero_allowed_info
from .typed_nan import NaNType, NAN_RECOVERY_POLICY, nan_recovery_policy, nan_description
from .uncertainty import Uncertainty
from .interval import Interval
from .units import (
    Unit, DimensionalError,
    DIMENSIONLESS, METER, SECOND, KILOGRAM, AMPERE, KELVIN, MOLE, CANDELA,
    VELOCITY, ACCELERATION, NEWTON, JOULE, WATT, HERTZ, VOLT, OHM, FARAD, TESLA,
)
from .provenance import ProvenanceEntry, ProvenanceChain
from .typed_value import BackendInfo, TypedValue, physics_add, physics_divide

__all__ = [
    # Domain
    "Domain",
    "domain_compatible",
    # Typed Zero
    "ZeroType",
    "ZERO_POLICY_TABLE",
    "zero_allowed",
    "zero_allowed_info",
    # Typed NaN
    "NaNType",
    "NAN_RECOVERY_POLICY",
    "nan_recovery_policy",
    "nan_description",
    # Uncertainty
    "Uncertainty",
    # Interval
    "Interval",
    # Units
    "Unit",
    "DimensionalError",
    "DIMENSIONLESS",
    "METER",
    "SECOND",
    "KILOGRAM",
    "AMPERE",
    "KELVIN",
    "MOLE",
    "CANDELA",
    "VELOCITY",
    "ACCELERATION",
    "NEWTON",
    "JOULE",
    "WATT",
    "HERTZ",
    "VOLT",
    "OHM",
    "FARAD",
    "TESLA",
    # Provenance
    "ProvenanceEntry",
    "ProvenanceChain",
    # TypedValue
    "BackendInfo",
    "TypedValue",
    "physics_add",
    "physics_divide",
]
