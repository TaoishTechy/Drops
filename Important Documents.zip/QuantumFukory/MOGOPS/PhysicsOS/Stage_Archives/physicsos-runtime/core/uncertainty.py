from dataclasses import dataclass, field
from typing import Optional
import math


@dataclass
class Uncertainty:
    lower: float
    upper: float
    confidence: float
    measurement: float = 0.0
    rounding: float = 0.0
    model: float = 0.0
    hardware: float = 0.0
    time: float = 0.0
    security: float = 0.0
    covariance_id: Optional[str] = None

    @property
    def width(self) -> float:
        return self.upper - self.lower

    @property
    def midpoint(self) -> float:
        return (self.lower + self.upper) / 2.0

    def total(self) -> float:
        """Combined uncertainty - NOT a simple max unless units match."""
        return math.sqrt(
            self.measurement**2 +
            self.rounding**2 +
            self.model**2 +
            self.hardware**2 +
            self.time**2 +
            self.security**2
        )

    def overlaps(self, other: "Uncertainty") -> bool:
        return not (self.upper < other.lower or other.upper < self.lower)

    def overlap_fraction(self, other: "Uncertainty") -> float:
        """Intersection width / union width, for contextual equality."""
        if not self.overlaps(other):
            return 0.0
        intersection = min(self.upper, other.upper) - max(self.lower, other.lower)
        union = max(self.upper, other.upper) - min(self.lower, other.lower)
        if union <= 0:
            return 0.0
        return intersection / union

    @classmethod
    def from_point(cls, value: float, half_width: float = 0.0, confidence: float = 1.0, **kwargs) -> "Uncertainty":
        return cls(lower=value - half_width, upper=value + half_width, confidence=confidence, **kwargs)

    @classmethod
    def from_confidence(cls, confidence: float) -> "Uncertainty":
        return cls(lower=0.0, upper=1.0, confidence=confidence)

    @classmethod
    def infinite(cls) -> "Uncertainty":
        return cls(lower=float('-inf'), upper=float('inf'), confidence=0.0)

    @classmethod
    def exact(cls, value: float) -> "Uncertainty":
        return cls(lower=value, upper=value, confidence=1.0)

    def __add__(self, other: "Uncertainty") -> "Uncertainty":
        return Uncertainty(
            lower=self.lower + other.lower,
            upper=self.upper + other.upper,
            confidence=min(self.confidence, other.confidence),
            measurement=self.measurement + other.measurement,
            rounding=self.rounding + other.rounding,
            model=self.model + other.model,
            hardware=self.hardware + other.hardware,
            time=self.time + other.time,
            security=self.security + other.security,
        )

    def __mul__(self, scalar: float) -> "Uncertainty":
        return Uncertainty(
            lower=self.lower * scalar,
            upper=self.upper * scalar,
            confidence=self.confidence,
            measurement=self.measurement,
            rounding=self.rounding,
            model=self.model,
            hardware=self.hardware,
            time=self.time,
            security=self.security,
        )

    def __repr__(self):
        return f"Uncertainty([{self.lower}, {self.upper}], conf={self.confidence:.3f})"
