from enum import Enum
from .domain import Domain


class ZeroType(Enum):
    EXACT_SYMBOLIC_ZERO = "exact_symbolic_zero"
    MEASURED_ABSENCE = "measured_absence"
    HARDWARE_GROUND = "hardware_ground"
    NULL_CAPABILITY = "null_capability"
    COMPUTATIONAL_OPERAND_ZERO = "computational_operand_zero"
    UNTYPED_ZERO = "untyped_zero"


# Zero policy table mapping Domain -> set of allowed ZeroTypes
ZERO_POLICY_TABLE = {
    Domain.FORMAL_PROOF: {ZeroType.EXACT_SYMBOLIC_ZERO},
    Domain.PHYSICS_NUMERIC: {ZeroType.MEASURED_ABSENCE, ZeroType.HARDWARE_GROUND},
    Domain.SECURITY_AUTHORITY: {ZeroType.NULL_CAPABILITY},
    Domain.MEMORY_ACCESS: {ZeroType.NULL_CAPABILITY},
    Domain.SENSOR_DATA: {ZeroType.MEASURED_ABSENCE, ZeroType.HARDWARE_GROUND, ZeroType.EXACT_SYMBOLIC_ZERO},
    Domain.FILESYSTEM_EXACT: {ZeroType.EXACT_SYMBOLIC_ZERO, ZeroType.NULL_CAPABILITY},
    Domain.FILESYSTEM_APPROX: {ZeroType.MEASURED_ABSENCE, ZeroType.HARDWARE_GROUND, ZeroType.EXACT_SYMBOLIC_ZERO},
    Domain.NETWORK_TELEMETRY: {ZeroType.MEASURED_ABSENCE, ZeroType.HARDWARE_GROUND},
    Domain.ML_INFERENCE: {ZeroType.MEASURED_ABSENCE, ZeroType.HARDWARE_GROUND, ZeroType.EXACT_SYMBOLIC_ZERO},
    Domain.HUMAN_DISPLAY: {zt for zt in ZeroType if zt != ZeroType.UNTYPED_ZERO},
}


def zero_allowed(zero_type: ZeroType, context: Domain) -> bool:
    """Check if a zero of given type is allowed in the given context domain."""
    allowed = ZERO_POLICY_TABLE.get(context, set())
    return zero_type in allowed


def zero_allowed_info(zero_type: ZeroType, context: Domain) -> str:
    """Return reason string for why zero was allowed/rejected."""
    allowed = ZERO_POLICY_TABLE.get(context, set())
    if zero_type in allowed:
        return f"ALLOWED: {zero_type.value} in {context.value}"
    return f"REJECTED: {zero_type.value} not allowed in {context.value} (allowed: {', '.join(z.value for z in allowed)})"
