from enum import Enum
from .domain import Domain


class NaNType(Enum):
    DOMAIN = "nan_domain"
    DIVERGENT = "nan_divergent"
    UNMEASURED = "nan_unmeasured"
    UNAUTHORIZED = "nan_unauthorized"
    HARDWARE_FAULT = "nan_hardware_fault"
    TIMEOUT = "nan_timeout"


# Recovery policy for each NaN type
NAN_RECOVERY_POLICY = {
    NaNType.DOMAIN: "raise_domain_error_with_operands",
    NaNType.DIVERGENT: "return_clamped_interval_or_raise",
    NaNType.UNMEASURED: "defer_to_policy_or_request_measurement",
    NaNType.UNAUTHORIZED: "deny_and_log_security_event",
    NaNType.HARDWARE_FAULT: "retry_with_different_backend_or_fail",
    NaNType.TIMEOUT: "retry_with_increased_timeout_or_return_approximation",
}


def nan_recovery_policy(nan_type: NaNType) -> str:
    return NAN_RECOVERY_POLICY.get(nan_type, "raise_generic_error")


def nan_description(nan_type: NaNType) -> str:
    descriptions = {
        NaNType.DOMAIN: "Operation violated domain constraints (e.g., division by forbidden zero, incompatible units)",
        NaNType.DIVERGENT: "Computation diverged beyond representable bounds",
        NaNType.UNMEASURED: "Required measurement was not available",
        NaNType.UNAUTHORIZED: "Value lacked authorization for the requested context",
        NaNType.HARDWARE_FAULT: "Hardware backend reported an unrecoverable fault",
        NaNType.TIMEOUT: "Computation did not complete within the allowed time budget",
    }
    return descriptions.get(nan_type, "Unknown NaN type")
