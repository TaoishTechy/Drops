from dataclasses import dataclass
from functools import total_ordering


@dataclass(frozen=True)
class Unit:
    kg: int = 0
    m: int = 0
    s: int = 0
    A: int = 0
    K: int = 0
    mol: int = 0
    cd: int = 0

    def __post_init__(self):
        # Check if this is dimensionless
        dims = (self.kg, self.m, self.s, self.A, self.K, self.mol, self.cd)
        if all(d == 0 for d in dims):
            object.__setattr__(self, '_dimensionless', True)
        else:
            object.__setattr__(self, '_dimensionless', False)

    @property
    def is_dimensionless(self) -> bool:
        return getattr(self, '_dimensionless', True)

    def compatible(self, other: "Unit") -> bool:
        """Two units are compatible if they have the same dimensional signature."""
        return (self.kg == other.kg and self.m == other.m and self.s == other.s
                and self.A == other.A and self.K == other.K
                and self.mol == other.mol and self.cd == other.cd)

    def __add__(self, other):
        if not self.compatible(other):
            raise DimensionalError(f"Cannot add {self} + {other}: incompatible units")
        return self

    def __sub__(self, other):
        if not self.compatible(other):
            raise DimensionalError(f"Cannot subtract {self} - {other}: incompatible units")
        return self

    def __mul__(self, other):
        if isinstance(other, Unit):
            return Unit(
                kg=self.kg + other.kg, m=self.m + other.m, s=self.s + other.s,
                A=self.A + other.A, K=self.K + other.K,
                mol=self.mol + other.mol, cd=self.cd + other.cd,
            )
        return self

    def __truediv__(self, other):
        if isinstance(other, Unit):
            return Unit(
                kg=self.kg - other.kg, m=self.m - other.m, s=self.s - other.s,
                A=self.A - other.A, K=self.K - other.K,
                mol=self.mol - other.mol, cd=self.cd - other.cd,
            )
        return self

    def __pow__(self, exponent):
        if isinstance(exponent, int):
            return Unit(kg=self.kg * exponent, m=self.m * exponent, s=self.s * exponent,
                        A=self.A * exponent, K=self.K * exponent,
                        mol=self.mol * exponent, cd=self.cd * exponent)
        raise TypeError("Unit exponent must be integer")

    def __eq__(self, other):
        if not isinstance(other, Unit):
            return False
        return (self.kg == other.kg and self.m == other.m and self.s == other.s
                and self.A == other.A and self.K == other.K
                and self.mol == other.mol and self.cd == other.cd)

    def __hash__(self):
        return hash((self.kg, self.m, self.s, self.A, self.K, self.mol, self.cd))

    def __repr__(self):
        parts = []
        if self.kg != 0: parts.append(f"kg^{self.kg}" if self.kg != 1 else "kg")
        if self.m != 0: parts.append(f"m^{self.m}" if self.m != 1 else "m")
        if self.s != 0: parts.append(f"s^{self.s}" if self.s != 1 else "s")
        if self.A != 0: parts.append(f"A^{self.A}" if self.A != 1 else "A")
        if self.K != 0: parts.append(f"K^{self.K}" if self.K != 1 else "K")
        if self.mol != 0: parts.append(f"mol^{self.mol}" if self.mol != 1 else "mol")
        if self.cd != 0: parts.append(f"cd^{self.cd}" if self.cd != 1 else "cd")
        if not parts:
            return "dimensionless"
        return " * ".join(parts)


class DimensionalError(Exception):
    """Raised when an operation violates dimensional analysis."""
    pass


# Common units
DIMENSIONLESS = Unit()
METER = Unit(m=1)
SECOND = Unit(s=1)
KILOGRAM = Unit(kg=1)
AMPERE = Unit(A=1)
KELVIN = Unit(K=1)
MOLE = Unit(mol=1)
CANDELA = Unit(cd=1)
VELOCITY = Unit(m=1, s=-1)
ACCELERATION = Unit(m=1, s=-2)
NEWTON = Unit(kg=1, m=1, s=-2)
JOULE = Unit(kg=1, m=2, s=-2)
WATT = Unit(kg=1, m=2, s=-3)
HERTZ = Unit(s=-1)
VOLT = Unit(kg=1, m=2, s=-3, A=-1)
OHM = Unit(kg=1, m=2, s=-3, A=-2)
FARAD = Unit(kg=-1, m=-2, s=4, A=2)
TESLA = Unit(kg=1, s=-2, A=-1)
