from enum import Enum


class Domain(Enum):
    FORMAL_PROOF = "formal_proof"
    PHYSICS_NUMERIC = "physics_numeric"
    SECURITY_AUTHORITY = "security_authority"
    MEMORY_ACCESS = "memory_access"
    SENSOR_DATA = "sensor_data"
    FILESYSTEM_EXACT = "filesystem_exact"
    FILESYSTEM_APPROX = "filesystem_approx"
    NETWORK_TELEMETRY = "network_telemetry"
    ML_INFERENCE = "ml_inference"
    HUMAN_DISPLAY = "human_display"


def domain_compatible(a: Domain, b: Domain) -> bool:
    """Return True if two domains are compatible for cross-domain operations.

    Rules:
    - Same domain is always compatible.
    - HUMAN_DISPLAY is compatible with anything (it's a sink/display domain).
    - FORMAL_PROOF is compatible with anything (it can verify any domain).
    """
    if a == b:
        return True
    if a == Domain.HUMAN_DISPLAY or b == Domain.HUMAN_DISPLAY:
        return True
    if a == Domain.FORMAL_PROOF or b == Domain.FORMAL_PROOF:
        return True
    return False
