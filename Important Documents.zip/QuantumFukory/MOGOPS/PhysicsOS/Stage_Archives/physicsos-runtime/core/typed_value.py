from dataclasses import dataclass, field
from typing import Any, Optional
from .domain import Domain
from .typed_zero import ZeroType, zero_allowed
from .typed_nan import NaNType, nan_description, nan_recovery_policy
from .uncertainty import Uncertainty
from .interval import Interval
from .provenance import ProvenanceChain
from .units import Unit, DimensionalError


@dataclass
class BackendInfo:
    backend_id: str = "runtime"
    backend_type: str = "cpu"
    is_exact: bool = True
    precision_range: tuple = (0.0, 1e-15)

    @classmethod
    def runtime(cls):
        return cls()

    @classmethod
    def simulated_analog(cls):
        return cls(backend_id="sim_analog", backend_type="analog", is_exact=False, precision_range=(0.01, 0.1))

    @classmethod
    def simulated_gpu(cls):
        return cls(backend_id="sim_gpu", backend_type="gpu", is_exact=False, precision_range=(1e-7, 1e-6))


@dataclass
class TypedValue:
    value: Any
    uncertainty: Uncertainty
    domain: Domain
    provenance: ProvenanceChain
    backend: BackendInfo = field(default_factory=BackendInfo.runtime)
    units: Optional[Unit] = None
    zero_type: Optional[ZeroType] = None
    nan_type: Optional[NaNType] = None

    def is_zero(self) -> bool:
        if self.nan_type is not None:
            return False
        if self.value is None:
            return True
        if isinstance(self.value, (int, float)):
            return self.value == 0.0
        return False

    def is_nan(self) -> bool:
        return self.nan_type is not None

    def interval(self) -> Interval:
        return Interval(self.uncertainty.lower, self.uncertainty.upper)

    def with_domain(self, new_domain: Domain) -> "TypedValue":
        return TypedValue(
            value=self.value,
            uncertainty=self.uncertainty,
            domain=new_domain,
            provenance=self.provenance.add("domain_change", f"{self.domain.value} -> {new_domain.value}"),
            backend=self.backend,
            units=self.units,
            zero_type=self.zero_type,
            nan_type=self.nan_type,
        )

    def with_zero_type(self, zt: ZeroType) -> "TypedValue":
        return TypedValue(
            value=self.value,
            uncertainty=self.uncertainty,
            domain=self.domain,
            provenance=self.provenance.add("zero_type_assign", zt.value),
            backend=self.backend,
            units=self.units,
            zero_type=zt,
            nan_type=self.nan_type,
        )

    def with_nan_type(self, nt: NaNType, reason: str = "") -> "TypedValue":
        return TypedValue(
            value=None,
            uncertainty=Uncertainty.infinite(),
            domain=self.domain,
            provenance=self.provenance.add("nan_assign", f"{nt.value}: {reason}"),
            backend=self.backend,
            units=self.units,
            zero_type=None,
            nan_type=nt,
        )

    @classmethod
    def typed_nan(cls, nan_type: NaNType, reason: str, domain: Domain,
                  provenance: ProvenanceChain = None, operands: list = None) -> "TypedValue":
        prov = provenance or ProvenanceChain(source="typed_nan")
        if operands:
            for i, op in enumerate(operands):
                prov = prov.add("operand", f"operand_{i}")
        return cls(
            value=None,
            uncertainty=Uncertainty.infinite(),
            domain=domain,
            provenance=prov.add("nan_created", f"{nan_type.value}: {reason}"),
            nan_type=nan_type,
        )

    @classmethod
    def from_float(cls, value: float, domain: Domain = Domain.PHYSICS_NUMERIC,
                   half_width: float = 0.0, units: Unit = None) -> "TypedValue":
        if value == 0.0:
            return cls(
                value=value,
                uncertainty=Uncertainty.exact(value),
                domain=domain,
                provenance=ProvenanceChain(source="float_zero"),
                zero_type=ZeroType.COMPUTATIONAL_OPERAND_ZERO,
                units=units,
            )
        return cls(
            value=value,
            uncertainty=Uncertainty.from_point(value, half_width=half_width),
            domain=domain,
            provenance=ProvenanceChain(source="float"),
            units=units,
        )

    def __repr__(self):
        parts = [f"TypedValue("]
        if self.is_nan():
            parts.append(f"  NaN: {self.nan_type.value}")
        else:
            parts.append(f"  value={self.value}")
        parts.append(f"  uncertainty={self.uncertainty}")
        parts.append(f"  domain={self.domain.value}")
        if self.zero_type:
            parts.append(f"  zero_type={self.zero_type.value}")
        if self.units:
            parts.append(f"  units={self.units}")
        parts.append(f"  backend={self.backend.backend_type}")
        parts.append(f")")
        return "\n".join(parts)


def physics_add(a: TypedValue, b: TypedValue, domain: Domain = None) -> TypedValue:
    """Add two TypedValues with interval arithmetic and unit checking."""
    if a.units and b.units:
        _ = a.units + b.units  # Raises DimensionalError if incompatible
    target = domain or a.domain
    result_interval = a.interval() + b.interval()
    combined_unc = a.uncertainty + b.uncertainty
    return TypedValue(
        value=result_interval.midpoint,
        uncertainty=Uncertainty(
            result_interval.lower, result_interval.upper,
            min(a.uncertainty.confidence, b.uncertainty.confidence)
        ),
        domain=target,
        provenance=a.provenance.merge(b.provenance).add("physics_add"),
        backend=BackendInfo.runtime(),
        units=a.units or b.units,
    )


def physics_divide(a: TypedValue, b: TypedValue, domain: Domain = None) -> TypedValue:
    """Divide two TypedValues with typed zero checking and interval division."""
    target = domain or a.domain

    if b.is_zero():
        if b.zero_type is not None and not zero_allowed(b.zero_type, target):
            return TypedValue.typed_nan(
                nan_type=NaNType.DOMAIN,
                reason="division_by_forbidden_zero",
                domain=target,
                provenance=a.provenance.merge(b.provenance),
                operands=[a, b],
            )
        if b.zero_type is None:
            return TypedValue.typed_nan(
                nan_type=NaNType.DOMAIN,
                reason="division_by_untyped_zero",
                domain=target,
                provenance=a.provenance.merge(b.provenance),
                operands=[a, b],
            )
        # Zero is typed and allowed — but division by zero still diverges
        result_units = None
        if a.units and b.units:
            result_units = a.units / b.units
        return TypedValue.typed_nan(
            nan_type=NaNType.DIVERGENT,
            reason=f"division_by_typed_zero ({b.zero_type.value})",
            domain=target,
            provenance=a.provenance.merge(b.provenance),
            operands=[a, b],
        )

    result_units = None
    if a.units and b.units:
        result_units = a.units / b.units

    try:
        result_interval = a.interval() / b.interval()
    except ZeroDivisionError:
        result_interval = Interval.entire()

    return TypedValue(
        value=result_interval.midpoint,
        uncertainty=result_interval.to_uncertainty(),
        domain=target,
        provenance=a.provenance.merge(b.provenance).add("physics_divide"),
        backend=BackendInfo.runtime(),
        units=result_units,
    )
