"""
PhysicsOS Stage 1 Runtime

A typed numerical runtime with domain-aware gates, uncertainty tracking,
typed zero/NaN, provenance chains, and SI unit dimensional analysis.
"""
