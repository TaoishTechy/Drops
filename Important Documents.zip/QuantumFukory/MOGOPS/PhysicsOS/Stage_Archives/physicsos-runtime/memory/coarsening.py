"""Coarsening strategies for approximate fields."""
from typing import List
from .approximate_field import ApproxField


def simple_coarsen(field: ApproxField, levels: int = 1) -> int:
    """Simple linear coarsening."""
    return field.coarsen(levels)


def priority_coarsen(fields: List[ApproxField], target_levels: dict) -> dict:
    """Coarsen multiple fields based on target fidelity levels."""
    results = {}
    for field in fields:
        target = target_levels.get(field.field_id, field.fidelity_level)
        levels = field.fidelity_level - target
        if levels > 0:
            saved = field.coarsen(levels)
            results[field.field_id] = {"saved": saved, "new_fidelity": field.fidelity_level}
    return results
