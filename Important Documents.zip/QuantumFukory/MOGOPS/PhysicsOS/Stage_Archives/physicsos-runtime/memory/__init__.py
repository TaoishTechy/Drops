"""
PhysicsOS Stage 1 Runtime - Memory Module

This module provides the memory management system for PhysicsOS, including:
- ExactObject: memory objects that must NEVER be degraded or approximated
- ApproxField: approximate field-memory objects that can be coarsened under pressure
- No-OOM degradation policy: graceful degradation instead of out-of-memory crashes
- Coarsening strategies for approximate fields
- Memory pressure simulation utilities
"""

from .exact_object import ExactObject
from .approximate_field import ApproxField, CoarseningPolicy
from .no_oom_degrader import (
    MemoryObject,
    DegradationAction,
    DegradationReport,
    handle_memory_pressure,
)
from .coarsening import simple_coarsen, priority_coarsen
from .memory_pressure import simulate_pressure, pressure_color

__all__ = [
    # Exact memory
    "ExactObject",
    # Approximate memory
    "ApproxField",
    "CoarseningPolicy",
    # Degradation
    "MemoryObject",
    "DegradationAction",
    "DegradationReport",
    "handle_memory_pressure",
    # Coarsening
    "simple_coarsen",
    "priority_coarsen",
    # Pressure utilities
    "simulate_pressure",
    "pressure_color",
]
