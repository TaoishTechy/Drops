"""Memory pressure simulation utilities."""
import random
import time


def simulate_pressure(base: float = 0.5, volatility: float = 0.3, steps: int = 100) -> list:
    """Simulate memory pressure over time."""
    pressure = base
    pressures = []
    for _ in range(steps):
        pressure += random.uniform(-volatility, volatility) * 0.1
        pressure = max(0.1, min(0.99, pressure))
        pressures.append(pressure)
    return pressures


def pressure_color(pressure: float) -> str:
    if pressure < 0.6:
        return "GREEN"
    elif pressure < 0.8:
        return "YELLOW"
    elif pressure < 0.9:
        return "ORANGE"
    return "RED"
