from dataclasses import dataclass, field
from typing import Optional, List
from core.uncertainty import Uncertainty
from core.provenance import ProvenanceChain


@dataclass
class CoarseningPolicy:
    """Defines how a field degrades under memory pressure."""
    min_fidelity: int = 1
    coarsen_step: int = 1
    memory_per_fidelity_level: int = 1024  # bytes saved per level


@dataclass
class ApproxField:
    """Approximate field-memory object that can be coarsened under pressure."""
    field_id: str
    shape: tuple
    basis: str
    fidelity_level: int
    uncertainty: Uncertainty
    backend_hint: str = "cpu"
    can_degrade: bool = True
    coarsening_policy: CoarseningPolicy = field(default_factory=CoarseningPolicy)
    priority: int = 0
    provenance: ProvenanceChain = field(default_factory=lambda: ProvenanceChain(source="approx_field"))

    @property
    def memory_size_bytes(self) -> int:
        return self.fidelity_level * self.coarsening_policy.memory_per_fidelity_level

    @property
    def can_coarsen(self) -> bool:
        return self.can_degrade and self.fidelity_level > self.coarsening_policy.min_fidelity

    def coarsen(self, levels: int = 1) -> int:
        """Reduce fidelity level. Returns memory saved."""
        if not self.can_coarsen:
            return 0
        old_level = self.fidelity_level
        self.fidelity_level = max(
            self.coarsening_policy.min_fidelity,
            self.fidelity_level - (levels * self.coarsening_policy.coarsen_step)
        )
        # Increase uncertainty when coarsening
        lost = old_level - self.fidelity_level
        self.uncertainty = Uncertainty(
            lower=self.uncertainty.lower - lost * 0.001,
            upper=self.uncertainty.upper + lost * 0.001,
            confidence=max(0.1, self.uncertainty.confidence - lost * 0.05),
        )
        return (old_level - self.fidelity_level) * self.coarsening_policy.memory_per_fidelity_level

    def __repr__(self):
        return f"ApproxField(id={self.field_id}, fidelity={self.fidelity_level}, degrade={self.can_degrade})"
