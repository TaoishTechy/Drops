from dataclasses import dataclass, field
from typing import List, Union
from core.uncertainty import Uncertainty
from core.provenance import ProvenanceChain
from .exact_object import ExactObject
from .approximate_field import ApproxField

MemoryObject = Union[ExactObject, ApproxField]


@dataclass
class DegradationAction:
    object_id: str
    object_type: str  # "exact" or "approx"
    action: str  # "preserved", "coarsened", "protected"
    old_fidelity: int = 0
    new_fidelity: int = 0
    memory_saved: int = 0


@dataclass
class DegradationReport:
    pressure_before: float
    pressure_after: float
    target_pressure: float
    actions: List[DegradationAction] = field(default_factory=list)

    def add(self, action: DegradationAction):
        self.actions.append(action)

    def __str__(self):
        lines = [f"Degradation Report: {self.pressure_before:.1%} -> {self.pressure_after:.1%} (target: {self.target_pressure:.1%})"]
        for a in self.actions:
            if a.action == "preserved":
                lines.append(f"  [PRESERVED] {a.object_id} ({a.object_type})")
            elif a.action == "protected":
                lines.append(f"  [PROTECTED] {a.object_id} ({a.object_type}): cannot degrade")
            elif a.action == "coarsened":
                lines.append(f"  [COARSENED] {a.object_id}: fidelity {a.old_fidelity} -> {a.new_fidelity} ({a.memory_saved} bytes saved)")
        return "\n".join(lines)


def handle_memory_pressure(objects: List[MemoryObject], pressure: float,
                           target_pressure: float = 0.70) -> DegradationReport:
    """
    No-OOM degradation policy:
    1. Preserve exact objects (they cannot degrade)
    2. Coarsen approximate objects
    3. Degrade lowest-priority approximate field first
    4. Log all fidelity loss
    5. Refuse degradation if object is exact/security-critical
    """
    report = DegradationReport(
        pressure_before=pressure,
        pressure_after=pressure,
        target_pressure=target_pressure,
    )

    # Separate exact and approximate objects
    for obj in objects:
        if isinstance(obj, ExactObject):
            report.add(DegradationAction(
                object_id=obj.object_id,
                object_type="exact",
                action="preserved",
            ))
        else:
            if not obj.can_degrade:
                report.add(DegradationAction(
                    object_id=obj.field_id,
                    object_type="approx",
                    action="protected",
                ))

    # Sort approximate objects by priority (ascending) and memory size (descending)
    approx = [o for o in objects if isinstance(o, ApproxField) and o.can_degrade]
    approx.sort(key=lambda o: (o.priority, -o.memory_size_bytes))

    current_pressure = pressure
    for obj in approx:
        if current_pressure <= target_pressure:
            break
        if not obj.can_coarsen:
            continue
        old_fidelity = obj.fidelity_level
        saved = obj.coarsen()
        if saved > 0:
            current_pressure -= saved / 1_000_000  # Assume 1MB total for demo
            current_pressure = max(current_pressure, target_pressure)
            report.add(DegradationAction(
                object_id=obj.field_id,
                object_type="approx",
                action="coarsened",
                old_fidelity=old_fidelity,
                new_fidelity=obj.fidelity_level,
                memory_saved=saved,
            ))

    report.pressure_after = current_pressure
    return report
