from dataclasses import dataclass, field
from typing import Optional
from core.provenance import ProvenanceChain
import hashlib


@dataclass
class ExactObject:
    """Memory object that must NEVER be degraded or approximated."""
    object_id: str
    bytes_data: bytes
    integrity_hash: str
    provenance: ProvenanceChain
    can_degrade: bool = False
    priority: int = 0  # Higher = more important
    memory_size_bytes: int = 0

    def __post_init__(self):
        if self.memory_size_bytes == 0:
            self.memory_size_bytes = len(self.bytes_data)

    def verify_integrity(self) -> bool:
        current = hashlib.sha256(self.bytes_data).hexdigest()
        return current == self.integrity_hash

    def __repr__(self):
        return f"ExactObject(id={self.object_id}, size={self.memory_size_bytes}, degradable={self.can_degrade})"
