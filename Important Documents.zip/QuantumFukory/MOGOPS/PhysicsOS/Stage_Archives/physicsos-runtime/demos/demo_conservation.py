#!/usr/bin/env python3
"""
Demo: Conservation Law Debugger

Validates energy conservation with uncertainty-aware tolerance checking.
Catches real conservation violations while allowing boundary losses.
"""

from demo_imports import setup_path
setup_path()

from core.typed_value import TypedValue
from core.uncertainty import Uncertainty
from core.domain import Domain
from core.units import JOULE
from core.provenance import ProvenanceChain


def check_conservation(label, energy_before, energy_after, boundary_loss, tolerance):
    """Check conservation law and print result."""
    diff = abs(energy_before - energy_after - boundary_loss)
    conserved = diff <= tolerance

    print(f"  {label}")
    print(f"    Energy before:  {energy_before:.1f} J")
    print(f"    Energy after:   {energy_after:.1f} J")
    print(f"    Boundary loss:  {boundary_loss:.1f} J")
    print(f"    Tolerance:      {tolerance:.1f} J")
    print(f"    |Δ - loss|:     {diff:.1f} J")
    print(f"    Conserved:      {conserved}")
    if not conserved:
        unexplained = diff
        print(f"    *** CONSERVATION VIOLATION: {unexplained:.1f} J unexplained ***")
    print(f"    Status:         {'PASS' if conserved else 'FAIL'}")
    print()
    return conserved


def main():
    sep = "=" * 60
    print(sep)
    print("Demo: Conservation Law Debugger")
    print(sep)
    print()

    print("PhysicsOS conservation law: energy_before = energy_after + boundary_loss ± tolerance")
    print()

    # --- Valid case: small numerical drift within tolerance ---
    print("1) Valid case: numerical drift within tolerance")
    ok1 = check_conservation(
        label="Case 1: energy_before=100, energy_after=98, boundary_loss=2, tolerance=0.1",
        energy_before=100.0,
        energy_after=98.0,
        boundary_loss=2.0,
        tolerance=0.1,
    )

    # --- Invalid case: unexplained energy loss ---
    print("2) Invalid case: unexplained energy loss")
    ok2 = check_conservation(
        label="Case 2: energy_before=100, energy_after=91, boundary_loss=2, tolerance=0.1",
        energy_before=100.0,
        energy_after=91.0,
        boundary_loss=2.0,
        tolerance=0.1,
    )

    # --- TypedValue version with units ---
    print("3) TypedValue version with joule units:")
    before_tv = TypedValue(
        value=100.0,
        uncertainty=Uncertainty(lower=99.9, upper=100.1, confidence=0.99),
        domain=Domain.PHYSICS_NUMERIC,
        provenance=ProvenanceChain(source="energy_measurement"),
        units=JOULE,
    )
    after_tv = TypedValue(
        value=98.0,
        uncertainty=Uncertainty(lower=97.9, upper=98.1, confidence=0.99),
        domain=Domain.PHYSICS_NUMERIC,
        provenance=ProvenanceChain(source="energy_measurement"),
        units=JOULE,
    )
    loss_tv = TypedValue(
        value=2.0,
        uncertainty=Uncertainty(lower=1.95, upper=2.05, confidence=0.99),
        domain=Domain.PHYSICS_NUMERIC,
        provenance=ProvenanceChain(source="boundary_measurement"),
        units=JOULE,
    )
    print(f"   Energy before: {before_tv.value} {before_tv.units}")
    print(f"   Energy after:  {after_tv.value} {after_tv.units}")
    print(f"   Boundary loss: {loss_tv.value} {loss_tv.units}")
    diff = abs(before_tv.value - after_tv.value - loss_tv.value)
    print(f"   |Δ - loss|:    {diff:.1f} J")
    print(f"   All values carry joule units → dimensional consistency ✓")
    print(f"   All values carry uncertainty → measurement confidence tracked ✓")
    print()

    # --- Summary ---
    print("-" * 60)
    print("Summary:")
    if ok1:
        print("  PASS: Valid conservation case accepted (drift within tolerance)")
    else:
        print("  FAIL: Valid conservation case incorrectly rejected")
    if not ok2:
        print("  PASS: Conservation violation detected (7.0 J unexplained)")
    else:
        print("  FAIL: Conservation violation not detected")
    print("  - TypedValue with joule units ensures dimensional consistency")
    print("  - Uncertainty intervals enable tolerance-aware checking")
    print("-" * 60)


if __name__ == "__main__":
    main()
