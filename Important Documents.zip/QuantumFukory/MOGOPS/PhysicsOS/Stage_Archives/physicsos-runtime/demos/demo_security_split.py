#!/usr/bin/env python3
"""
Demo 5 & 6: Exact Security + Approximate Science Planes

Shows that approximate values cannot authorize security decisions, while
exact values can. Also shows the approximate science gate accepting values
within policy.
"""

from demo_imports import setup_path
setup_path()

from core.typed_value import TypedValue, BackendInfo
from core.uncertainty import Uncertainty
from core.domain import Domain
from core.provenance import ProvenanceChain
from policy.exact_security_gate import exact_security_gate
from policy.approximate_science_gate import approximate_science_gate, ApproximationPolicy


def main():
    sep = "=" * 60
    print(sep)
    print("Demo 5 & 6: Exact Security + Approximate Science Planes")
    print(sep)
    print()

    # --- Case 1: Approximate sensor value tries to authorize login ---
    print("1) Approximate sensor value attempts to authorize login:")
    sensor_val = TypedValue(
        value=42.0,
        uncertainty=Uncertainty(lower=41.5, upper=42.5, confidence=0.90,
                                measurement=0.5, hardware=0.1),
        domain=Domain.SENSOR_DATA,
        provenance=ProvenanceChain(source="thermocouple"),
        backend=BackendInfo.simulated_analog(),
    )
    result1 = exact_security_gate(sensor_val, "user_login")
    print(f"   Domain:              {sensor_val.domain.value}")
    print(f"   Backend exact:       {sensor_val.backend.is_exact}")
    print(f"   Security uncertainty:{sensor_val.uncertainty.security}")
    print(f"   Decision:            {result1.decision.value}")
    print(f"   Reason:              {result1.reason}")
    status1 = "PASS" if result1.decision.value == "deny" else "FAIL"
    print(f"   Status:              {status1}")
    print()

    # --- Case 2: Exact security value authorizes login ---
    print("2) Exact security value authorizes login:")
    auth_token = TypedValue(
        value=1,
        uncertainty=Uncertainty(lower=1, upper=1, confidence=1.0, security=0.0),
        domain=Domain.SECURITY_AUTHORITY,
        provenance=ProvenanceChain(source="auth_service"),
        backend=BackendInfo(backend_id="auth_cpu", backend_type="cpu",
                            is_exact=True),
    )
    result2 = exact_security_gate(auth_token, "user_login")
    print(f"   Domain:              {auth_token.domain.value}")
    print(f"   Backend exact:       {auth_token.backend.is_exact}")
    print(f"   Security uncertainty:{auth_token.uncertainty.security}")
    print(f"   Decision:            {result2.decision.value}")
    print(f"   Reason:              {result2.reason}")
    status2 = "PASS" if result2.decision.value == "allow" else "FAIL"
    print(f"   Status:              {status2}")
    print()

    # --- Case 3: Approximate science gate accepts within-policy value ---
    print("3) Approximate Science Gate accepts sensor reading:")
    science_val = TypedValue(
        value=293.15,
        uncertainty=Uncertainty(lower=293.0, upper=293.3, confidence=0.95,
                                measurement=0.15, hardware=0.02),
        domain=Domain.SENSOR_DATA,
        provenance=ProvenanceChain(source="thermometer"),
        backend=BackendInfo.simulated_analog(),
    )
    policy = ApproximationPolicy(max_uncertainty=0.2, min_confidence=0.5)
    result3 = approximate_science_gate(science_val, policy)
    print(f"   Total uncertainty:   {science_val.uncertainty.total():.6f}")
    print(f"   Policy max:          {policy.max_uncertainty}")
    print(f"   Confidence:          {science_val.uncertainty.confidence}")
    print(f"   Accepted:            {result3.accepted}")
    print(f"   Reason:              {result3.reason}")
    status3 = "PASS" if result3.accepted else "FAIL"
    print(f"   Status:              {status3}")
    print()

    # --- Summary ---
    print("-" * 60)
    print("Summary:")
    print("  - Approximate sensor data DENIED at security gate  ✓")
    print("  - Exact auth value ALLOWED at security gate         ✓")
    print("  - Approximate sensor data ACCEPTED at science gate  ✓")
    print("  - Two-plane architecture separates security from science")
    print("-" * 60)


if __name__ == "__main__":
    main()
