#!/usr/bin/env python3
"""
Demo 10: Xi Efficiency Report

Computes and displays the Xi efficiency metric, which measures the ratio
of useful work to total work including all overhead categories.
"""

from demo_imports import setup_path
setup_path()

from metrics.xi_metric import (
    OverheadMetrics, compute_xi, format_xi_report, XiReport,
)


def main():
    sep = "=" * 60
    print(sep)
    print("Demo 10: Xi Efficiency Report")
    print(sep)
    print()

    print("Xi = W_useful / (W_useful + O_control + O_memory + O_error "
          "+ O_calibration + O_translation)")
    print()

    # --- Create metrics ---
    metrics = OverheadMetrics(
        useful_work=1000.0,
        control_overhead=42.0,
        memory_overhead=81.0,
        error_overhead=19.0,
        calibration_overhead=12.0,
        translation_overhead=7.0,
    )

    print("1) Input metrics:")
    print(f"   Useful work:          {metrics.useful_work:>10.2f} units")
    print(f"   Control overhead:     {metrics.control_overhead:>10.2f}")
    print(f"   Memory overhead:      {metrics.memory_overhead:>10.2f}")
    print(f"   Error overhead:       {metrics.error_overhead:>10.2f}")
    print(f"   Calibration overhead: {metrics.calibration_overhead:>10.2f}")
    print(f"   Translation overhead: {metrics.translation_overhead:>10.2f}")
    print()

    # --- Compute Xi ---
    xi = compute_xi(metrics)
    total_overhead = (metrics.control_overhead + metrics.memory_overhead
                      + metrics.error_overhead + metrics.calibration_overhead
                      + metrics.translation_overhead)

    print("2) Xi calculation:")
    print(f"   Total overhead:       {total_overhead:>10.2f}")
    print(f"   Total work:           {metrics.useful_work + total_overhead:>10.2f}")
    print(f"   Xi = {metrics.useful_work:.2f} / "
          f"({metrics.useful_work:.2f} + {total_overhead:.2f})")
    print(f"   Xi = {xi:.6f}")
    print()

    # --- Generate report ---
    report = XiReport.from_metrics(metrics)
    print("3) Full Xi Report:")
    print()
    print(format_xi_report(report))
    print()

    # --- Verdict ---
    print("-" * 60)
    # Xi > 0.80 means the system is spending most time on useful work
    if xi >= 0.80:
        print(f"PASS: Xi = {xi:.4f} — system is efficient "
              f"({xi * 100:.1f}% useful work)")
    elif xi >= 0.50:
        print(f"WARN: Xi = {xi:.4f} — moderate overhead "
              f"({xi * 100:.1f}% useful work)")
    else:
        print(f"FAIL: Xi = {xi:.4f} — excessive overhead "
              f"({xi * 100:.1f}% useful work)")
    print("-" * 60)


if __name__ == "__main__":
    main()
