"""Shared import setup for all PhysicsOS demo scripts.

Usage at the top of every demo file:
    from demo_imports import setup_path
    setup_path()
    # ... then import from core, policy, memory, backend, replay, metrics ...
"""

import sys
import os
import types
import importlib

_initialized = False


def setup_path():
    """Set up sys.path and package aliases so all PhysicsOS sub-packages
    import correctly, including those that use double-dot relative imports
    (e.g. ``from ..core.domain import Domain`` in the policy package)."""
    global _initialized
    if _initialized:
        return

    PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    pkg_name = "__physicsos__"

    # Register the project root as a parent package so that ``from ..core``
    # style relative imports resolve correctly.
    pkg = types.ModuleType(pkg_name)
    pkg.__path__ = [PROJECT_ROOT]
    pkg.__package__ = pkg_name
    pkg.__file__ = os.path.join(PROJECT_ROOT, "__init__.py")
    sys.modules[pkg_name] = pkg

    # Import every sub-package through the parent so relative imports
    # inside policy/, memory/, etc. can find ``..core``.
    for sub in ("core", "policy", "memory", "backend", "replay", "metrics"):
        importlib.import_module(f"{pkg_name}.{sub}")
        sys.modules[sub] = sys.modules[f"{pkg_name}.{sub}"]

    _initialized = True
