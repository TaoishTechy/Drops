#!/usr/bin/env python3
"""
Demo 2 & 3: Typed Zero Boundary Checking

Shows untyped zero rejection and typed zero acceptance at various
trust-boundary domains.
"""

from demo_imports import setup_path
setup_path()

from core.typed_value import TypedValue
from core.uncertainty import Uncertainty
from core.domain import Domain
from core.typed_zero import ZeroType
from core.provenance import ProvenanceChain
from policy.zero_policy import check_zero_at_boundary


def check(label, value, target):
    """Run a boundary check and print the result."""
    result = check_zero_at_boundary(value, target)
    status = "PASS" if result.allowed else "REJECTED"
    print(f"  [{status:^10s}] {label}")
    print(f"              zero_type={value.zero_type.value if value.zero_type else 'None'}, "
          f"domain={target.value}")
    print(f"              reason: {result.reason}")
    print()


def main():
    sep = "=" * 60
    print(sep)
    print("Demo 2 & 3: Typed Zero Boundary Checking")
    print(sep)
    print()

    # --- Case 1: Untyped zero rejected at PHYSICS_NUMERIC ---
    print("1) Untyped zero at PHYSICS_NUMERIC boundary:")
    untyped = TypedValue(
        value=0.0,
        uncertainty=Uncertainty.exact(0.0),
        domain=Domain.PHYSICS_NUMERIC,
        provenance=ProvenanceChain(source="untyped_zero"),
        zero_type=None,
    )
    check("UNTYPED_ZERO in PHYSICS_NUMERIC", untyped, Domain.PHYSICS_NUMERIC)

    # --- Case 2: MEASURED_ABSENCE accepted at SENSOR_DATA ---
    print("2) MEASURED_ABSENCE at SENSOR_DATA boundary:")
    measured = TypedValue(
        value=0.0,
        uncertainty=Uncertainty.exact(0.0),
        domain=Domain.SENSOR_DATA,
        provenance=ProvenanceChain(source="sensor"),
        zero_type=ZeroType.MEASURED_ABSENCE,
    )
    check("MEASURED_ABSENCE in SENSOR_DATA", measured, Domain.SENSOR_DATA)

    # --- Case 3: EXACT_SYMBOLIC_ZERO accepted at FORMAL_PROOF ---
    print("3) EXACT_SYMBOLIC_ZERO at FORMAL_PROOF boundary:")
    symbolic = TypedValue(
        value=0.0,
        uncertainty=Uncertainty.exact(0.0),
        domain=Domain.FORMAL_PROOF,
        provenance=ProvenanceChain(source="symbolic"),
        zero_type=ZeroType.EXACT_SYMBOLIC_ZERO,
    )
    check("EXACT_SYMBOLIC_ZERO in FORMAL_PROOF", symbolic, Domain.FORMAL_PROOF)

    # --- Case 4: NULL_CAPABILITY accepted at SECURITY_AUTHORITY ---
    print("4) NULL_CAPABILITY at SECURITY_AUTHORITY boundary:")
    null_cap = TypedValue(
        value=0.0,
        uncertainty=Uncertainty.exact(0.0),
        domain=Domain.SECURITY_AUTHORITY,
        provenance=ProvenanceChain(source="security"),
        zero_type=ZeroType.NULL_CAPABILITY,
    )
    check("NULL_CAPABILITY in SECURITY_AUTHORITY", null_cap, Domain.SECURITY_AUTHORITY)

    # --- Case 5: COMPUTATIONAL_OPERAND_ZERO rejected at SECURITY_AUTHORITY ---
    print("5) COMPUTATIONAL_OPERAND_ZERO at SECURITY_AUTHORITY boundary:")
    comp_zero = TypedValue(
        value=0.0,
        uncertainty=Uncertainty.exact(0.0),
        domain=Domain.SECURITY_AUTHORITY,
        provenance=ProvenanceChain(source="computation"),
        zero_type=ZeroType.COMPUTATIONAL_OPERAND_ZERO,
    )
    check("COMPUTATIONAL_OPERAND_ZERO in SECURITY_AUTHORITY", comp_zero,
          Domain.SECURITY_AUTHORITY)

    # --- Summary ---
    print("-" * 60)
    print("Summary:")
    print("  - UNTYPED_ZERO rejected everywhere (security by default)")
    print("  - MEASURED_ABSENCE accepted at SENSOR_DATA (physical meaning)")
    print("  - EXACT_SYMBOLIC_ZERO accepted at FORMAL_PROOF (math meaning)")
    print("  - NULL_CAPABILITY accepted at SECURITY_AUTHORITY (auth meaning)")
    print("  - COMPUTATIONAL_OPERAND_ZERO rejected at SECURITY_AUTHORITY")
    print("-" * 60)


if __name__ == "__main__":
    main()
