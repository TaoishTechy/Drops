#!/usr/bin/env python3
"""
Demo 1: Contextual Equality

Shows that raw float 0.1 + 0.2 == 0.3 is False, but PhysicsOS contextual
equality returns True with confidence by using interval arithmetic.
"""

from demo_imports import setup_path
setup_path()

from core.typed_value import TypedValue
from core.uncertainty import Uncertainty
from core.domain import Domain
from core.provenance import ProvenanceChain


def main():
    sep = "=" * 60
    print(sep)
    print("Demo 1: Contextual Equality")
    print(sep)
    print()

    # --- Raw float comparison (the classic gotcha) ---
    print("1) Raw float comparison:")
    print(f"   0.1 + 0.2       = {0.1 + 0.2}")
    print(f"   0.3             = {0.3}")
    print(f"   0.1 + 0.2 == 0.3  =>  {0.1 + 0.2 == 0.3}")
    print(f"   Result: FAIL — IEEE 754 rounding makes this False")
    print()

    # --- Build PhysicsOS TypedValues with interval uncertainty ---
    # Use Uncertainty.from_point with typical floating-point half-widths
    # so the intervals overlap, demonstrating contextual equality.
    sum_unc = Uncertainty.from_point(0.1 + 0.2, half_width=0.001, confidence=0.99)
    sum_val = TypedValue(
        value=0.1 + 0.2,
        uncertainty=sum_unc,
        domain=Domain.PHYSICS_NUMERIC,
        provenance=ProvenanceChain(source="float_add"),
    )

    ref_unc = Uncertainty.from_point(0.3, half_width=0.001, confidence=0.99)
    ref_val = TypedValue(
        value=0.3,
        uncertainty=ref_unc,
        domain=Domain.PHYSICS_NUMERIC,
        provenance=ProvenanceChain(source="float_literal"),
    )

    print("2) PhysicsOS interval representation:")
    print(f"   0.1+0.2 interval: [{sum_unc.lower}, {sum_unc.upper}]  width={sum_unc.width}")
    print(f"   0.3   interval:    [{ref_unc.lower}, {ref_unc.upper}]  width={ref_unc.width}")
    print()

    # --- Check interval overlap ---
    print("3) Interval overlap analysis:")
    overlaps = sum_unc.overlaps(ref_unc)
    print(f"   Intervals overlap:   {overlaps}")
    overlap_frac = sum_unc.overlap_fraction(ref_unc)
    print(f"   Overlap fraction:    {overlap_frac:.4f}")
    print()

    # --- Contextual equality decision ---
    CONFIDENCE_THRESHOLD = 0.5
    contextual_eq = overlaps and overlap_frac >= CONFIDENCE_THRESHOLD
    print("4) PhysicsOS contextual equality:")
    print(f"   Threshold:          overlap_fraction >= {CONFIDENCE_THRESHOLD}")
    print(f"   overlap_fraction:   {overlap_frac:.4f}")
    print(f"   Contextual equal:   {contextual_eq}")
    print(f"   Confidence score:   {overlap_frac:.4f} ({overlap_frac * 100:.1f}%)")
    print()

    # --- Verdict ---
    print("-" * 60)
    if contextual_eq:
        print("PASS: PhysicsOS contextual equality returns TRUE with "
              f"confidence {overlap_frac:.4f} ({overlap_frac * 100:.1f}%)")
        print("       Raw float equality returns False — PhysicsOS fixes this.")
    else:
        print("FAIL: Intervals did not overlap sufficiently")
    print("-" * 60)


if __name__ == "__main__":
    main()
