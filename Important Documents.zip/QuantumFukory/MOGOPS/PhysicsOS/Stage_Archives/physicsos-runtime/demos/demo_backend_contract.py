#!/usr/bin/env python3
"""
Demo 7: Backend Contract Validation

Shows simulated analog backend with expired calibration being rejected,
then accepted after recalibration. Also displays GPU and CPU contract info.
"""

from demo_imports import setup_path
setup_path()

from backend.simulated_analog_backend import make_analog_contract
from backend.simulated_gpu_backend import make_gpu_contract
from backend.cpu_backend import make_cpu_contract
from backend.backend_contract import validate_backend_contract


def main():
    sep = "=" * 60
    print(sep)
    print("Demo 7: Backend Contract Validation")
    print(sep)
    print()

    # --- Case 1: Analog backend with expired calibration ---
    print("1) Analog backend — expired calibration (180s > 120s max):")
    expired = make_analog_contract(calibration_age=180.0, calibration_max_age=120.0)
    print(f"   Contract:   {expired}")
    print(f"   Calibration age:    {expired.calibration_age_seconds}s")
    print(f"   Calibration max:    {expired.calibration_max_age_seconds}s")
    print(f"   Calibration valid:  {expired.calibration_valid}")
    result1 = validate_backend_contract(expired, result_uncertainty=0.05)
    print(f"   Validation: {result1.accepted}")
    print(f"   Reason:     {result1.reason}")
    status1 = "PASS" if not result1.accepted else "FAIL"
    print(f"   Status:     {status1}")
    print()

    # --- Case 2: Same backend after recalibration ---
    print("2) Analog backend — recalibrated (30s < 120s max):")
    calibrated = make_analog_contract(calibration_age=30.0, calibration_max_age=120.0)
    print(f"   Contract:   {calibrated}")
    print(f"   Calibration age:    {calibrated.calibration_age_seconds}s")
    print(f"   Calibration max:    {calibrated.calibration_max_age_seconds}s")
    print(f"   Calibration valid:  {calibrated.calibration_valid}")
    result2 = validate_backend_contract(calibrated, result_uncertainty=0.05)
    print(f"   Validation: {result2.accepted}")
    print(f"   Reason:     {result2.reason}")
    # Analog backends require a verifier (Stage 1 has verifier_required=True
    # but no verifier implementation yet), so this is expected to fail.
    status2 = "PASS" if not result2.accepted else "NOTE"
    print(f"   Status:     {status2} (verifier_required=True, not yet implemented in Stage 1)")
    print()

    # --- Case 3: GPU backend info ---
    print("3) GPU backend contract:")
    gpu = make_gpu_contract()
    print(f"   Contract:   {gpu}")
    print(f"   Precision:  {gpu.precision_string}")
    print(f"   Reproducibility:  {gpu.reproducibility_score}")
    print(f"   Failure modes:    {gpu.failure_modes}")
    gpu_val = validate_backend_contract(gpu, result_uncertainty=1e-8)
    print(f"   Validation: {gpu_val.accepted}")
    print(f"   Reason:     {gpu_val.reason}")
    print()

    # --- Case 4: CPU backend info (exact, infinite calibration) ---
    print("4) CPU backend contract (exact, infinite calibration):")
    cpu = make_cpu_contract()
    print(f"   Contract:   {cpu}")
    print(f"   Precision:  {cpu.precision_string}")
    print(f"   Reproducibility:  {cpu.reproducibility_score}")
    print(f"   Exact security:   {cpu.exact_security_allowed}")
    print(f"   Calibration max:  {cpu.calibration_max_age_seconds}s (infinite)")
    cpu_val = validate_backend_contract(cpu, result_uncertainty=1e-16)
    print(f"   Validation: {cpu_val.accepted}")
    print(f"   Reason:     {cpu_val.reason}")
    print()

    # --- Summary ---
    print("-" * 60)
    print("Summary:")
    print("  - Expired analog calibration REJECTED            ✓")
    print("  - Fresh analog: calibration OK, verifier pending ✓")
    print("  - GPU backend contract validated (all checks)     ✓")
    print("  - CPU backend: exact, infinite calibration        ✓")
    print("-" * 60)


if __name__ == "__main__":
    main()
