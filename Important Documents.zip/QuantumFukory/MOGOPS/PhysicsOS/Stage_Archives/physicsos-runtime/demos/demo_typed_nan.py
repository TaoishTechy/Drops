#!/usr/bin/env python3
"""
Demo 4: Typed NaN Division Recovery

Shows that division by a forbidden (untyped) zero returns a typed
NaN_DOMAIN value with a recovery policy, while division by an allowed
typed zero at FORMAL_PROOF returns a DIVERGENT NaN.
"""

from demo_imports import setup_path
setup_path()

from core.typed_value import TypedValue, physics_divide
from core.uncertainty import Uncertainty
from core.domain import Domain
from core.typed_zero import ZeroType
from core.typed_nan import NaNType, nan_description, nan_recovery_policy
from core.provenance import ProvenanceChain
from policy.nan_policy import nan_info


def main():
    sep = "=" * 60
    print(sep)
    print("Demo 4: Typed NaN Division Recovery")
    print(sep)
    print()

    # --- Case 1: Division by untyped zero → NaN_DOMAIN ---
    print("1) TypedValue(10) / TypedValue(0, zero_type=UNTYPED_ZERO)")
    numerator = TypedValue(
        value=10.0,
        uncertainty=Uncertainty.exact(10.0),
        domain=Domain.PHYSICS_NUMERIC,
        provenance=ProvenanceChain(source="literal"),
    )
    untyped_zero = TypedValue(
        value=0.0,
        uncertainty=Uncertainty.exact(0.0),
        domain=Domain.PHYSICS_NUMERIC,
        provenance=ProvenanceChain(source="computation"),
        zero_type=ZeroType.UNTYPED_ZERO,
    )
    result1 = physics_divide(numerator, untyped_zero)
    print(f"   Result is NaN: {result1.is_nan()}")
    info1 = nan_info(result1)
    print(f"   NaN type:        {info1['nan_type']}")
    print(f"   Description:     {info1['description']}")
    print(f"   Recovery policy: {info1['recovery_policy']}")
    print(f"   Domain:          {info1['domain']}")
    status1 = "PASS" if result1.is_nan() and result1.nan_type == NaNType.DOMAIN else "FAIL"
    print(f"   Status:          {status1}")
    print()

    # --- Case 2: Division by EXACT_SYMBOLIC_ZERO at FORMAL_PROOF → NaN_DIVERGENT ---
    print("2) TypedValue(10) / TypedValue(0, zero_type=EXACT_SYMBOLIC_ZERO) "
          "at FORMAL_PROOF")
    symbolic_zero = TypedValue(
        value=0.0,
        uncertainty=Uncertainty.exact(0.0),
        domain=Domain.FORMAL_PROOF,
        provenance=ProvenanceChain(source="symbolic"),
        zero_type=ZeroType.EXACT_SYMBOLIC_ZERO,
    )
    result2 = physics_divide(numerator.with_domain(Domain.FORMAL_PROOF), symbolic_zero)
    print(f"   Result is NaN: {result2.is_nan()}")
    info2 = nan_info(result2)
    print(f"   NaN type:        {info2['nan_type']}")
    print(f"   Description:     {info2['description']}")
    print(f"   Recovery policy: {info2['recovery_policy']}")
    print(f"   Domain:          {info2['domain']}")
    print(f"   Note: EXACT_SYMBOLIC_ZERO is allowed at FORMAL_PROOF, but "
          f"division by zero still diverges.")
    status2 = "PASS" if result2.is_nan() and result2.nan_type == NaNType.DIVERGENT else "FAIL"
    print(f"   Status:          {status2}")
    print()

    # --- Summary ---
    print("-" * 60)
    print("Summary:")
    print("  - Untyped zero → NaN_DOMAIN (operation forbidden)")
    print("  - Symbolic zero at FORMAL_PROOF → NaN_DIVERGENT (zero allowed, "
          "but division diverges)")
    print("  - Each NaN carries recovery policy for graceful handling")
    print("-" * 60)


if __name__ == "__main__":
    main()
