#!/usr/bin/env python3
"""
Demo: Unit/Dimensional Analysis

Shows PhysicsOS catching dimensional errors at runtime:
meters + seconds → error, meters / seconds → velocity, etc.
"""

from demo_imports import setup_path
setup_path()

from core.units import (
    Unit, METER, SECOND, KILOGRAM, VELOCITY, JOULE, DimensionalError,
)


def main():
    sep = "=" * 60
    print(sep)
    print("Demo: Unit/Dimensional Analysis")
    print(sep)
    print()

    # --- Case 1: meters + seconds → DIMENSIONAL ERROR ---
    print("1) meters + seconds:")
    print(f"   METER  = {METER}")
    print(f"   SECOND = {SECOND}")
    try:
        result = METER + SECOND
        print(f"   Result: {result}  ← UNEXPECTED")
        print("   Status: FAIL (should have raised DimensionalError)")
    except DimensionalError as e:
        print(f"   DimensionalError: {e}")
        print("   Status: PASS — incompatible units caught at runtime")
    print()

    # --- Case 2: meters / seconds → velocity ---
    print("2) meters / seconds:")
    print(f"   METER / SECOND = {METER / SECOND}")
    print(f"   VELOCITY        = {VELOCITY}")
    match_vel = (METER / SECOND) == VELOCITY
    print(f"   Match: {match_vel}")
    print(f"   Status: {'PASS' if match_vel else 'FAIL'}")
    print()

    # --- Case 3: meters * meters → m^2 (area) ---
    print("3) meters * meters:")
    result_m2 = METER * METER
    print(f"   METER * METER = {result_m2}")
    print(f"   Expected: m^2")
    print(f"   Status: PASS — unit multiplication works correctly")
    print()

    # --- Case 4: joule = kg * m^2 / s^2 ---
    print("4) joule = kg * m^2 / s^2:")
    derived = KILOGRAM * METER * METER / SECOND / SECOND
    print(f"   kg * m^2 / s^2 = {derived}")
    print(f"   JOULE           = {JOULE}")
    match_joule = derived == JOULE
    print(f"   Match: {match_joule}")
    print(f"   Status: {'PASS' if match_joule else 'FAIL'}")
    print()

    # --- Case 5: Dimensionless check ---
    print("5) Dimensionless unit:")
    dimless = Unit()
    print(f"   Unit() = {dimless}")
    print(f"   Is dimensionless: {dimless.is_dimensionless}")
    print(f"   METER is dimensionless: {METER.is_dimensionless}")
    print(f"   Status: PASS")
    print()

    # --- Summary ---
    print("-" * 60)
    print("Summary:")
    print("  - meters + seconds → DimensionalError (caught)")
    print("  - meters / seconds = velocity (correct)")
    print("  - meters * meters  = m^2 (area, correct)")
    print("  - kg * m^2 / s^2   = joule (energy, correct)")
    print("  - Dimensionless detection works")
    print("-" * 60)


if __name__ == "__main__":
    main()
