#!/usr/bin/env python3
"""
Demo 9: Deterministic Replay with Uncertainty

Uses the DeterministicRunner to run a simulated analog computation,
record the event, and replay it to verify decisions match.
"""

from demo_imports import setup_path
setup_path()

from core.typed_value import TypedValue, BackendInfo
from core.uncertainty import Uncertainty
from core.domain import Domain
from core.provenance import ProvenanceChain
from backend.simulated_analog_backend import make_analog_contract, analog_compute
from replay.replay_log import ReplayLog
from replay.deterministic_runner import DeterministicRunner


def main():
    sep = "=" * 60
    print(sep)
    print("Demo 9: Deterministic Replay with Uncertainty")
    print(sep)
    print()

    # --- Setup ---
    contract = make_analog_contract(calibration_age=30.0)
    log = ReplayLog("analog_replay_demo")
    runner = DeterministicRunner(replay_log=log)

    print("1) Recording a simulated analog computation:")
    print(f"   Contract:   {contract}")
    print()

    # --- Record an analog computation ---
    input_value = 42.0
    print(f"   Input:      {input_value}")

    outputs = runner.run_and_record(
        "analog_compute_42",
        analog_compute,
        input_value,
        backend_snapshot={
            "backend_id": contract.backend_id,
            "backend_type": contract.backend_type,
            "calibration_age": contract.calibration_age_seconds,
            "precision_range": contract.precision_range,
        },
    )
    recorded_result = outputs[0]
    print(f"   Output:     {recorded_result}")
    print(f"   Events in log: {len(log)}")
    print()

    # --- Replay the same computation ---
    print("2) Replaying the computation:")
    matches, replay_outputs, original_outputs = runner.replay(
        "analog_compute_42",
        analog_compute,
        input_value,
    )
    replay_result = replay_outputs[0]
    print(f"   Replay output:  {replay_result}")
    print(f"   Original output: {original_outputs[0]}")
    print()

    # --- Compare ---
    print("3) Comparison:")
    if matches:
        print("   PASS: Replay output matches recorded output")
    else:
        print(f"   NOTE: Outputs differ (expected for analog backends)")
        print(f"         Recorded:  {original_outputs[0]}")
        print(f"         Replay:    {replay_result}")
        print(f"         Difference: {abs(replay_result - original_outputs[0]):.6e}")
        print(f"         This demonstrates why analog backends need")
        print(f"         verifier_required=True in their contracts.")
    print()

    # --- Show replay log ---
    print("4) Replay log summary:")
    print(f"   Log ID:       {log.log_id}")
    print(f"   Total events: {len(log)}")
    if log.events:
        e = log.events[0]
        print(f"   Event 0:")
        print(f"     event_id:   {e.event_id}")
        print(f"     operation:  {e.operation}")
        print(f"     inputs:     {e.inputs}")
        print(f"     outputs:    {e.outputs}")
    print()

    print("-" * 60)
    print("PASS: Deterministic replay system operational")
    print("  - Analog backend results recorded with full context")
    print("  - Replay mechanism verifies computation reproducibility")
    print("-" * 60)


if __name__ == "__main__":
    main()
