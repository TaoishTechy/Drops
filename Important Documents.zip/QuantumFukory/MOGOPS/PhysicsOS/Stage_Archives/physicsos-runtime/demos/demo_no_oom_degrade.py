#!/usr/bin/env python3
"""
Demo 8: No-OOM Approximation Degradation

Under memory pressure, exact objects are preserved while approximate
fields are coarsened to free memory.
"""

from demo_imports import setup_path
setup_path()

import hashlib
from memory.exact_object import ExactObject
from memory.approximate_field import ApproxField
from memory.no_oom_degrader import handle_memory_pressure
from core.uncertainty import Uncertainty
from core.provenance import ProvenanceChain


def main():
    sep = "=" * 60
    print(sep)
    print("Demo 8: No-OOM Approximation Degradation")
    print(sep)
    print()

    # --- Create exact objects (must never be degraded) ---
    tax_data = b"tax_records_pdf_binary_data"
    tax_obj = ExactObject(
        object_id="tax_records.pdf",
        bytes_data=tax_data,
        integrity_hash=hashlib.sha256(tax_data).hexdigest(),
        provenance=ProvenanceChain(source="filesystem"),
        priority=10,
    )
    print(f"1) ExactObject: {tax_obj}")
    print(f"   Integrity valid: {tax_obj.verify_integrity()}")
    print()

    auth_data = b"super_secret_auth_token_12345"
    auth_obj = ExactObject(
        object_id="auth_token",
        bytes_data=auth_data,
        integrity_hash=hashlib.sha256(auth_data).hexdigest(),
        provenance=ProvenanceChain(source="security"),
        priority=10,
    )
    print(f"2) ExactObject: {auth_obj}")
    print(f"   Integrity valid: {auth_obj.verify_integrity()}")
    print()

    # --- Create approximate fields (can be coarsened) ---
    sim_field = ApproxField(
        field_id="simulation_grid",
        shape=(256, 256),
        basis="fourier",
        fidelity_level=10,
        uncertainty=Uncertainty(lower=0.0, upper=1.0, confidence=0.95),
        priority=2,
    )
    print(f"3) ApproxField: {sim_field}")
    print(f"   Memory size: {sim_field.memory_size_bytes} bytes")
    print(f"   Can coarsen: {sim_field.can_coarsen}")
    print()

    ml_field = ApproxField(
        field_id="ML_embedding_cache",
        shape=(128, 64),
        basis="neural",
        fidelity_level=8,
        uncertainty=Uncertainty(lower=0.0, upper=1.0, confidence=0.90),
        priority=1,
    )
    print(f"4) ApproxField: {ml_field}")
    print(f"   Memory size: {ml_field.memory_size_bytes} bytes")
    print(f"   Can coarsen: {ml_field.can_coarsen}")
    print()

    # --- Apply memory pressure ---
    print("5) Applying 92% memory pressure (target: 70%):")
    objects = [tax_obj, auth_obj, sim_field, ml_field]
    report = handle_memory_pressure(objects, pressure=0.92, target_pressure=0.70)
    print(report)
    print()

    # --- Verify exact objects untouched ---
    print("6) Post-degradation verification:")
    print(f"   tax_records.pdf integrity: {tax_obj.verify_integrity()}")
    print(f"   auth_token integrity:      {auth_obj.verify_integrity()}")
    print(f"   simulation_grid fidelity:  {sim_field.fidelity_level}")
    print(f"   ML_embedding_cache fidelity: {ml_field.fidelity_level}")
    print()

    # --- Verdict ---
    exact_ok = tax_obj.verify_integrity() and auth_obj.verify_integrity()
    approx_degraded = sim_field.fidelity_level < 10 or ml_field.fidelity_level < 8
    print("-" * 60)
    if exact_ok:
        print("PASS: All exact objects preserved with valid integrity")
    else:
        print("FAIL: Exact object integrity compromised")
    if approx_degraded:
        print("PASS: Approximate fields were coarsened to relieve pressure")
    else:
        print("NOTE: No coarsening needed (pressure already at target)")
    print("-" * 60)


if __name__ == "__main__":
    main()
