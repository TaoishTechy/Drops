"""
NaN Policy

Handle typed NaN values crossing domain boundaries.
Security-critical NaN types (UNAUTHORIZED) are always rejected.
Other NaN types follow their recovery policy.
"""

from dataclasses import dataclass
from typing import Optional

from core.domain import Domain
from core.typed_nan import NaNType, nan_recovery_policy, nan_description
from core.typed_value import TypedValue


@dataclass
class NaNHandling:
    """How to handle a NaN at a boundary."""
    allow_pass: bool
    recovery_policy: str
    reason: str


def handle_typed_nan(value: TypedValue, target_domain: Domain, allow_recovery: bool = True) -> TypedValue:
    """
    Handle a typed NaN crossing a boundary.

    Security-critical NaN types (UNAUTHORIZED) are always rejected.
    NaN values are always blocked at the SECURITY_AUTHORITY boundary.
    Other NaN types follow their recovery policy when allow_recovery=True.

    Parameters
    ----------
    value : TypedValue
        The value to handle (may or may not be NaN).
    target_domain : Domain
        The domain the value is crossing into.
    allow_recovery : bool
        If True, allow non-critical NaN types to pass through with
        recovery info attached. If False, reject all NaN types.

    Returns
    -------
    TypedValue
        The original value if not NaN, the original NaN if recovery is allowed,
        or a new typed NaN describing the rejection.
    """
    if not value.is_nan():
        return value

    if value.nan_type == NaNType.UNAUTHORIZED:
        return TypedValue.typed_nan(
            nan_type=NaNType.UNAUTHORIZED,
            reason=f"NaN_UNAUTHORIZED blocked at {target_domain.value}",
            domain=target_domain,
            provenance=value.provenance,
        )

    if target_domain == Domain.SECURITY_AUTHORITY:
        return TypedValue.typed_nan(
            nan_type=value.nan_type,
            reason=f"NaN ({value.nan_type.value}) blocked at security boundary",
            domain=target_domain,
            provenance=value.provenance,
        )

    recovery = nan_recovery_policy(value.nan_type)
    if allow_recovery:
        return value  # Pass through with recovery info attached
    else:
        return TypedValue.typed_nan(
            nan_type=value.nan_type,
            reason=f"NaN ({value.nan_type.value}) not allowed at {target_domain.value}: {recovery}",
            domain=target_domain,
            provenance=value.provenance,
        )


def nan_info(value: TypedValue) -> dict:
    """
    Get diagnostic info about a NaN value.

    Parameters
    ----------
    value : TypedValue

    Returns
    -------
    dict
        Information about the NaN type, description, recovery policy, and domain.
    """
    if not value.is_nan():
        return {"is_nan": False}
    return {
        "is_nan": True,
        "nan_type": value.nan_type.value,
        "description": nan_description(value.nan_type),
        "recovery_policy": nan_recovery_policy(value.nan_type),
        "domain": value.domain.value,
    }
