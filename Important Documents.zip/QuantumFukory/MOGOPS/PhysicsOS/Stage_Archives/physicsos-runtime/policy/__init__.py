"""
PhysicsOS Stage 1 Runtime - Policy & Gate Modules

This package provides domain-boundary policy enforcement:
- ExactSecurityGate: Reject approximate values for security decisions
- ApproximateScienceGate: Permit approximation under policy constraints
- ZeroPolicy: Reject untyped zeros at privileged boundaries
- NaNPolicy: Handle typed NaN crossing boundaries
- UncertaintyFirewall: Enforce uncertainty limits at trust boundaries
- ApproximationConfig: Global approximation configuration
"""

from .exact_security_gate import AccessDecision, SecurityResult, exact_security_gate
from .approximate_science_gate import ApproximationPolicy, GateResult, approximate_science_gate
from .zero_policy import ZeroCheckResult, check_zero_at_boundary
from .nan_policy import NaNHandling, handle_typed_nan, nan_info
from .uncertainty_firewall import BoundaryPolicy, BoundaryResult, uncertainty_firewall
from .approximation_policy import ApproximationConfig

__all__ = [
    # Exact Security Gate
    "AccessDecision",
    "SecurityResult",
    "exact_security_gate",
    # Approximate Science Gate
    "ApproximationPolicy",
    "GateResult",
    "approximate_science_gate",
    # Zero Policy
    "ZeroCheckResult",
    "check_zero_at_boundary",
    # NaN Policy
    "NaNHandling",
    "handle_typed_nan",
    "nan_info",
    # Uncertainty Firewall
    "BoundaryPolicy",
    "BoundaryResult",
    "uncertainty_firewall",
    # Approximation Config
    "ApproximationConfig",
]
