"""
Approximate Science Gate

Approximate values are permitted only when:
    U_total <= U_policy AND context is not security-critical.
"""

from dataclasses import dataclass, field

from core.domain import Domain
from core.typed_value import TypedValue


@dataclass
class ApproximationPolicy:
    """Policy controlling which approximate values are accepted."""
    max_uncertainty: float = 0.1
    min_confidence: float = 0.5
    allowed_domains: list = field(default=None)

    def __post_init__(self):
        if self.allowed_domains is None:
            self.allowed_domains = [d for d in Domain if d != Domain.SECURITY_AUTHORITY]


@dataclass
class GateResult:
    accepted: bool
    reason: str
    uncertainty_total: float = 0.0
    confidence: float = 0.0


def approximate_science_gate(value: TypedValue, policy: ApproximationPolicy) -> GateResult:
    """
    Evaluate whether an approximate value passes the science gate policy.

    Parameters
    ----------
    value : TypedValue
        The value to evaluate.
    policy : ApproximationPolicy
        The policy defining acceptance thresholds.

    Returns
    -------
    GateResult
        accepted=True if the value satisfies all policy constraints.
    """
    if value.is_nan():
        return GateResult(accepted=False, reason=f"NaN value rejected: {value.nan_type.value}")

    if value.domain == Domain.SECURITY_AUTHORITY:
        return GateResult(accepted=False, reason="Approximate gate rejects security_authority domain")

    if policy.allowed_domains is not None and value.domain not in policy.allowed_domains:
        return GateResult(accepted=False, reason=f"Domain {value.domain.value} not in allowed list")

    total = value.uncertainty.total()
    if total > policy.max_uncertainty:
        return GateResult(
            accepted=False,
            reason=f"Uncertainty {total:.6f} exceeds policy {policy.max_uncertainty}",
            uncertainty_total=total,
            confidence=value.uncertainty.confidence,
        )

    if value.uncertainty.confidence < policy.min_confidence:
        return GateResult(
            accepted=False,
            reason=f"Confidence {value.uncertainty.confidence:.3f} below minimum {policy.min_confidence}",
            uncertainty_total=total,
            confidence=value.uncertainty.confidence,
        )

    return GateResult(
        accepted=True,
        reason=f"Accepted: U={total:.6f} <= {policy.max_uncertainty}, conf={value.uncertainty.confidence:.3f}",
        uncertainty_total=total,
        confidence=value.uncertainty.confidence,
    )
