"""
Uncertainty Firewall

Reject data crossing a trust boundary if uncertainty exceeds policy.
"""

from dataclasses import dataclass

from core.domain import Domain
from core.typed_value import TypedValue


@dataclass
class BoundaryPolicy:
    """Policy defining uncertainty limits at a trust boundary."""
    max_uncertainty: float
    target_domain: Domain
    name: str = "default"


@dataclass
class BoundaryResult:
    accepted: bool
    reason: str
    value: TypedValue = None


def uncertainty_firewall(value: TypedValue, policy: BoundaryPolicy) -> BoundaryResult:
    """
    Evaluate whether a value is permitted to cross a trust boundary.

    NaN values are always rejected. Values whose total uncertainty exceeds
    the boundary policy maximum are rejected. Accepted values are
    automatically re-domained to the target domain.

    Parameters
    ----------
    value : TypedValue
        The value attempting to cross the boundary.
    policy : BoundaryPolicy
        The policy defining the boundary's uncertainty limit.

    Returns
    -------
    BoundaryResult
        accepted=True if the value passes, with value re-domained to
        the target domain.
    """
    if value.is_nan():
        return BoundaryResult(
            accepted=False,
            reason=f"NaN value rejected at boundary '{policy.name}': {value.nan_type.value}",
        )

    total = value.uncertainty.total()
    if total > policy.max_uncertainty:
        return BoundaryResult(
            accepted=False,
            reason=f"Uncertainty {total:.6f} exceeds boundary policy {policy.max_uncertainty} at '{policy.name}'",
        )

    return BoundaryResult(
        accepted=True,
        reason=f"Accepted at boundary '{policy.name}': U={total:.6f} <= {policy.max_uncertainty}",
        value=value.with_domain(policy.target_domain),
    )
