"""
Approximation Policy Configuration

Global approximation configuration for PhysicsOS runtime.
"""

from dataclasses import dataclass


@dataclass
class ApproximationConfig:
    """Global approximation configuration.

    Attributes
    ----------
    default_max_uncertainty : float
        Default maximum allowed total uncertainty.
    default_min_confidence : float
        Default minimum required confidence level.
    degradation_pressure_threshold : float
        Memory pressure threshold at which degradation begins.
    degradation_target_pressure : float
        Target memory pressure after degradation activates.
    replay_log_max_events : int
        Maximum number of events in the replay log.
    benchmark_iterations : int
        Number of iterations for uncertainty benchmarks.
    """
    default_max_uncertainty: float = 0.1
    default_min_confidence: float = 0.5
    degradation_pressure_threshold: float = 0.85  # Start degrading at 85% memory
    degradation_target_pressure: float = 0.70      # Target 70% after degradation
    replay_log_max_events: int = 100000
    benchmark_iterations: int = 100000
