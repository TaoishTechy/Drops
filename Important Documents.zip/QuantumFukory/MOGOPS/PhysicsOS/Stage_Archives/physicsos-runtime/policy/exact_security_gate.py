"""
Exact Security Gate

Approximate values cannot authorize security decisions.

Rule:
    security_allowed(value) :=
        value.domain == SECURITY_AUTHORITY
        AND value.uncertainty.security == 0
        AND value.backend.is_exact == True
        AND provenance.valid == True
"""

from dataclasses import dataclass
from enum import Enum

from core.domain import Domain
from core.typed_value import TypedValue, BackendInfo


class AccessDecision(Enum):
    ALLOW = "allow"
    DENY = "deny"


@dataclass
class SecurityResult:
    decision: AccessDecision
    reason: str
    value: TypedValue = None


def exact_security_gate(value: TypedValue, decision: str) -> SecurityResult:
    """
    Evaluate whether a value is authorized to make a security decision.

    Parameters
    ----------
    value : TypedValue
        The value requesting authorization.
    decision : str
        Description of the security decision being authorized.

    Returns
    -------
    SecurityResult
        ALLOW if all exactness/security checks pass, DENY otherwise.
    """
    if value.is_nan():
        return SecurityResult(
            decision=AccessDecision.DENY,
            reason=f"NaN value cannot authorize {decision}: {value.nan_type.value}",
            value=value,
        )

    if value.domain != Domain.SECURITY_AUTHORITY:
        return SecurityResult(
            decision=AccessDecision.DENY,
            reason=f"Domain mismatch: {value.domain.value} != security_authority for {decision}",
            value=value,
        )

    if value.uncertainty.security > 0:
        return SecurityResult(
            decision=AccessDecision.DENY,
            reason=f"Security uncertainty > 0 ({value.uncertainty.security}) cannot authorize {decision}",
            value=value,
        )

    if not value.backend.is_exact:
        return SecurityResult(
            decision=AccessDecision.DENY,
            reason=f"Inexact backend ({value.backend.backend_type}) cannot authorize {decision}",
            value=value,
        )

    if not value.provenance.valid:
        return SecurityResult(
            decision=AccessDecision.DENY,
            reason=f"Invalid provenance chain cannot authorize {decision}",
            value=value,
        )

    return SecurityResult(
        decision=AccessDecision.ALLOW,
        reason=f"Exact value authorized for {decision}",
        value=value,
    )
