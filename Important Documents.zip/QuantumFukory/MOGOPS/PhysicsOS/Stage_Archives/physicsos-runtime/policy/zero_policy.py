"""
Zero Policy

Reject untyped zero at all privileged/runtime boundaries.
"""

from dataclasses import dataclass

from core.domain import Domain
from core.typed_zero import ZeroType, zero_allowed, zero_allowed_info
from core.typed_nan import NaNType
from core.typed_value import TypedValue


@dataclass
class ZeroCheckResult:
    allowed: bool
    reason: str
    value: "TypedValue" = None


def check_zero_at_boundary(value: TypedValue, target_domain: Domain) -> ZeroCheckResult:
    """
    Check whether a zero value is permitted to cross into the target domain.

    Untyped zeros are ALWAYS rejected. Typed zeros are checked against the
    domain's zero policy table.

    Parameters
    ----------
    value : TypedValue
        The value being checked at the boundary.
    target_domain : Domain
        The domain the value is attempting to enter.

    Returns
    -------
    ZeroCheckResult
        allowed=True if the zero (or non-zero) is permitted, with the value
        possibly replaced by a typed NaN if rejected.
    """
    if not value.is_zero():
        return ZeroCheckResult(allowed=True, reason="Value is not zero", value=value)

    if value.zero_type is None:
        # Untyped zero - ALWAYS rejected
        rejected = TypedValue.typed_nan(
            nan_type=NaNType.DOMAIN,
            reason="untyped_zero_forbidden",
            domain=target_domain,
            provenance=value.provenance,
        )
        return ZeroCheckResult(
            allowed=False,
            reason=f"REJECTED: untyped zero at {target_domain.value} boundary",
            value=rejected,
        )

    if not zero_allowed(value.zero_type, target_domain):
        rejected = TypedValue.typed_nan(
            nan_type=NaNType.DOMAIN,
            reason=f"zero_type_{value.zero_type.value}_forbidden_in_{target_domain.value}",
            domain=target_domain,
            provenance=value.provenance,
        )
        return ZeroCheckResult(
            allowed=False,
            reason=zero_allowed_info(value.zero_type, target_domain),
            value=rejected,
        )

    return ZeroCheckResult(
        allowed=True,
        reason=zero_allowed_info(value.zero_type, target_domain),
        value=value,
    )
