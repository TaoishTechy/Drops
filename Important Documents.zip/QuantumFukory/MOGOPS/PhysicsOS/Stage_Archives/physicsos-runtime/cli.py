#!/usr/bin/env python3
"""PhysicsOS Stage 1 Runtime CLI"""

import sys
import os

# Ensure project root is on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import argparse
import subprocess
import json


def run_demo(name):
    """Run a specific demo."""
    demo_file = os.path.join(os.path.dirname(__file__), "demos", f"demo_{name}.py")
    if not os.path.exists(demo_file):
        print(f"Demo not found: {name}")
        return False
    result = subprocess.run([sys.executable, demo_file], capture_output=False)
    return result.returncode == 0


def run_all_demos():
    """Run all demos and report results."""
    demos = [
        ("contextual_equality", "Contextual Equality"),
        ("typed_zero", "Typed Zero Boundary"),
        ("typed_nan", "Typed NaN Division Recovery"),
        ("security_split", "Exact Security + Approximate Science"),
        ("backend_contract", "Backend Contract Validation"),
        ("no_oom_degrade", "No-OOM Approximation Degradation"),
        ("replay", "Deterministic Replay"),
        ("units", "Unit/Dimensional Analysis"),
        ("conservation", "Conservation Law Debugger"),
        ("xi_report", "Xi Efficiency Report"),
    ]

    print("=" * 60)
    print("PHYSICSOS STAGE 1 DEMO SUITE")
    print("=" * 60)
    print()

    results = []
    for name, description in demos:
        demo_file = os.path.join(os.path.dirname(__file__), "demos", f"demo_{name}.py")
        if os.path.exists(demo_file):
            result = subprocess.run([sys.executable, demo_file], capture_output=True, text=True)
            passed = result.returncode == 0
            status = "PASS" if passed else "FAIL"
            print(f"  [{status}] {description}")
            if not passed:
                print(f"         Error: {result.stderr.strip()[:100]}")
            results.append((name, description, passed))
        else:
            print(f"  [SKIP] {description} (file not found)")
            results.append((name, description, None))

    print()
    all_pass = all(r[2] for r in results if r[2] is not None)
    total = len(results)
    passed = sum(1 for r in results if r[2] is True)
    failed = sum(1 for r in results if r[2] is False)
    skipped = sum(1 for r in results if r[2] is None)

    print(f"Results: {passed}/{total} PASS, {failed} FAIL, {skipped} SKIP")
    print()
    if all_pass:
        print("Stage 1 Demo Result: PASS")
    else:
        print("Stage 1 Demo Result: FAIL")

    return all_pass


def run_benchmarks(output_json=None):
    """Run benchmark suite."""
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from metrics.benchmark_runner import BenchmarkRunner
    from core.typed_value import TypedValue
    from core.domain import Domain
    from core.uncertainty import Uncertainty
    from core.provenance import ProvenanceChain
    from core.interval import Interval
    from policy.zero_policy import check_zero_at_boundary
    from policy.exact_security_gate import exact_security_gate
    from policy.uncertainty_firewall import uncertainty_firewall, BoundaryPolicy

    runner = BenchmarkRunner()
    iterations = 100000

    # B1: Contextual equality overhead
    def bench_equality():
        a = TypedValue.from_float(0.1 + 0.2, half_width=1e-16)
        b = TypedValue.from_float(0.3, half_width=1e-16)
        overlap = a.uncertainty.overlap_fraction(b.uncertainty)
        return {"correct": 1}

    # B2: Typed zero boundary overhead
    def bench_zero_boundary():
        v = TypedValue(value=0, uncertainty=Uncertainty.exact(0), domain=Domain.PHYSICS_NUMERIC,
                       provenance=ProvenanceChain(source="bench"))
        result = check_zero_at_boundary(v, Domain.SENSOR_DATA)
        return {"correct": 1}

    # B3: Interval arithmetic overhead
    def bench_interval():
        a = Interval(0.1 - 1e-16, 0.1 + 1e-16)
        b = Interval(0.2 - 1e-16, 0.2 + 1e-16)
        c = a + b
        return {"correct": 1}

    # B4: Security gate overhead
    sec_val = TypedValue(value=42, uncertainty=Uncertainty.exact(42), domain=Domain.SECURITY_AUTHORITY,
                         provenance=ProvenanceChain(source="bench"))
    def bench_security():
        result = exact_security_gate(sec_val, "test")
        return {"correct": 1 if result.decision.value == "allow" else 0, "false_reject": 0, "false_accept": 0}

    runner.run("contextual_equality", bench_equality, iterations)
    runner.run("typed_zero_boundary", bench_zero_boundary, iterations)
    runner.run("interval_arithmetic", bench_interval, iterations)
    runner.run("exact_security_gate", bench_security, iterations)

    print()
    print("PhysicsOS Stage 1 Benchmark Results")
    print("=" * 60)
    print(runner.summary_table())
    print()

    if output_json:
        with open(output_json, 'w') as f:
            f.write(runner.to_json())
        print(f"Results saved to {output_json}")


def run_tests():
    """Run all tests."""
    test_dir = os.path.join(os.path.dirname(__file__), "tests")
    result = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", test_dir, "-v"],
                          capture_output=False)
    return result.returncode == 0


def main():
    parser = argparse.ArgumentParser(description="PhysicsOS Stage 1 Runtime")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Demo commands
    demo_parser = subparsers.add_parser("demo", help="Run demos")
    demo_parser.add_argument("name", nargs="?", default="all", help="Demo name or 'all'")

    # Benchmark commands
    bench_parser = subparsers.add_parser("bench", help="Run benchmarks")
    bench_parser.add_argument("name", nargs="?", default="all", help="Benchmark name or 'all'")
    bench_parser.add_argument("--json", dest="output_json", help="Output JSON file")

    # Test command
    subparsers.add_parser("test", help="Run all tests")

    # Report command
    report_parser = subparsers.add_parser("report", help="Generate report")
    report_parser.add_argument("type", choices=["stage1"], help="Report type")
    report_parser.add_argument("--out", help="Output file")

    args = parser.parse_args()

    if args.command == "demo":
        if args.name == "all":
            success = run_all_demos()
            sys.exit(0 if success else 1)
        else:
            success = run_demo(args.name)
            sys.exit(0 if success else 1)
    elif args.command == "bench":
        run_benchmarks(args.output_json)
    elif args.command == "test":
        success = run_tests()
        sys.exit(0 if success else 1)
    elif args.command == "report":
        if args.type == "stage1":
            from metrics.report import Stage1ReportGenerator
            gen = Stage1ReportGenerator()
            content = gen.generate()
            if args.out:
                with open(args.out, 'w') as f:
                    f.write(content)
                print(f"Report saved to {args.out}")
            else:
                print(content)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
