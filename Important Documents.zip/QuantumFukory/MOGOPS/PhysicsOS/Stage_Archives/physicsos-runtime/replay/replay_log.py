"""Replay log: append-only event store with JSON persistence."""
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
import json
import time
import os
from .event_record import ReplayEvent, serialize_typed_value


class ReplayLog:
    """Append-only log of ReplayEvents with save/load support."""

    def __init__(self, log_id: str = "default"):
        self.log_id = log_id
        self.events: List[ReplayEvent] = []
        self.start_time_ns = time.time_ns()

    def record(
        self,
        operation: str,
        inputs: list,
        outputs: list,
        policy_snapshot: dict = None,
        backend_snapshot: dict = None,
        uncertainty_snapshot: dict = None,
    ) -> ReplayEvent:
        """Record a computation event with full context."""
        event = ReplayEvent(
            event_id=f"{self.log_id}_{len(self.events)}",
            timestamp_ns=time.time_ns(),
            operation=operation,
            inputs=[
                serialize_typed_value(tv) if hasattr(tv, "value") else tv
                for tv in inputs
            ],
            outputs=[
                serialize_typed_value(tv) if hasattr(tv, "value") else tv
                for tv in outputs
            ],
            policy_snapshot=policy_snapshot or {},
            backend_contract_snapshot=backend_snapshot or {},
            uncertainty_snapshot=uncertainty_snapshot or {},
        )

        # Compute provenance hash from inputs
        prov_parts = []
        for inp in event.inputs:
            if isinstance(inp, dict) and "provenance_hash" in inp:
                prov_parts.append(inp["provenance_hash"])
        event.provenance_hash = "|".join(prov_parts)

        self.events.append(event)
        return event

    def __len__(self):
        return len(self.events)

    def __repr__(self):
        return f"ReplayLog(id={self.log_id}, events={len(self.events)})"

    def to_dict(self) -> dict:
        return {
            "log_id": self.log_id,
            "start_time_ns": self.start_time_ns,
            "event_count": len(self.events),
            "events": [
                {
                    "event_id": e.event_id,
                    "timestamp_ns": e.timestamp_ns,
                    "operation": e.operation,
                    "inputs": e.inputs,
                    "outputs": e.outputs,
                    "provenance_hash": e.provenance_hash,
                }
                for e in self.events
            ],
        }

    def save(self, filepath: str):
        """Save replay log to JSON file."""
        with open(filepath, "w") as f:
            json.dump(self.to_dict(), f, indent=2, default=str)

    @classmethod
    def load(cls, filepath: str) -> "ReplayLog":
        """Load replay log from JSON file."""
        with open(filepath, "r") as f:
            data = json.load(f)
        log = cls(log_id=data["log_id"])
        log.start_time_ns = data["start_time_ns"]
        for ed in data["events"]:
            log.events.append(
                ReplayEvent(
                    event_id=ed["event_id"],
                    timestamp_ns=ed["timestamp_ns"],
                    operation=ed["operation"],
                    inputs=ed["inputs"],
                    outputs=ed["outputs"],
                    policy_snapshot=ed.get("policy_snapshot", {}),
                    backend_contract_snapshot=ed.get("backend_contract_snapshot", {}),
                    uncertainty_snapshot=ed.get("uncertainty_snapshot", {}),
                    provenance_hash=ed.get("provenance_hash", ""),
                )
            )
        return log
