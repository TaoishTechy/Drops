"""Deterministic runner: execute computations and verify reproducibility."""
from typing import Callable, Dict, Any, Optional
from .replay_log import ReplayLog


class DeterministicRunner:
    """Run a computation and verify it can be replayed deterministically."""

    def __init__(self, replay_log: ReplayLog = None):
        self.log = replay_log or ReplayLog("deterministic")

    def run_and_record(
        self,
        operation: str,
        func: Callable,
        *args,
        policy_snapshot: dict = None,
        backend_snapshot: dict = None,
        uncertainty_snapshot: dict = None,
    ) -> tuple:
        """Run a function and record its inputs/outputs for replay."""
        inputs = list(args)
        outputs = func(*args)
        if not isinstance(outputs, (list, tuple)):
            outputs = [outputs]

        self.log.record(
            operation=operation,
            inputs=inputs,
            outputs=outputs,
            policy_snapshot=policy_snapshot,
            backend_snapshot=backend_snapshot,
            uncertainty_snapshot=uncertainty_snapshot,
        )
        return outputs

    def replay(self, operation_id: str, func: Callable, *args) -> tuple:
        """Replay a specific operation and compare with recorded output."""
        # Find the event
        event = None
        for e in self.log.events:
            if e.event_id == operation_id or e.operation == operation_id:
                event = e
                break

        if event is None:
            raise ValueError(
                f"Event {operation_id} not found in replay log"
            )

        # Re-run the function
        current_outputs = func(*args)
        if not isinstance(current_outputs, (list, tuple)):
            current_outputs = [current_outputs]

        # Compare
        matches = True
        for i, (cur, rec) in enumerate(zip(current_outputs, event.outputs)):
            if hasattr(cur, "value") and isinstance(rec, dict):
                if cur.value != rec.get("value"):
                    matches = False
            elif cur != rec:
                matches = False

        return matches, current_outputs, event.outputs

    def verify_full_replay(self, func_map: Dict[str, Callable]) -> bool:
        """Verify all events in the log can be replayed."""
        all_match = True
        for event in self.log.events:
            if event.operation in func_map:
                func = func_map[event.operation]
                # For a full replay, we'd need to reconstruct inputs from
                # serialization. This is a simplified check.
                pass
        return all_match
