"""Event recording for deterministic replay of PhysicsOS computations."""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import time


@dataclass
class ReplayEvent:
    """A single recorded computation event with full context for replay."""
    event_id: str
    timestamp_ns: int
    operation: str
    inputs: List[Dict[str, Any]]       # Serialized TypedValue dicts
    outputs: List[Dict[str, Any]]      # Serialized TypedValue dicts
    policy_snapshot: Dict[str, Any] = field(default_factory=dict)
    backend_contract_snapshot: Dict[str, Any] = field(default_factory=dict)
    uncertainty_snapshot: Dict[str, Any] = field(default_factory=dict)
    provenance_hash: str = ""


def serialize_typed_value(tv: "TypedValue") -> dict:
    """Serialize a TypedValue for replay logging."""
    return {
        "value": tv.value,
        "uncertainty": {
            "lower": tv.uncertainty.lower,
            "upper": tv.uncertainty.upper,
            "confidence": tv.uncertainty.confidence,
        },
        "domain": tv.domain.value if tv.domain else None,
        "backend": tv.backend.backend_type,
        "zero_type": tv.zero_type.value if tv.zero_type else None,
        "nan_type": tv.nan_type.value if tv.nan_type else None,
        "units": repr(tv.units) if tv.units else None,
        "provenance_hash": tv.provenance.hash(),
    }
