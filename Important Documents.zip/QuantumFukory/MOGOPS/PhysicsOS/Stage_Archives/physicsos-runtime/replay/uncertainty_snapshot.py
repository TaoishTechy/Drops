"""Uncertainty state snapshots for replay logging."""
from dataclasses import dataclass, field
from typing import Dict, Any
import time


@dataclass
class UncertaintySnapshot:
    """Point-in-time snapshot of the global uncertainty state."""
    snapshot_id: str
    timestamp_ns: int
    global_max_uncertainty: float
    domain_uncertainties: Dict[str, float] = field(default_factory=dict)
    active_policies: Dict[str, Any] = field(default_factory=dict)
    backend_states: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "snapshot_id": self.snapshot_id,
            "timestamp_ns": self.timestamp_ns,
            "global_max_uncertainty": self.global_max_uncertainty,
            "domain_uncertainties": self.domain_uncertainties,
            "active_policies": self.active_policies,
            "backend_states": self.backend_states,
        }
