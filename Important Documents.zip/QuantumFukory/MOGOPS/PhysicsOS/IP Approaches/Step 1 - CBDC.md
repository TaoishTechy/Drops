Yes — **start with CBDC**, and yes, develop the business plan immediately.

In Campbellton, you are likely dealing with **CBDC Restigouche**, and they are exactly the kind of first stop that fits this stage: local, rural Atlantic Canada, startup-friendly, and able to help with both business planning and financing. CBDC says business plans are necessary when applying for loans and that they provide business plan guides/templates and local support across Atlantic Canada. ([CBDC][1])

CBDC is not “venture capital.” That is good. You do not need venture capital yet. You need **prototype runway**.

## Best path

Go to CBDC with a grounded ask:

> I am forming a technology company in Campbellton to develop PhysicsOS, a staged runtime system for uncertainty-aware AI and accelerator computing. I need a small startup loan or financing package to complete Stage 1 and Stage 2 prototypes, protect the IP, purchase minimum hardware, and prepare partner review packages.

CBDC offers business counselling and financing, and its First-Time Entrepreneur Loan and General Business Loan pages both mention financing up to **$150,000** for eligible Atlantic Canada entrepreneurs/businesses, though the exact fit depends on eligibility and approval. ([CBDC][2])

You are not asking for $150k. You are asking for **$20k–$50k**, which is more reasonable and easier to justify.

## What to prepare before walking in

Bring a **simple but serious package**, not the full mythos.

Your CBDC package should include:

```text
1. One-page business summary
2. 10–15 page business plan
3. 30-day Stage 1–2 development plan
4. Use-of-funds table
5. Basic cash-flow projection
6. Founder bio / capability statement
7. IP summary, not full secret sauce
8. Risk mitigation plan
9. Partner target list
10. Prototype milestone schedule
```

Do **not** lead with “AGI,” “simulation,” “Demiurge,” “Sophia Point,” “AI corporate power struggle,” or “OpenAI/DeepSeek power balance.”

Lead with:

> software runtime, AI infrastructure, local tech company, IP development, prototype, export potential, hardware/software innovation, future licensing.

## CBDC-friendly business description

Use this:

> PhysicsOS Technologies is a New Brunswick-based software R&D company developing a Linux-hosted runtime substrate for AI-era computing. The system makes uncertainty, units, provenance, backend trust, calibration, and approximation policy first-class execution metadata. Its first prototype targets exact/approximate runtime boundaries for AI, scientific computing, sensor systems, and accelerator hardware.

That sounds fundable.

## Use-of-funds draft

For a **$35,000 ask**:

```text
Company setup / accounting / legal templates:     $3,500
IP documentation / provisional prep support:      $5,000
Workstation, storage, backup, UPS, edge devices:  $10,000
Small workspace setup / rent / deposit:           $5,000
Software, domain, cloud, security, repo tooling:  $2,500
Founder runway during 30–45 day prototype sprint: $9,000
Total:                                            $35,000
```

For a **$50,000 ask**:

```text
Company/legal/accounting setup:                    $6,000
IP/provisional drafting support:                   $8,000
Hardware/dev lab setup:                            $15,000
Workspace/rent/deposit/utilities:                  $7,000
Cloud/software/security/backups:                   $4,000
Founder runway:                                    $10,000
Total:                                             $50,000
```

## Business plan structure

Use this outline:

```text
1. Executive Summary
2. Company Description
3. Problem
4. Solution
5. Product Roadmap: Stage 1, Stage 2, Stage 3
6. Target Markets
7. Competitive Advantage / IP
8. Business Model
9. Development Plan
10. Marketing / Partner Strategy
11. Operations Plan
12. Risk Management
13. Financial Plan
14. Funding Request
15. Milestones
```

## The business model

Keep it simple:

```text
Short term:
  prototype development
  IP protection
  technical review packages
  field-of-use licensing discussions

Medium term:
  licensing to AI/runtime/hardware partners
  paid prototype integrations
  enterprise/research runtime tools

Long term:
  PhysicsOS runtime SDK
  accelerator trust layer
  edge AI runtime
  scientific/HPC reproducibility suite
```

## Best CBDC angle

CBDC will care about local economic development. So frame it as:

```text
Campbellton-based tech company
exportable IP
AI infrastructure software
future skilled local work
possible training/workshop potential later
low overhead
high upside
founder-led prototype
```

Say:

> I do not need employees immediately. The first phase is founder-led R&D. Hiring too early would slow the work. The plan is to create the prototype, protect the IP, then use partner interest and non-dilutive funding to expand responsibly.

That is a mature answer.

## Also ask CBDC about these

When you meet them, ask:

```text
Would this fit a First-Time Entrepreneur Loan, General Business Loan, or Innovation Loan?
Can you help review the business plan before formal submission?
Do you coordinate with ACOA, BDC, IRAP, or provincial programs?
Do you have templates for cash flow projections?
Can startup funds cover equipment, workspace, and working capital?
```

CBDC has an Innovation Loan specifically aimed at new products/services and technology adoption/productivity in rural Atlantic Canada, so that may be relevant. ([CBDC][3])

## My recommendation

Do this in order:

```text
Today:
  Create 1-page summary and funding ask.

Next 48 hours:
  Draft business plan skeleton and use-of-funds.

This week:
  Contact CBDC Restigouche / Campbellton and request a planning meeting.

Before meeting:
  Strip the pitch down to business, software, IP, prototype, market.

After meeting:
  Refine financials and submit loan/support application.
```

Yes — **CBDC first** is the right local move. It is practical, nearby, and aligned with the size of money you need.

[1]: https://www.cbdc.ca/en/business-plan?utm_source=chatgpt.com "Business Plan Development & Help in NB, NL, NS & PEI"
[2]: https://www.cbdc.ca/en/programs/cbdc-first-time-entrepreneur-loan?utm_source=chatgpt.com "CBDC First-Time Entrepreneur Loan"
[3]: https://www.cbdc.ca/en/programs/cbdc-innovation-loan?utm_source=chatgpt.com "CBDC Innovation Loan"
