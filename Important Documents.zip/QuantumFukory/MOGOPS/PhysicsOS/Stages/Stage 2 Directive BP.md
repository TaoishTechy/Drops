# PhysicsOS v2.0 — Stage 2 Directive Blueprint

## Runtime Kernel Prototype: From Stage 1 Semantics to Buildable Substrate

Stage 1 proved the **semantic spine**:

```text
TypedValue
TypedZero
TypedNaN
Contextual equality
Exact security gate
Approximate science gate
Backend contract validation
No-OOM approximation degradation
Replay with uncertainty
Xi overhead reporting
```

Stage 2 turns that into a **Linux-hosted runtime kernel prototype**.

Not a full OS yet. Not bare metal. Not a microkernel simulator yet. Stage 2 is the bridge between library and OS:

> **A runtime substrate that behaves like the inner physics/value layer of an operating system while still running safely inside Linux.**

The merged PhysicsOS v2.0 document already defines the core architecture as a verified hybrid microkernel direction with typed values, uncertainty, provenance, field memory, analog/GPU accelerator contracts, Linux compatibility in user space, and the falsifiable efficiency metric `Xi = W / (W + O_control + O_memory + O_error + O_calibration + O_translation)`. 

---

# 0. Stage 2 Mission

## Primary objective

Build:

```text
physicsos-runtime-kernel
```

A user-space runtime that implements the **minimum viable substrate**:

```text
Typed-Zero ABI
+ PhysVal typed value system
+ interval / affine arithmetic
+ unit-carrying values
+ uncertainty propagation engine
+ conservation-law checker
+ field memory object
+ backend contract system
+ scheduler cost model
+ Linux compatibility harness
+ proof / benchmark ledger
```

## Stage 2 thesis

> **PhysicsOS is a dual-plane runtime: exact control/security stays deterministic, while physics/numerical computation becomes typed, uncertain, unit-aware, provenance-aware, and backend-aware.**

## Stage 2 non-goal

Do **not** build a full OS yet.

Stage 2 should not attempt:

```text
bootloader
bare metal
real driver stack
full POSIX
kernel module
actual seL4 port
analog hardware
formal proof completion
quantum/neuro/cosmology claims
```

Stage 2 is where the architecture becomes executable and measurable.

---

# 1. Stage 2 Core Target

## Minimum Viable Substrate

```text
PhysicsOS Stage 2 =
  Layer A: Exact Control Plane
+ Layer B: Physics Value Plane
+ Layer C: Constraint Execution Plane
+ Layer D: Field Memory Plane
+ Layer E: Backend Contract Plane
+ Layer F: Scheduler Cost Plane
+ Layer G: Linux Harness
+ Layer H: Proof Ledger
```

Each layer must be separable, testable, and benchmarked.

---

# 2. Stage 2 Architecture Overview

```text
┌─────────────────────────────────────────────┐
│             Linux Host System               │
│  Python/Rust runtime, CLI, filesystem, logs  │
└─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────┐
│        PhysicsOS Runtime Kernel             │
│  physicsd / libphysos / physrun / physbench │
└─────────────────────────────────────────────┘
                    │
     ┌──────────────┼──────────────┐
     ▼              ▼              ▼
┌─────────┐   ┌────────────┐   ┌─────────────┐
│ Exact   │   │ Physics    │   │ Constraint  │
│ Control │   │ Value      │   │ Execution   │
│ Plane   │   │ Plane      │   │ Plane       │
└─────────┘   └────────────┘   └─────────────┘
     │              │              │
     ▼              ▼              ▼
┌─────────┐   ┌────────────┐   ┌─────────────┐
│ Ledger  │   │ Field      │   │ Backend     │
│ Proof   │   │ Memory     │   │ Contracts   │
│ Plane   │   │ Plane      │   │ Plane       │
└─────────┘   └────────────┘   └─────────────┘
                    │
                    ▼
            Scheduler Cost Model
```

---

# 3. Stage 2 Layer A — Exact Control Plane

## Purpose

The Exact Control Plane handles things that must never become fuzzy:

```text
permissions
process identity
security decisions
object ownership
runtime configuration
provenance validation
rollback records
benchmark logs
ledger hash chains
```

## Core law

```text
No approximate value may decide authority.
```

This law must be enforced in code, not just stated.

## Exact control types

```text
ExactBool
ExactInt
ExactString
CapabilityToken
ObjectID
ProcessID
LedgerHash
PolicyID
BackendID
```

## Forbidden in exact control

```text
interval-valued authorization
probabilistic permission
analog-derived access token
uncertain identity
confidence-based root/admin
field-memory security object
```

## Required function

```python
def require_exact_authority(value: PhysVal, context: str) -> ExactDecision:
    if value.is_approximate():
        return ExactDecision.deny("approximate_value_in_exact_control_plane")
    if value.domain != Domain.SECURITY_AUTHORITY:
        return ExactDecision.deny("wrong_domain_for_authority")
    if not value.provenance.valid():
        return ExactDecision.deny("invalid_provenance")
    return ExactDecision.allow()
```

## Acceptance tests

```text
[PASS] approximate sensor value cannot authorize access
[PASS] interval confidence cannot become permission
[PASS] valid exact capability authorizes operation
[PASS] revoked capability denies operation
[PASS] provenance failure denies operation
```

---

# 4. Stage 2 Layer B — Physics Value Plane

## Purpose

The Physics Value Plane is the heart of Stage 2.

Every numerical/physical value becomes:

```text
PhysVal<T> = {
  value: T,
  interval: [lower, upper],
  uncertainty: U,
  unit: Unit,
  zero_type: ZeroType,
  nan_type: NaNType | None,
  provenance: Provenance,
  backend: Backend,
  confidence: float,
  domain: Domain
}
```

## Canonical Python model

```python
@dataclass
class PhysVal:
    value: float | int | complex | list | None
    lo: float | None
    hi: float | None
    uncertainty: "Uncertainty"
    unit: "Unit"
    zero_type: "ZeroType"
    nan_type: "NaNType | None"
    provenance: "Provenance"
    backend: "BackendInfo"
    confidence: float
    domain: "Domain"
```

## Canonical JSON representation

```json
{
  "value": 0.30000000000000004,
  "interval": [0.29999999999999993, 0.30000000000000010],
  "uncertainty": {
    "rounding": 1e-16,
    "measurement": 0.0,
    "model": 0.0,
    "hardware": 0.0,
    "time": 0.0,
    "security": 0.0
  },
  "unit": "dimensionless",
  "zero_type": "NotZero",
  "nan_type": null,
  "provenance": "operation:add:float64_interval_checked",
  "backend": "cpu_interval",
  "confidence": 0.999999,
  "domain": "physics_numeric"
}
```

## Required methods

```python
PhysVal.add(other)
PhysVal.sub(other)
PhysVal.mul(other)
PhysVal.div(other)
PhysVal.equals(other, policy)
PhysVal.assert_unit(expected)
PhysVal.to_json()
PhysVal.from_json()
PhysVal.is_exact()
PhysVal.is_approximate()
PhysVal.is_authority_safe()
```

## Stage 2 improvement over Stage 1

Stage 1 proves the types.

Stage 2 makes them a **runtime ABI**.

That means values must serialize, cross module boundaries, enter ledgers, feed constraints, and return from backend contracts.

---

# 5. Stage 2 Typed-Zero ABI

## ZeroType enum

```python
class ZeroType(Enum):
    NOT_ZERO = "NotZero"
    EXACT_SYMBOLIC_ZERO = "ExactSymbolicZero"
    MEASURED_ABSENCE = "MeasuredAbsence"
    HARDWARE_GROUND_REFERENCE = "HardwareGroundReference"
    NULL_CAPABILITY = "NullCapability"
    UNDERFLOW_ZERO = "UnderflowZero"
    FORBIDDEN_OPERAND_ZERO = "ForbiddenOperandZero"
    UNKNOWN_ZERO = "UnknownZero"
    UNTYPED_ZERO = "UntypedZero"
```

## Zero rules

```text
ExactSymbolicZero
  allowed in algebra, proof, symbolic simplification

MeasuredAbsence
  allowed in sensor and physics values with uncertainty

HardwareGroundReference
  allowed in electrical calibration and reference domains

NullCapability
  allowed only in access-control logic

UnderflowZero
  allowed as representation-collapse marker

ForbiddenOperandZero
  blocks division, log, normalization, inverse, reciprocal

UnknownZero
  must be refined, measured, or rejected before use

UntypedZero
  forbidden at all Stage 2 runtime boundaries
```

## Core law

```text
No zero crosses a runtime domain boundary without a ZeroType tag.
```

## Required boundary function

```python
def validate_zero_boundary(value: PhysVal, target_domain: Domain) -> BoundaryResult:
    if value.zero_type == ZeroType.UNTYPED_ZERO:
        return BoundaryResult.reject("untyped_zero_forbidden")

    allowed = ZERO_POLICY[target_domain]

    if value.zero_type not in allowed:
        return BoundaryResult.reject(
            f"zero_type_{value.zero_type.value}_not_allowed_in_{target_domain.value}"
        )

    if value.zero_type == ZeroType.UNKNOWN_ZERO:
        return BoundaryResult.reject("unknown_zero_requires_refinement")

    return BoundaryResult.accept()
```

## Stage 2 zero tests

```text
[PASS] NotZero accepted in physics numeric domain
[PASS] MeasuredAbsence accepted in sensor domain
[PASS] HardwareGroundReference accepted in calibration domain
[PASS] NullCapability accepted in security domain
[PASS] NullCapability rejected in division
[PASS] UnknownZero rejected until refined
[PASS] UntypedZero always rejected
```

---

# 6. Stage 2 Arithmetic Model

## 6.1 Addition

```text
x + y:
  require compatible units
  value = x.value + y.value
  interval = [x.lo + y.lo, x.hi + y.hi]
  uncertainty = propagate_add(x.U, y.U)
  unit = x.unit
  zero_type = infer_zero_type(result)
  provenance = hash(x.P, y.P, "add")
```

## 6.2 Subtraction

```text
x - y:
  require compatible units
  value = x.value - y.value
  interval = [x.lo - y.hi, x.hi - y.lo]
  uncertainty = propagate_sub(x.U, y.U)
  zero_type = infer_zero_type(result)
```

## 6.3 Multiplication

```text
x * y:
  unit = x.unit * y.unit
  interval = min/max {
    x.lo*y.lo,
    x.lo*y.hi,
    x.hi*y.lo,
    x.hi*y.hi
  }
```

## 6.4 Division

```text
x / y allowed iff 0 ∉ interval(y)
```

If denominator interval contains zero:

```python
return Undefined(
    reason="denominator_interval_contains_zero",
    nan_type=NaNType.DOMAIN,
    zero_type=ZeroType.FORBIDDEN_OPERAND_ZERO,
    uncertainty=Uncertainty.infinity(),
    operands=[x, y]
)
```

## 6.5 Logarithm

```text
log(x) allowed iff interval(x) > 0 and unit(x) is dimensionless
```

## 6.6 Trigonometry

```text
sin(x), cos(x), tan(x) require dimensionless angle or explicit radian unit.
```

## 6.7 Normalization

```text
normalize(v) allowed iff norm(v) interval excludes 0.
```

## Arithmetic acceptance tests

```text
[PASS] 0.1 + 0.2 interval-overlaps 0.3
[PASS] meters + meters succeeds
[PASS] meters + seconds fails
[PASS] meters / seconds returns velocity unit
[PASS] divide by interval containing zero returns UndefinedDomain
[PASS] log of negative interval returns UndefinedDomain
[PASS] normalize zero vector fails safely
```

---

# 7. Stage 2 Unit System

## Unit representation

Represent SI units as exponent vectors:

```text
Unit = M^a L^b T^c I^d Θ^e N^f J^g
```

Python:

```python
@dataclass(frozen=True)
class Unit:
    mass: int = 0          # kg
    length: int = 0        # meter
    time: int = 0          # second
    current: int = 0       # ampere
    temperature: int = 0   # kelvin
    substance: int = 0     # mole
    luminosity: int = 0    # candela
```

## Common units

```python
DIMENSIONLESS = Unit()
METER = Unit(length=1)
SECOND = Unit(time=1)
KELVIN = Unit(temperature=1)
VELOCITY = Unit(length=1, time=-1)
ACCELERATION = Unit(length=1, time=-2)
FORCE = Unit(mass=1, length=1, time=-2)
ENERGY = Unit(mass=1, length=2, time=-2)
POWER = Unit(mass=1, length=2, time=-3)
```

## Unit laws

```text
Addition/subtraction require identical units.
Multiplication adds unit exponents.
Division subtracts unit exponents.
Exponentiation multiplies unit exponents by scalar.
Log requires dimensionless input.
Exp requires dimensionless input.
Sin/cos require dimensionless/radian input.
Comparison requires compatible units.
```

## Required functions

```python
assert_same_unit(a: PhysVal, b: PhysVal)
mul_units(a: Unit, b: Unit) -> Unit
div_units(a: Unit, b: Unit) -> Unit
parse_unit("kg*m^2/s^2") -> Unit
format_unit(Unit(mass=1, length=2, time=-2)) -> "kg*m^2*s^-2"
```

## Stage 2 unit demos

```text
3 meters + 4 meters = 7 meters
3 meters + 4 seconds = UnitFault
10 meters / 2 seconds = 5 meters/second
log(3 meters) = UnitFault
log(3 dimensionless) = valid
```

---

# 8. Stage 2 Uncertainty Propagation Engine

## Uncertainty object

```python
@dataclass
class Uncertainty:
    measurement: float = 0.0
    rounding: float = 0.0
    model: float = 0.0
    hardware: float = 0.0
    time: float = 0.0
    security: float = 0.0
    confidence: float = 1.0
    covariance_ref: str | None = None
```

## Total uncertainty

```text
U_total = f(U_measure, U_round, U_model, U_hw, U_time, U_security, Cov)
```

Do not collapse with `max()` by default.

## Stage 2 minimum propagation

For Stage 2, implement:

```text
interval propagation
root-sum-square propagation for independent components
affine-lite dependency tags
optional covariance placeholder
```

## Addition uncertainty

```text
U_add = sqrt(U_x^2 + U_y^2)
```

when independent.

If dependency tags match:

```text
preserve dependency; do not widen unnecessarily
```

## Multiplication relative uncertainty

```text
U_xy ≈ |xy| * sqrt((U_x/x)^2 + (U_y/y)^2)
```

with interval fallback when values near zero.

## Stage 2 uncertainty tests

```text
[PASS] rounding uncertainty attached to float64 operations
[PASS] measurement uncertainty propagates through addition
[PASS] interval bounds never narrower than input uncertainty
[PASS] unknown covariance does not pretend independence
[PASS] infinity uncertainty triggers Undefined / BoundaryReject
```

---

# 9. Stage 2 Contextual Equality

## Equality function

```python
def phys_equal(a: PhysVal, b: PhysVal, policy: EqualityPolicy) -> PhysVal:
    # 1. Unit compatibility
    # 2. Domain compatibility
    # 3. Interval overlap
    # 4. Uncertainty threshold
    # 5. Provenance validity
    # 6. Return exact boolean for control OR PhysVal confidence for science
```

## Overlap probability

```text
P_overlap = measure(I_a ∩ I_b) / measure(I_a ∪ I_b)
```

## Equality modes

```text
ExactMode:
  only exact values allowed
  returns ExactBool

PhysicsMode:
  interval overlap allowed
  returns PhysVal[bool] with confidence

DisplayMode:
  human-readable approximate equality

SecurityMode:
  approximate equality forbidden
```

## Required demo

```python
a = PhysVal.from_float(0.1)
b = PhysVal.from_float(0.2)
c = PhysVal.from_float(0.3)

result = phys_equal(a + b, c, PhysicsMode(tolerance=0.999))
```

Expected:

```text
raw Python: False
PhysicsOS: True within interval policy
confidence: reported
ledger: emitted
```

---

# 10. Stage 2 Layer C — Constraint Execution Plane

## Purpose

Stage 2 introduces runtime contracts:

```text
CONSERVE
PROPAGATE
MEASURE
ASSERT_UNITS
ASSERT_INTERVAL
ASSERT_PROVENANCE
ASSERT_BACKEND
```

These are **not CPU instructions**. They are runtime contract calls.

## 10.1 CONSERVE

General form:

```text
ΔC = |C_after - C_before - C_boundary|
valid iff ΔC ≤ tolerance
```

Python:

```python
def conserve(
    name: str,
    before: PhysVal,
    after: PhysVal,
    boundary: PhysVal,
    tolerance: PhysVal,
    ledger: Ledger
) -> ConstraintResult:
    ...
```

## Conservation examples

### Energy

```text
ΔE = |E_after - E_before - W_in + W_out - Q_in + Q_out|
```

### Momentum

```text
Δp = |p_after - p_before - impulse_boundary|
```

### Charge

```text
Δq = |q_after - q_before - charge_boundary|
```

### Ledger/finance analog

```text
Δledger = |assets_after - assets_before - deposits + withdrawals|
```

This is powerful because conservation debugging generalizes beyond physics.

## 10.2 ASSERT_UNITS

```python
ASSERT_UNITS(expression, expected_unit)
```

Fails if result unit does not match expected.

## 10.3 ASSERT_INTERVAL

```python
ASSERT_INTERVAL(value, lower, upper)
```

Fails if interval escapes bound.

## 10.4 ASSERT_PROVENANCE

```python
ASSERT_PROVENANCE(value, trust_policy)
```

Fails if provenance chain does not satisfy policy.

## 10.5 MEASURE

```python
MEASURE(value, observable, uncertainty_model)
```

Converts unknown or broad uncertainty into updated uncertainty through measurement metadata.

## Required constraint tests

```text
[PASS] correct energy balance accepted
[PASS] missing boundary loss creates conservation violation
[PASS] charge balance accepted
[PASS] finance ledger imbalance detected
[PASS] unit assertion catches wrong unit
[PASS] interval assertion catches out-of-bound value
[PASS] provenance assertion catches untrusted value
```

---

# 11. Stage 2 Layer D — Field Memory Plane

## Purpose

Field memory becomes a practical object type.

It does not replace RAM. It creates physics-native numerical storage.

```text
byte memory  → exact compatibility
field memory → approximate numerical/physics objects
```

## FieldRegion

```python
@dataclass
class FieldRegion:
    field_id: str
    shape: tuple[int, ...]
    basis: BasisType
    coefficients: np.ndarray
    uncertainty_map: np.ndarray
    unit_map: Unit | np.ndarray
    backend: BackendInfo
    refinement_policy: RefinementPolicy
    compression_policy: CompressionPolicy
    provenance: Provenance
    security_allowed: bool = False
```

## Supported bases

```text
dense_grid
sparse_grid
wavelet
radial_basis_function
fourier
finite_element
adaptive_mesh
```

Stage 2 only needs to implement:

```text
dense_grid
wavelet-lite or downsample coarsening
```

Other bases can be stubs.

## Field operations

```text
FIELD_CREATE(shape, basis, unit, uncertainty)
FIELD_EVALUATE(region, point)
FIELD_STORE(region, point, value, uncertainty)
FIELD_REFINE(region, subdomain, target_error)
FIELD_COARSEN(region, max_error)
FIELD_DIFF(region_a, region_b)
FIELD_SNAPSHOT(region)
FIELD_ROLLBACK(region, snapshot)
```

## Coarsening law

```text
coarsening = lossy approximation unless explicitly lossless
```

Every coarsened region must declare:

```text
lossless: false
reconstruction_error_bound: ε
allowed_for_security: false
```

## Stage 2 field demos

```text
[PASS] create 2D heat field
[PASS] evaluate point
[PASS] store value with unit K
[PASS] reject value with wrong unit
[PASS] coarsen field
[PASS] report compression ratio
[PASS] report reconstruction error bound
[PASS] snapshot field
[PASS] rollback field
```

---

# 12. Stage 2 Layer E — Backend Contract System

## Purpose

Backends become safely pluggable.

Backends include:

```text
CPU exact
CPU interval
GPU placeholder
FPGA placeholder
analog placeholder
symbolic placeholder
```

Stage 2 does not need real GPU/FPGA/analog acceleration. It needs contract enforcement.

## BackendContract

```python
@dataclass
class BackendContract:
    backend_id: str
    backend_type: BackendType
    supports: list[str]
    precision_bits_effective: tuple[int, int] | None
    noise_model: str | None
    drift_model: str | None
    calibration_required: bool
    calibration_age_ms: int
    max_calibration_age_ms: int
    verifier: str | None
    security_allowed: bool
    exact_allowed: bool
    energy_model: dict
    latency_model: dict
    failure_modes: list[str]
```

## Backend acceptance rule

```text
accept(result) iff:
  uncertainty(result) ≤ policy.max_uncertainty
  calibration_age ≤ contract.max_calibration_age
  verifier_passed = true
  backend_allowed_by_domain = true
```

## Backend selection logic

```text
CPU_EXACT:
  exact control, unit checking, low-level policy

CPU_INTERVAL:
  physics numeric, interval correctness

GPU_PLACEHOLDER:
  dense numeric approximate workloads

ANALOG_PLACEHOLDER:
  approximate dense workloads only, never security

SYMBOLIC_PLACEHOLDER:
  proof/specification operations
```

## Required backend demos

```text
[PASS] CPU exact selected for security
[PASS] CPU interval selected for interval arithmetic
[PASS] GPU placeholder selected for matrix workload
[PASS] analog placeholder rejected in security domain
[PASS] expired calibration rejects backend
[PASS] verifier failure rejects backend
[PASS] backend output contains uncertainty metadata
```

---

# 13. Stage 2 Layer F — Scheduler Cost Model

## Purpose

Stage 2 introduces scheduling without pretending to be a full OS scheduler.

It selects execution backends based on a cost objective.

## Universal scheduler objective

```text
J = αT + βE + γU + δL + ηR + κC
```

Where:

```text
T = runtime cost
E = energy cost
U = uncertainty growth
L = lateness / deadline violation
R = risk / security exposure
C = calibration or backend cost
```

## Task declaration

```json
{
  "task": "solve_heat_equation",
  "deadline_ms": 100,
  "max_uncertainty": 0.001,
  "energy_preference": "low",
  "backend_allowed": ["cpu_interval", "gpu_stub", "analog_stub"],
  "security_exact": false
}
```

## Scheduler decision table

```text
small/exact/control-heavy       → CPU_EXACT
numeric + interval required     → CPU_INTERVAL
dense/vectorizable              → GPU_PLACEHOLDER
streaming/deterministic         → FPGA_PLACEHOLDER
approximate/dense/error-tolerant→ ANALOG_PLACEHOLDER
proof required                  → SYMBOLIC_PLACEHOLDER
```

## Required scheduler outputs

```json
{
  "selected_backend": "cpu_interval",
  "reason": "max_uncertainty policy requires interval backend",
  "estimated_cost": {
    "T": 0.12,
    "E": 0.20,
    "U": 0.0004,
    "L": 0.0,
    "R": 0.01,
    "C": 0.0,
    "J": 0.154
  }
}
```

## Stage 2 scheduler tests

```text
[PASS] exact task never goes to analog
[PASS] dense approximate task prefers GPU/analog stub
[PASS] calibration cost changes backend choice
[PASS] high uncertainty penalty forces CPU interval
[PASS] deadline penalty changes selection
[PASS] security risk dominates speed
```

---

# 14. Stage 2 Layer G — Linux Compatibility Harness

## Runtime components

```text
physicsd      — optional background daemon
libphysos.so  — user-space API target
physrun       — command runner
physbench     — benchmark suite
physcheck     — validator/proof checker
physledger    — ledger viewer
```

Stage 2 may begin in Python, but the API should be shaped so it can become a Rust/C ABI.

## CLI commands

```bash
physrun demos/equality.py
physrun demos/conservation.py
physrun demos/field_memory.py

physbench all --out results/stage2_bench.json
physcheck ledger results/run_0001.ledger.json
physledger view results/run_0001.ledger.json
```

## Python API

```python
from physos import PhysVal, Unit, conserve, FieldRegion, BackendPolicy

a = PhysVal.float(0.1, uncertainty=1e-16)
b = PhysVal.float(0.2, uncertainty=1e-16)
c = PhysVal.float(0.3, uncertainty=1e-16)

print((a + b).equals(c))
```

Expected:

```text
true within tolerance
interval overlap: yes
confidence: 0.999999
ledger entry: led:000042
```

## Stage 2 Linux harness law

```text
PhysicsOS Stage 2 runs inside Linux, but every PhysicsOS operation emits typed metadata and ledger evidence.
```

---

# 15. Stage 2 Layer H — Proof / Benchmark Ledger

## Purpose

Every meaningful run emits a ledger.

The ledger is not decorative. It is the evidence system.

## Ledger entry

```python
@dataclass
class LedgerEntry:
    run_id: str
    entry_id: str
    timestamp_ns: int
    operation: str
    inputs_hash: str
    outputs_hash: str
    unit_check: str
    zero_check: str
    interval_check: str
    provenance_check: str
    backend_used: str
    uncertainty_before: dict
    uncertainty_after: dict
    violations: list[str]
    overhead: dict
    parent_hash: str
    entry_hash: str
```

## Example ledger

```json
{
  "run_id": "physos-000042",
  "program": "heat_equation_demo",
  "backend": "cpu_interval",
  "values_checked": 18392,
  "unit_errors": 0,
  "zero_violations": 0,
  "conservation_violations": 1,
  "max_uncertainty": 0.00083,
  "rollback_events": 0,
  "efficiency": {
    "useful_work": 0.82,
    "control_overhead": 0.04,
    "memory_overhead": 0.07,
    "error_overhead": 0.03,
    "calibration_overhead": 0.00,
    "translation_overhead": 0.04,
    "xi": 0.82
  }
}
```

## Ledger laws

```text
Every demo emits a ledger.
Every violation emits a ledger entry.
Every backend decision is ledgered.
Every tolerance relaxation is ledgered.
Every conservation result is ledgered.
Every Xi score is ledgered with overhead details.
```

---

# 16. Stage 2 Efficiency Metric

## Formula

```text
Ξ = W_useful / (W_useful + O_control + O_memory + O_error + O_calibration + O_translation)
```

## Stage 2 target values

Do **not** chase 0.999 yet.

Stage 2 targets:

```text
Ξ ≥ 0.70 for numerical workloads
Ξ ≥ 0.50 for mixed workloads
Ξ ≥ 0.90 for simple interval arithmetic demos
Ξ ≥ 0.95 for conservation checking on structured simulations
```

## Overhead definitions

```text
W_useful:
  useful domain work completed

O_control:
  type checks, policy checks, zero checks, unit checks

O_memory:
  metadata storage, field memory operations, coarsening/refinement

O_error:
  interval propagation, verifier checks, recovery overhead

O_calibration:
  backend calibration and calibration validation

O_translation:
  Python/Linux wrapper, compatibility layer, serialization
```

## Required report

```text
Useful work:              1000.00 units
Control overhead:           74.00
Memory overhead:           112.00
Error overhead:             51.00
Calibration overhead:        0.00
Translation overhead:        88.00

Xi = 1000 / (1000 + 74 + 112 + 51 + 0 + 88)
Xi = 0.7547
```

## Rule

```text
No Xi value is valid unless every overhead category is present.
```

---

# 17. Stage 2 MVP Modules

## Module 1 — `physval.py`

Handles:

```text
PhysVal
TypedZero
TypedNaN
intervals
confidence
provenance
backend metadata
domain metadata
```

## Module 2 — `units.py`

Handles:

```text
dimension vectors
unit parsing
unit algebra
unit validation
unit errors
```

## Module 3 — `uncertainty.py`

Handles:

```text
uncertainty categories
interval propagation
affine-lite dependency tags
infinite uncertainty
undefined propagation
```

## Module 4 — `field.py`

Handles:

```text
FieldRegion
evaluate
store
refine
coarsen
snapshot
rollback
diff
compression metrics
```

## Module 5 — `constraints.py`

Handles:

```text
conserve
assert_units
assert_interval
assert_provenance
boundary terms
tolerance policies
```

## Module 6 — `backends.py`

Handles:

```text
BackendContract
CPU exact backend
CPU interval backend
GPU placeholder
analog placeholder
symbolic placeholder
verifier hooks
```

## Module 7 — `scheduler.py`

Handles:

```text
task declaration
backend selection
cost objective J
deadline policy
energy policy
uncertainty policy
risk policy
calibration cost
```

## Module 8 — `ledger.py`

Handles:

```text
run logs
proof logs
benchmark metrics
violation records
hash chain
ledger export
ledger validation
```

## Module 9 — `cli.py`

Handles:

```text
physrun
physbench
physcheck
physledger
```

---

# 18. Stage 2 Reference API

## Create a PhysVal

```python
temperature = PhysVal(
    value=293.15,
    uncertainty=Uncertainty(measurement=0.05),
    unit=Unit.KELVIN,
    zero_type=ZeroType.NOT_ZERO,
    provenance=Provenance.source("sensor:temp0"),
    backend=BackendInfo("sensor_interval"),
    confidence=0.99,
    domain=Domain.SENSOR_DATA
)
```

## Safe equality

```python
temperature.equals(
    PhysVal(
        value=293.16,
        uncertainty=Uncertainty(measurement=0.05),
        unit=Unit.KELVIN,
        zero_type=ZeroType.NOT_ZERO,
        provenance=Provenance.source("sensor:temp1"),
        backend=BackendInfo("sensor_interval"),
        confidence=0.99,
        domain=Domain.SENSOR_DATA
    ),
    tolerance=0.95
)
```

## Conservation check

```python
conserve(
    name="energy",
    before=E0,
    after=E1,
    boundary=Q_in - W_out,
    tolerance=PhysVal.energy(0.001),
    ledger=ledger
)
```

## Field memory

```python
heat = FieldRegion(
    shape=(256, 256),
    basis="dense_grid",
    unit=Unit.KELVIN,
    default_uncertainty=Uncertainty(measurement=0.01),
    backend=BackendInfo("cpu_interval")
)

heat.evaluate(point=(12.5, 91.2))
```

## Backend contract

```python
backend = BackendContract(
    backend_id="gpu_float32_stub",
    backend_type=BackendType.GPU_PLACEHOLDER,
    supports=["matmul", "field_interpolate"],
    precision_bits_effective=(16, 24),
    noise_model="rounding_float32",
    drift_model=None,
    calibration_required=False,
    calibration_age_ms=0,
    max_calibration_age_ms=0,
    verifier="residual_check",
    security_allowed=False,
    exact_allowed=False
)
```

---

# 19. Stage 2 Internal Constitution

These are non-negotiable.

```text
1. No untyped zero.
2. No unitless physics value unless declared dimensionless.
3. No approximate value in security decisions.
4. No backend result without uncertainty metadata.
5. No conservation claim without boundary terms.
6. No efficiency claim without overhead accounting.
7. No analog result without calibration metadata.
8. No field coarsening without reconstruction error.
9. No “cannot crash” claim; only bounded containment.
10. No golden-ratio rule without ablation benchmark.
11. No exotic equation without variables, units, observables, and null hypothesis.
12. No Linux replacement claim before ABI compatibility testing.
```

This constitution protects the project from drifting back into overclaiming.

---

# 20. Stage 2 Experimental Suite

## Experiment 1 — Floating Equality Repair

Input:

```text
0.1 + 0.2 ≈ 0.3
```

Pass condition:

```text
intervals overlap
unit valid
zero violations = 0
ledger generated
```

Expected output:

```text
raw_float_equal: false
physos_equal: true
confidence: reported
```

---

## Experiment 2 — Divide-by-Zero Containment

Input:

```text
a / b where interval(b) includes 0
```

Expected:

```text
UndefinedDomain
uncertainty = infinity
zero_type = ForbiddenOperandZero
no process crash
ledger violation recorded
```

---

## Experiment 3 — Unit Error Detection

Input:

```text
3 meters + 4 seconds
```

Expected:

```text
UnitFault
operation rejected
ledger records dimensional mismatch
```

---

## Experiment 4 — Conservation Debugger

Run toy physical simulation.

Expected:

```text
energy drift detected
boundary term estimated
tolerance violation logged
```

Example:

```text
E_before = 100 J
E_after = 91 J
boundary_loss = 2 J
tolerance = 0.1 J

violation = 7 J unexplained
```

---

## Experiment 5 — Field Memory Coarsening

Create a 2D heat field.

Operations:

```text
store values
evaluate point
coarsen field
reconstruct field
measure error
rollback snapshot
```

Expected:

```text
compression ratio recorded
max reconstruction error recorded
coarsened data marked security_allowed=false
exact/security object not coarsened
ledger generated
```

---

## Experiment 6 — Backend Selection

Run matrix multiplication under different policies.

Expected:

```text
exact mode          → CPU_EXACT
interval mode       → CPU_INTERVAL
fast approximate    → GPU_PLACEHOLDER
security mode       → approximate backend rejected
expired calibration → backend rejected
```

---

## Experiment 7 — Proof Ledger Reproducibility

Run demo twice using same seed.

Expected:

```text
same inputs
same backend contracts
same policy state
same ledger decisions
same final state
```

---

## Experiment 8 — Xi Accounting

Run benchmark suite.

Expected:

```text
all overhead categories present
Xi computed honestly
no hidden calibration/translation cost
```

---

# 21. Stage 2 Benchmark Protocol

## Benchmarks

```text
B1: PhysVal construction overhead
B2: typed-zero boundary validation
B3: interval addition/multiplication/division
B4: unit algebra overhead
B5: conservation check overhead
B6: field evaluate/store overhead
B7: field coarsening/reconstruction error
B8: backend contract validation
B9: scheduler backend selection
B10: ledger write/validate overhead
B11: replay determinism
B12: Xi report generation
```

## Metrics per benchmark

```text
operation_count
runtime_ms
memory_mb
metadata_bytes_per_value
ledger_bytes_per_operation
unit_faults_detected
zero_faults_detected
conservation_faults_detected
false_accept_count
false_reject_count
Xi
```

## Benchmark output schema

```json
{
  "benchmark": "field_coarsen",
  "operations": 1000,
  "runtime_ms": 124.8,
  "memory_mb_before": 64.0,
  "memory_mb_after": 21.5,
  "compression_ratio": 2.97,
  "max_reconstruction_error": 0.043,
  "metadata_overhead_bytes_per_value": 96,
  "ledger_bytes_per_operation": 180,
  "xi": 0.721
}
```

---

# 22. Stage 2 Directory Blueprint

```text
physos_stage2/
  physos/
    __init__.py
    physval.py
    zero.py
    nan.py
    units.py
    uncertainty.py
    provenance.py
    intervals.py
    constraints.py
    field.py
    backends.py
    scheduler.py
    ledger.py
    policies.py
    cli.py

  demos/
    demo_equality.py
    demo_div_zero.py
    demo_units.py
    demo_conservation.py
    demo_field_memory.py
    demo_backend_selection.py
    demo_ledger_replay.py
    demo_xi.py

  tests/
    test_physval.py
    test_zero.py
    test_units.py
    test_uncertainty.py
    test_constraints.py
    test_field.py
    test_backends.py
    test_scheduler.py
    test_ledger.py

  benchmarks/
    bench_physval.py
    bench_interval.py
    bench_units.py
    bench_field.py
    bench_backends.py
    bench_ledger.py

  docs/
    stage2_architecture.md
    stage2_api.md
    stage2_benchmark_protocol.md
    stage2_ip_claim_map.md
    stage2_results.md

  results/
    ledgers/
    benchmarks/
    reports/

  README.md
  pyproject.toml
```

---

# 23. Stage 2 Development Timeline

## Week 1 — Core Runtime ABI

Deliver:

```text
PhysVal
ZeroType
NaNType
Unit
Uncertainty
Provenance
Interval
```

Demos:

```text
equality
division by zero
unit mismatch
```

Tests:

```text
test_physval
test_zero
test_units
test_uncertainty
```

---

## Week 2 — Constraint Plane + Ledger

Deliver:

```text
conserve()
assert_units()
assert_interval()
assert_provenance()
LedgerEntry
Ledger hash chain
ledger export/validate
```

Demos:

```text
conservation debugger
ledger output
ledger validation
```

---

## Week 3 — Field Memory

Deliver:

```text
FieldRegion
evaluate
store
coarsen
refine stub
snapshot
rollback
diff
reconstruction error
```

Demos:

```text
heat field creation
coarsening
rollback
error bound
```

---

## Week 4 — Backends + Scheduler

Deliver:

```text
BackendContract
CPU_EXACT
CPU_INTERVAL
GPU_PLACEHOLDER
ANALOG_PLACEHOLDER
SYMBOLIC_PLACEHOLDER
Scheduler objective J
backend selection
```

Demos:

```text
backend selection
expired calibration rejection
security rejection
```

---

## Week 5 — Benchmarks + Reports

Deliver:

```text
physbench
physrun
physcheck
stage2_results.md
stage2_ip_claim_map.md
benchmark JSON
ledger artifacts
```

Stage 2 can be done in 4 weeks aggressively, 5–6 weeks cleanly.

---

# 24. Stage 2 Acceptance Criteria

Stage 2 is complete when:

```text
[ ] PhysVal serializes/deserializes with value, interval, unit, uncertainty, provenance, backend.
[ ] Untyped zero is rejected at runtime boundaries.
[ ] UnknownZero must be refined before use.
[ ] Division by zero returns typed UndefinedDomain, not crash.
[ ] Unit algebra rejects incoherent operations.
[ ] Contextual equality validates 0.1 + 0.2 ≈ 0.3.
[ ] Conservation checker detects drift with boundary terms.
[ ] FieldRegion supports evaluate/store/coarsen/snapshot/rollback.
[ ] Field coarsening records reconstruction error.
[ ] Backend contracts validate uncertainty, calibration, verifier, and domain.
[ ] Scheduler selects backend using J = αT + βE + γU + δL + ηR + κC.
[ ] Approximate backend is rejected in security mode.
[ ] Every demo emits a ledger.
[ ] Every ledger validates hash chain.
[ ] Benchmarks output Xi with all overhead categories.
[ ] Stage 2 report generated.
```

---

# 25. Stage 2 Failure Conditions

Stage 2 fails if:

```text
[FAIL] any untyped zero is accepted silently
[FAIL] approximate value authorizes security
[FAIL] unit mismatch is allowed
[FAIL] division by zero crashes process
[FAIL] backend output lacks uncertainty metadata
[FAIL] conservation check omits boundary terms
[FAIL] coarsening lacks error bound
[FAIL] Xi omits overhead category
[FAIL] ledger cannot reproduce decision chain
[FAIL] claims 0.999 efficiency without measurement
```

---

# 26. Stage 2 IP Capture

Stage 2 should produce stronger IP artifacts than Stage 1.

## Invention cards to update

```text
IC-01 Typed-Zero ABI
IC-02 PhysVal Typed Value ABI
IC-03 Unit-Carrying Runtime Values
IC-04 Interval Equality Boundary Semantics
IC-05 Conservation-Law Runtime Contracts
IC-06 Field Memory Object with Error-Bounded Coarsening
IC-07 Backend Contract System
IC-08 Scheduler Cost Model for Exact/Approx Workloads
IC-09 Proof Ledger for Uncertainty-Carrying Runtime
IC-10 Xi Efficiency Accounting with Calibration/Translation Overheads
```

## Each invention card must include

```text
problem
prior failure mode
mechanism
data structure
runtime flow
example output
technical advantage
stage 2 demo evidence
claim language seed
prior-art risk
```

## Stage 2 provisional-ready titles

```text
Typed Value Runtime ABI for Exact and Approximate Computation

Field Memory Objects with Error-Bounded Coarsening and Security Exclusion

Backend Contract Validation for Approximate Accelerated Computation

Runtime Conservation-Law Contracts with Unit and Uncertainty Enforcement

Proof Ledger for Reproducible Uncertainty-Carrying Computation
```

---

# 27. Stage 2 144-Point Build Matrix

## A. PhysVal / Typed Value System 1–12

1. PhysVal dataclass implemented.
2. Interval bounds implemented.
3. Uncertainty object implemented.
4. Domain enum implemented.
5. BackendInfo implemented.
6. Provenance object implemented.
7. Confidence score implemented.
8. JSON serialization implemented.
9. JSON deserialization implemented.
10. PhysVal hashing implemented.
11. PhysVal ledger export implemented.
12. PhysVal tests pass.

## B. Typed Zero / Undefined 13–24

13. ZeroType enum implemented.
14. NaNType enum implemented.
15. UntypedZero boundary rejection.
16. UnknownZero refinement rejection.
17. MeasuredAbsence accepted in sensor domain.
18. NullCapability accepted only in security domain.
19. ForbiddenOperandZero blocks division.
20. UnderflowZero records collapsed threshold.
21. Typed undefined object implemented.
22. Recovery policy field implemented.
23. Zero policy table implemented.
24. Zero tests pass.

## C. Arithmetic / Intervals 25–36

25. Addition interval propagation.
26. Subtraction interval propagation.
27. Multiplication interval propagation.
28. Division interval validation.
29. Log validation.
30. Trig validation.
31. Normalization validation.
32. Contextual equality.
33. Overlap probability.
34. Confidence result.
35. Interval serialization.
36. Arithmetic tests pass.

## D. Units 37–48

37. Unit vector implemented.
38. Unit parser.
39. Unit formatter.
40. Addition unit check.
41. Multiplication unit algebra.
42. Division unit algebra.
43. Exponentiation rule.
44. Log dimensionless rule.
45. Trig dimensionless/radian rule.
46. UnitFault implemented.
47. Unit ledger entry.
48. Unit tests pass.

## E. Uncertainty 49–60

49. Measurement uncertainty.
50. Rounding uncertainty.
51. Model uncertainty.
52. Hardware uncertainty.
53. Time uncertainty.
54. Security uncertainty.
55. Root-sum-square propagation.
56. Interval widening.
57. Affine-lite dependency tags.
58. Infinite uncertainty.
59. Uncertainty serialization.
60. Uncertainty tests pass.

## F. Constraints 61–72

61. ConstraintResult object.
62. CONSERVE general form.
63. Energy conservation.
64. Momentum conservation.
65. Charge conservation.
66. Ledger/finance conservation.
67. ASSERT_UNITS.
68. ASSERT_INTERVAL.
69. ASSERT_PROVENANCE.
70. Boundary terms required.
71. Tolerance policy.
72. Constraint tests pass.

## G. Field Memory 73–84

73. FieldRegion object.
74. Dense grid basis.
75. Wavelet/downsample coarsening.
76. Field evaluate.
77. Field store.
78. Field unit validation.
79. Field uncertainty map.
80. Field coarsen.
81. Reconstruction error bound.
82. Field snapshot.
83. Field rollback.
84. Field tests pass.

## H. Backend Contracts 85–96

85. BackendContract object.
86. CPU exact backend.
87. CPU interval backend.
88. GPU placeholder backend.
89. FPGA placeholder backend.
90. Analog placeholder backend.
91. Symbolic placeholder backend.
92. Calibration validation.
93. Verifier hook.
94. Security_allowed flag enforcement.
95. Backend rejection ledger.
96. Backend tests pass.

## I. Scheduler 97–108

97. TaskDeclaration object.
98. Scheduler policy object.
99. Cost objective `J`.
100. Runtime cost estimate.
101. Energy cost estimate.
102. Uncertainty growth estimate.
103. Lateness penalty.
104. Risk penalty.
105. Calibration cost.
106. Backend choice explanation.
107. Scheduler ledger entry.
108. Scheduler tests pass.

## J. Ledger 109–120

109. LedgerEntry object.
110. RunID.
111. EntryID.
112. Timestamp.
113. Input hash.
114. Output hash.
115. Parent hash.
116. Entry hash.
117. Ledger append.
118. Ledger validate.
119. Ledger export.
120. Ledger tests pass.

## K. CLI / Linux Harness 121–132

121. `physrun` command.
122. `physbench` command.
123. `physcheck` command.
124. `physledger` command.
125. Demo runner.
126. Benchmark runner.
127. Report generator.
128. JSON output.
129. Markdown report output.
130. Error display.
131. Linux path handling.
132. CLI tests pass.

## L. Reports / IP / Validation 133–144

133. Stage 2 architecture doc.
134. Stage 2 API doc.
135. Benchmark protocol doc.
136. Stage 2 results doc.
137. IP claim map.
138. Invention cards updated.
139. Demo outputs captured.
140. Benchmark outputs captured.
141. Ledger samples archived.
142. Known limitations listed.
143. Stage 3 handoff notes.
144. Stage 2 acceptance gate signed off.

---

# 28. Stage 2 “Novelty Compression”

The breakthrough of Stage 2 is not one module.

It is the combined runtime rule:

```text
Every physical/numeric value carries type, unit, interval, uncertainty,
zero-status, provenance, backend, and confidence;
every operation checks those contracts;
every violation is ledgered;
every efficiency claim accounts for overhead.
```

That is the minimum real PhysicsOS substrate.

---

# 29. Stage 2 Final Directive

```text
DIRECTIVE: PHYSICSOS_STAGE_2_RUNTIME_KERNEL_PROTOTYPE

OBJECTIVE:
Build a Linux-hosted PhysicsOS runtime substrate that upgrades Stage 1
typed semantics into a protocol stack for uncertainty-aware computation.

CORE DELIVERABLES:
1. PhysVal ABI with value, interval, unit, uncertainty, zero type, provenance, backend, confidence.
2. Typed-zero ABI rejecting untyped and unknown zero at runtime boundaries.
3. Interval arithmetic and contextual equality.
4. Unit-carrying arithmetic with dimensional analysis.
5. Typed uncertainty propagation engine.
6. Conservation-law checker with boundary terms.
7. FieldRegion memory object with evaluate/store/coarsen/snapshot/rollback.
8. Backend contract system for CPU/GPU/analog/symbolic placeholders.
9. Scheduler cost model over time, energy, uncertainty, lateness, risk, and calibration.
10. Linux CLI harness: physrun, physbench, physcheck, physledger.
11. Proof ledger emitting reproducible evidence for every run.
12. Xi efficiency reporter with all overhead categories.

NON-GOALS:
- No bare metal.
- No full OS.
- No real drivers.
- No full POSIX.
- No unsupported 0.999 efficiency.
- No approximate security.
- No mythic claims as engineering claims.

COMPLETION CONDITION:
Stage 2 is complete when all demos, tests, benchmarks, ledgers,
and reports validate that PhysicsOS can execute typed, unit-aware,
uncertainty-aware, provenance-aware runtime operations inside Linux.

MOTTO:
Exact where authority matters.
Approximate where reality demands it.
Typed everywhere.
Ledgered always.
```

Stage 2 victory condition:

> **PhysicsOS stops being a value-system concept and becomes a Linux-hosted executable truth-bounded runtime substrate.**
