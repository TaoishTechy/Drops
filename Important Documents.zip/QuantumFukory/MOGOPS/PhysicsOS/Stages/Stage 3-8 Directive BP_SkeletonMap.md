Yes — that is the right mindset. Stage 3+ should not be fully “filled in” yet because it will need real feedback from Stage 2: benchmark results, pain points, ledger shape, API friction, which abstractions survived, and which were too heavy.

So the correct artifact now is a **Stage 3+ skeleton framework**: enough structure to guide future expansion, but not so rigid that it ignores Stage 2 discoveries.

# PhysicsOS v2.0 — Stage 3+ Foundation Skeleton

## Microkernel-Shaped Runtime → Kernel Prototype → Verified Substrate

## Core premise

Stage 1 proves the semantics.

Stage 2 builds the Linux-hosted runtime substrate.

Stage 3 begins shaping that substrate like an operating system.

The merged PhysicsOS v2.0 document already defines the long-range direction: typed values, typed zero, interval/uncertainty semantics, exact security separation, field memory, backend contracts, Linux compatibility in user space, and falsifiable overhead accounting through `Xi`. 

Stage 3+ should therefore evolve from this principle:

> **Every computation is either exact-control or approximate-physics, and every crossing between them is mediated by a typed, ledgered, replayable contract.**

---

# 1. Stage 3 Purpose

Stage 3 should not yet be a real OS.

It should be a **Linux-hosted microkernel simulator**.

Meaning:

```text
Stage 3 =
  Stage 2 runtime substrate
+ process objects
+ capability objects
+ syscall-like contract layer
+ object table
+ message passing
+ field memory manager
+ backend broker
+ deterministic scheduler loop
+ rollback / snapshot system
+ hash-chained ledger
+ minimal POSIX-like shim
+ formal invariant skeleton
```

The goal is to prove that PhysicsOS can behave like a small OS **without needing bare metal yet**.

---

# 2. Stage 3 Master Architecture

```text
PHYSICSOS STAGE 3
────────────────────────────────────────

Linux Host
  │
  ▼
PhysicsOS Microkernel Simulator
  │
  ├── Exact Control Plane
  │     ├── Process identity
  │     ├── Capabilities
  │     ├── Object ownership
  │     ├── Exact memory
  │     ├── Syscall authorization
  │     └── Ledger integrity
  │
  ├── Approximate Physics Plane
  │     ├── PhysVal operations
  │     ├── Unit-carrying values
  │     ├── Interval / affine arithmetic
  │     ├── FieldRegion objects
  │     ├── Conservation contracts
  │     └── Backend uncertainty
  │
  ├── Contract Boundary Layer
  │     ├── Zero checks
  │     ├── Unit checks
  │     ├── Uncertainty checks
  │     ├── Provenance checks
  │     ├── Backend checks
  │     └── Capability checks
  │
  ├── Scheduler / Backend Broker
  │     ├── Time cost
  │     ├── Energy cost
  │     ├── Uncertainty cost
  │     ├── Risk cost
  │     ├── Calibration cost
  │     └── Deadline cost
  │
  └── Replayable Proof Ledger
        ├── Syscall entries
        ├── Fault entries
        ├── Backend entries
        ├── Rollback entries
        ├── Policy entries
        └── Hash chain
```

Stage 3 is successful when PhysicsOS becomes a **miniature governed runtime**, not just a numerical library.

---

# 3. Stage 3 Kernel Object Model

Everything important becomes an object.

```text
KernelObject :=
  Process
  Capability
  ExactMemory
  FieldRegion
  BackendContract
  ConstraintContract
  LedgerStream
  Snapshot
  MessagePort
  FileObject
  RuntimePolicy
```

Every object has a common header:

```text
ObjectHeader = {
  object_id,
  object_type,
  owner_process,
  rights_required,
  provenance_hash,
  created_at,
  mutable,
  exact_required,
  uncertainty_policy,
  ledger_anchor
}
```

This is the first major transition from runtime library to OS-like substrate.

---

# 4. Stage 3 Capability Skeleton

Capabilities replace user/root-style authority.

```text
Capability = {
  cap_id,
  subject_process,
  target_object,
  rights,
  attenuation_rules,
  expires_at,
  revocation_id,
  proof_hash
}
```

Rights:

```text
read
write
execute
refine
coarsen
snapshot
rollback
delegate
inspect_ledger
select_backend
```

Core law:

```text
No process mutates an object without a valid capability.
```

Stage 3 must enforce this everywhere.

No shortcuts. No “admin override.” No fuzzy authority.

---

# 5. Stage 3 Syscall Contract Skeleton

Stage 3 introduces syscall-like calls.

Not real kernel syscalls yet — structured runtime calls that behave like future syscalls.

```text
PhysSyscall = {
  syscall_id,
  caller_process,
  operation,
  input_objects,
  input_values,
  required_capabilities,
  uncertainty_policy,
  unit_policy,
  backend_policy,
  rollback_policy,
  ledger_policy
}
```

Result:

```text
PhysResult = {
  status,
  value,
  interval,
  unit,
  uncertainty,
  zero_type,
  backend_used,
  checks_performed,
  violations,
  ledger_entry_id
}
```

Initial syscall set:

```text
phys_create_process()
phys_create_value()
phys_add()
phys_mul()
phys_div()
phys_assert_units()
phys_create_field()
phys_field_eval()
phys_field_store()
phys_field_refine()
phys_field_coarsen()
phys_conserve()
phys_snapshot()
phys_rollback()
phys_select_backend()
phys_send()
phys_recv()
phys_emit_ledger()
```

---

# 6. Stage 3 Process Skeleton

A Stage 3 process is a sandboxed computation cell.

```text
PhysProcess = {
  pid,
  name,
  capabilities,
  exact_memory,
  field_regions,
  uncertainty_budget,
  energy_budget,
  backend_permissions,
  ledger_stream,
  message_ports,
  status,
  rollback_policy
}
```

Statuses:

```text
Ready
Running
Blocked
SuspendedForViolation
RolledBack
Terminated
```

Core law:

```text
A process cannot mutate another process’s memory, field, backend, ledger, or policy without a delegated capability.
```

---

# 7. Stage 3 Field Memory Manager

Stage 2 has `FieldRegion`.

Stage 3 turns it into a managed kernel object.

```text
ManagedFieldRegion = {
  object_id,
  owner_pid,
  shape,
  basis,
  coefficients,
  uncertainty_map,
  unit_map,
  backend_affinity,
  refinement_policy,
  coarsening_policy,
  snapshots,
  security_forbidden,
  exact_forbidden,
  ledger_anchor
}
```

Required operations:

```text
evaluate(point)
store(point, PhysVal)
refine(subdomain, target_error)
coarsen(max_error)
snapshot()
rollback(snapshot_id)
diff(other_region)
checksum()
```

Field safety laws:

```text
FieldRegion cannot store security secrets.
FieldRegion cannot decide authority.
FieldRegion cannot be used as exact memory.
FieldRegion coarsening must record reconstruction error.
FieldRegion rollback must restore coefficients and uncertainty maps.
```

This preserves the core exact/approximate separation.

---

# 8. Stage 3 Message Passing

Stage 3 should use microkernel-style message passing.

```text
PhysMessage = {
  sender_pid,
  receiver_pid,
  payload,
  attached_capabilities,
  uncertainty_summary,
  provenance_hash,
  exact_control_only,
  ledger_entry_id
}
```

Rules:

```text
Exact-control messages cannot include approximate decision values.
Physics messages must include uncertainty summaries.
Capabilities can be delegated only if attenuation rules allow it.
Every message is ledgered.
```

This prepares PhysicsOS for a future seL4-like structure without trying to become seL4 immediately.

---

# 9. Stage 3 Backend Broker

The backend broker chooses where work runs.

Backends:

```text
CPU_EXACT
CPU_INTERVAL
GPU_FLOAT
GPU_INTERVAL
FPGA_STREAM
ANALOG_IMC
SYMBOLIC_PROVER
SOFTWARE_EMULATED
```

Backend contract:

```text
BackendContract = {
  backend_id,
  backend_type,
  supported_ops,
  precision_bounds,
  uncertainty_model,
  calibration_state,
  calibration_expiry,
  verification_method,
  energy_model,
  latency_model,
  security_allowed,
  exact_allowed,
  failure_modes
}
```

Backend allowed iff:

```text
operation ∈ supported_ops
process has backend capability
uncertainty_model satisfies policy
calibration is valid
security_allowed matches domain
verifier is available if required
```

Backend decision objective:

```text
J = αT + βE + γU + δL + ηR + κC
```

Where:

```text
T = expected runtime
E = expected energy
U = expected uncertainty growth
L = deadline penalty
R = risk penalty
C = calibration / verification cost
```

---

# 10. Stage 3 Fault System

Faults must be typed.

```text
Fault :=
  UnitFault
  ZeroDomainFault
  UncertaintyOverflow
  ConservationViolation
  CapabilityViolation
  BackendCalibrationFault
  BackendVerifierFault
  FieldReconstructionFault
  DeadlineFault
  LedgerIntegrityFault
  ReplayMismatchFault
  PolicyViolation
```

Fault response pipeline:

```text
detect
classify
ledger
contain
attempt local recovery
rollback if allowed
suspend process if boundary crossed
escalate if kernel invariant threatened
```

Core law:

```text
No fault may silently relax policy.
```

If the system widens tolerance, coarsens memory, switches backend, or accepts degraded output, the ledger must say so.

---

# 11. Stage 3 Rollback Skeleton

Rollback becomes a first-class operation.

```text
Snapshot = {
  snapshot_id,
  object_ids,
  field_coefficients_hash,
  exact_memory_hash,
  uncertainty_state,
  capability_state_hash,
  backend_contract_hash,
  created_by,
  created_at,
  ledger_entry_id
}
```

Rollback allowed iff:

```text
caller has rollback capability
snapshot hash validates
rollback does not resurrect revoked capabilities
field uncertainty state is restored
ledger appends rollback event
```

Critical law:

```text
Rollback never deletes history.
```

It appends correction history.

That law matters for trust.

---

# 12. Stage 3 Ledger Skeleton

Stage 3 ledger becomes the proof spine.

```text
LedgerEntry = {
  entry_id,
  timestamp,
  pid,
  operation,
  input_hashes,
  output_hashes,
  capabilities_checked,
  backend_used,
  uncertainty_before,
  uncertainty_after,
  unit_check,
  zero_check,
  conservation_check,
  violations,
  policy_changes,
  parent_entry,
  entry_hash
}
```

Hash chain:

```text
entry_hash_n = H(entry_n || entry_hash_{n-1})
```

Ledger laws:

```text
Every syscall emits one entry.
Every violation emits one entry.
Every rollback emits one entry.
Every backend decision emits one entry.
Every policy relaxation emits one entry.
Every replay validation emits one entry.
```

---

# 13. Stage 3 Minimal POSIX-Like Shim

Do not attempt full POSIX.

Implement:

```text
open
read
write
close
mmap_field
snapshot
rollback
spawn
send
recv
wait
exit
```

Mapping:

```text
open/read/write → exact file objects
mmap_field      → FieldRegion object
spawn           → PhysProcess
send/recv       → message passing
wait            → process status join
exit            → capability cleanup
```

Explicitly not supported yet:

```text
fork
execve
signals
threads
full sockets
GPU drivers
dynamic linking
filesystem journaling
```

Stage 3 must remain humble.

---

# 14. Stage 3 Formal Spec Skeleton

Stage 3 should begin formalization, but not pretend it is complete.

Objects to model:

```text
Process
Capability
Object
Syscall
Result
Fault
Ledger
Snapshot
BackendContract
FieldRegion
```

Core invariants:

```text
I1: No object mutation without capability.
I2: No approximate value controls authority.
I3: No untyped zero crosses syscall boundary.
I4: No unit-incoherent operation succeeds.
I5: No backend result accepted without contract validation.
I6: No rollback deletes ledger history.
I7: No field coarsening occurs without reconstruction error bound.
I8: No security object is stored in FieldRegion.
I9: No silent tolerance relaxation.
I10: Replay determinism holds under fixed backend contracts.
```

This is the Stage 3 proof spine.

---

# 15. Stage 3 Directory Skeleton

```text
physos_stage3/
  kernel/
    objects.py
    capabilities.py
    process.py
    syscall.py
    scheduler.py
    faults.py
    rollback.py
    ledger.py

  physics/
    physval.py
    units.py
    uncertainty.py
    constraints.py
    field.py

  backends/
    contracts.py
    cpu_exact.py
    cpu_interval.py
    gpu_stub.py
    analog_stub.py
    symbolic_stub.py
    broker.py

  posix/
    shim.py
    fileobj.py
    message.py

  specs/
    invariants.md
    state_machine.md
    syscall_abi.md
    capability_model.md
    replay_model.md

  demos/
    demo_zero.py
    demo_units.py
    demo_conservation.py
    demo_field.py
    demo_rollback.py
    demo_scheduler.py
    demo_capabilities.py
    demo_replay.py

  tests/
    test_capabilities.py
    test_no_approx_security.py
    test_zero_boundary.py
    test_units.py
    test_rollback.py
    test_replay.py
    test_backend_policy.py
    test_ledger_integrity.py

  results/
    ledgers/
    benchmarks/
    reports/

  README.md
```

---

# 16. Stage 3 State Machine Skeleton

Kernel loop:

```text
BOOT
  ↓
INIT_OBJECT_TABLE
  ↓
LOAD_BACKEND_CONTRACTS
  ↓
CREATE_INIT_PROCESS
  ↓
SCHEDULER_LOOP
  ↓
EXECUTE_SYSCALL
  ↓
VALIDATE_RESULT
  ↓
LEDGER_COMMIT
  ↓
CONTINUE / SUSPEND / ROLLBACK / TERMINATE
```

Process operation lifecycle:

```text
REQUEST
  ↓
CAPABILITY_CHECK
  ↓
TYPE_CHECK
  ↓
UNIT_CHECK
  ↓
ZERO_CHECK
  ↓
BACKEND_SELECT
  ↓
EXECUTE
  ↓
VERIFY
  ↓
BUDGET_UPDATE
  ↓
LEDGER_APPEND
  ↓
RETURN
```

---

# 17. Stage 3 Test Battery Skeleton

## Security plane tests

```text
Process cannot mutate object without capability.
Delegated capability cannot exceed parent rights.
Revoked capability fails.
Approximate field value cannot authorize access.
Rollback cannot resurrect revoked capability.
Security object cannot be stored in FieldRegion.
```

## Physics plane tests

```text
0.1 + 0.2 interval-overlaps 0.3.
Division by interval containing zero returns ZeroDomainFault.
Meters plus seconds fails unit check.
Energy conservation drift is detected.
Field coarsening records reconstruction error.
Backend verifier failure rejects result.
```

## Ledger / replay tests

```text
Every syscall produces one ledger entry.
Ledger hash chain validates.
Rollback appends correction entry.
Replaying ledger reproduces object state.
Backend calibration state is recorded.
Policy relaxation is visible in ledger.
```

## Scheduler tests

```text
Exact task never selected for analog backend.
Approximate dense task prefers GPU stub when allowed.
Deadline task receives priority when risk is acceptable.
Calibration-expired backend is rejected.
Uncertainty-over-budget process is suspended.
Same seed produces same schedule.
```

---

# 18. Stage 3 Metrics Skeleton

Measure:

```text
capability violations blocked
unit faults detected
zero faults contained
conservation violations detected
field compression ratio
field reconstruction error
ledger replay success rate
backend rejection correctness
scheduler determinism
rollback success rate
approximate/exact boundary violations
```

Stage 3 targets:

```text
ledger coverage:              100% of syscalls
capability enforcement:       100% of object mutations
unit check coverage:          100% of PhysVal operations
zero boundary tagging:        100%
replay determinism:           ≥ 99% under CPU backend
field rollback success:       ≥ 99%
backend policy correctness:   ≥ 99%
Xi for toy physics demos:      0.60–0.85 acceptable
```

Correctness first. Speed later.

---

# 19. Stage 3 144-Point Build Matrix Skeleton

## A. Kernel Objects 1–12

1. Object header
2. Process object
3. Capability object
4. FieldRegion object
5. ExactMemory object
6. BackendContract object
7. ConstraintContract object
8. LedgerStream object
9. Snapshot object
10. MessagePort object
11. Object table
12. Object lifecycle rules

## B. Capabilities 13–24

13. Capability creation
14. Capability validation
15. Capability attenuation
16. Capability delegation
17. Capability revocation
18. Capability expiry
19. Capability proof hash
20. Rights map
21. Object-right matching
22. Process capability table
23. Revocation ledger entry
24. Capability fuzz tests

## C. Syscalls 25–36

25. Syscall envelope
26. Caller validation
27. Input object validation
28. Unit policy validation
29. Zero policy validation
30. Backend policy validation
31. Rollback policy validation
32. Result envelope
33. Fault result format
34. Ledger hook
35. Replay hook
36. Syscall ABI document

## D. Processes 37–48

37. Init process
38. Spawn process
39. Terminate process
40. Suspend process
41. Resume process
42. Process budgets
43. Process backend permissions
44. Process ledger stream
45. Process message inbox
46. Process field ownership
47. Process exact memory ownership
48. Process state tests

## E. Message Passing 49–60

49. Message object
50. Sender validation
51. Receiver validation
52. Payload hash
53. Capability attachment
54. Capability attenuation on send
55. Approximate payload summary
56. Exact-only payload rejection
57. Inbox queue
58. Receive syscall
59. Message ledger entry
60. Message replay

## F. Field Memory 61–72

61. Field creation
62. Field evaluate
63. Field store
64. Field refine
65. Field coarsen
66. Field snapshot
67. Field rollback
68. Field diff
69. Field checksum
70. Reconstruction error bound
71. Security-forbidden flag
72. Coarsening tests

## G. Backend Broker 73–84

73. Backend contract parser
74. CPU exact backend
75. CPU interval backend
76. GPU stub
77. FPGA stub
78. Analog stub
79. Symbolic stub
80. Calibration state
81. Backend verifier hook
82. Backend selection objective
83. Backend rejection ledger
84. Backend policy tests

## H. Scheduler 85–96

85. Ready queue
86. Blocked queue
87. Suspended queue
88. Operation cost estimation
89. Backend load tracking
90. Budget tracking
91. Deterministic seed
92. Schedule decision ledger
93. Deadline penalty
94. Uncertainty penalty
95. Risk penalty
96. Scheduler replay tests

## I. Faults 97–108

97. Fault enum
98. UnitFault
99. ZeroDomainFault
100. UncertaintyOverflow
101. ConservationViolation
102. CapabilityViolation
103. BackendCalibrationFault
104. BackendVerifierFault
105. FieldReconstructionFault
106. DeadlineFault
107. LedgerIntegrityFault
108. Fault containment policy

## J. Rollback 109–120

109. Snapshot creation
110. Snapshot validation
111. Field rollback
112. Exact memory rollback
113. Capability-state validation
114. Revocation preservation
115. Backend-contract hash check
116. Rollback authorization
117. Rollback ledger event
118. Replay after rollback
119. Corrupt snapshot rejection
120. Rollback tests

## K. Ledger 121–132

121. Entry format
122. Hash chain
123. Syscall logging
124. Fault logging
125. Backend logging
126. Scheduler logging
127. Rollback logging
128. Policy-change logging
129. Ledger validation
130. Ledger export
131. Ledger replay
132. Ledger tests

## L. POSIX Shim / Spec 133–144

133. open shim
134. read shim
135. write shim
136. close shim
137. spawn shim
138. send shim
139. recv shim
140. wait shim
141. exit shim
142. invariants.md
143. syscall_abi.md
144. state_machine.md

---

# 20. Stage 3 Victory Condition

Stage 3 is complete when:

```bash
physos run demos/demo_stage3.py
physos replay ledgers/demo_stage3.ledger
physos verify ledgers/demo_stage3.ledger
```

proves:

```text
1. No object was mutated without capability.
2. No approximate value made a security decision.
3. No untyped zero crossed a syscall boundary.
4. No invalid unit operation succeeded.
5. No backend result bypassed its contract.
6. Every syscall produced a ledger entry.
7. Every rollback appended history instead of deleting it.
8. Replay reproduced the same final object state.
```

That is the Stage 3 gate.

---

# 21. Stage 4 Skeleton — Executable Microkernel Simulator

Stage 4 should be the actual implementation of Stage 3.

```text
Stage 4 =
  implement Stage 3 skeleton
+ CLI runner
+ object table
+ syscall dispatcher
+ capability enforcement
+ field manager
+ backend broker
+ deterministic scheduler
+ replay verifier
+ benchmark suite
```

Stage 4 output:

```text
physos_stage4/
  working CLI
  demo suite
  replayable ledgers
  benchmark baseline
  invariant checker
```

Stage 4 motto:

> **No more architecture without executable proof.**

---

# 22. Stage 5 Skeleton — Microkernel Port Target

Stage 5 begins moving from simulator to real OS-adjacent substrate.

Possible paths:

```text
Path A: seL4 user-space service
Path B: Linux kernel module experiments
Path C: unikernel prototype
Path D: Rust microkernel prototype
Path E: WASM sandbox runtime
```

Recommended path:

```text
Stage 5A: seL4-style user-space service
Stage 5B: Rust runtime with C ABI
Stage 5C: WASM sandbox for process isolation
Stage 5D: optional seL4 integration study
```

Stage 5 goal:

> **Make PhysicsOS process isolation and capability semantics real enough to survive hostile workloads.**

---

# 23. Stage 6 Skeleton — Accelerator and Hardware Contracts

Stage 6 should focus on real backend integration.

Backends:

```text
CPU exact
CPU interval
GPU CUDA/OpenCL
WASM sandbox
FPGA simulation
analog simulator
eventual analog hardware
```

Stage 6 deliverables:

```text
real GPU backend
uncertainty-aware kernel wrapper
calibration metadata
verifier hooks
scheduler backend comparison
Xi benchmark reports
```

Goal:

> **Prove backend contracts can make approximate acceleration trustworthy without contaminating exact control.**

---

# 24. Stage 7 Skeleton — Formal Verification Track

Stage 7 begins formal methods seriously.

Targets:

```text
TLA+ state model
Lean/Coq invariant models
capability safety proof
no approximate authority proof
ledger append-only proof
rollback non-resurrection proof
unit check soundness proof
zero boundary proof
```

Formal claims should be narrow.

Do not try to prove all of PhysicsOS.

Prove:

```text
No object mutation without capability.
No approximate value controls authority.
Rollback does not erase ledger history.
Untyped zero cannot cross syscall boundary.
```

Those are enough.

---

# 25. Stage 8 Skeleton — Scientific Workload Validation

Stage 8 should target real scientific workloads.

Best domains:

```text
heat equation
wave equation
N-body toy simulation
sensor fusion
robotics control loop
financial ledger invariant
ML inference reproducibility
GPU numerical drift
```

Goal:

> **Show PhysicsOS catches real numerical, unit, backend, and conservation errors that normal runtimes miss.**

---

# 26. Long-Range Development Map

```text
Stage 1 — Semantic MVP
  Typed values, zero, NaN, exact/approx split.

Stage 2 — Runtime Substrate
  PhysVal ABI, units, uncertainty, field memory, backend contracts, ledger.

Stage 3 — Microkernel-Shaped Skeleton
  Processes, capabilities, syscall contracts, rollback, object model.

Stage 4 — Executable Microkernel Simulator
  Implement Stage 3 skeleton with CLI, tests, replay.

Stage 5 — Isolation / OS-Adjacent Prototype
  WASM, seL4-style service, Rust runtime, stronger sandboxing.

Stage 6 — Real Backend Integration
  GPU/FPGA/analog contracts, verifier hooks, calibration-aware scheduling.

Stage 7 — Formal Verification Track
  Narrow proofs for capability, zero, authority, rollback, ledger.

Stage 8 — Scientific Workload Validation
  Real simulations, robotics, sensor fusion, ML reproducibility.

Stage 9 — External Review / IP Hardening
  White paper, patent family, benchmarks, hostile review.

Stage 10 — PhysicsOS Kernel Research Program
  Decide whether actual OS/kernel path is justified.
```

---

# 27. Contextual Insight Slots for Future Work

Stage 3+ should reserve explicit places for lessons learned.

## After Stage 2, fill:

```text
Stage2_Lessons = {
  heaviest_metadata_cost,
  worst_API_friction,
  most_useful_demo,
  weakest abstraction,
  best IP claim,
  hardest bug class,
  most convincing benchmark,
  least useful feature,
  highest-risk overclaim,
  highest-value next implementation
}
```

## Before Stage 3 implementation, decide:

```text
Stage3_Decisions = {
  Python vs Rust,
  object table design,
  capability structure,
  ledger format,
  syscall ABI,
  field region representation,
  backend broker policy,
  replay determinism model,
  fault response policy,
  minimal POSIX shim scope
}
```

This is important. It prevents Stage 3 from being built blind.

---

# 28. Final Stage 3+ Foundation Directive

```text
DIRECTIVE: PHYSICSOS_STAGE_3_PLUS_FOUNDATION

OBJECTIVE:
Create the skeleton for PhysicsOS beyond Stage 2 without overfitting before
Stage 2 evidence exists.

CORE PRINCIPLE:
Stage 3 transforms the Stage 2 runtime substrate into a microkernel-shaped
simulator with processes, capabilities, syscall contracts, managed field memory,
backend brokering, rollback, and replayable ledgers.

NON-NEGOTIABLE INVARIANTS:
1. No object mutation without capability.
2. No approximate value controls authority.
3. No untyped zero crosses syscall boundary.
4. No unit-incoherent operation succeeds.
5. No backend result is accepted without contract validation.
6. No rollback deletes history.
7. No field coarsening occurs without reconstruction error.
8. No security object is stored in FieldRegion.
9. No policy relaxation occurs silently.
10. Replay determinism holds under fixed backend contracts.

STAGE 3 OUTPUT:
A Linux-hosted microkernel simulator skeleton.

STAGE 4 OUTPUT:
Executable implementation of that simulator.

STAGE 5 OUTPUT:
OS-adjacent isolation prototype.

STAGE 6 OUTPUT:
Real accelerator/backend integration.

STAGE 7 OUTPUT:
Narrow formal verification proofs.

STAGE 8 OUTPUT:
Scientific workload validation.

FINAL MOTTO:
Exact authority.
Approximate physics.
Typed boundaries.
Ledgered reality.
```

The foundation is now set up correctly: Stage 3 can absorb real contextual insights from Stage 2 instead of pretending the future is already known.
