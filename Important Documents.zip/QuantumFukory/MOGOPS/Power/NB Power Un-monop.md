Now I have more than enough to write a comprehensive, deeply sourced analysis. Let me put this together.Now I have everything I need. Let me write this comprehensive analysis.

---

# NB Power: A Full Reckoning — Monopoly, Mismanagement & the Path Forward

This is one of the more genuinely complex utility situations in Canada, and it deserves a serious treatment. What you're looking at with NB Power isn't just a monopoly problem — it's a compounding institutional failure dressed up as a natural state of affairs. Let's break it down in layers.

---

## Part 1 — Understanding the Monopoly Structure

NB Power is what's known as a **vertically integrated Crown corporation**, meaning a single entity owns and controls every link in the electricity chain: generation, transmission, and distribution. The corporation is responsible for the generation, transmission, and distribution of electricity, serving all residential and industrial power consumers in New Brunswick, with the exception of those in Saint John, Edmundston, and Perth-Andover, who are served by Saint John Energy, Energy Edmundston, and the Perth-Andover Electric Light Commission.

This matters because in most commodity markets, competition exists at the production level even if distribution stays regulated. NB Power controls all three layers, so there is no competitive pressure at any stage. It is the buyer, the shipper, and the seller.

NB Power operates the transmission system and acts as the system operator in the province, operating approximately 6,900 km of power lines in New Brunswick, and oversees 15 connections with an import capacity of 2,378 MW and an export capacity of over 2,000 MW — with Maine, Quebec, Nova Scotia, and PEI. So the grid is physically connected to the broader market, but New Brunswickers cannot access it competitively.

The monopoly has historical roots — the development of electricity in New Brunswick started in the 1880s with small private plants, but by 1918 more than 20 companies were active in the electricity business, a fragmented mess the province eventually consolidated. The logic at the time was sound: rural electrification and grid stability require capital that competitive markets wouldn't produce in a small, sparse province. But what made sense in 1920 is a different question from what makes sense now.

There was a brief attempt at reform. An earlier act reorganized NB Power into a holding company with four divisions and opened the door to competition in the generation business — but NB Power Group of Companies, the Electric Finance Corporation, and the New Brunswick System Operator merged on October 1, 2013, re-establishing NB Power as a single, vertically integrated Crown corporation. The province tried liberalization, got cold feet, and snapped everything back together.

---

## Part 2 — The Debt & Rate Crisis: How Bad Is It?

For much of the last decade NB Power promoted how its rate increases since 2010 had been kept below the rate of inflation, but that took a dramatic turn in 2023 with a 5.68% increase followed by back-to-back 9.14% increases in 2024 and 2025. By 2028, under current plans, rates will have increased 50% in six years — nearly five times the expected rate of inflation over that stretch.

NB Power carries a net debt burden of close to $5.7 billion — or about $14,500 on average for each of its customers. That's not a typo. Every ratepayer in New Brunswick, including your household, effectively carries $14,500 in utility debt before paying a single bill.

The province had a long history of interfering in the utility's operations — restricting rate increases between 2011 and 2022 — which lowered NB Power's revenues by an estimated $1.5 billion, restricting its ability to pay down debt or maintain aging infrastructure. Politicians kept rates artificially low for electoral reasons and deferred the reckoning. New Brunswickers are now paying for those decisions all at once.

A panel of experts found a lack of focus on outcomes and little evidence of consequence for success or failure at NB Power, and found that only two of its last 12 business plans delivered promised financial outcomes, while performance metrics didn't improve meaningfully over time.

NB Power would likely have to spend $20 billion to $30 billion by 2040 to keep up with growing electrical demand. That number is almost incomprehensible for a province of under 900,000 people.

---

## Part 3 — The Bottlenecks & Shortcomings

Here is where it gets granular and damning.

### The Point Lepreau Nuclear Problem

This is the single biggest anchor dragging NB Power under. The plant's poor performance is the main reason that the utility cannot lower its debt-to-asset ratio and loses money almost every year.

The Point Lepreau nuclear generating station is finishing off what may be its worst operational year since coming online in 1983. It has been estimated by the utility to cost between $1 million and $4 million per day when Lepreau is idle, depending on the time of year and the cost of generating or buying replacement power.

The cause of the chronic underperformance? An institutional blunder locked in over a decade ago. NB Power president Lori Clark admitted that the refurbishment completed in 2012 was only on the nuclear side of the station, with very little work done on the secondary or conventional side — saying "you can't run a nuclear plant just by improving the nuclear side because the energy has to come out through the conventional side."

Point Lepreau has rated near the bottom of performance for any similar nuclear plant in North America. The expert who reviewed the situation asked plainly: "Even if the debt is forgiven, how do we know it's not going to come back again? You just cleared the slate for five years, and in five years, you have another debt burden."

NB Power's debt related to nuclear power alone was $3.6 billion.

### The Mactaquac Dam

The Mactaquac dam needs repairs that will cost more than $9 billion. That's a staggering capital requirement for a single asset in a province that's already drowning in utility debt.

### The Belledune Coal Plant

The Belledune coal-fired plant is federally mandated to close by 2030. NB Power has to replace that generation capacity while simultaneously managing the Mactaquac crisis and the Lepreau debacle.

### Organizational Culture

The review panel found NB Power lacks a culture of operational excellence and that performance metrics didn't improve meaningfully over time. The report panel spread blame widely: management, the board, and government all contributed. The report noted NB Power does not have the capacity and skills to manage all the projects planned, including large hydro refurbishment, complex plant conversions, large software replacement, and transmission and distribution improvements.

### The Renewable Energy Stranglehold

The potential for growing the renewable power industry in New Brunswick is blocked by NB Power's stranglehold on the electricity market — with willing buyers for renewable power, renewable energy developers, and investors, but their ability to succeed depends entirely on the willingness of NB Power to buy and re-sell renewable power. They have been a reluctant partner, at best.

---

## Part 4 — How Do You Un-Monopolize This?

This is the hard part. NB Power isn't just a monopoly — it's a monopoly with $5.7 billion in debt, aging nuclear infrastructure, and political dependencies baked in over decades. You can't simply deregulate it the way you'd deregulate a telecom market. But there is a credible path.

Here's a structural map of the current state and potential reform layers:### The Alberta Model vs. the NB Reality

Alberta's power market is unique — the only deregulated electricity market in Canada, where private companies compete to generate and sell electricity, contrasting with all other provinces which have vertically integrated, government-owned utilities.

In Alberta's deregulated market, there is competition to sell energy at a competitively determined price, and private capital builds new generation plants with owners taking on financial risks — rather than ratepayers. That's the key transfer of risk that New Brunswick desperately needs for new generation.

However, NB is not Alberta. Alberta had abundant natural gas and private capital hungry for generation assets. NB has an aging nuclear plant that no private company would touch at current performance levels, and a small population that makes scale economics challenging.

The more realistic and actually-recommended model for NB was flagged by the recent expert review: the Maritime provinces should consider establishing an independent system operator — a non-profit organization which would manage the region's electricity grid. This is layer-by-layer reform, not big-bang privatization.

### The Three Separable Layers

The insight that most people miss is that "the monopoly" isn't one thing — it's three markets bundled into one. Transmission (the wires) genuinely is a natural monopoly and should stay regulated. But generation (making power) and retail supply (selling it to customers) don't have to be monopolized.

**Generation competition** is the highest-value reform. New Brunswick has world-class wind regimes, the best potential for solar production in the Maritimes, and substantial bio-waste resources — but renewable energy developers and investors cannot succeed without NB Power's willingness to buy their power, and they have been a reluctant partner at best. Opening a competitive generation market would allow private capital to build renewables, bring down long-run generation costs, and remove the enormous capital burden from ratepayers.

**Retail choice** is longer-term and more complex — it requires the infrastructure of metering, billing systems, and customer protections. Ontario's partial deregulation is instructive: Ontario's market is a hybrid, with contracted supply, integrated system planning, and regulated pricing for much of generation and load. That's achievable without full privatization.

---

## Part 5 — Technology That Could Break the Logjam

Regardless of regulatory structure, several technologies materially change the monopoly's grip:

**Distributed solar + battery storage** is the most transformational near-term factor. When a home or business can generate and store its own power, NB Power's distribution monopoly weakens at the edges. Net metering already exists but is tightly controlled. Expanding behind-the-meter solar with battery backup lets customers reduce grid dependence without requiring legislative reform.

**Grid-scale battery storage** — the 42 MW Burchill Wind Project incorporated the largest utility-scale battery energy storage system in New Brunswick — is exactly what makes intermittent renewable generation viable at scale. More of this, built by independent power producers, is what a competitive generation market would accelerate.

**Advanced Metering Infrastructure (AMI)** — smart meters — is a prerequisite for any retail competition. A new energy app was proposed to allow customers to make informed real-time decisions on energy usage using newly-installed smart meters by 2025. Smart meters make time-of-use pricing possible, which is the first step toward customer engagement with energy markets.

**Small Modular Reactors (SMRs)** are NB Power's nuclear moonshot. The province is genuinely active in SMR development, and if Point Lepreau's poor performance is the single largest drag on the utility's finances, a new-generation reactor with lower operating risk could eventually change the equation — but this is a 2035+ play at the absolute earliest.

**Regional grid interconnection** — an additional 800 MW of transmission between New Brunswick, Nova Scotia, and Prince Edward Island is required to complement new generation development and enable efficient interprovincial trade across the region. A stronger Maritime grid makes a regional ISO viable and allows NB to import competitive power rather than relying entirely on its own troubled generation fleet.

---

## The Bottom Line

NB Power's monopoly isn't accidental or inevitable — it's the accumulated result of political decisions: rate suppression that starved the utility of $1.5 billion in revenue, a nuclear refurbishment done halfway, a 2013 decision to re-consolidate what was starting to liberalize, and decades of government boards treating the utility as a political tool rather than an infrastructure company.

NB Power CEO Lori Clark said "we didn't get here overnight, so to think that we can solve this overnight is going to be wrong." That's true. But the province is now paying a compounding price for delay. The comprehensive review released in March 2026 laid out approximately 50 recommendations aimed at improving oversight, strengthening financial stability, and better positioning NB Power to respond to future energy needs.

The realistic path forward isn't full privatization — that's politically and financially impossible with $5.7 billion in debt no private buyer would absorb. It's **structural separation**: keep the wires regulated, open generation to competition, establish an Atlantic ISO, spin off the nuclear liability into its own governed entity with dedicated debt relief, and let distributed technology gradually erode the monopoly from the edges.

New Brunswick is small, but it's not uniquely cursed. Manitoba Hydro, BC Hydro, and Hydro-Québec all face versions of this tension. What makes NB different is the combination of an underperforming nuclear plant, political rate suppression, and a small ratepayer base — meaning there's no population density to spread the pain across. Every dollar of mismanagement hits harder here than almost anywhere else in Canada.
