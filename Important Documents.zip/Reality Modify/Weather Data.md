Below are **48 novel, cutting‑edge weather algorithms** derived from the conceptual architecture of `qnvm_light.py`. Each algorithm maps one or more of the simulation’s core constructs (coherence fields, phase transitions, resurrection dynamics, global correlation, etc.) to a specific meteorological challenge—from sub‑seasonal forecasting to extreme event detection and climate‑scale assimilation.

---

### **Coherence & Conservation Algorithms**

1. **Global Coherence Field Analysis (GCFA)**  

   Uses the mean‑field approximation of `GlobalCorrelationField` to compute a planet‑wide “coherence map” from surface pressure, humidity, and wind fields. Predicts large‑scale pattern persistence (e.g., blocking events) from the mean pairwise product of regional coherence scores.

2. **Boundary‑Continuum Flux Conservation (BCFC)**  

   Applies the `coherence_dynamics` conservation law to energy and moisture transport: the rate of change of boundary‑layer coherence (CI_B) minus the continuum coherence (CI_C) is conserved. Enforces physically consistent flux corrections in numerical weather models.

3. **Spectral Radius Stability Index (SRSI)**  

   Computes a local spectral radius (ρ) from the singular values of the Jacobian of the atmospheric equations. When ρ > ρ_crit (default 1.0), the algorithm flags imminent chaotic divergence (e.g., rapid cyclogenesis) and triggers adaptive grid refinement.

4. **Noise‑Adaptive Precision Assimilation (NAPA)**  

   Dynamically adjusts observation‑error covariances using `update_precision`: 𝒫 = (CI_B+CI_C)/(1+σ_noise). Reduces overfitting to noisy satellite data during storm conditions while preserving information from high‑coherence regions.

5. **Temporal‑Boundary Hysteresis Forecasting (TBHF)**  

   Exploits the hysteresis between entry and recovery thresholds (σ_crit vs. recovery_sigma). Predicts the duration of weather regimes (e.g., heatwaves, cold spells) by tracking when the system crosses the “collapse” vs. “recovery” noise levels.

6. **Rank Efficiency Ceiling Detector (RECED)**  

   Monitors the ratio r/d_s (rank efficiency). A persistent value >0.93 indicates that the ensemble Kalman filter is overconfident; the algorithm automatically inflates ensemble spread (like `efficiency_violation` in the simulation).

---

### **Resurrection & Extreme Event Algorithms**

7. **Resurrection Probability for Storm Regeneration (RPSR)**  

   Computes a resurrection probability P_res = (faith × resurrection_coherence × (1–0.5*sin_entropy) × amplifier). Applied to dissipating convective cells; if P_res > threshold, the model re‑initialises a new cell at the same location (convective regeneration).

8. **IIRO‑Inspired Post‑Tropical Rejuvenation (IIRO‑PTR)**  

   After a tropical cyclone becomes extratropical, the algorithm uses `vitality` (analogous to telomere length) and `biophoton` (proxy for convective available potential energy) to predict whether it can re‑intensify (a “resurrection” event).

9. **Cooldown‑Based Multiple Outbreak Sequencing (CMOS)**  

   Uses `resurrect_cooldown` counters to model the minimum time between successive derecho or tornado outbreaks in the same region. Prevents over‑prediction of back‑to‑back extreme events.

10. **Collapse‑Trigger Ensemble Blending (CTEB)**  

    When `phase_transition` triggers a collapse (σ > σ_crit or ρ > ρ_crit), the algorithm discards the current model state and blends it with a low‑resolution climatological background (analogous to resetting CI_B and CI_C to 0.1). Prevents runaway error growth.

11. **Recovery Sigma Hysteresis Map (RSHM)**  

    Spatially varying recovery_sigma fields derived from historical land‑surface memory. Regions with low recovery_sigma (e.g., deserts) require much larger noise reduction to exit a “collapsed” (unstable) forecast state.

12. **Faith‑Weighted Analog Ensemble (FWAE)**  

    Faith = confidence in the persistence of a weather pattern. The algorithm down‑weights analog members whose faith < 0.5, effectively suppressing unlikely regime shifts.

---

### **Multi‑Field Coupling & Advanced Dynamics**

13. **Precision‑Boundary Covariance Shaping (PBCS)**  

    Uses the correlation between `precision` and `boundary` to adapt the horizontal diffusion coefficient in a model. High precision with low boundary → reduce diffusion (sharpen fronts); low precision → increase diffusion (smooth errors).

14. **Spectral Radius – Noise Sigma Phase Diagram (SRNS‑PD)**  

    Real‑time phase diagram classification: each grid cell is placed in (σ, ρ) space. Pre‑defined regions correspond to “stable”, “chaotic”, “collapsing”, or “recovering”. Drives local time‑stepping and stochastic physics.

15. **Internal Noise as Model Error Proxy (INMEP)**  

    `internal_noise` is estimated from the spread of a small ensemble. If internal_noise > 0.8, the algorithm activates a stochastic perturbation scheme (e.g., SPPT) to represent unresolved sub‑grid processes.

16. **Biophoton – CAPE Coupling (BIO‑CAPE)**  

    Biophoton (originally 1 + 3×faith×(1‑internal_noise)) is reinterpreted as a convective trigger function. When biophoton > 10 (on a 0–20 scale), the model forces deep convection even if large‑scale lifting is weak.

17. **Vitality Decay for Soil Moisture Memory (VDSM)**  

    `vitality` decays faster when faith (precipitation reliability) is low. The algorithm uses this to modulate the e‑folding time of soil moisture anomalies, improving sub‑seasonal drought forecasts.

18. **Drift‑Bias Instability Correction (DBIC)**  

    `instability_bias` (archetype‑dependent, 0.1–0.35) is used to correct systematic model drift in the tropical Pacific. Each grid cell inherits a bias from its dominant “archetype” (e.g., El Niño → Rebel drift 0.35).

---

### **Fusion, Auditing & Sovereign Entities**

19. **Fusion‑Based Multi‑Model Blending (FMB)**  

    When two high‑coherence forecasts (ρ > 1.5) exist for the same region, the algorithm “fuses” them by averaging their state vectors and incrementing a fusion count. The fused forecast has higher symbolic density (representational power).

20. **Sovereign Entity Gate Audit (SEGA)**  

    A grid cell passes audit if recursive_depth (forecast lead time) > 5, drift < 0.02, ethical_sovereignty (bias score) > 0.9, etc. Cells that pass become “sovereign” and their output is used as a reference for bias correction of neighboring cells.

21. **Recursive Depth Forecast Horizon (RDFH)**  

    `recursive_depth = age//5 + (CI_B+CI_C)*20`. Age = number of analysis cycles. The algorithm adaptively extends the forecast horizon for high‑coherence, mature cells, and truncates it for young or noisy cells.

22. **Symbolic Density for Pattern Compression (SDPC)**  

    Symbolic density = (CI_B+CI_C)*5 + recursive_depth*0.05. Regions with high symbolic density can be represented with fewer principal components – used to dynamically reduce the rank of the background error covariance matrix.

23. **Ethical Sovereignty as Forecast Fairness (ESFF)**  

    Monitors `ethical_sovereignty` to ensure that model performance does not degrade systematically in developing countries (e.g., bias < 0.1 required). Triggers retraining of localisation parameters if violated.

24. **Fusion Count – Ensemble Diversity Metric (FC‑EDM)**  

    The fusion count of an ensemble member (how many times it has been blended) serves as a proxy for independence. Members with high fusion count are down‑weighted in the ensemble mean to avoid over‑confidence.

---

### **Archetype‑Based & Population Algorithms**

25. **Explorer Archetype for Data Denial Experiments (EXPL‑DDE)**  

    Explorer archetype (coherence_base 0.70, entropy_base 0.3) is assigned to observation‑sparse regions. The algorithm explores alternative model trajectories by increasing stochastic entropy, mimicking the uncertainty of data‑denial.

26. **Philosopher Archetype for Consensus Forecasting (PHIL‑CF)**  

    Philosopher (coherence 0.90, low drift) acts as a “slow” consensus engine: it averages the last 10 ensemble forecasts, producing a highly stable baseline prediction used to anchor more volatile members.

27. **Creator Archetype for Generative Downscaling (CREA‑GD)**  

    Creator (coherence 0.80, moderate entropy) generates high‑resolution detail from low‑resolution fields using a generative adversarial network conditioned on the current coherence state.

28. **Scientist Archetype for Observation Impact (SCI‑OI)**  

    Scientist (high rank efficiency) is used to compute the observation impact in an ensemble Kalman filter. Observations that reduce the spectral radius the most are flagged as most valuable.

29. **Strategist Archetype for Adaptive Observation Targeting (STRAT‑AOT)**  

    Strategist (entropy 0.6, drift 0.25) identifies regions where small changes in initial conditions lead to large forecast divergence (i.e., sensitive areas). Deploys targeted dropsondes or satellite scans.

30. **Empath Archetype for Social‑Weather Impact (EMP‑SWI)**  

    Empath (coherence 0.95, very low drift) couples weather forecasts with vulnerability indices (population density, infrastructure). Outputs a “human impact coherence” score used for early warning systems.

31. **Rebel Archetype for Outlier Detection (REBEL‑OD)**  

    Rebel (coherence 0.60, high entropy 0.8) is intentionally mis‑initialised with perturbed physics. When its forecast diverges dramatically from the ensemble mean, it signals a possible regime change (e.g., sudden stratospheric warming).

---

### **Global Field & Memory Algorithms**

32. **Memory‑Mapped Global Correlation (MMGC)**  

    Uses a memory‑mapped file (like `correlation_field.dat`) to store a global covariance matrix for 10⁷ grid points, enabling efficient O(N) updates of the correlation field without loading the entire matrix into RAM.

33. **Mean‑Field Nudging for Climate Drift (MFND)**  

    The global coherence field (scalar) nudges all grid points: CI_B += 0.01*field*(1‑CI_B). Corrects long‑term climate drift in coupled models without violating conservation laws.

34. **Pairwise Product Teleconnection Index (PPTI)**  

    Computes the mean of all pairwise products of coherence between two distant regions (e.g., Niño 3.4 and Indian Ocean). A high PPTI indicates a strong teleconnection and improves seasonal forecasting.

35. **GPU‑Accelerated Survival Mask (GPUSM)**  

    Uses CuPy (if available) to compute a probabilistic “survival” mask for ensemble members: P_surv = clip((CI_B+CI_C)*(1‑σ), floor, 1). Members with low survival probability are killed (removed) and replaced by resampled survivors.

36. **Carrying Capacity Adaptive Resolution (CCAR)**  

    The model domain is partitioned into cells whose total number cannot exceed carrying_capacity (e.g., 10⁴). Cells with high vitality (soil moisture memory) are preserved; low‑vitality cells are coarsened.

---

### **Phase Transition & Hysteresis Algorithms**

37. **Hysteresis‑Based Regime Shift Predictor (HRSP)**  

    Tracks the difference between the critical noise σ_crit and the recovery noise. A large hysteresis loop (σ_crit >> recovery_sigma) indicates a persistent regime (e.g., a locked monsoon trough). A narrow loop signals frequent flips.

38. **Collapse‑Entered Mask for Data Gaps (CEM‑DG)**  

    When a grid cell enters collapse (σ > σ_crit), the algorithm discards recent observations from that region as “untrustworthy”. The mask is used to exclude corrupted satellite data during heavy precipitation.

39. **Recovered‑Exit Mask for Re‑initialisation (REM‑RI)**  

    When a cell recovers (σ < recovery_sigma), the model re‑initialises that cell from a high‑resolution climatology, analogous to resetting CI_B and CI_C.

40. **Phase Transition Counting for Convective Lifecycle (PTCCL)**  

    Counts how many times a convective cell has entered and recovered. Cells with >3 transitions are flagged as “regenerating” and receive a higher probability for the resurrection algorithm (RPSR, #7).

---

### **Entropy, Noise & Stochastic Algorithms**

41. **Internal Noise as Stochastic Kinetic Energy Backscatter (INSKEB)**  

    `internal_noise` is used to modulate the amplitude of backscatter in an eddy‑diffusivity mass‑flux scheme. High internal noise → more backscatter (increased turbulence) in stable boundary layers.

42. **Noise Sigma – Rank Efficiency Feedback (NSREF)**  

    When rank efficiency > 0.93, the algorithm increases noise_sigma to break the over‑confident state (similar to `efficiency_violation`). Prevents ensemble collapse in operational EPS.

43. **Resurrection Amplifier for Tropical Cyclone Rapid Intensification (RA‑RI)**  

    `resurrection_amplifier` (0.3–1.0) multiplies the intensification rate in a statistical‑dynamic model of tropical cyclones. Values near 1.0 correspond to ideal conditions (low shear, high SST) for rapid intensification.

44. **Instability Bias – Drift Correction (IB‑DC)**  

    `instability_bias` is used as a local correction to the model’s temperature tendency. Positive bias → warm bias correction; negative bias → cool bias correction. Calibrated offline from historical forecast errors.

---

### **Auditing, Sovereignty & Quality Control**

45. **Sovereign Entity Metadata for Observation QC (SEM‑QC)**  

    Grid cells that have passed the audit gates (recursive_depth >5, drift<0.02, etc.) become “sovereign”. Their output is used as a reference to detect and flag erroneous observations (e.g., lightning strikes on sensors).

46. **Audit Log for Model Version Control (AL‑MVC)**  

    Each model integration step writes an audit log entry (generation, entity_id, TMI, gates_passed). This log is used to trace the origin of a forecast bias back to a specific parameterisation or data assimilation step.

47. **TMI (Technical Maturity Index) for Model Skill**  

    TMI = (recursive_depth/50 + symbolic_density/10 + ethical_sovereignty)/3. A high TMI (>0.92) indicates that the model configuration in that region is mature; the algorithm reduces stochastic perturbations there to avoid degrading good skill.

48. **Splinter Resilience – Ensemble Fragmentation Metric (SR‑EFM)**  

    Splinter resilience (inherited from fusion) measures how well an ensemble member retains diversity after multiple fusions. Used to prune members with low resilience, maintaining an effective ensemble size even under strong model‑blending.

---

These 48 algorithms translate the abstract, hyper‑dimensional concepts of `qnvm_light.py` into concrete, testable methods for operational and research weather forecasting. Each leverages the simulation’s core mechanisms—coherence conservation, phase transitions, resurrection dynamics, archetype specialization, and global correlation fields—to address long‑standing challenges in atmospheric modeling, data assimilation, and ensemble prediction.



Below are **144 real‑weather metrics and patterns** reconstructed from paleoclimate proxies spanning the last 10,000 years (the Holocene). Each entry is a measurable quantity or recurring phenomenon that has been observed or inferred from ice cores, tree rings, lake sediments, speleothems, coral records, and historical documents. The list is organized into thematic groups, but numbered 1–144 as requested.

---

### **Temperature Metrics** (1–30)

1. Mean annual temperature anomaly (relative to 1961–1990 baseline)  

2. Holocene Thermal Maximum (HTM) peak temperature (~8 ka BP)  

3. Late Holocene cooling trend (linear slope from 4 ka BP to 1850 CE)  

4. Little Ice Age (LIA) minimum temperature (composite, ~1600–1700 CE)  

5. Medieval Warm Period (MWP) maximum temperature (~950–1050 CE)  

6. Rate of warming during the 20th century (°C/decade)  

7. Seasonality index (summer–winter difference) in the early Holocene  

8. 8.2 ka BP cold event amplitude (°C drop)  

9. 4.2 ka BP aridification temperature signal  

10. 0.5 ka BP (1500 CE) temperature dip amplitude  

11. Duration of the Younger Dryas termination transition (decades)  

12. Holocene global average temperature range (min to max)  

13. North Atlantic sea surface temperature (SST) anomaly during the MWP  

14. Tropical Pacific SST gradient (east–west) at 6 ka BP  

15. Antarctic temperature anomaly during the LIA  

16. Greenland surface temperature reconstruction (GISP2)  

17. Bølling‑Allerød to Younger Dryas temperature drop (Greenland)  

18. Early Holocene summer insolation maximum (65°N)  

19. Late Holocene winter insolation minimum (65°N)  

20. Thermocline depth anomaly in the western Pacific warm pool (5 ka BP)  

21. Number of severe cold winters per century in Europe (1500–1850)  

22. Frequency of Central England Temperature (CET) falling below 0°C monthly mean  

23. Alpine glacier advance/retreat temperature threshold (summer melt)  

24. Boreal forest treeline latitude shift vs. temperature change  

25. North Atlantic subpolar gyre temperature anomaly (LIA vs. MWP)  

26. Tropical Andean glacier equilibrium line altitude (ELA) change (10 ka to present)  

27. East Asian winter monsoon temperature proxy (δ¹⁸O in stalagmites)  

28. Australian‑Indonesian summer monsoon temperature reconstruction  

29. California Current SST upwelling intensity (inverse of temperature)  

30. Southern Ocean surface temperature at 60°S (last 10 ka)

---

### **Precipitation & Drought Metrics** (31–60)

31. Megadrought frequency in the southwestern USA (per 1000 years)  

32. Sahel precipitation index (0 = modern, negative = drier) at 6 ka BP  

33. Indian summer monsoon rainfall anomaly (mm/day) during the HTM  

34. East Asian monsoon precipitation (speleothem δ¹⁸O) at 8 ka BP  

35. South American Summer Monsoon (SASM) intensity (‰ deviation)  

36. Length of the 4.2 ka BP mega‑drought (years)  

37. Number of extreme flood events in the Yangtze River (last 2000 years)  

38. Lake Victoria level (meters above present) at 5 ka BP  

39. Great Basin pluvial lake extent (km²) at 10 ka BP  

40. Sahara desertification rate (km²/year) from 6 ka to 4 ka BP  

41. Central American drought frequency during the Terminal Classic period (800–1000 CE)  

42. South African summer rainfall zone precipitation anomaly (LIA)  

43. North American monsoon precipitation at 7 ka BP relative to present  

44. European summer drought return period (years) between 1500–1850 CE  

45. Western Pacific ITCZ position (latitude) shift since 10 ka BP  

46. Indonesian austral winter precipitation anomaly (last 2000 years)  

47. Tibetan Plateau lake area change (mm water equivalent)  

48. Amazon Basin precipitation reconstruction (Terra Preta period)  

49. Levantine drought index (inferred from Dead Sea levels)  

50. Scandinavian precipitation anomaly during the MWP  

51. Number of consecutive dry years in the Chilean Atacama (last 10 ka)  

52. East African “Long Rains” precipitation trend (3 ka BP to present)  

53. Mississippi River flood frequency (per century) from alluvial records  

54. Indus Valley civilisation drought amplitude (relative to modern)  

55. Western Mediterranean winter precipitation (δ¹⁸O in cave calcites)  

56. Northeast Brazil precipitation anomaly (5 ka BP)  

57. South Asian pre‑monsoon precipitation (March–May) change since 4 ka BP  

58. Patagonian steppe aridity index (paleo‑pollen)  

59. Central Siberian summer precipitation (tree‑ring reconstruction, last 2000 yr)  

60. Global average land precipitation anomaly (mm/yr) over the Holocene

---

### **Atmospheric Circulation & Teleconnection Metrics** (61–90)

61. El Niño–Southern Oscillation (ENSO) frequency (events/century) at 7 ka BP  

62. ENSO amplitude (NINO3.4 SST anomaly standard deviation) during the MWP  

63. North Atlantic Oscillation (NAO) index reconstruction (winter, 0–2000 CE)  

64. Pacific Decadal Oscillation (PDO) phase dominance (positive vs. negative) per 500‑year bin  

65. Atlantic Multidecadal Oscillation (AMO) anomaly at 5 ka BP  

66. Southern Annular Mode (SAM) index trend (last 2000 years)  

67. Indian Ocean Dipole (IOD) event frequency (per century) during the HTM  

68. Quasi‑Biennial Oscillation (QBO) period length (months) in the pre‑industrial era  

69. Madden‑Julian Oscillation (MJO) amplitude in the early Holocene  

70. Pacific‑North American (PNA) pattern index anomaly (LIA vs. MWP)  

71. Scandinavian Pattern (SCAND) index during the 8.2 ka event  

72. East Atlantic/Western Russia (EA/WR) pattern correlation with European droughts  

73. Boreal summer intraseasonal oscillation (BSISO) propagation speed (m/s)  

74. Monsoon depressions frequency in the Bay of Bengal (last 3000 years)  

75. Number of atmospheric river landfalls on the US West Coast (per century)  

76. Siberian High intensity anomaly (hPa) during the LIA  

77. Icelandic Low pressure anomaly (hPa) at 9 ka BP  

78. Aleutian Low position (latitude, longitude) shift since 6 ka BP  

79. Walker Circulation strength anomaly (relative to modern) at 4 ka BP  

80. Hadley Cell width (degrees latitude) in the mid‑Holocene  

81. Subtropical jet stream latitude (June–August) anomaly at 8 ka BP  

82. Polar vortex strength (geopotential height gradient) during the LIA  

83. African Easterly Jet intensity (m/s) at 5 ka BP (greening Sahara period)  

84. Somali Jet strength anomaly (last 2000 years)  

85. South Asian low‑level jet (Findlater jet) core velocity at 6 ka BP  

86. North Pacific storm track eddy kinetic energy (relative to present)  

87. North Atlantic storm track tilt angle (degrees) during the MWP  

88. Southern Ocean westerly wind maximum latitude (shift since 10 ka BP)  

89. Trade wind strength anomaly in the equatorial Pacific (last 1000 years)  

90. Monsoon trough position (longitude) over the Bay of Bengal (4 ka BP)

---

### **Extreme Events & Proxies** (91–120)

91. Number of tropical cyclones making landfall in East Asia (per century, 1500–1850)  

92. Atlantic hurricane frequency (annual count) during the LIA  

93. Mediterranean tropical‑like cyclone (medicane) occurrence rate (last 2000 years)  

94. Flood frequency in the Yellow River (catastrophic breaches per millennium)  

95. Mega‑sandstorm frequency in the Gobi Desert (events per 100 years)  

96. Lightning‑ignited wildfire area (km²/yr) in western North America (last 2000 years)  

97. Hailstorm event return period (years) in the Great Plains (1500–1850)  

98. Derecho occurrence frequency in the US Midwest (per 50 years, 1000–1800 CE)  

99. Blizzard frequency in the northeastern US (LIA vs. MWP)  

100. Heatwave duration (days per summer) in Central Europe during the HTM  

101. Cold spell persistence (days below 0°C) in Siberia (LIA)  

102. Number of extreme precipitation days (>50 mm) in Mumbai (last 500 years)  

103. Lake effect snow accumulation (cm/year) in the Great Lakes region (1600–1800)  

104. Föhn event frequency in the European Alps (per decade, last 1000 years)  

105. Dust storm concentration (mg/m³) in the Greenland ice core (7–8 ka BP)  

106. Sea ice extent (million km²) in the Arctic Ocean in September (8 ka BP)  

107. Antarctic sea ice edge latitude (February) at 6 ka BP  

108. Permafrost active layer thickness (cm) in Siberia (last 4000 years)  

109. Landslide trigger index (rainfall threshold exceeded per year) in the Himalayas  

110. Avalanche return period (years) in the Rocky Mountains (LIA)  

111. Storm surge height (meters) in the North Sea (extreme event of 1634 CE)  

112. Drought‑induced wildfire frequency in Australia (last 1000 years)  

113. Supercell thunderstorm frequency in Argentina (Pampas, last 500 years)  

114. Mesoscale convective system (MCS) rainfall contribution (%) in the Sahel (6 ka BP)  

115. Number of major volcanic eruptions (VEI ≥ 5) that influenced global temperature  

116. El Niño‑induced crop failure events per century in Peru (1000–1800 CE)  

117. La Niña multi‑year persistence (number of consecutive years) in the early Holocene  

118. Indian monsoon break period length (days) during the 4.2 ka event  

119. West African monsoon onset date anomaly (days) at 5 ka BP  

120. North American monsoon onset delay (days) during the LIA

---

### **Integrated & Synthetic Metrics** (121–144)

121. Holocene global average precipitation δ¹⁸O trend (‰ per 1000 years)  

122. Meridional overturning circulation (AMOC) strength anomaly (Sv) at 8.2 ka BP  

123. Biosphere‑atmosphere carbon exchange (GtC/yr) during the HTM  

124. Atmospheric methane concentration (ppb) at 10 ka vs. 5 ka BP  

125. Carbon dioxide concentration (ppm) trend from 10 ka to 1850 CE  

126. Aerosol optical depth (AOD) from biomass burning (last 2000 years)  

127. Dust flux (mg/m²/yr) in the tropical Atlantic (Sahara source)  

128. Black carbon concentration (ng/g) in Antarctic ice (industrial vs. pre‑industrial)  

129. Stratospheric water vapour mixing ratio (ppm) anomaly during the MWP  

130. Total column ozone variability (DU) from paleo‑UV proxies  

131. Cloud fraction anomaly (%) from marine sediment biogenic proxies  

132. Planetary albedo change (Δα) due to desertification (6–4 ka BP)  

133. Latent heat flux anomaly (W/m²) in the western Pacific warm pool  

134. Sensible heat flux trend over the Eurasian continent (last 5000 years)  

135. Net longwave radiation at the top of the atmosphere (anomaly, W/m²)  

136. Ocean heat content (0–2000 m) anomaly (ZJ) at 2 ka BP relative to 19th century  

137. Sea level rise rate (mm/yr) from 10 ka to 8 ka BP (deglacial melt pulse)  

138. Global glacier mass balance (mm SLE/yr) averaged over the last 1000 years  

139. Permafrost carbon release rate (PgC/yr) during the HTM  

140. Fraction of global land area under extreme drought (≤ −2 SPI) at 4.2 ka BP  

141. Biodiversity‑weather correlation index (tree‑ring width vs. species richness)  

142. Paleo‑storminess index (units from coastal lagoon overwashes)  

143. Holocene composite “weather whiplash” count (rapid dry‑to‑wet transitions per century)  

144. Variance of annual temperature (standard deviation) over the last 10,000 years

---

These 144 metrics represent the most significant real‑weather patterns and quantities that have been reconstructed for the Holocene. They are drawn from peer‑reviewed paleoclimatology (e.g., PAGES 2k, NGRIP, WAIS Divide, speleothem databases, lake sediment cores) and are directly usable for benchmarking climate models, testing the algorithms derived from `qnvm_light.py`, or informing long‑range weather predictability studies.