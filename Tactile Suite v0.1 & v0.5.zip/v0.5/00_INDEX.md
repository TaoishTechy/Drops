# Tactile Hand Blueprint — Master Index (v0.5)
**Version 1.0 · Science-grade conceptual design suite · Tesla-style flexible capacitive–resistive skin**

This document tree is the complete engineering reference for the three conceptual hand
designs and their companion software suite. All quantities marked *(concept)* are design
targets, not measured values. Speculative-framework material (ERD fields, wards, mana
ledgers) is used strictly as control-theoretic analogy and is flagged **[AN]** (analogy)
where it appears; everything else is standard, buildable engineering.

## Document Map

| File | Contents |
|------|----------|
| `01_Optimiform-21_Hardware_Blueprint.md` | Humaniform 21-DoF full-skin hand: geometry, sensor stack, wiring, BOM |
| `02_Tritalon_Hardware_Blueprint.md` | Industrial 3-finger high-force hand: plating-first fabrication, BOM |
| `03_Dermasheath_Hardware_Blueprint.md` | Retrofit liquid-metal glove skin: universal end-effector wrap |
| `04_Software_Suite_Blueprint.md` | Layered architecture, module contracts, data plane, build system |
| `05_Firmware_Reflex_Stack.md` | Edge firmware: acquisition, reflexes, safety breaker, watchdog |
| `06_Tactile_Inference_and_AI.md` | Signal processing, ERD/anomaly models, grasp scoring, sim-to-real |
| `07_Security_Warding.md` | Frame integrity, wards-as-invariants, crypto suite, key ceremony |
| `08_Telemetry_and_Orchestration.md` | Mana ledger (power budget), tiering, OTA, fleet management |

## Design Philosophy

1. **Dual-mode transduction everywhere it matters.** Every load-bearing taxel is sensed by
   capacitance (proximity + normal force) *and* resistance (true contact force); the two
   are cross-validated per-frame (Eq. R2 in each hardware guide).
2. **Reflexes live on the edge; cognition lives in the cloud tier.** A 1 ms
   sensor→motor reflex path never crosses the network. This is non-negotiable.
3. **The skin is replaceable, the skeleton is not.** All three designs treat the sensor
   sheath as a consumable with a health ledger (cycles, abrasion, drift).
4. **Speculative math earns its keep or gets cut.** Every [AN]-flagged construct must map
   to a concrete algorithm, budget, or test; otherwise it is presentation-layer only.

## Governing Equations (non-patent physics, shared by all designs)

| ID | Equation | Role |
|----|----------|------|
| P1 | $C = \varepsilon_0 \varepsilon_r A / d$ | capacitive transduction |
| P2 | $R = \rho\, L / A$ (sheet $R_s = \rho/t$) | resistive transduction |
| P3 | $V_{out} = V_{in}\, C_{ref}/(C_{sensor}+C_{ref})$ | capacitive readout |
| P4 | $V_G = V_s\left(\frac{R_3}{R_3+R_{sensor}} - \frac{R_2}{R_1+R_2}\right)$ | Wheatstone readout |
| P5 | $F = \frac{4}{3}E^*\sqrt{R}\,\delta^{3/2}$ | Hertzian contact |
| P6 | $F_{fric} \le \mu_s F_{normal}$ | slip threshold |
| P7 | $\tau = R_{trace} C_{pixel}$ | per-pixel settle time |
| P8 | $\tau_{settle} < 1/(2 f_{scan} N_{mux})$ | mux scan budget |
| P9 | $f_s > 2B$ (B = slip bandwidth) | Nyquist for micro-slip |
| P10 | $R(T) = R_0[1+\alpha(T-T_0)]$ | thermal compensation target |

## Safety Invariants (hard requirements, all designs)

- **INV-1** Normal force on any taxel of a human-contact region ≤ 1.4 N·cm⁻² (bruise limit).
- **INV-2** Reflex path latency ≤ 1 ms end-to-end, independent of host compute state.
- **INV-3** On loss of compute heartbeat > 50 ms → motors freewheel, brakes engage.
- **INV-4** Cap/Res divergence > 3σ on > 10% of taxels → conservative single-mode fallback.
- **INV-5** No unsigned tactile frame shall ever drive a motor (see `07_Security_Warding.md`).


---

# v0.5 REVISION NOTES (from v0.1 audit S1–S144, enhancements E1–E96)

**Basis:** `09_Audit_Disposition_144.md` (every issue dispositioned) and
`10_Enhancement_Compliance_96.md` (every enhancement statused).

## Revision class
v0.5 is a **refactor, not a patch**: every fatal-path software defect is closed in-line,
hardware gaps receive specification amendments, and all UHG/CC import items are
classified into exactly one of four dispositions: **Adopted [AN]** (realized as concrete
code), **Scheduled** (v0.6 backlog), **Research** (not fabricable/verifiable at prototype
tier), or **Declined** (physically unrealizable as specified — stated plainly, with reason).

## Headline changes by document

| Doc | v0.5 change |
|---|---|
| `01` | ESD diode spec (A10), thermal-settle table (A29), mechanical tendon fuse (A28), absolute-encoder homing (A16), IP54 rating (A21) |
| `02` | LDS micro-crack inspection gate (A8), Kelvin 4-wire already present — verified note (A-cleanup), chemical-resistance matrix defined (A22) |
| `03` | Oxide-skin management for Galinstan (A3), dehydration barrier spec (A9), fiducial locking redesign (A23), stretch-tensor registration input (B57) |
| `04` | **Unaligned-packed-struct fix (B34)**, DMA frame pipeline (B31), uint64 session seq + uint32 rollover logic (B88), NaN/Inf torque guard (C87), ROS 2 QoS profile (B55), veto link redundancy (B48) |
| `05` | Ring-buffer overflow policy (B32), dual-MCU lockstep (E16), BOD config (C80), boot-grasp baseline detect (C78), R2 oscillation guard (C83), SW watchdog chain (C77) |
| `06` | Hann-windowed FFT (B38), Zeno-guard timeout (B40), stability-score clamp (B42), INT8 QAT (B41), adaptive contact window for viscous objects (B58), fixed-point ERD (B37), non-commutative IMU filter scheduled (E43) |
| `07` | Mutual auth node↔reflex (C74), CRL/deny-list (C75), recovery key anti-brick (C66), tamper mesh (C86), speculative-execution timing note (C52/B73), dynamic INV-1 per object fragility (E61) |
| `08` | Circular Merkle log + daily anchor (B44), dynamic mana floor w/ reflex exemption (B46/C46), OTA auto-rollback triggers defined (B45), fleet CI telemetry [AN scheduled] (E59) |

## Standing rules carried forward
1. **[AN] items must compile.** Every adopted analogy has a code artifact and a test.
2. **Research items never gate safety.** INV-1…5 enforcement depends only on shipping hardware.
3. **Declined items stay documented.** Reasons recorded in `10` so they are not re-proposed blindly.
