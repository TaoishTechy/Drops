# 06 — Tactile Inference & AI
**Signal processing, touch-state estimation, grasp scoring, and learning pipeline**

## 1. Signal Chain (per region, edge + host split)

```
raw ADC → thermal comp (P10) → cross-validation (R2) →
ERD state update [AN] → spatial Gaussian (σ = 1.5 px) →
sub-pixel bicubic (P22 analog) → feature extraction → host
```

## 2. ERD Touch-State Estimate [AN → concrete]

The "essence-recursion field" reduces to a bounded complex running state:

```python
def erd_update(e, dC, dR):
    z = complex(e.real + dC, e.imag + dR)
    n = abs(z)**2
    return complex(z.real/(1+n), z.imag/(1+n))   # |ε| < 1 guaranteed
```

Uses: (a) touch *attention* = |ε| modulates scan allocation (dynamic zoning);
(b) similarity = Re⟨εᵢ, εⱼ⟩ / (|εᵢ||εⱼ|) for nearest-template lookup.
Both are ordinary normalized-signal operations; the field language is presentation only.

## 3. Micro-Slip Detection (canonical algorithm)

Slip vibration band 100–140 Hz on a 9 Hz amplitude carrier (predicted fingerprint):

```python
def slip_ratio(fft_mag, N, fs):
    hi = np.sum(fft_mag[int(120*N/fs):int(140*N/fs)]**2)
    lo = np.sum(fft_mag[0:int(100*N/fs)]**2)
    return hi / (lo + 1e-12)          # > 0.15 => pre-slip (R2 arc input)
```

Detection target: ≥ 95% recall, ≤ 5 ms lead time, ≤ 1 false/10 min on the Tritalon
lubricated-steel benchmark (see `02` §8).

## 4. P-B-T Grasp Controller (host, 100 Hz)

```python
def pbt_controller(state, target, dt):
    pi, dB, gam = state                       # precision, boundary, temporal
    e = target - state
    # fractional-order terms (Grünwald-Letnikov, window M=32)
    u_pi  = FOPID(e.pi,  alpha=0.8, beta=0.6, Kp=2.0, Ki=0.5, Kd=0.3)
    u_dB  = FOPID(e.dB,  alpha=0.8, beta=0.6, Kp=1.0, Ki=0.2, Kd=0.2)
    u_gam = FOPID(e.gam, alpha=0.8, beta=0.6, Kp=0.5, Ki=0.1, Kd=0.1)
    u = np.clip([u_pi, u_dB, u_gam], -0.1, 0.1)   # anti-windup clamp
    return state + u*dt, grasp_health(state)      # ||x|| < 1.5 healthy
```

Sophia-locked damping [AN→concrete]: ζ = 1/(2φω₀) with φ = 1.618 — used as the
fixed damping design value for the impedance loop (compliant-grip mode), chosen because
it sits in the flat region of the settling-time-vs-ζ curve.

## 5. Material & Object ID

- **Thermal step response** (optional layer): fit $T(t) = T_0 + \Delta T e^{-t/\tau_{th}}$
  → material class from τ_th (metal ≪ wood < plastic).
- **Vibration spectroscopy**: tap → FFT peak → hollow/solid classification.
- **CNN classifier** (tactile-only, darkness-capable): input = sliding-window pressure
  movie 32×32×16, backbone = MobileNetV3-small, output = 40 object classes + anomaly
  head (bruise/dent detection). Target ≥ 92% top-1.
- **Force-curve prediction**: from first 20 ms of contact, regress full F(δ) curve
  (P5 Hertzian family + Kelvin-Voigt term); feeds the crush breaker (`05` §4) and
  compliance matching.

## 6. Grasp Stability Score

```python
def grasp_stability(frame_hist):
    P = slip_risk(frame_hist)          # from §3 trends
    B = force_closure_margin()         # kinematic wrench closure
    T = horizon_consistency(frame_hist)
    return float(np.exp(-np.sqrt(P**2 + B**2 + T**2)))   # 0..1
```

Published at 10 Hz; thresholds: > 0.8 confident hold, 0.5–0.8 tighten, < 0.5 re-grasp.

## 7. Sim-to-Real & Self-Supervised Learning

- Sim: soft-body (XPBD) taxel renderer matching P1/P2/P5; domain randomization over
  sheath thickness (±20%), temperature (−10…+45 °C), EMI noise floor.
- Self-supervised squeeze protocol: autonomous squeezes → outcome labels from R2/R3
  events → offline preference update of the grasp prior (no human labels after bootstrap).
- Sparse-data reconstruction: masked autoencoder trained on fleet data, distilled to
  edge for dead-pixel fill (holographic repair, Eq. R7 of `01`).

## 8. Evaluation Harness

`test-bench/` replays recorded + synthetic taxel traces against every algorithm:
- slip library: 120 labeled slip events (dry/wet/oily)
- crush library: 60 instrumented over-grip sequences
- ghost-touch EMI library: 200 interference captures

Gate: no regression > 2% on any metric vs. release baseline.
