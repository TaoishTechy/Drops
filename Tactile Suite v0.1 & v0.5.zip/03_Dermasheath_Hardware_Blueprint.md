# 03 — Dermasheath Hardware Blueprint
**Retrofit tactile glove · passive 6-DoF wrap · liquid-metal traces · 380 taxels**

## 1. Concept Summary

A universal tactile skin that wraps *any* existing end-effector (parallel grippers,
vacuum tools, third-party claws) and gives it the Tesla-patent sensing envelope without
redesigning the robot underneath. Key enabler: Galinstan liquid-metal traces in microfluidic
channels — infinite strain cycling without the resistance drift or crack failure of printed
particle inks.

## 2. Mechanical Design

- **Form:** two-layer knit sleeve with integrated microfluidic channels; hook-and-loop
  wrap with indexed tension marks so sensor geometry is reproducible after re-fit.
- **Fit range:** tool circumferences 60–140 mm via three sizes (S/M/L); stretch to 250%.
- **Indexing:** 3 alignment fiducials (printed dots) register the taxel grid to the tool
  surface at install; software re-maps region boundaries at install time.

## 3. Taxel Layout (concept figures)

Uniform 120 taxels/cm² everywhere (no finger anatomy to follow): 8 mm pitch hex grid.
380 taxels across a nominal M-size wrap; per-region semantics assigned at install
("jaw face", "jaw edge", "back").

## 4. Sensor Stack

| Layer | Material | Thickness |
|---|---|---|
| L1 skin | Self-healing hydrogel (ionic) | 1.0 mm |
| L2 cap electrodes | Galinstan channels, 200 µm wide | — |
| L3 dielectric | Gel elastomer | 0.4 mm |
| L4 substrate | Stretchable knit, microfluidic-embedded | 0.6 mm |
| L5 mount | Hook-and-loop + fiducial print | — |

Single-mode capacitive sensing; resistive validation provided by the hydrogel's ionic
conductivity channel (lower precision, used only for gross fault detection).

**Settle budget:** C_pixel ≈ 25 pF, R_channel ≈ 4 kΩ → τ ≈ 0.1 µs; 500 Hz uniform scan,
12:1 mux → 1.2 µs ≪ 1 ms half-period. ✓

## 5. Electronics

- 1× ESP32-S3 edge node in a wrist puck; 2× ADS7142 (12-bit, 8-ch, 1 MSPS) cap-to-digital.
- No reflex MCU on-tool: the retrofit targets existing grippers whose controllers own
  the motors; the sheath exposes a **haptic reflex API** (see `05`, §7) the host
  controller must call at ≥ 100 Hz. (Not meeting this voids the safety claims.)
- IMU in the puck (tool-frame motion compensation).

## 6. Bill of Materials (prototype tier)

| Item | Qty | Unit | Ext. |
|---|---|---|---|
| Knit + microfluidic lamination | 1 | 45 | 45 |
| Galinstan (10 g) | 1 | 30 | 30 |
| Hydrogel skin sheet | 1 | 25 | 25 |
| ESP32-S3 puck + ADCs + IMU | 1 | 40 | 40 |
| Fiducial print + hook-loop | lot | 10 | 10 |
| **Total** | | | **≈ 150** |

## 7. Verification Plan

| Test | Method | Acceptance |
|---|---|---|
| Strain cycling | 100k × 100% stretch | ΔR < 1% (liquid-metal advantage) |
| Refit reproducibility | remove & refit 10× | region remap error < 2 mm |
| Host API compliance | 100 Hz reflex call audit | zero missed deadlines in 24 h |
| Washdown | IPX6 spray | no false touches > 1/min |

## 8. Equation anchors

Stretch-invariant trace resistance: $R=\rho L/A$ with $L\to\lambda L,\ A\to A/\lambda$
(ρ constant for liquid metal) → **R invariant under uniaxial stretch**; this is the
design's core physics advantage over particle-ink traces where percolation changes with strain.
