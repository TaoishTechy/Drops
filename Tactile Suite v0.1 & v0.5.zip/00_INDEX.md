# Tactile Hand Blueprint — Master Index
**Version 1.0 · Science-grade conceptual design suite · Tesla-style flexible capacitive–resistive skin**

This document tree is the complete engineering reference for the three conceptual hand
designs and their companion software suite. All quantities marked *(concept)* are design
targets, not measured values. Speculative-framework material (ERD fields, wards, mana
ledgers) is used strictly as control-theoretic analogy and is flagged **[AN]** (analogy)
where it appears; everything else is standard, buildable engineering.

## Document Map

| File | Contents |
|------|----------|
| `01_Optimiform-21_Hardware_Blueprint.md` | Humaniform 21-DoF full-skin hand: geometry, sensor stack, wiring, BOM |
| `02_Tritalon_Hardware_Blueprint.md` | Industrial 3-finger high-force hand: plating-first fabrication, BOM |
| `03_Dermasheath_Hardware_Blueprint.md` | Retrofit liquid-metal glove skin: universal end-effector wrap |
| `04_Software_Suite_Blueprint.md` | Layered architecture, module contracts, data plane, build system |
| `05_Firmware_Reflex_Stack.md` | Edge firmware: acquisition, reflexes, safety breaker, watchdog |
| `06_Tactile_Inference_and_AI.md` | Signal processing, ERD/anomaly models, grasp scoring, sim-to-real |
| `07_Security_Warding.md` | Frame integrity, wards-as-invariants, crypto suite, key ceremony |
| `08_Telemetry_and_Orchestration.md` | Mana ledger (power budget), tiering, OTA, fleet management |

## Design Philosophy

1. **Dual-mode transduction everywhere it matters.** Every load-bearing taxel is sensed by
   capacitance (proximity + normal force) *and* resistance (true contact force); the two
   are cross-validated per-frame (Eq. R2 in each hardware guide).
2. **Reflexes live on the edge; cognition lives in the cloud tier.** A 1 ms
   sensor→motor reflex path never crosses the network. This is non-negotiable.
3. **The skin is replaceable, the skeleton is not.** All three designs treat the sensor
   sheath as a consumable with a health ledger (cycles, abrasion, drift).
4. **Speculative math earns its keep or gets cut.** Every [AN]-flagged construct must map
   to a concrete algorithm, budget, or test; otherwise it is presentation-layer only.

## Governing Equations (non-patent physics, shared by all designs)

| ID | Equation | Role |
|----|----------|------|
| P1 | $C = \varepsilon_0 \varepsilon_r A / d$ | capacitive transduction |
| P2 | $R = \rho\, L / A$ (sheet $R_s = \rho/t$) | resistive transduction |
| P3 | $V_{out} = V_{in}\, C_{ref}/(C_{sensor}+C_{ref})$ | capacitive readout |
| P4 | $V_G = V_s\left(\frac{R_3}{R_3+R_{sensor}} - \frac{R_2}{R_1+R_2}\right)$ | Wheatstone readout |
| P5 | $F = \frac{4}{3}E^*\sqrt{R}\,\delta^{3/2}$ | Hertzian contact |
| P6 | $F_{fric} \le \mu_s F_{normal}$ | slip threshold |
| P7 | $\tau = R_{trace} C_{pixel}$ | per-pixel settle time |
| P8 | $\tau_{settle} < 1/(2 f_{scan} N_{mux})$ | mux scan budget |
| P9 | $f_s > 2B$ (B = slip bandwidth) | Nyquist for micro-slip |
| P10 | $R(T) = R_0[1+\alpha(T-T_0)]$ | thermal compensation target |

## Safety Invariants (hard requirements, all designs)

- **INV-1** Normal force on any taxel of a human-contact region ≤ 1.4 N·cm⁻² (bruise limit).
- **INV-2** Reflex path latency ≤ 1 ms end-to-end, independent of host compute state.
- **INV-3** On loss of compute heartbeat > 50 ms → motors freewheel, brakes engage.
- **INV-4** Cap/Res divergence > 3σ on > 10% of taxels → conservative single-mode fallback.
- **INV-5** No unsigned tactile frame shall ever drive a motor (see `07_Security_Warding.md`).
