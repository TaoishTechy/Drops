# 05 — Firmware: Reflex Stack
**Edge acquisition, 1 ms reflexes, safety breaker, watchdog — the tier that must never fail**

## 1. Acquisition Loop (edge node, per finger)

```c
// touchfeat acquisition core — 1 kHz fingertip scan
void IRAM_ATTR scan_tick(void) {
  for (uint8_t ch = 0; ch < MUX_N; ch++) {
    mux_select(ch);
    cap[ch]  = cdc_read(ch);            // P3 divider, ~2 µs
    res[ch]  = adc_read_diff(ch);       // P4 bridge, ~1 µs
  }
  thermal_comp(cap, res, temp);         // P10: R(T), α_C·ΔT subtraction
  erd_update(cap, res);                 // bounded complex state |ε|<1
  validate_cres(cap, res);              // Eq. R2: 3σ cross-check, flag divergences
  frame_pack(&frame, cap, res);         // TactFrame (see 04 §3.1)
  sign_frame(&frame);                   // ward-crypto (see 07)
  ring_push(&frame);
}
```

Budget: 16 mux × 3 µs = 48 µs scan + 30 µs processing ≪ 1 ms. ✓

## 2. Reflex Arcs (STM32G4, from receipt of signed frame)

| Arc | Trigger | Action | Latency budget |
|---|---|---|---|
| R1 sharp-object withdrawal | dF/dt > threshold AND edge-gradient sharpness | open nearest finger 20°, brake | ≤ 1 ms |
| R2 micro-slip tighten | 130 Hz/9 Hz band ratio B > 0.15 | +Δτ on slipping finger | ≤ 2 ms |
| R3 crush breaker | ∫prot − ∫backfire < 0 (§5) | graduated release | ≤ 2 ms |
| R4 pinch-point freeze | pattern match: foreign body in joint gap | freeze all, reverse 5° | ≤ 3 ms |
| R5 heartbeat loss | no host frame > 50 ms | freewheel + brake (INV-3) | ≤ 1 ms |
| R6 sheath fault | > 10% taxels flagged (INV-4) | conservative single-mode | ≤ 10 ms |

## 3. Watchdog & Heartbeat

- Host → reflex heartbeat every 10 ms; reflex tolerates 5 misses (50 ms) then R5.
- Reflex → host veto channel is asynchronous and cannot be masked by host load.
- On boot, reflex enters SAFE (brakes on) until first valid signed host frame.

## 4. Crush Breaker (R3) — integrator form

```
U_prot  += grip_score(F_grip, stability) * dt
C_bf    += (k1*F_grip² + k2*crush_rate²) * dt
if (U_prot - C_bf < 0) graduated_release();     // Pazuzu-Effect as circuit breaker
```

`crush_rate` = low-passed second derivative of object-deformation estimate (P5 Hertzian
reconstruction of δ(t)). `k1, k2` tuned per design: Optimiform-21 (egg envelope),
Tritalon (40 N/pad), Dermasheath (host-supplied limits via haptic reflex API).

## 5. Haptic Reflex API (Dermasheath host contract)

```c
typedef struct {
  uint8_t  region;          // jaw face / edge / back
  float    normal_force;    // N, P5-reconstructed
  float    slip_band_ratio; // B (§06 §3)
  uint8_t  flags;           // INV-4, ward-breach, sheath-fault
} HapticReflexReport;

// Host MUST call at ≥ 100 Hz; missing 3 consecutive calls => sheath-safe state
// (gripper-independent: logs + alarm, since sheath cannot command host motors).
```

## 6. Calibration & Self-Test

- Boot: dark-frame baseline capture (both modes), τ settle check (P7/P8),
  cross-validation self-audit (Eq. R2 across all pixels).
- Runtime: slow auto-zero (P10 drift) at 0.1 Hz when contact-free; Zeno-rate guard —
  recalibration halted during active slip events to avoid baseline freezing.
- Per-sheath ledger write on every fault, cycle counter, and drift excursion (see `08`).
