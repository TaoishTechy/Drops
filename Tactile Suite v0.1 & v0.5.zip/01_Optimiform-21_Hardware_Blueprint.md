# 01 — Optimiform-21 Hardware Blueprint
**Humaniform hand · 21 DoF · full-skin capacitive+resistive coverage · 1,240 taxels**

## 1. Concept Summary

A five-finger humaniform hand matching the Tesla patent's geometry: curved sensors
wrapping thumb, palm, and fingers; independently monitored pixels; two transduction modes.
Design intent: general manipulation — the "egg to power tool" envelope, dexterous
in-hand manipulation, and human-safe physical interaction.

## 2. Kinematics

| Joint group | DoF | Range | Actuation |
|---|---|---|---|
| Thumb CMC / MCP / IP | 3 | 45°/60°/70° | 3× frameless BLDC + tendon, Ø8 mm |
| Fingers (×4): MCP ab/ad | 1 each | ±15° | geared BLDC, Ø6 mm |
| Fingers (×4): MCP/PIP coupled | 1 each | 90° (coupled 1:1) | same motor via four-bar |
| Wrist (pitch/roll/yaw) | 3 | ±60°/±30°/±90° | 3× Ø12 mm BLDC |

Total 21 DoF. Tendon routing through dorsal channels keeps the palmar volume clear
for the sensor stack (§4).

## 3. Taxel Layout (concept figures)

Region densities follow human mechanoreceptor distribution (fingertip-dense, palm-sparse):

| Region | Area (cm²) | Density (taxels/cm²) | Taxels | Pitch (mm) |
|---|---|---|---|---|
| Fingertip pads (×5) | 2.0 ea | 230 | 460 | 2.1 |
| Proximal phalanges (×8) | 1.5 ea | 100 | 240 | 3.2 |
| Palm thenar/hypothenar | 30 | 50 | 300 | 4.5 |
| Palm central | 40 | 50 | 200 | 4.5 |
| Thumb base | 8 | 100 | 40 | 3.2 |
| **Total** | — | — | **1,240** | — |

Dorsal coverage at 35% of palmar density (390 taxels) for collision/footprint sensing.

## 4. Sensor Stack (per §00 P1–P10)

| Layer | Material | Thickness | Function |
|---|---|---|---|
| L1 sheath | Silicone (Shore A 20) + self-healing topcoat | 0.3 mm | abrasion, wet-grip |
| L2 cap electrodes | Ag flake ink, screen-printed | 12 µm | proximity + normal force |
| L3 dielectric | PU foam, closed cell | 0.5 mm | compressible gap (P1) |
| L4 resistive | CNT/polymer piezo-ink | 15 µm | true contact force (P2) |
| L5 interconnect | Anisotropic conductive film | 50 µm | column routing |
| L6 substrate | Polyimide flex, 2-layer | 50 µm | fold + bond pads |
| L7 skeleton | Mg alloy frame + joint inserts | structural | thermal spreader |

Fabrication (patent route A): screen-print L2/L4 on flat PI → heat-mold at 140 °C over
male mandrels matched to each phalanx radius → laser-trim edges → bond L5/L6 → sheath.

**Per-tixel settle budget (P7/P8):** τ = R_trace·C_pixel ≈ 10 kΩ × 40 pF = 0.4 µs;
with 16:1 muxing at 1 kHz fingertip scan: 0.4 µs × 16 = 6.4 µs ≪ 500 µs half-period. ✓

## 5. Electronics

- **Edge node:** 1× ESP32-S3 per finger (5 nodes) + 1 palm node = 6-node I²C/RS-485 mesh.
- **ADC:** ADS131M04 (24-bit, 4-ch, 32 kSPS) per node for Wheatstone legs (P4);
  MPR121 banks for capacitive proximity channels (P3) at lower rate.
- **Reflex MCU:** STM32G4 (170 MHz) per hand — owns INV-2/INV-3 paths independent of S3s.
- **IMU:** 1× MPU9250 per finger base + 1 palm — inertial-tactile fusion (active vs passive touch).
- **Thermistors:** 1 per region (6 total) — P10 compensation in firmware (see `05`).

## 6. Wiring Plan

Dorsal bus: 6 × (SDA/SCL + RS-485 A/B + 5 V + GND) in a flat flex "spine" from wrist to
nodes. Per-finger taxel matrix ≤ 48 rows × 26 cols → 74 lines → 5 × ACF tail bonds.
Hot-swap: sheath connects via zero-insertion-force connector at each knuckle; tool-free
sheath swap < 5 min (consumable design philosophy).

## 7. Bill of Materials (prototype tier, ~USD)

| Item | Qty | Unit | Ext. |
|---|---|---|---|
| ESP32-S3 module | 6 | $8 | 48 |
| STM32G4 + driver board | 1 | $22 | 22 |
| ADS131M04 breakout | 6 | $12 | 72 |
| BLDC Ø8/Ø6/Ø12 + drivers | 21 | — | 260 |
| Mg alloy frame (CNC) | 1 | 180 | 180 |
| Sensor ink set (Ag + CNT) | 1 | 90 | 90 |
| PI flex + ACF + foam + silicone | lot | 60 | 60 |
| MPR121 + misc passives | lot | 35 | 35 |
| **Total** | | | **≈ 767** |

## 8. Verification Plan

| Test | Method | Acceptance |
|---|---|---|
| Pixel SNR | 1 g–1 kg force steps, static | SNR ≥ 40 dB (P10-baseline) |
| Scan integrity | known 3×3 touch pattern at max rate | zero missed/dropped pixels |
| Slip detection | 130 Hz/9 Hz synthetic slip (see `06`) | ≥ 95% detection ≤ 5 ms pre-failure |
| Reflex latency | scope: taxel edge → motor command | ≤ 1 ms (INV-2) |
| INV-4 fallback | force 5% pixel divergence via injected fault | single-mode fallback ≤ 10 ms |
| Sheath life | 1M cycle flex rig | < 5% taxel failure, drift < 2%/100k cycles |

## 9. Equation anchors

Cross-validation Eq. R2: $valid(p)=\mathbf{1}\big[\big|\frac{\Delta C/C_0}{\alpha}-\frac{\Delta R/R_0}{GF}\big|<3\sigma\big]$;
curvature compensation: $\varepsilon_{true}=\varepsilon_{raw}(1+\kappa^2EI/2)$;
holographic repair [AN]: $\hat\varepsilon_i=\sum_{j\in\partial i} w_{ij}\varepsilon_j$.
