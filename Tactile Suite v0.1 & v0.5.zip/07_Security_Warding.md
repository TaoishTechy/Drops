# 07 — Security & Warding
**Frame integrity, wards-as-invariants, cryptographic suite, and key ceremony**

> Terminology note: "ward" is used throughout as *a safety or integrity invariant enforced
> in code* — never as a metaphysical claim. All cryptography is standard, public, and vetted.

## 1. Threat Model

| Threat | Vector | Countermeasure |
|---|---|---|
| Spoofed motor commands | network injection | INV-5: Ed25519-signed MotorCmd |
| Tactile frame tampering | bus snoop/rewrite | per-frame signature + seq |
| Replay | recorded frames | seq + PTP timestamp window (±2 ms) |
| Timing side-channel | MAC comparison | constant-time compare |
| Malicious OTA | firmware supply chain | signed bundles + rollback counter |
| Sensor self-spoofing | EMI injection | spectral quarantine (§5) + R2/R3 arcs |

## 2. Frame Cryptography

- Signature: Ed25519 on all `TactFrame` and `MotorCmd` (`04` §3).
  Signing cost on STM32G4: ~900 µs per frame batch (amortized over 16-px batches).
- MAC: HMAC-SHA-256 on the high-rate edge↔reflex link; session keys via HKDF.
- Session salt: derived from the physical taxel-layout matrix (hardware binding —
  frames from a different physical hand fail verification).
- Post-quantum roadmap: ML-DSA-65 hybrid signatures at next key rotation (tracked item).

## 3. Wards (invariants enforced)

```c
enum Ward {
  WARD_FORCE_LIMIT,     // INV-1: per-region force ceiling      [reflex, hard]
  WARD_REFLEX_LATENCY,  // INV-2: 1 ms path timer                [reflex, hard]
  WARD_HEARTBEAT,       // INV-3: 50 ms host liveness            [reflex, hard]
  WARD_DUAL_MODE,       // INV-4: cap/res divergence budget      [edge, hard]
  WARD_SIGNED_DRIVE,    // INV-5: unsigned frames never drive    [reflex, hard]
  WARD_SKIN_LEDGER,     // sheath cycles/drift within envelope   [host, soft]
};
```

A ward "holds" iff its predicate is continuously true; breach → declared state +
mitigation (never silent). Ward state is exposed in telemetry (`08`) and on the
debug LED stack (green = all hold; red = breach class).

## 4. Constant-Time & Pipeline Discipline

All gates in the frame-accept pipeline run fixed-size, branch-minimal code:

```c
bool accept_frame(const Frame* f) {
  uint8_t bad = 0;
  bad |= (f->n_taxels != EXPECTED);
  bad |= seq_replay(f);                 // monotonic counter
  bad |= ts_stale(f);                   // ±2 ms window
  bad |= !ct_mac_equal(f->mac, compute_mac(f));   // no early exit
  return bad == 0;
}
```

## 5. Spectral Quarantine (EMI self-spoofing defense)

Attack signatures (recurring EMI interference patterns) form a propagation graph;
if the graph's spectral radius exceeds 1, the interference is self-amplifying across
regions → isolate the affected bank, fall back to resistive-only mode (INV-4).

```python
def quarantine_needed(emi_corr_adj):
    return max(abs(np.linalg.eigvals(emi_corr_adj))) > 1.0
```

## 6. Key Ceremony & Rotation

- Per-hand keypair generated in the STM32G4 at first boot; private key never leaves.
- Factory cert (offline root) signs the hand's public key → chain anchored in fleet CA.
- Rotation: every 90 days or on ward-breach event, whichever first; rotation requires
  the old key to countersign the new one (no gap).
- Ceremony transcripts append-only to the Merkle grasp log (`08` §3).

## 7. Paraconsistent Reporting

Contradictory sensor evidence (cap says contact, res says none) is *carried* as flagged
data with a contradiction budget (≤ 3 per region) — never silently resolved — so
downstream systems see the ambiguity explicitly. Resolution only after evidence
accumulates or a reflex arc forces the issue.
