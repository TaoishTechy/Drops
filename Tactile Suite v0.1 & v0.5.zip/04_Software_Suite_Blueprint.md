# 04 — Software Suite Blueprint
**Layered architecture, module contracts, data plane, and build system for all three hands**

## 1. Architecture Overview

```
┌──────────────────────────────────────────────────────────────────────┐
│ CLOUD TIER   inference training · fleet analytics · heavy compression │
├──────────────────────────────────────────────────────────────────────┤
│ HOST TIER    grasp planning · tactile-only classification · logging  │
│              (ROS 2 / custom IPC; runs on robot computer)            │
├──────────────────────────────────────────────────────────────────────┤
│ EDGE TIER    per-finger ESP32-S3 nodes: acquisition + light inference│
├──────────────────────────────────────────────────────────────────────┤
│ REFLEX TIER  STM32G4 per hand: 1 ms sensor→motor path, safety INV    │
└──────────────────────────────────────────────────────────────────────┘
```

Hard rule: the reflex tier can veto any motor command from any upper tier, instantly,
on tactile evidence. Upper tiers cannot veto the reflex tier.

## 2. Module Map

| Module | Tier | Responsibility | Doc |
|---|---|---|---|
| `taxel-hal` | Edge | ADC scan, mux, thermal comp, calibration | `05` |
| `reflex` | Reflex | slip, crush, watchdog, heartbeat, reflex arcs | `05` |
| `tact-ipc` | Edge/Host | framed, signed, timestamped tactile streams | `07` |
| `touchfeat` | Edge | FFT bands, ERD update, cross-validation | `06` |
| `graspctl` | Host | FOPID + impedance loops, P-B-T state | `06` |
| `tactile-ai` | Host/Cloud | CNN classifier, anomaly, force-curve prediction | `06` |
| `skin-health` | Host | per-sheath ledger: cycles, drift, abrasion | `08` |
| `ward-crypto` | All | frame signing, wards, attestation | `07` |
| `fleet-tele` | Cloud | telemetry, OTA, Merkle grasp logs | `08` |

## 3. Data Plane

### 3.1 Tactile frame (canonical)

```c
struct TactFrame {
  uint32_t seq;           // strictly increasing per channel
  uint64_t t_us;          // PTP-synced, ±50 µs across nodes
  uint16_t node_id;
  uint16_t n_taxels;
  int16  cap_delta[];     // Q4.12, P3-normalized
  int16  res_delta[];     // Q4.12, P4-normalized
  int8   temp_c[];        // per-region, P10 input
  uint8  flags;           // bit0 conservative-mode, bit1 sheath-fault, bit2 ward-breach
} __attribute__((packed));
```

Rate: fingertip nodes 1 kHz, palm 200 Hz (Optimiform-21); Tritalon 2 kHz/500 Hz;
Dermasheath 500 Hz. Transport: UDP over RS-485 (edge↔reflex) and Ethernet (host).

### 3.2 Motor command frame

```c
struct MotorCmd {
  uint32_t seq;
  uint64_t t_us_deadline;  // reflex discards if |now-deadline| > 2 ms
  float    torque[21];
  uint8    sig[64];        // Ed25519 over (seq‖deadline‖torque‖prev_hash)
};
```

INV-5 enforcement: reflex hardware drops unsigned or stale frames.

## 4. Control Contracts

- `REFLEX_VETO` — reflex tier publishes veto events (overpressure, slip, watchdog).
  Host must acknowledge within 10 ms or reflex escalates to freewheel (INV-3).
- `GRASP_STATE` — P-B-T vector (π_eff, ∂B, γ) published at 100 Hz by `graspctl`.
- `SKIN_HEALTH` — per-sheath ledger object (see `08`).

## 5. Build System

- Edge/reflex: PlatformIO, C++17, `-O2 -Werror`, unit tests (Unity) on host stubs.
- Host: ROS 2 Jazzy + `colcon`; algorithms in C++/Python (PyTorch for `tactile-ai`).
- CI gates: unit tests → HIL rig (recorded taxel traces) → static analysis → signed OTA
  bundle (see `08` §4).

## 6. Interfaces to the speculative layer [AN]

| Analogy construct | Software realization | Guard |
|---|---|---|
| ERD field ε | running complex touch-state estimate (touchfeat) | bounded \|ε\|<1 by construction |
| Ward invariant | signed frame + INV limits in reflex | never presentation-only |
| Mana ledger | power/compute budget governor (08 §2) | hard ceilings, no narrative |
| Pazuzu breaker | crush-cost vs protection-utility integrator | see `05` §5 |
| Coherence polytope | health gate σ/ρ/r thresholds → degradation | hysteresis bands |

Every [AN] construct that cannot point to a line of code and a test is excluded from builds.
