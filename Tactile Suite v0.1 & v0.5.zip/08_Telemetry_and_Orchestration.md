# 08 — Telemetry, Orchestration & Fleet
**Power/compute budget governor ("mana ledger"), data tiering, OTA, fleet management**

## 1. Telemetry Envelope

Per hand, steady-state: 1.2 k taxel frames/s avg × ~120 B ≈ 145 kB/s raw; after
edge pre-filtering (contact regions only, Δ-encoding) ≈ 18 kB/s per hand uplink.
Debug channel (full-fidelity ring buffer, 10 s) on demand only.

## 2. Mana Ledger (power/compute budget governor) [AN → concrete]

```python
class ManaLedger:
    # Every scan, inference, and transmission spends; regenerator replenishes.
    # Hard ceilings prevent any 'spell' from overchanneling the node.
    def tick(self, regen, spend_scan, spend_infer, spend_tx, dt):
        self.M += (regen - spend_scan - spend_infer - spend_tx) * dt
    def can(self, cost, floor=10.0):
        return self.M - cost > floor      # act only above the safety floor
```

Governed allocations: scan rate (never below reflex minimum), AI inference duty cycle,
OTA window scheduling, and haptic mirroring bandwidth. All ceilings are config values
with engineering sign-off — no narrative overrides.

## 3. Data Tiering & Grasp Log

| Tier | Contents | Retention |
|---|---|---|
| SRAM (edge) | live frames, reflex window | seconds |
| SD/eMMC (host) | filtered sessions, health ledger | 30 days |
| Cloud | VQ-VAE-compressed maps, training corpora | per policy |

Every completed grasp is appended as a Merkle leaf (seq, object class, peak force,
stability score, ward state); the daily root is anchored externally — tamper-evident
manipulation history across the fleet.

## 4. OTA & Release Train

- Bundles: signed (Ed25519), versioned, with rollback counter in secure element.
- Ring deployment: 1% → 10% → 100% with automatic halt on ward-breach-rate regression.
- HIL gate (`06` §8) must pass on recorded traces before any ring opens.

## 5. Skin-Health Ledger (per sheath, per hand)

Tracks: deformation cycles (Arrhenius-weighted by temperature), per-region drift
(P10 compensation history), abrasion events (high-shear counters), fault flags (INV-4),
ward breaches. Predictive replacement: remaining-life model = f(cycles, drift slope,
fault density); alert at 20% predicted life. This ledger is what makes the sheath a
managed consumable (design philosophy §00).

## 6. Fleet Analytics

Cross-fleet aggregates (privacy-preserving, no raw human-contact data leaves the robot):
- slip-event rate per surface class → fleet-wide friction prior updates
- crush-breaker firing rate → training data for the `k1, k2` integrator gains
- taxel failure density maps → fabrication feedback to `01–03` print parameters

## 7. Failure Ops Runbook (summary)

| Symptom | First action | Escalation |
|---|---|---|
| Ward-burst on one node | isolate node → conservative mode | swap sheath/node |
| Repeated R2/R3 firings | freeze task, dump ring buffer | replay bench, retrain prior |
| Fleet-wide drift slope ↑ | halt OTA ring | fabrication review |
| Heartbeat storms (INV-3) | check host scheduler | reflex-only degraded mode |
