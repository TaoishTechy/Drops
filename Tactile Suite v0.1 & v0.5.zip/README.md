# Tactile Hand Blueprint Suite — v1.0

Nine-document engineering blueprint for three conceptual tactile hands (Optimiform-21,
Tritalon, Dermasheath) built on Tesla-style flexible capacitive–resistive skin, plus the
full software suite that runs them.

Read in order: `00_INDEX` → hardware guide (01/02/03) → `04_Software_Suite_Blueprint` →
05–08 by role.

Conventions: *(concept)* = design target, not measured; **[AN]** = speculative-framework
analogy realized as concrete code; safety invariants INV-1…INV-5 are hard requirements.
