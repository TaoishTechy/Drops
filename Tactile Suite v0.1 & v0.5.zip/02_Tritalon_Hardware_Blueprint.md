# 02 — Tritalon Hardware Blueprint
**Industrial 3-finger gripper · 9 DoF · plating-first fabrication · 540 taxels · high-force**

## 1. Concept Summary

A three-finger industrial manipulator (caging, parallel-pinch, and power-grasp modes)
using the patent's *second* fabrication route: build the curved structural base first,
then add conductive patterns via ink dispensers / printing pads / laser-prepared metal
plating. Design intent: factory manipulation — metal parts, tools, crates; chemical and
high-wear environments; force-dominant tasks where the humaniform hand's compliance is
a liability.

## 2. Kinematics

| Joint group | DoF | Range | Actuation |
|---|---|---|---|
| Finger 1–3: proximal | 1 ea | 0–110° | 3× 50 N·m harmonic BLDC, Ø28 mm |
| Finger 1–3: distal | 1 ea (coupled 1.4:1) | 0–90° | same motor, linkage |
| Wrist yaw / pitch | 2 | ±180°/±45° | 2× Ø22 mm BLDC |
| Palm spread | 1 | 0–60° | 1× Ø22 mm BLDC |

Total 9 DoF. Max continuous fingertip force 180 N; structural limit 600 N (verified by
Mohr-Coulomb shear check on held object, P6-family).

## 3. Taxel Layout (concept figures)

| Region | Area (cm²) | Density | Taxels | Notes |
|---|---|---|---|---|
| Fingertip pads (×3) | 3.5 ea | 180 | 189 | 2.4 mm pitch, dual-mode |
| Distal segments (×3) | 4.0 ea | 60 | 72 | resistive-primary |
| Proximal segments (×3) | 8.0 ea | 30 | 72 | resistive-primary |
| Palm plate | 60 | 35 | 210 | cap-validated |
| **Total** | — | — | **543 → spec 540** | — |

Dorsal coverage 20% (crash/footprint sensing).

## 4. Sensor Stack — plating-first route

| Layer | Material | Thickness | Process |
|---|---|---|---|
| L1 sheath | TPU (Shore A 85), chemical-resistant | 0.6 mm | overmold |
| L2 resistive grid | Electroless Cu on LDS polymer | 18 µm | laser-direct-structuring |
| L3 dielectric | Perforated PU foam | 0.8 mm | bonded |
| L4 cap electrodes | Ag ink, dispenser-printed | 12 µm | 5-axis dispenser |
| L5 substrate | The structural finger shell itself | — | plated directly |
| L6 skeleton | Grade-5 Ti shell (curved base) | 2 mm | CNC + LDS activator |

Rationale: plating the conductor onto the load-bearing shell eliminates the flex-substrate
delamination mode entirely; the skin wears, the shell does not.

**Settle budget (P7/P8):** longer traces (R_trace ≈ 25 kΩ) → τ ≈ 1.0 µs; 2 kHz fingertip
scan with 24:1 mux: 24 µs ≪ 250 µs half-period. ✓

## 5. Electronics

- Single edge node per finger (3× ESP32-S3) + 1 wrist node.
- Resistive readout: 4-wire Kelvin via ADS131M04 (nulls L2 trace resistance drift).
- Capacitive: custom CDC front-end (FDC2214, 28-bit) for L4 validation channel.
- Reflex MCU: STM32G4 — owns crush-avoidance (INV-1 at 180 N scale: cap force limit
  per region, not per taxel: 40 N/pad).
- Vibration channel: 1× piezo film strip per fingertip (slip spectroscopy, see `06`).

## 6. Wiring Plan

Through-shell vias from dorsal pad ring to internal cavity; single armored flex umbilical
wrist→controller. No per-knuckle connectors (sealed industrial design); sheath replacement
is a service operation (~30 min), not a consumable swap.

## 7. Bill of Materials (prototype tier)

| Item | Qty | Unit | Ext. |
|---|---|---|---|
| Harmonic BLDC Ø28 + drivers | 3 | 85 | 255 |
| BLDC Ø22 + drivers | 3 | 45 | 135 |
| Ti shell set (CNC + LDS) | 3 | 140 | 420 |
| ESP32-S3 + ADS131M04 + FDC2214 | 4 | 32 | 128 |
| Cu plating chem + Ag ink | lot | 110 | 110 |
| TPU overmold tooling (soft tool) | 1 | 300 | 300 |
| Piezo strips, passives, seals | lot | 60 | 60 |
| **Total** | | | **≈ 1,408** |

## 8. Verification Plan

| Test | Method | Acceptance |
|---|---|---|
| Force accuracy | 10–180 N reference load cell | ±2% FS |
| Chemical soak | 72 h in cutting-fluid mist | zero drift > 3σ |
| Wear | 500k grasp cycles on grit-blasted parts | sheath intact, < 8% taxel loss |
| Slip spectroscopy | lubricated steel plate pull | ≥ 90% pre-slip detection |
| Crush guard | 200 N commanded into instrumented egg analog | auto-release ≤ 5 ms, egg intact (INV analog) |

## 9. Equation anchors

Wind-modulated friction threshold [AN]: $F_{fric}\le\mu_s F_n - \rho|\vec v_{sw}|^2A_d$
(aerodynamic unload term for high-speed approach); spectral quarantine [AN]:
$R_0=\rho(A_{attack})>1\Rightarrow$ isolate EMI signature cluster.
