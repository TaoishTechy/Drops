"""Hardware discovery and a portable execution plan.

The same plan object is used on NVIDIA CUDA, AMD ROCm (when exposed
through torch), Apple MPS, and CPU. Callers never branch on vendor
strings in application code.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

import torch


Backend = Literal["cuda", "rocm", "mps", "cpu"]


@dataclass(frozen=True)
class DevicePlan:
    backend: Backend
    device: torch.device
    device_index: int
    name: str
    compute_capability: tuple[int, int] | None
    total_memory_bytes: int | None
    supports_tf32: bool
    supports_bf16: bool
    supports_fp16: bool
    supports_compile: bool
    notes: tuple[str, ...] = field(default_factory=tuple)

    def tensor_kwargs(self, dtype: torch.dtype | None = None) -> dict[str, Any]:
        kw: dict[str, Any] = {"device": self.device}
        if dtype is not None:
            kw["dtype"] = dtype
        return kw

    def enable_fast_math(self) -> None:
        if self.backend == "cuda" and self.supports_tf32:
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.backends.cudnn.allow_tf32 = True
            if hasattr(torch, "set_float32_matmul_precision"):
                torch.set_float32_matmul_precision("high")


def detect_device(prefer: Backend | None = None) -> DevicePlan:
    """Select the best available device. Never raises on missing GPU."""
    notes: list[str] = []

    if prefer == "cpu":
        return _cpu_plan(notes + ["explicit CPU preference"])

    if torch.cuda.is_available():
        idx = torch.cuda.current_device()
        props = torch.cuda.get_device_properties(idx)
        name = props.name
        is_rocm = bool(getattr(torch.version, "hip", None))
        backend: Backend = "rocm" if is_rocm else "cuda"
        major = int(getattr(props, "major", 0))
        minor = int(getattr(props, "minor", 0))
        bf16 = (not is_rocm and major >= 8) or is_rocm
        plan = DevicePlan(
            backend=backend,
            device=torch.device(f"cuda:{idx}"),
            device_index=idx,
            name=name,
            compute_capability=(major, minor) if not is_rocm else None,
            total_memory_bytes=int(getattr(props, "total_memory", 0)),
            supports_tf32=not is_rocm and major >= 8,
            supports_bf16=bf16,
            supports_fp16=True,
            supports_compile=_compile_available(),
            notes=tuple(notes + [f"selected {backend}:{idx}"]),
        )
        plan.enable_fast_math()
        return plan

    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return DevicePlan(
            backend="mps",
            device=torch.device("mps"),
            device_index=0,
            name="Apple MPS",
            compute_capability=None,
            total_memory_bytes=None,
            supports_tf32=False,
            supports_bf16=False,
            supports_fp16=True,
            supports_compile=False,
            notes=tuple(notes + ["selected mps"]),
        )

    return _cpu_plan(notes + ["no accelerator advertised by torch"])


def _cpu_plan(notes: list[str]) -> DevicePlan:
    return DevicePlan(
        backend="cpu",
        device=torch.device("cpu"),
        device_index=-1,
        name="CPU",
        compute_capability=None,
        total_memory_bytes=None,
        supports_tf32=False,
        supports_bf16=True,
        supports_fp16=False,
        supports_compile=_compile_available(),
        notes=tuple(notes),
    )


def _compile_available() -> bool:
    return hasattr(torch, "compile")
