"""Portable fused kernels.

When Triton is present these can be swapped for vendor kernels. The
default path is pure PyTorch so the stack remains drop-in on CPU, MPS,
ROCm, and CUDA without extra compilers.
"""

from __future__ import annotations

import math
from typing import Literal

import torch
import torch.nn.functional as F


Precision = Literal["fp32", "fp16", "bf16"]


def dtype_of(precision: Precision) -> torch.dtype:
    return {"fp32": torch.float32, "fp16": torch.float16, "bf16": torch.bfloat16}[precision]


def autocast_dtype(device_type: str, precision: Precision) -> torch.dtype | None:
    if precision == "fp32":
        return None
    if device_type == "cpu" and precision == "fp16":
        return None
    return dtype_of(precision)


def fused_linear_gelu(x: torch.Tensor, weight: torch.Tensor, bias: torch.Tensor | None) -> torch.Tensor:
    return F.gelu(F.linear(x, weight, bias), approximate="tanh")


def rms_norm(x: torch.Tensor, weight: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    rms = torch.rsqrt(x.pow(2).mean(dim=-1, keepdim=True) + eps)
    return x * rms * weight


def scaled_dot_product(q: torch.Tensor, k: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    if hasattr(F, "scaled_dot_product_attention"):
        return F.scaled_dot_product_attention(q, k, v)
    scale = 1.0 / math.sqrt(q.shape[-1])
    scores = torch.matmul(q, k.transpose(-2, -1)) * scale
    return torch.matmul(torch.softmax(scores, dim=-1), v)


def landauer_cost_joules(n_bits: int, temperature_k: float = 310.0) -> float:
    """Lower bound on irreversible bit erasure (Landauer). Diagnostic only."""
    k_b = 1.380649e-23
    return n_bits * k_b * temperature_k * math.log(2.0)
