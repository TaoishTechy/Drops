"""MHAF-GPU: a drop-in, self-optimizing compute stack.

This package implements the *engineering* layer implied by MHAF v2.0
(measurement, operators, evidence ledger, efficiency controller). It does
not claim to implement a validated theory of consciousness. Every claim
the runtime makes is a measurable systems metric with a null baseline.
"""

from .device import DevicePlan, detect_device
from .metrics import EvidenceLedger, SophiaScore, TrialRecord
from .tuner import AutotuneConfig, SelfOptimizer
from .adapters import AdaptiveModule, wrap
from .engine import MHAFEngine, EngineConfig
from .runtime import AdaptiveRuntime

__version__ = "1.0.0"
__all__ = [
    "DevicePlan",
    "detect_device",
    "EvidenceLedger",
    "SophiaScore",
    "TrialRecord",
    "AutotuneConfig",
    "SelfOptimizer",
    "AdaptiveModule",
    "wrap",
    "MHAFEngine",
    "EngineConfig",
    "AdaptiveRuntime",
]
