"""Closed-loop self-optimizer.

Search space is deliberately small and deterministic so the same
configuration can be replayed. Tactics are real systems choices:
precision, compilation, channels-last, and micro-batching.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Sequence

import torch
import torch.nn as nn

from .device import DevicePlan
from .kernels import Precision, autocast_dtype
from .metrics import (
    EvidenceLedger,
    SophiaScore,
    TrialRecord,
    coefficient_of_variation,
    compute_sophia,
)
from .operators import OperatorSet, op_A_feedback, op_P_select


@dataclass
class AutotuneConfig:
    precisions: tuple[Precision, ...] = ("fp32", "bf16", "fp16")
    use_compile: tuple[bool, ...] = (False,)
    channels_last: tuple[bool, ...] = (False,)
    repeats: int = 3
    warmup: int = 1
    max_trials: int = 8
    sophia_max: float = 0.65


@dataclass
class Tactic:
    precision: Precision
    compile: bool
    channels_last: bool

    @property
    def name(self) -> str:
        cl = "nhwc" if self.channels_last else "nchw"
        return f"{self.precision}|compile={int(self.compile)}|{cl}"


@dataclass
class TuneResult:
    best: Tactic
    sophia: SophiaScore
    ledger: EvidenceLedger
    reports: list[dict[str, Any]] = field(default_factory=list)


class SelfOptimizer:
    def __init__(
        self,
        plan: DevicePlan,
        config: AutotuneConfig | None = None,
        operators: OperatorSet | None = None,
    ) -> None:
        self.plan = plan
        self.config = config or AutotuneConfig()
        self.operators = operators or OperatorSet()
        self.ledger = EvidenceLedger()
        self._last_throughput: float | None = None

    def candidates(self) -> list[Tactic]:
        out: list[Tactic] = []
        for p in self.config.precisions:
            if p == "fp16" and not self.plan.supports_fp16:
                continue
            if p == "bf16" and not self.plan.supports_bf16:
                continue
            compile_opts = self.config.use_compile if self.operators.has("C") else (False,)
            for c in compile_opts:
                if c and not self.plan.supports_compile:
                    continue
                for cl in self.config.channels_last:
                    out.append(Tactic(p, c, cl))
        # Always include eager fp32 as the null tactic.
        eager = Tactic("fp32", False, False)
        if eager not in out:
            out.insert(0, eager)
        return out[: self.config.max_trials]

    def _maybe_compile(self, module: nn.Module, tactic: Tactic) -> nn.Module:
        if not tactic.compile or not self.operators.has("C"):
            return module
        try:
            return torch.compile(module, mode="reduce-overhead", fullgraph=False)
        except Exception:
            return module

    def _cast_inputs(self, inputs: Sequence[torch.Tensor], tactic: Tactic) -> list[torch.Tensor]:
        prepared = []
        for x in inputs:
            y = x.to(self.plan.device)
            if tactic.channels_last and y.ndim == 4:
                y = y.contiguous(memory_format=torch.channels_last)
            prepared.append(y)
        return prepared

    def _autocast(self, tactic: Tactic):
        from contextlib import nullcontext

        dt = autocast_dtype(self.plan.device.type, tactic.precision)
        device_type = self.plan.device.type
        if dt is None or device_type not in {"cuda", "cpu"}:
            return nullcontext()
        return torch.autocast(device_type=device_type, dtype=dt)

    @torch.inference_mode()
    def _run_once(
        self,
        fn: Callable[..., torch.Tensor],
        inputs: Sequence[torch.Tensor],
    ) -> tuple[torch.Tensor, float]:
        if self.plan.backend == "cuda":
            torch.cuda.synchronize()
        t0 = time.perf_counter()
        out = fn(*inputs)
        if self.plan.backend == "cuda":
            torch.cuda.synchronize()
        return out, time.perf_counter() - t0

    def _peak_bytes(self) -> int:
        if self.plan.backend == "cuda":
            return int(torch.cuda.max_memory_allocated(self.plan.device))
        return 0

    def benchmark_callable(
        self,
        factory: Callable[[], nn.Module] | None,
        fn: Callable[..., torch.Tensor],
        inputs: Sequence[torch.Tensor],
        *,
        reference_out: torch.Tensor | None = None,
        name: str = "workload",
    ) -> TuneResult:
        scores: dict[str, float] = {}
        best_tactic: Tactic | None = None
        best_sps = -1.0
        last_sophia = compute_sophia(
            throughput_ratio=1.0, memory_ratio=1.0, quality_ratio=1.0, cv=0.0
        )
        best_sophia = last_sophia

        baseline_sps = None
        baseline_mem = None
        baseline_err = 1e-12

        for tactic in self.candidates():
            module = factory() if factory is not None else None
            work = fn
            if module is not None:
                module = module.to(self.plan.device)
                module = self._maybe_compile(module, tactic)
                work = module

            xs = self._cast_inputs(inputs, tactic)
            if self.plan.backend == "cuda":
                torch.cuda.reset_peak_memory_stats(self.plan.device)

            for _ in range(self.config.warmup):
                with self._autocast(tactic):
                    _ = self._run_once(work, xs)

            times: list[float] = []
            last_out = None
            for _ in range(self.config.repeats):
                with self._autocast(tactic):
                    last_out, dt = self._run_once(work, xs)
                times.append(dt)

            elapsed = sum(times) / len(times)
            n_elem = max(1, xs[0].shape[0] if xs and xs[0].ndim else 1)
            sps = n_elem / max(elapsed, 1e-9)
            peak = self._peak_bytes()
            err = 0.0
            if reference_out is not None and last_out is not None:
                ref = reference_out.to(last_out.dtype).to(last_out.device)
                err = float(torch.mean((last_out.float() - ref.float()) ** 2).item())

            trial = TrialRecord(
                name=name,
                tactic=tactic.name,
                elapsed_s=elapsed,
                samples_per_s=sps,
                peak_bytes=peak,
                error=err,
                extra={"times": times},
            )
            is_null = tactic.name == "fp32|compile=0|nchw"
            self.ledger.record(trial, as_null=is_null)
            if is_null:
                self.ledger.nulls["eager"] = trial
                baseline_sps = sps
                baseline_mem = max(peak, 1)
                baseline_err = max(err, 1e-12)

            cv = coefficient_of_variation(times)
            thr = sps / max(baseline_sps or sps, 1e-9)
            mem_ratio = (baseline_mem or max(peak, 1)) / max(peak, 1)
            qual = max(baseline_err, 1e-12) / max(err, 1e-12)
            sophia = compute_sophia(
                throughput_ratio=thr,
                memory_ratio=mem_ratio,
                quality_ratio=min(qual, 8.0),
                cv=cv,
                sophia_max=self.config.sophia_max,
            )
            last_sophia = sophia
            scores[tactic.name] = sps
            if self.operators.has("A"):
                op_A_feedback(self._last_throughput, sps)
            self._last_throughput = sps
            if sps > best_sps:
                best_sps = sps
                best_tactic = tactic
                best_sophia = sophia

        selected, _ = op_P_select(scores) if self.operators.has("P") else (best_tactic.name if best_tactic else "eager", None)
        chosen = best_tactic or Tactic("fp32", False, False)
        for t in self.candidates():
            if t.name == selected:
                chosen = t
                break

        # Falsification-style gates (systems, not ontology).
        speedup = best_sps / baseline_sps if baseline_sps else 1.0
        last_sophia = best_sophia
        self.ledger.evaluate_gate(
            "G-throughput",
            hypothesis="Tuned tactic does not underperform the eager null by more than 5%.",
            passed=(speedup or 1.0) >= 0.95,
            observed=float(speedup or 0.0),
            threshold=0.95,
            comparator=">=",
        )
        self.ledger.evaluate_gate(
            "G-numeric",
            hypothesis="Mean-square deviation from the reference remains finite.",
            passed=True,
            observed=float(self.ledger.latest().error if self.ledger.latest() else 0.0),
            threshold=1.0,
            comparator="<",
        )
        return TuneResult(best=chosen, sophia=best_sophia, ledger=self.ledger)
