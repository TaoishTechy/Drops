"""Command-line benchmark: mhaf-gpu-bench"""

from __future__ import annotations

import argparse
import json

import torch
import torch.nn as nn

from .device import detect_device
from .engine import MHAFEngine
from .tuner import AutotuneConfig, SelfOptimizer


class _Toy(nn.Module):
    def __init__(self, dim: int = 256) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, dim),
            nn.GELU(),
            nn.Linear(dim, dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="MHAF-GPU self-optimizer benchmark")
    p.add_argument("--batch", type=int, default=64)
    p.add_argument("--dim", type=int, default=256)
    p.add_argument("--repeats", type=int, default=3)
    p.add_argument("--engine-steps", type=int, default=8)
    args = p.parse_args(argv)

    plan = detect_device()
    model = _Toy(args.dim).to(plan.device)
    x = torch.randn(args.batch, args.dim, device=plan.device)
    cfg = AutotuneConfig(repeats=args.repeats, warmup=1, max_trials=6, use_compile=(False,))
    opt = SelfOptimizer(plan, cfg)
    result = opt.benchmark_callable(factory=None, fn=model, inputs=(x,), name="toy_mlp")
    engine = MHAFEngine(plan=plan)
    engine.run(args.engine_steps)
    payload = {
        "device": {"backend": plan.backend, "name": plan.name},
        "best_tactic": result.best.name,
        "sophia": result.sophia.as_dict(),
        "ledger": result.ledger.summary(),
        "engine": engine.efficiency_report(),
    }
    print(json.dumps(payload, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
