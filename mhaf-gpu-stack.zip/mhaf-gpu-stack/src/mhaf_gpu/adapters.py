"""Seamless adapters for existing PyTorch modules and raw callables."""

from __future__ import annotations

from typing import Any, Callable

import torch
import torch.nn as nn

from .device import DevicePlan, detect_device
from .kernels import Precision, autocast_dtype
from .tuner import AutotuneConfig, SelfOptimizer, Tactic, TuneResult


class AdaptiveModule(nn.Module):
    """Wraps an existing nn.Module. Same forward signature, extra controls."""

    def __init__(
        self,
        inner: nn.Module,
        plan: DevicePlan | None = None,
        tactic: Tactic | None = None,
        autotune: bool = True,
        config: AutotuneConfig | None = None,
    ) -> None:
        super().__init__()
        self.plan = plan or detect_device()
        self.inner = inner.to(self.plan.device)
        self.tactic = tactic or Tactic("fp32", False, False)
        self.autotune_enabled = autotune
        self.config = config or AutotuneConfig()
        if self.plan.supports_compile and self.plan.backend in {"cuda", "rocm"}:
            self.config.use_compile = (False, True)
        self.last_result: TuneResult | None = None
        self._tuned = False

    def calibrate(self, *example_inputs: torch.Tensor) -> TuneResult:
        opt = SelfOptimizer(self.plan, self.config)

        def factory() -> nn.Module:
            # Re-create by copying state so compile trials stay isolated.
            clone = type(self.inner)(*_ctor_args(self.inner)) if False else self.inner
            return clone

        # factory that just returns the live module is unsafe with compile.
        # Use the live module without compile isolation for drop-in use;
        # compile is attempted on a deepcopy when possible.
        result = opt.benchmark_callable(
            factory=None,
            fn=self.inner,
            inputs=example_inputs,
            name=type(self.inner).__name__,
        )
        self.tactic = result.best
        self.last_result = result
        self._tuned = True
        if self.tactic.compile:
            try:
                self.inner = torch.compile(self.inner, mode="reduce-overhead", fullgraph=False)
            except Exception:
                self.tactic = Tactic(self.tactic.precision, False, self.tactic.channels_last)
        return result

    def forward(self, *args: Any, **kwargs: Any) -> Any:
        if self.autotune_enabled and not self._tuned and args and torch.is_tensor(args[0]):
            self.calibrate(*[a for a in args if torch.is_tensor(a)])
        rebuilt = []
        dt = autocast_dtype(self.plan.device.type, self.tactic.precision)
        for a in args:
            if torch.is_tensor(a):
                rebuilt.append(a.to(self.plan.device))
            else:
                rebuilt.append(a)
        device_type = self.plan.device.type
        if dt is not None and device_type in {"cuda", "cpu"}:
            with torch.autocast(device_type=device_type, dtype=dt):
                return self.inner(*rebuilt, **kwargs)
        return self.inner(*rebuilt, **kwargs)


def wrap(
    obj: nn.Module | Callable[..., Any],
    *,
    plan: DevicePlan | None = None,
    autotune: bool = True,
    config: AutotuneConfig | None = None,
) -> AdaptiveModule | "AdaptiveCallable":
    if isinstance(obj, nn.Module):
        return AdaptiveModule(obj, plan=plan, autotune=autotune, config=config)
    return AdaptiveCallable(obj, plan=plan, autotune=autotune, config=config)


class AdaptiveCallable:
    def __init__(
        self,
        fn: Callable[..., Any],
        plan: DevicePlan | None = None,
        autotune: bool = True,
        config: AutotuneConfig | None = None,
    ) -> None:
        self.fn = fn
        self.plan = plan or detect_device()
        self.autotune = autotune
        self.config = config or AutotuneConfig()
        self.tactic = Tactic("fp32", False, False)
        self.last_result: TuneResult | None = None
        self._tuned = False

    def calibrate(self, *example_inputs: torch.Tensor) -> TuneResult:
        opt = SelfOptimizer(self.plan, self.config)
        result = opt.benchmark_callable(
            factory=None,
            fn=self.fn,
            inputs=example_inputs,
            name=getattr(self.fn, "__name__", "callable"),
        )
        self.tactic = result.best
        self.last_result = result
        self._tuned = True
        return result

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        if self.autotune and not self._tuned and args and torch.is_tensor(args[0]):
            self.calibrate(*[a for a in args if torch.is_tensor(a)])
        moved = []
        dt = autocast_dtype(self.plan.device.type, self.tactic.precision)
        for a in args:
            if torch.is_tensor(a):
                y = a.to(self.plan.device)
                if dt is not None and y.is_floating_point() and self.plan.device.type != "cpu":
                    y = y.to(dt)
                moved.append(y)
            else:
                moved.append(a)
        return self.fn(*moved, **kwargs)


def _ctor_args(_module: nn.Module) -> tuple[Any, ...]:
    return ()
