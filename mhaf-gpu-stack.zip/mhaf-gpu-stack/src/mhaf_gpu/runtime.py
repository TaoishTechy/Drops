"""Process-wide runtime that can be attached to an existing training loop."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Iterator

import torch
import torch.nn as nn

from .adapters import AdaptiveModule, wrap
from .device import DevicePlan, detect_device
from .engine import EngineConfig, MHAFEngine
from .metrics import EvidenceLedger
from .tuner import AutotuneConfig, SelfOptimizer


class AdaptiveRuntime:
    """Singleton-style façade for drop-in use:

        rt = AdaptiveRuntime.attach()
        model = rt.wrap(model)
        x = rt.to_device(x)
    """

    _instance: "AdaptiveRuntime | None" = None

    def __init__(self, plan: DevicePlan | None = None, config: AutotuneConfig | None = None) -> None:
        self.plan = plan or detect_device()
        self.config = config or AutotuneConfig()
        self.ledger = EvidenceLedger()
        self.engine = MHAFEngine(EngineConfig(), plan=self.plan)
        self.optimizer = SelfOptimizer(self.plan, self.config)

    @classmethod
    def attach(cls, **kwargs: Any) -> "AdaptiveRuntime":
        if cls._instance is None:
            cls._instance = cls(**kwargs)
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        cls._instance = None

    def wrap(self, obj: nn.Module | Any, autotune: bool = True) -> Any:
        return wrap(obj, plan=self.plan, autotune=autotune, config=self.config)

    def to_device(self, x: torch.Tensor) -> torch.Tensor:
        return x.to(self.plan.device)

    def prepare_module(self, module: nn.Module) -> nn.Module:
        return module.to(self.plan.device)

    def report(self) -> dict[str, Any]:
        return {
            "device": {
                "backend": self.plan.backend,
                "name": self.plan.name,
                "index": self.plan.device_index,
                "compile": self.plan.supports_compile,
                "notes": list(self.plan.notes),
            },
            "optimizer_ledger": self.optimizer.ledger.summary(),
            "engine": self.engine.efficiency_report(),
        }

    @contextmanager
    def session(self, module: nn.Module) -> Iterator[AdaptiveModule]:
        wrapped = self.wrap(module)
        try:
            yield wrapped
        finally:
            if wrapped.last_result is not None:
                self.ledger.trials.extend(wrapped.last_result.ledger.trials)
