"""Measurable proxies, Sophia efficiency score, and the evidence ledger.

Science-grade here means: every reported number has units, a baseline,
a null hypothesis, and a recorded trial. The names follow MHAF v2.0
section 7.2 / section 10 so experimental logs can be compared with the
paper's bookkeeping, not because the ontological claims are assumed true.
"""

from __future__ import annotations

import json
import math
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable


@dataclass
class SophiaWeights:
    coherence: float = 0.25
    compression: float = 0.20
    prediction: float = 0.25
    reproducibility: float = 0.20
    ambiguity: float = 0.10


@dataclass
class SophiaScore:
    """s = w1 coherence + w2 compression + w3 prediction + w4 reproducibility - w5 ambiguity."""

    value: float
    coherence: float
    compression: float
    prediction: float
    reproducibility: float
    ambiguity: float
    components: dict[str, float] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "sophia": self.value,
            "coherence": self.coherence,
            "compression": self.compression,
            "prediction": self.prediction,
            "reproducibility": self.reproducibility,
            "ambiguity": self.ambiguity,
            **self.components,
        }


def clamp01(x: float) -> float:
    if math.isnan(x) or math.isinf(x):
        return 0.0
    return max(0.0, min(1.0, x))


def compute_sophia(
    *,
    throughput_ratio: float,
    memory_ratio: float,
    quality_ratio: float,
    cv: float,
    weights: SophiaWeights | None = None,
    sophia_max: float = 0.65,
) -> SophiaScore:
    """Map systems metrics onto the paper's Sophia weighting.

    throughput_ratio: tuned_samples_per_s / baseline_samples_per_s
    memory_ratio:     baseline_peak_bytes / tuned_peak_bytes  (>=1 is better)
    quality_ratio:    baseline_error / tuned_error            (>=1 is better)
    cv:               coefficient of variation across repeats
    """
    w = weights or SophiaWeights()
    coherence = clamp01(math.tanh(max(throughput_ratio, 0.0) / 2.0))
    compression = clamp01(math.tanh(max(memory_ratio, 0.0) / 2.0))
    prediction = clamp01(math.tanh(max(quality_ratio, 0.0) / 2.0))
    reproducibility = clamp01(math.exp(-4.0 * max(cv, 0.0)))
    ambiguity = clamp01(min(1.0, max(cv, 0.0)))
    raw = (
        w.coherence * coherence
        + w.compression * compression
        + w.prediction * prediction
        + w.reproducibility * reproducibility
        - w.ambiguity * ambiguity
    )
    value = clamp01(raw)
    return SophiaScore(
        value=value,
        coherence=coherence,
        compression=compression,
        prediction=prediction,
        reproducibility=reproducibility,
        ambiguity=ambiguity,
        components={
            "throughput_ratio": throughput_ratio,
            "memory_ratio": memory_ratio,
            "quality_ratio": quality_ratio,
            "cv": cv,
            "sophia_max_ref": sophia_max,
            "above_phase_threshold": value >= sophia_max,
        },
    )


@dataclass
class TrialRecord:
    name: str
    tactic: str
    elapsed_s: float
    samples_per_s: float
    peak_bytes: int
    error: float
    extra: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)

    def as_dict(self) -> dict[str, Any]:
        d = asdict(self)
        return d


class EvidenceLedger:
    """Append-only trial log with explicit null baselines and gates."""

    def __init__(self) -> None:
        self.trials: list[TrialRecord] = []
        self.nulls: dict[str, TrialRecord] = {}
        self.gates: list[dict[str, Any]] = []

    def record(self, trial: TrialRecord, *, as_null: bool = False) -> TrialRecord:
        self.trials.append(trial)
        if as_null:
            self.nulls[trial.name] = trial
        return trial

    def latest(self, name: str | None = None) -> TrialRecord | None:
        if not self.trials:
            return None
        if name is None:
            return self.trials[-1]
        for t in reversed(self.trials):
            if t.name == name:
                return t
        return None

    def evaluate_gate(
        self,
        gate_id: str,
        *,
        hypothesis: str,
        passed: bool,
        observed: float,
        threshold: float,
        comparator: str,
    ) -> dict[str, Any]:
        entry = {
            "gate_id": gate_id,
            "hypothesis": hypothesis,
            "passed": passed,
            "observed": observed,
            "threshold": threshold,
            "comparator": comparator,
            "timestamp": time.time(),
        }
        self.gates.append(entry)
        return entry

    def speedup_vs_null(self, name: str = "eager") -> float | None:
        null = self.nulls.get(name)
        last = self.latest()
        if null is None or last is None or null.samples_per_s <= 0:
            return None
        return last.samples_per_s / null.samples_per_s

    def dump(self, path: str | Path) -> Path:
        path = Path(path)
        payload = {
            "trials": [t.as_dict() for t in self.trials],
            "nulls": {k: v.as_dict() for k, v in self.nulls.items()},
            "gates": self.gates,
        }
        path.write_text(json.dumps(payload, indent=2))
        return path

    def summary(self) -> dict[str, Any]:
        return {
            "n_trials": len(self.trials),
            "n_nulls": len(self.nulls),
            "n_gates": len(self.gates),
            "gates_passed": sum(1 for g in self.gates if g["passed"]),
            "speedup_vs_eager": self.speedup_vs_null("eager"),
        }


def coefficient_of_variation(xs: Iterable[float]) -> float:
    vals = list(xs)
    if len(vals) < 2:
        return 0.0
    mean = sum(vals) / len(vals)
    if mean == 0:
        return 0.0
    var = sum((x - mean) ** 2 for x in vals) / (len(vals) - 1)
    return math.sqrt(var) / abs(mean)
