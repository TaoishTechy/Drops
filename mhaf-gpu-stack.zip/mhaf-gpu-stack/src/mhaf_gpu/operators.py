"""Seven operators mapped onto concrete GPU/CPU systems primitives.

MHAF v2.0 defines O_T = {S, T, G, C, P, A, K}. In this stack those
symbols are *interfaces* over real runtime actions. Ablating an operator
(see Minimal Basis Conjecture) is implemented as disabling the
corresponding pass and measuring generative / throughput loss.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

import torch
import torch.nn as nn


@dataclass
class OperatorReport:
    name: str
    enabled: bool
    detail: dict[str, Any]


class OperatorSet:
    def __init__(self, enabled: frozenset[str] | None = None) -> None:
        all_ops = frozenset({"S", "T", "G", "C", "P", "A", "K"})
        self.enabled = all_ops if enabled is None else frozenset(enabled) & all_ops

    def has(self, op: str) -> bool:
        return op in self.enabled

    def ablate(self, op: str) -> "OperatorSet":
        return OperatorSet(self.enabled - {op})


def op_S_self_reference(module: nn.Module) -> OperatorReport:
    """Capture the module's own parameter/graph fingerprint."""
    n_params = sum(p.numel() for p in module.parameters())
    n_buffers = sum(b.numel() for b in module.buffers())
    return OperatorReport("S", True, {"n_params": int(n_params), "n_buffers": int(n_buffers)})


def op_T_entropy(tensors: list[torch.Tensor]) -> OperatorReport:
    """Information/entropy proxy: dtype bits and activation energy cost analog."""
    bits = 0
    for t in tensors:
        bits += t.numel() * t.element_size() * 8
    return OperatorReport("T", True, {"activation_bits": int(bits)})


def op_G_geometry(x: torch.Tensor) -> OperatorReport:
    """Layout / tiling geometry of the leading tensor."""
    return OperatorReport(
        "G",
        True,
        {
            "shape": list(x.shape),
            "stride": list(x.stride()),
            "contiguous": bool(x.is_contiguous()),
            "dtype": str(x.dtype),
        },
    )


def op_C_compile(module: nn.Module, enabled: bool) -> tuple[nn.Module, OperatorReport]:
    """Computational closure: torch.compile when available and requested."""
    if not enabled or not hasattr(torch, "compile"):
        return module, OperatorReport("C", False, {"reason": "disabled_or_unavailable"})
    try:
        compiled = torch.compile(module, mode="reduce-overhead", fullgraph=False)
        return compiled, OperatorReport("C", True, {"mode": "reduce-overhead"})
    except Exception as exc:  # pragma: no cover - backend dependent
        return module, OperatorReport("C", False, {"reason": str(exc)})


def op_P_select(candidates: dict[str, float]) -> tuple[str, OperatorReport]:
    """Participatory collapse: argmax over measured tactics."""
    if not candidates:
        return "eager", OperatorReport("P", False, {"reason": "empty"})
    best = max(candidates.items(), key=lambda kv: kv[1])[0]
    return best, OperatorReport("P", True, {"scores": candidates, "selected": best})


def op_A_feedback(previous: float | None, current: float) -> OperatorReport:
    """Autopoietic feedback: sign of improvement used by the tuner."""
    delta = 0.0 if previous is None else current - previous
    return OperatorReport("A", True, {"delta_throughput": delta, "improved": delta > 0})


def op_K_causal(fn: Callable[..., Any], *args: Any, **kwargs: Any) -> tuple[Any, OperatorReport]:
    """Causal ordering: synchronize device streams before/after the call."""
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    out = fn(*args, **kwargs)
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    return out, OperatorReport("K", True, {"synchronized": torch.cuda.is_available()})
