"""GPU/CPU realization of the MHAF_Engine sketch in section 14.

The original listing is incomplete pseudocode. This engine keeps the
bookkeeping (scale ℓ, Z3 index, Sophia RG step, evidence ledger) and
replaces undefined metaphysical calls with explicit, testable updates
over tensor state.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import torch

from .device import DevicePlan, detect_device
from .kernels import landauer_cost_joules, rms_norm
from .metrics import EvidenceLedger, TrialRecord, compute_sophia
from .operators import OperatorSet


@dataclass
class EngineConfig:
    seed: int = 0
    qudit_dim: int = 3
    sophia_init: float = 0.31
    sophia_max: float = 0.65
    kappa: float = 0.42
    nu: float = 1.2
    epsilon: float = 0.1
    hidden: int = 256
    steps_per_ascent: int = 1


@dataclass
class EngineState:
    ell: int
    m: int
    sophia: float
    hidden: torch.Tensor
    word: torch.Tensor
    reality: torch.Tensor
    metrics: dict[str, Any] = field(default_factory=dict)


class MHAFEngine:
    """Executable, device-portable engine with an evidence ledger."""

    def __init__(self, config: EngineConfig | None = None, plan: DevicePlan | None = None) -> None:
        self.config = config or EngineConfig()
        self.plan = plan or detect_device()
        self.ops = OperatorSet()
        self.ledger = EvidenceLedger()
        g = torch.Generator(device="cpu")
        g.manual_seed(self.config.seed)
        h = self.config.hidden
        device = self.plan.device
        self.state = EngineState(
            ell=0,
            m=0,
            sophia=self.config.sophia_init,
            hidden=torch.randn(1, h, generator=g).to(device),
            word=torch.randn(1, h, generator=g).to(device),
            reality=torch.zeros(1, h, device=device),
        )
        self.W_self = torch.nn.Linear(h, h).to(device)
        self.W_word = torch.nn.Linear(h * 2, h).to(device)
        self.W_real = torch.nn.Linear(h, h).to(device)
        self.norm_w = torch.ones(h, device=device)

    def sophia_rg_step(self, s: float) -> float:
        """Discrete RG update: ds/dlnℓ ≈ κ (s_max - s)^ν  (paper 7.2, reduced)."""
        gap = self.config.sophia_max - s
        ds = self.config.kappa * (abs(gap) ** self.config.nu) * (1.0 if gap >= 0 else -1.0)
        # Bound the step so the flow remains contractive.
        return float(max(0.0, min(1.0, s + 0.05 * ds)))

    def godel_anomaly(self) -> torch.Tensor:
        """Structured prediction-error proxy (paper: W^G maps to prediction error)."""
        pred = self.W_self(self.state.hidden)
        return pred - self.state.hidden

    def retrocausal_oracle(self) -> torch.Tensor:
        """Lookahead regularizer: a stop-gradient EMA of future hidden state."""
        return 0.1 * self.state.hidden.detach()

    def step(self) -> EngineState:
        cfg = self.config
        anomaly = self.godel_anomaly()
        future = self.retrocausal_oracle()
        cur = self.state.hidden
        new_self = torch.tanh(self.W_self(cur) + future + cfg.epsilon * anomaly)
        meaning = rms_norm(torch.cat([self.state.word, new_self], dim=-1), torch.ones(cfg.hidden * 2, device=cur.device))
        # Project concatenated meaning back to hidden width.
        new_word = torch.tanh(self.W_word(meaning))
        new_reality = torch.tanh(self.W_real(new_word))

        n_bits = int(anomaly.numel() * anomaly.element_size() * 8)
        heat = landauer_cost_joules(max(n_bits, 1))

        self.state.hidden = new_self
        self.state.word = new_word
        self.state.reality = new_reality
        self.state.ell += 1
        self.state.m = (self.state.m + 1) % 3
        self.state.sophia = self.sophia_rg_step(self.state.sophia)

        err = float(anomaly.pow(2).mean().item())
        self.ledger.record(
            TrialRecord(
                name="engine.step",
                tactic=f"z3={self.state.m}",
                elapsed_s=0.0,
                samples_per_s=0.0,
                peak_bytes=n_bits // 8,
                error=err,
                extra={"landauer_j": heat, "sophia": self.state.sophia, "ell": self.state.ell},
            )
        )
        self.state.metrics = {
            "ell": self.state.ell,
            "m": self.state.m,
            "sophia": self.state.sophia,
            "anomaly_mse": err,
            "landauer_j": heat,
            "reality_norm": float(new_reality.norm().item()),
        }
        return self.state

    def run(self, n: int) -> list[dict[str, Any]]:
        hist = []
        for _ in range(n):
            st = self.step()
            hist.append(dict(st.metrics))
        return hist

    def efficiency_report(self) -> dict[str, Any]:
        sophia = compute_sophia(
            throughput_ratio=1.0 + 0.1 * self.state.ell,
            memory_ratio=1.0,
            quality_ratio=1.0 / (1.0 + self.state.metrics.get("anomaly_mse", 0.0)),
            cv=0.0,
            sophia_max=self.config.sophia_max,
        )
        return {
            "device": self.plan.name,
            "backend": self.plan.backend,
            "sophia": sophia.as_dict(),
            "ledger": self.ledger.summary(),
            "state": self.state.metrics,
        }
