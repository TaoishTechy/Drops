# MHAF-GPU — drop-in self-optimizing compute stack

A portable runtime that attaches to an existing PyTorch module or callable,
selects a device, autotunes precision and compilation tactics, and writes an
append-only **evidence ledger** with explicit null baselines and pass/fail
gates.

This repository implements the *systems* layer that the MHAF v2.0 note asks
for (typed operators, measurable proxies, null hypotheses, a ledger). It does
**not** treat the note’s consciousness ontology, microtubule claims, or
99.99999 % efficiency target as established science. Those claims remain
unvalidated. What is implemented here is testable performance engineering.

## What “seamless” means

```python
from mhaf_gpu import wrap
import torch.nn as nn

model = wrap(existing_nn_module)   # same forward(...) signature
y = model(x)                       # first call calibrates, later calls reuse the winner
```

No change to optimizer, dataloader, or loss. Tensors are moved to the selected
device; mixed precision is applied only when the device supports it.

Process-wide attachment:

```python
from mhaf_gpu import AdaptiveRuntime
rt = AdaptiveRuntime.attach()
model = rt.wrap(model)
x = rt.to_device(x)
```

## Operator mapping (engineering, not ontology)

| Symbol | MHAF name | Implementation in this stack |
|--------|-----------|------------------------------|
| S | Self-reference | Graph / parameter fingerprint of the hosted module |
| T | Information–entropy | Activation bit-volume and Landauer diagnostic |
| G | Geometry | Shape, stride, channels-last layout |
| C | Computational closure | `torch.compile` when the backend supports it |
| P | Participatory collapse | Argmax over measured tactic scores |
| A | Autopoietic feedback | Closed-loop use of the previous trial’s throughput |
| K | Causal ordering | Device synchronize around timed regions |

Ablating an operator (`OperatorSet.ablate("C")`) disables that pass so the
Minimal Basis Conjecture can be tested as a *systems* experiment: does
removing compilation, selection, or feedback reduce generative capacity
(throughput × numeric fidelity)?

## Sophia score

The paper’s weighting is used as an efficiency scalar, not as a claim about
cognition:

`s = w1·coherence + w2·compression + w3·prediction + w4·reproducibility − w5·ambiguity`

where coherence is a squash of the throughput ratio versus the eager null,
compression is a squash of the inverse peak-memory ratio, prediction is a
squash of inverse error versus a reference output, and ambiguity is the
coefficient of variation across repeats. The 0.65 threshold is recorded as a
reference line, not as a discovered constant of nature.

## Falsification gates (systems)

- **G-throughput**: tuned tactic must not fall more than 5 % below the eager
  null (`speedup ≥ 0.95`).
- **G-numeric**: mean-square deviation from the reference remains finite.

Additional gates from the note (BPMI quadratic law, 130 Hz / 9 Hz coupling,
colchicine / microtubule correlation) are *not* implemented, because they
require EEG / pharmacology protocols that this runtime does not perform.

## Layout

```
src/mhaf_gpu/
  device.py      hardware plan (CUDA / ROCm / MPS / CPU)
  adapters.py    wrap() for modules and callables
  tuner.py       closed-loop tactic search
  engine.py      executable MHAFEngine with Sophia RG step
  metrics.py     Sophia score + EvidenceLedger
  operators.py   S,T,G,C,P,A,K as runtime passes
  kernels.py     portable fused ops (SDP, RMSNorm, GELU-linear)
  runtime.py     AdaptiveRuntime façade
  cli.py         mhaf-gpu-bench
```

## Install and run

```bash
pip install -e .
python examples/drop_in.py
python -m mhaf_gpu.cli --batch 64 --dim 256
python -m pytest tests/test_stack.py -q
```

CUDA is used when `torch.cuda.is_available()` is true. Otherwise the identical
API runs on CPU. Compilation tactics that fail on a given backend are skipped;
the eager null always remains in the ledger.

## Honest limits

- There is no holographic bulk, no Gödel tensor on the GPU, and no Orch-OR
  hardware path. Those objects are not defined at the level of CUDA.
- `torch.compile` speedups depend on the vendor compiler and appear after
  warmup. The first calibration call is therefore slower than subsequent calls.
- Landauer’s principle is reported as a thermodynamic *lower bound* on
  irreversible bit erasure, not as measured GPU wall-plug energy.
- Multi-node collectives (NCCL / RCCL) are out of scope of v1.0; attach this
  runtime *inside* each rank of an existing DDP/FSDP job.

## Version

`mhaf-gpu 1.0.0` — Apache-2.0.
