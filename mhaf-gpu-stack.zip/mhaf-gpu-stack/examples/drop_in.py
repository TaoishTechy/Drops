"""Drop an existing PyTorch module into the stack without changing its API."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import torch
import torch.nn as nn

from mhaf_gpu import AdaptiveRuntime, wrap


class ExistingNet(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.features = nn.Sequential(
            nn.Linear(128, 256),
            nn.ReLU(),
            nn.Linear(256, 10),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.features(x)


def main() -> None:
    rt = AdaptiveRuntime.attach()
    model = wrap(ExistingNet(), autotune=True)
    x = torch.randn(32, 128)
    y = model(x)
    print("output", tuple(y.shape), y.dtype)
    print("tactic", model.tactic.name)
    if model.last_result:
        print("sophia", model.last_result.sophia.value)
        print("ledger", model.last_result.ledger.summary())
    print("runtime", rt.report()["device"])


if __name__ == "__main__":
    main()
