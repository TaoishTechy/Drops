# Integration notes

## Existing training loop

```python
from mhaf_gpu import AdaptiveRuntime

rt = AdaptiveRuntime.attach()
model = rt.prepare_module(model)
model = rt.wrap(model, autotune=True)

for xb, yb in loader:
    xb, yb = rt.to_device(xb), rt.to_device(yb)
    pred = model(xb)
    loss = criterion(pred, yb)
    loss.backward()
    opt.step(); opt.zero_grad()
```

Calibration runs on the first forward. To calibrate on a representative batch
before the epoch:

```python
model.calibrate(next(iter(loader))[0])
```

## Existing inference service

Wrap the module once at process start. Persist `model.tactic.name` and
`model.last_result.ledger.dump("ledger.json")` next to the checkpoint.

## Ablation study

```python
from mhaf_gpu.operators import OperatorSet
from mhaf_gpu.tuner import SelfOptimizer

opt = SelfOptimizer(plan, operators=OperatorSet().ablate("C"))
```

Compare ledgers with and without `C` (compile), `P` (selection), and `A`
(feedback). Loss of throughput under ablation is the systems-level test of
the paper’s minimal-basis claim.
