from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import torch
import torch.nn as nn

from mhaf_gpu import MHAFEngine, wrap, detect_device
from mhaf_gpu.metrics import compute_sophia
from mhaf_gpu.operators import OperatorSet
from mhaf_gpu.tuner import AutotuneConfig, SelfOptimizer


class Tiny(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.l = nn.Linear(16, 16)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.relu(self.l(x))


def test_device_plan_never_raises() -> None:
    plan = detect_device()
    assert plan.backend in {"cuda", "rocm", "mps", "cpu"}
    t = torch.zeros(2, 2, **plan.tensor_kwargs())
    assert t.device.type == plan.device.type


def test_sophia_bounds() -> None:
    s = compute_sophia(throughput_ratio=2.0, memory_ratio=1.5, quality_ratio=1.0, cv=0.01)
    assert 0.0 <= s.value <= 1.0
    assert s.components["above_phase_threshold"] in {True, False}


def test_engine_steps_are_deterministic() -> None:
    a = MHAFEngine()
    b = MHAFEngine()
    ha = a.run(5)
    hb = b.run(5)
    assert ha[-1]["ell"] == 5
    assert abs(ha[-1]["sophia"] - hb[-1]["sophia"]) < 1e-6


def test_wrap_forward() -> None:
    m = wrap(Tiny(), autotune=False)
    y = m(torch.randn(4, 16))
    assert y.shape == (4, 16)


def test_optimizer_records_null() -> None:
    plan = detect_device()
    model = Tiny().to(plan.device)
    x = torch.randn(8, 16, device=plan.device)
    opt = SelfOptimizer(plan, AutotuneConfig(repeats=2, warmup=0, max_trials=3, use_compile=(False,)))
    res = opt.benchmark_callable(factory=None, fn=model, inputs=(x,), name="tiny")
    assert res.best is not None
    assert res.ledger.summary()["n_trials"] >= 1
    assert any(g["gate_id"] == "G-throughput" for g in res.ledger.gates)


def test_operator_ablation() -> None:
    ops = OperatorSet()
    cut = ops.ablate("C")
    assert "C" not in cut.enabled
    assert "S" in cut.enabled
